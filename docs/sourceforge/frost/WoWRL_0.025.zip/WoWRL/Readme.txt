
	/* ###################################### */
	/* ###   WoW Raid Leader, by Kalith   ### */
	/* ###################################### */
	/*                                        */
	/* Powered by :                           */
	/* Haaf's Game Engine 1.6                 */
	/* Copyright (C) 2003-2006, Relish Games  */
	/* hge.relishgames.com                    */
	/*                                        */
	/*                  README                */
	/*                                        */
	/******************************************/

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of
    the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program; if not, write to the Free
    Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
    Boston, MA 02110-1301 USA.


## What is done so far :

- Mouse and keyboard input.
- Zoom function removed because of its lack of interest and the
  complexity it adds to the code.
- Pan function removed too, not needed atm : the background is
  locked.
- Click the player and it will display a glowing circle around
  its feet indicating you have
  successfuly selected it.
- Right click the BG to make the player go where you clicked if
  it is selected.
- Drag the left button to make a selection square !
- Implemented a collision detection system with pathfinding.
- Animation added.
- Almost everything is dynamic now : look at inis.
- Added special effect to the mage incantation.
- Added a new map (ZulGurub) to test shadows and distortions.
- Now handle particle systems as projectiles !
- Added status bars. Only displaying health.


## To Do :

- allow zoning
- manage mana
- find a proper way to display those infos
- allow hostile units to aggro
- manage attack range


## Settings :

See config.ini to edit them.
Resolution suported :
 - 1024 / 768 and higher


## Controls :

  [Mouse, left click]
     - > Select a unit (or deselect)

  [Mouse, drag left click]
     - > Selection square

  [Mouse, right click]
     - > If a unit is selected, order it to go where you clicked
         or attack a hostile unit.

  [Escape]
     - > Exit the game.


## Good to know :

 - Almost all the graphics of the game are extracted from World
of Warcraft and are the property of Blizzard. Please do not use
them unless you own the game.
 - For those interested, backgrounds are extracted with WoW
mapview and sprites are extracted with WoW modelview. See
http://www.wowmodelviewer.org/ for more infos.
 - HGE is a powerfull and flexible 2D game engine. It used to be
a shareware, but it is now released as a freeware. So great
thanks to Haaf and his team !
 - This program is released under the GPL license. See gnu.txt
for more details.
/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Movement source             */
/*                                        */
/*  ## : Contains all the functions that  */
/*  manage a unit's movement.             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge.h"
#include "hgevector.h"

#include "wowrl_point.h"
#include "wowrl_structs.h"
#include "wowrl_global.h"
#include "wowrl_unit.h"
#include "wowrl_collision.h"
#include "wowrl_distortion.h"
#include "wowrl_zone.h"

extern HGE *hge;
extern Zone zone;
extern float dt;

// Make a unit walk to a point
bool goTo( Unit* unit, Point destPoint )
{
	hgeVector orderVec;
	float speed = unit->getSpeed()*unit->getScale();
	orderVec.x = destPoint.x-unit->getX();
	orderVec.y = destPoint.y-unit->getY();

	float coefx, coefy;
	coefx = pow(speed*speed/2, 0.5)*cos(orderVec.Angle());
	coefy = pow(speed*speed/2, 0.5)*sin(orderVec.Angle());

	/*if (CheckPointCollision(toInt(unit->getX()+coefx*dt), toInt(unit->getY()+coefy*dt)))
	{
		hge->System_Log("pouet");
		return false;
	}*/

	if ( !((fabs(destPoint.x-unit->getX()) < 1) && (fabs(destPoint.y-unit->getY()) < 1)) )
	{

		unit->setX(unit->getX()+coefx*dt);
		unit->setY(unit->getY()+coefy*dt);
		unit->setRotFromAngle(orderVec.Angle());
		return true;
	}
	else
	{
        // Unit is arrived at detination
		return false;
	}
}

// Make a unit follow a path
bool followPath( Unit* unit, std::vector<Point> path )
{
    if (path.size()==1)
    {
        bool moving = goTo(unit, (*path.begin()));
        if (moving)
        {
            unit->setAnimState("walk");
        }
        else
        {
            unit->setAnimState("stand");
        }
        return moving;
    }
    else
    {
    	static int pointIndice;
    	static bool initialised;

    	if (!unit->following)
    	{
            unit->pointIndice = 0;
            unit->setAnimState("walk");
            unit->following = true;
        }

        std::vector<Point>::iterator iter = unit->path.begin();
        for (int i=0; i != unit->pointIndice; i++)
        {
        	iter++;
		}

		if (unit->pointIndice==path.size())
    	{
            // Unit has followed the whole path
            unit->following = false;
            unit->setAnimState("stand");
    		return false;
        }
        else
        {
			if (!goTo(unit, *iter))
			{
				unit->pointIndice++;
			}
			return true;
        }
    }
}

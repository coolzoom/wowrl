/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Doodad source             */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Doodad class.                  */
/*       A Doodad is a part of the back-  */
/*  ground that can be rendered above     */
/*  units, but it can also be rendered    */
/*  beneath units, depending on depth.    */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hgevector.h"
#include "wowrl_doodad.h"
#include "wowrl_global.h"
#include "wowrl_distortion.h"
#include "wowrl_scenemanager.h"

extern HGE *hge;
extern SceneManager mySceneManager;

Doodad::Doodad() : z(-1.0f), locked(true)
{
}

Doodad::~Doodad()
{
}

void Doodad::setX(float x)
{
	m_x = x;
}

void Doodad::setY(float y)
{
	m_y = y;
}

float Doodad::getX()
{
	return m_x+mySceneManager.gx;
}

float Doodad::getY()
{
	return m_y+mySceneManager.gy;
}

float Doodad::getZ()
{
	// Check Z value only the first time or if the doodad is not locked
	if ( (z==-1.0f) || (!locked) )
	{
		z = getPointDepth(toInt(m_x), toInt(m_y));
	}
    return z;
}

hgeRect* Doodad::getBox()
{
    hgeRect* box = new hgeRect();
	this->sprite->GetBoundingBox(this->getX(), this->getY(), box);
    return box;
}

float Doodad::getRelativeDepth(Point p)
{
	float relz;
	hgeVector pvec;
	pvec.x = p.x-this->getX();
	pvec.y = p.y-this->getY();
	hgeVector ovec;
	ovec.x = cos(degToRad(orientation));
	ovec.y = -sin(degToRad(orientation));

	relz = pvec.Length();
	float angle = ovec.Angle()-pvec.Angle();
	angle = radToDeg(angle);
	if (angle < -180.0f)
	{
		angle = 360.0f+angle;
	}

	/* Now, angle is a float value that is ranging between -180 and 180.
	    # angle = 0 or -180 : the point is at the same depth as the doodad.
			-> 0, the unit is rendered behind (first), -180 it is rendered above (last)
	    # angle < 0 : the point is nearer than the doodad.
	    	-> the unit is rendered above (last)
		# angle > 0 : the point is more far than the doodad.
			-> the unit is rendered behind (first)
	*/

	if (angle >= 0.0f)
	{
		return -relz;
	}
	else if (angle < 0.0f)
	{
		return relz;
	}
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Projectile source           */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Projectile class.              */
/*       A Projecille is used whenever a  */
/*  spell is casted, a bullet is fired,   */
/*  an arrow is thrown, ... it can follow */
/*  its target and it has a particle      */
/*  system linked to it.                  */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge.h"
#include "hgerect.h"

#include "wowrl_projectile.h"
#include "wowrl_scenemanager.h"
#include "wowrl_distortion.h"

extern HGE *hge;
extern float dt;
extern SceneManager mySceneManager;
extern hgeParticleManager myParticleManager;
extern hgeParticleSystem *psys;

Projectile::Projectile() : x(0.0f), y(0.0f), m_destination(NULL), m_psys(NULL)
{
}

Projectile::Projectile( std::string psysname,
						Unit* destination,
						Unit* origin ) :
							m_psysname(psysname),
							m_destination(destination),
							m_origin(origin),
							arrived(false)
{
	x = origin->getX()+mySceneManager.particleFXList[m_psysname].offset_x;
	y = origin->getY()+mySceneManager.particleFXList[m_psysname].offset_y;
	m_spell = origin->getSpell();
}

Projectile::~Projectile()
{
    x = 0.0f; y = 0.0f;
    m_destination = NULL;
    m_psys = NULL;
}

hgeParticleSystem* Projectile::getPSys()
{
	if (m_psysname != m_old_psysname)
	{
		m_psys = new hgeParticleSystem(*mySceneManager.particleFXList[m_psysname].psys);
		m_old_psysname = m_psysname;
	}
	return m_psys;
}

float Projectile::getZ()
{
	float z = getPointDepth(toInt(x), toInt(y));
    return z;
}

Unit* Projectile::getParent()
{
	return m_origin;
}

Unit* Projectile::getDestination()
{
	return m_destination;
}

Spell* Projectile::getSpell()
{
	return m_spell;
}

void Projectile::setDestination(Unit* destination)
{
	if (destination != NULL)
		{m_destination = destination;}
}

bool Projectile::updatePos()
{
	hgeVector destVec;
	float speed = 600.0f;
	hgeRect *destBox = m_destination->getBox();
	float destx = destBox->x1 + (destBox->x2-destBox->x1)/2;
	float desty = destBox->y1 + (destBox->y2-destBox->y1)/2;
	destVec.x = destx-x;
	destVec.y = desty-y;

	float coefx, coefy;
	coefx = pow(speed*speed/2, 0.5)*cos(destVec.Angle());
	coefy = pow(speed*speed/2, 0.5)*sin(destVec.Angle());

	hgeRect* particleRect = new hgeRect(x-5,y-5,x+5,y+5);
	bool collides = particleRect->Intersect(m_destination->getBox());

	if (!collides)
	{
		x += coefx*dt;
		y += coefy*dt;
		arrived = false;
		return true;
	}
	else
	{
		arrived = true;
		m_destination->hit(m_spell);
		return false;
	}
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Unit source               */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Unit class.                    */
/*       A Unit is a character. For now,  */
/*  its attributes are graphical ones,    */
/*  but they are soon to be completed by  */
/*  gameplay ones, such as 'life'.        */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "hgevector.h"

#include "wowrl_unit.h"
#include "wowrl_distortion.h"
#include "wowrl_scenemanager.h"
#include "wowrl_zone.h"

extern HGE *hge;
extern SceneManager mySceneManager;
extern Zone zone;

Unit::Unit() : m_speed(150.0f),
               m_rot(0),
               m_orientation(0.0f),
               m_attack_timer(0.0f),
               alphaFXTimer(0.0f),
               m_animstate("stand"),
               m_target(NULL),
               m_hostile(false),
               m_selected(false),
               m_attacking(false),
               FXFaded(false),
               FXPlaying(false),
               following(false),
               m_dead(false),
               dying(false),
               m_finishAnim(true),
               hidden(false)
{
}

Unit::Unit( std::string name,
            float x, float y,
            float speed ) :
				m_name(name),
                m_x(x), m_y(y),
                m_speed(speed),
                // Default values
                m_rot(0),
                m_orientation(0.0f),
                m_attack_timer(0.0f),
                alphaFXTimer(0.0f),
                m_animstate("stand"),
                m_target(NULL),
                m_hostile(false),
                m_selected(false),
                m_attacking(false),
                FXFaded(false),
                FXPlaying(false),
                following(false),
                m_dead(false),
                dying(false),
                m_finishAnim(true),
                hidden(false)
{
}

Unit::Unit( std::string name ) : m_name(name),
                               m_speed(150.0f),
                               m_rot(0),
                               m_orientation(0.0f),
                               m_attack_timer(0.0f),
                               alphaFXTimer(0.0f),
                               m_animstate("stand"),
                               m_target(NULL),
                               m_hostile(false),
                               m_selected(false),
                               m_attacking(false),
                               FXFaded(false),
                               FXPlaying(false),
                               following(false),
                               m_dead(false),
                               dying(false),
                               m_finishAnim(true),
                               hidden(false)
{
}

Unit::~Unit()
{
}

/********* Graphic funcs **********/

float Unit::getX()
{
    return m_x+mySceneManager.gx;
}

float Unit::getY()
{
    return m_y+mySceneManager.gy;
}

Point Unit::getPoint()
{
	Point p;
	p.x = this->getX();
	p.y = this->getY();
	return p;
}

int Unit::getRot()
{
    return m_rot;
}

float Unit::getSpeed()
{
    return m_speed;
}

float Unit::getScale()
{
	float mdist = getPointDistortion(toInt(this->getX()), toInt(this->getY()));
    float scale = zone.distortion_scale_min-mdist*(zone.distortion_scale_min-zone.distortion_scale_max);
	m_scale = scale;
    return m_scale;
}

float Unit::getVScale()
{
	float mdist = getPointDistortion(toInt(this->getX()), toInt(this->getY()));
    float scale = zone.distortion_vscale_min-mdist*(zone.distortion_vscale_min-zone.distortion_vscale_max);
	m_scale = scale;
    return m_scale;
}

float Unit::getAngle()
{
	float mdist = getPointDistortion(toInt(this->getX()), toInt(this->getY()));
    float angle = zone.distortion_angle_min-mdist*(zone.distortion_angle_min-zone.distortion_angle_max);
    angle = angle*2*M_PI/360;
    return angle;
}

float Unit::getZ()
{
	float z = getPointDepth(toInt(this->getX()), toInt(this->getY()));
    return z;
}

float Unit::getRelativeDepth(Point p)
{
	float relz;
	hgeVector pvec;
	pvec.x = p.x-this->getX();
	pvec.y = p.y-this->getY();
	hgeVector ovec;
	ovec.x = cos(degToRad(m_orientation));
	ovec.y = -sin(degToRad(m_orientation));

	relz = pvec.Length();
	float angle = ovec.Angle()-pvec.Angle();
	angle = radToDeg(angle);
	if (angle < -180.0f)
	{
		angle = 360.0f+angle;
	}

	/* Now, angle is a float value that is contained in [-180;180[
	    # angle = 0 or -180 : the point is at the same depth as the doodad.
			-> 0, the unit is rendered behind (first), -180 it is rendered above (last)
	    # angle < 0 : the point is nearer than the doodad.
	    	-> the unit is rendered above (last)
		# angle > 0 : the point is more far than the doodad.
			-> the unit is rendered behind (first)
	*/

	if (angle >= 0.0f)
	{
		return -relz;
	}
	else if (angle < 0.0f)
	{
		return relz;
	}
}

float Unit::getShadow()
{
	m_shadow = getPointShadow(toInt(this->getX()), toInt(this->getY()));
    return m_shadow;
}

std::string Unit::getAnimState()
{
    return m_animstate;
}

hgeAnimation* Unit::getAnimation()
{
	if ( (m_animstate != m_old_animstate) || (m_old_rot != m_rot) )
	{
		delete m_animation;
		m_animation = new hgeAnimation(*mySceneManager.pAnimList[m_class->name].animation[m_animstate].state[m_rot]);
		m_old_animstate = m_animstate;
		m_old_rot = m_rot;
	}
	return m_animation;
}

hgeAnimation* Unit::getEffect()
{
	if ( (m_effectstate != m_old_effectstate) || (m_old_rot != m_rot) )
	{
		delete m_effect;
		m_effect = new hgeAnimation(*mySceneManager.animatedFXList[m_effectstate].state[m_rot]);
		m_old_effectstate = m_effectstate;
		m_old_rot = m_rot;
	}
	return m_effect;
}

std::string Unit::getEffectName()
{
	return m_effectstate;
}

hgeRect* Unit::getBox()
{
    m_box = new hgeRect();
	this->getAnimation()->GetBoundingBoxEx(this->getX(), this->getY(), 0.0f, m_scale, m_scale, m_box);
	m_box->Set
	(
		m_box->x1+(m_class->offx1+mySceneManager.pAnimList[m_class->name].animation[m_animstate].offx1)*m_scale,
		m_box->y1+(m_class->offy1+mySceneManager.pAnimList[m_class->name].animation[m_animstate].offy1)*m_scale,
		m_box->x2+(m_class->offx2+mySceneManager.pAnimList[m_class->name].animation[m_animstate].offx2)*m_scale,
		m_box->y2+(m_class->offy2+mySceneManager.pAnimList[m_class->name].animation[m_animstate].offy2)*m_scale
	);
    return m_box;
}

hgeRect* Unit::getStandBox()
{
    hgeRect* box = new hgeRect();
	mySceneManager.pAnimList[m_class->name].animation["stand"].state[m_rot]->GetBoundingBoxEx(this->getX(), this->getY(), 0.0f, m_scale, m_scale, box);
	box->Set
	(
		box->x1+(m_class->offx1+mySceneManager.pAnimList[m_class->name].animation["stand"].offx1)*m_scale,
		box->y1+(m_class->offy1+mySceneManager.pAnimList[m_class->name].animation["stand"].offy1)*m_scale,
		box->x2+(m_class->offx2+mySceneManager.pAnimList[m_class->name].animation["stand"].offx2)*m_scale,
		box->y2+(m_class->offy2+mySceneManager.pAnimList[m_class->name].animation["stand"].offy2)*m_scale
	);
	return box;
}

RGB Unit::getColor()
{
	if (m_shadow+m_color.R > 255)
	{
		m_color.R = 255-m_shadow;
	}
	if (m_shadow+m_color.G > 255)
	{
		m_color.G = 255-m_shadow;
	}
	if (m_shadow+m_color.B > 255)
	{
		m_color.B = 255-m_shadow;
	}
	return m_color;
}

StatusBar* Unit::getStatusBar()
{
	if (mySceneManager.statusBarList.find(m_name) == mySceneManager.statusBarList.end())
	{
		mySceneManager.createStatusBar(this);
		m_status_bar = &mySceneManager.statusBarList[m_name];
		m_status_bar->gauge = new hgeSprite(*mySceneManager.statusB_gauge);
	}

	hgeRect* box;
	box = this->getStandBox();
	m_status_bar->size = toInt(box->x2-box->x1);
	m_status_bar->background_left = new hgeSprite(*mySceneManager.statusB_dead_bg_left);
	m_status_bar->background_middle = new hgeSprite(*mySceneManager.statusB_dead_bg_middle);
	m_status_bar->background_right = new hgeSprite(*mySceneManager.statusB_dead_bg_right);
	RGB color;

	if (this->isDead())
	{
		//m_status_bar->state = zone.respawn[m_name]/zone.respawnTime;
		m_status_bar->state = 1.0f;
		color.R = 150; color.G = 150; color.B = 150;
		m_status_bar->color = color;
	}
	else
	{
		m_status_bar->state = m_health/m_max_health;
		if (m_status_bar->state >= 0.5f)
		{
			RGB color;
			color.R = (1-m_status_bar->state)*2*255; color.G = 255; color.B = 0;
			m_status_bar->color = color;
		}
		if (m_status_bar->state < 0.5f)
		{
			RGB color;
			color.R = 255; color.G = m_status_bar->state*2*255; color.B = 0;
			m_status_bar->color = color;
		}
	}
	return m_status_bar;
}

bool Unit::intersects( Object o )
{
	if (o.type == "unit")
	{
		Unit* u = static_cast<Unit*>(o.ptr);
		return this->getBox()->Intersect(u->getBox());
	}
	else if (o.type == "doodad")
	{
		Doodad* d = static_cast<Doodad*>(o.ptr);
		return this->getBox()->Intersect(d->getBox());
	}
}


void Unit::setX( float x )
{
    m_x = x-mySceneManager.gx;
}

void Unit::setY( float y )
{
    m_y = y-mySceneManager.gy;
}

void Unit::setRot( int rot )
{
    m_rot = rot;
}

void Unit::setRotFromAngle( float angle )
{
	angle = angle/(2*M_PI);

	if (angle<0)
	{
        angle = 1+angle;
    }
    angle = 360*angle;

	if ((angle>22.5) && (angle<=67.5))
		{this->setRot(5);}
	if ((angle>67.5) && (angle<=112.5))
		{this->setRot(4);}
	if ((angle>112.5) && (angle<=157.5))
		{this->setRot(3);}
	if ((angle>157.5) && (angle<=202.5))
		{this->setRot(2);}
	if ((angle>202.5) && (angle<=247.5))
		{this->setRot(1);}
	if ((angle>247.5) && (angle<=292.5))
		{this->setRot(0);}
	if ((angle>292.5) && (angle<=337.5))
		{this->setRot(7);}
    if ((angle>337.5) || (angle<=22.5))
		{this->setRot(6);}
}

void Unit::setSpeed( float speed )
{
    m_speed = speed;
}

void Unit::setScale( float scale )
{
    m_scale = scale;
}

void Unit::setAnimState( std::string animstate )
{
    m_animstate = animstate;
}

void Unit::updateAttack(float dt)
{
	if ( (m_target->isDead()) && (m_finishAnim) )
	{
		this->stopAttack();
	}
	else
	{
		if (m_animstate == "prepare_attack")
		{
			m_attack_timer += dt;
			if (m_attack_timer >= m_spell->cast_time)
			{
				this->getAnimation()->Stop();
				this->setAnimState("attack");
				this->getAnimation()->Play();
				m_attack_timer = 0.0f;
				FXFaded = false;
				m_projectile = false;

				if (m_spell->cast_fx)
				{
					this->getEffect()->Stop();

					if (mySceneManager.animatedFXList[this->getEffectName()].fade_out != 0.0f)
					{
						FXPlaying = true;
					}
					else
					{
						FXPlaying = false;
					}
				}
				if (!m_spell->attack_fx)
				{
					m_target->hit(m_spell);
				}
				if (m_target->isDead())
				{
					m_finishAnim = false;
				}
			}
		}
		else if (m_animstate == "attack")
		{
			m_attack_timer += dt;
			if ( (m_attack_timer >= mySceneManager.particleFXList[m_spell->attack_effect].delay) && !(m_projectile) && (m_spell->attack_fx) )
			{
				mySceneManager.createProjectile(m_spell->attack_effect, m_target, this);
				m_projectile = true;
			}

			if (!this->getAnimation()->IsPlaying())
			{
				this->getAnimation()->Stop();
				this->setAnimState("prepare_attack");
				this->getAnimation()->Play();
				m_attack_timer = 0.0f;
				FXFaded = false;
				m_finishAnim = true;

				if (m_spell->attack_fx)
				{
					this->getEffect()->Stop();

					if (mySceneManager.animatedFXList[this->getEffectName()].fade_out != 0.0f)
					{
						FXPlaying = true;
					}
					else
					{
						FXPlaying = false;
					}
				}
				if (m_spell->cast_fx)
				{
					this->setEffect(m_spell->cast_effect);
					this->getEffect()->Play();
					FXPlaying = true;
				}
			}
		}
	}
}

void Unit::setEffect(std::string effectstate)
{
	m_effectstate = effectstate;
}

void Unit::setColor(RGB color)
{
	m_color = color;
}

void Unit::setColor(int R, int G, int B)
{
	m_color.R = R;
	m_color.G = G;
	m_color.B = B;
};

/********** Mixed funcs ***********/

Class* Unit::getClass()
{
    return m_class;
}

void Unit::setClass( Class* new_class )
{
    m_class = new_class;
    m_spec = &m_class->spec[m_class->defaultSpec];
    m_spell = &m_class->spell[m_spec->defaultSpell];
    m_max_health = m_class->max_health;
    m_max_mana = m_class->max_mana;
    m_health = m_max_health;
}

/********* Gameplay funcs **********/

std::string Unit::getName()
{
    return m_name;
}

bool Unit::isHostile()
{
	return m_hostile;
}

bool Unit::isSelected()
{
	return m_selected;
}

bool Unit::isAttacking()
{
	return m_attacking;
}

bool Unit::isDead()
{
	return m_dead;
}

Spell* Unit::getSpell()
{
	return m_spell;
}

void Unit::setHostile( bool hostile )
{
	if (m_hostile != hostile)
	{
		m_hostile = hostile;
		if (m_hostile == true)
		{
			mySceneManager.hostileList[m_name] = this;
		}
		else
		{
			if (mySceneManager.hostileList.find(m_name) != mySceneManager.hostileList.end())
			{
				mySceneManager.hostileList.erase(m_name);
			}
			else
			{
				hge->System_Log("# WARNING # : Trying to remove \"%s\" from hostile unit list : not found.", m_name.c_str());
			}
		}
	}
}

void Unit::setSelected( bool selected )
{
	m_selected = selected;
	if (m_selected == true)
	{
		mySceneManager.selectedList[m_name] = this;
	}
	else
	{
		if (mySceneManager.selectedList.find(m_name) != mySceneManager.selectedList.end())
		{
			mySceneManager.selectedList.erase(m_name);
		}
		else
		{
			hge->System_Log("# WARNING # : Trying to remove \"%s\" from selected unit list : not found.", m_name.c_str());
			return;
		}
	}
}

void Unit::target( std::string u_name )
{
	if (m_target->getName() != u_name)
	{
		if (mySceneManager.targetList.find(m_target->getName()) != mySceneManager.targetList.end())
		{
			mySceneManager.targetList.erase(m_target->getName());
		}
		else
		{
			hge->System_Log("# WARNING # : Trying to remove \"%s\" from target list : not found.", m_target->getName().c_str());
			return;
		}

		if (u_name != "")
		{
			mySceneManager.targetList[u_name] = &mySceneManager.unitList[u_name];
			m_target = &mySceneManager.unitList[u_name];
		}
		else
		{
			m_target = NULL;
		}
	}
}

void Unit::target( Unit* u_target )
{
	if (m_target == NULL)
	{
		mySceneManager.targetList[u_target->getName()] = u_target;
		m_target = u_target;
	}
	if (m_target->getName() != u_target->getName())
	{
		if (mySceneManager.targetList.find(m_target->getName()) != mySceneManager.targetList.end())
		{
			mySceneManager.targetList.erase(m_target->getName());
		}
		else
		{
			hge->System_Log("# WARNING # : Trying to remove \"%s\" from target list : not found.", m_target->getName().c_str());
			return;
		}
		if (u_target != NULL)
		{
			mySceneManager.targetList[u_target->getName()] = u_target;
			m_target = u_target;
		}
		else
		{
			m_target = NULL;
		}
	}
}

void Unit::attack( std::string u_name )
{
	this->target(u_name);
	this->attack();
}

void Unit::attack( Unit* u_target )
{
	this->target(u_target);
	this->attack();
}

void Unit::attack()
{
	m_attacking = true;
	hgeVector target_vec;
	target_vec.x = m_target->getX()-this->getX();
	target_vec.y = m_target->getY()-this->getY();

	this->setRotFromAngle(target_vec.Angle());

	m_animstate = "prepare_attack";

	if (m_spell->cast_fx)
	{
		FXPlaying = true;
		this->setEffect(m_spell->cast_effect);
		this->getEffect()->Play();
	}

	mySceneManager.attackerList[m_name] = this;
}

void Unit::stopAttack()
{
	m_attacking = false;
	if (FXPlaying)
	{
		this->getEffect()->Stop();
		FXPlaying = false;
	}
	m_animstate = "stand";
	m_attack_timer = 0.0f;
	mySceneManager.attackerList.erase(m_name);
}

void Unit::hit(Spell* spell)
{
	if (!m_dead)
	{
		float rand_dmg = rand()%(toInt(spell->dmg_max)-toInt(spell->dmg_min));
		float damage = spell->dmg_min + rand_dmg;
		m_health -= toInt(damage);
		if (m_health <= 0)
		{
			m_health = 0;
			this->kill();
		}
	}
}

void Unit::kill()
{
	mySceneManager.deadList[m_name] = this;
	m_animstate = "death";
	this->getAnimation()->Play();
	dying = true;
	m_dead = true;
}

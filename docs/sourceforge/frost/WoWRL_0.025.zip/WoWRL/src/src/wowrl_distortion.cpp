/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Distortion source            */
/*                                        */
/*  ## : Contains all the functions that  */
/*  are related to distortion.            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge.h"
#include "hgesprite.h"
#include "hgevector.h"

#include "wowrl_point.h"
#include "wowrl_structs.h"
#include "wowrl_global.h"
#include "wowrl_zone.h"

extern HGE *hge;
extern Zone zone;
extern int sWidth, sHeight;

float getPointDistortion( int x, int y )
{
	// Distortion is read on the RED chanel
    float distortion;
    int colorIndex = (y+(zone.h/2-toInt(sHeight)/2))*zone.w + x+(zone.w/2-toInt(sWidth)/2);
    if ( (colorIndex > 0) && (colorIndex < zone.h*zone.w+zone.w) )
    {
        distortion = GETR(zone.dist[colorIndex]);
    }
    else
    {
    	// Return a buggy value
        distortion = -255.0f;
    }

    distortion = distortion/255;

    return distortion;
}

float getPointShadow( int x, int y )
{
	// Shadow is read on the GREEN chanel
    float shadow;
    int colorIndex = (y+(zone.h/2-toInt(sHeight)/2))*zone.w + x+(zone.w/2-toInt(sWidth)/2);
    if ( (colorIndex > 0) && (colorIndex < zone.h*zone.w+zone.w) )
    {
        shadow = GETG(zone.dist[colorIndex]);
    }
    else
    {
        shadow = 255.0f;
    }

    return shadow;
}

float getPointDepth( int x, int y )
{
	// Depth is read on the BLUE chanel
    float depth;
    int colorIndex = (y+(zone.h/2-toInt(sHeight)/2))*zone.w + x+(zone.w/2-toInt(sWidth)/2);
    if ( (colorIndex > 0) && (colorIndex < zone.h*zone.w+zone.w) )
    {
        depth = GETB(zone.dist[colorIndex]);
    }
    else
    {
        depth = 255.0f;
    }

	depth = depth/2.55f;

    return depth;
}

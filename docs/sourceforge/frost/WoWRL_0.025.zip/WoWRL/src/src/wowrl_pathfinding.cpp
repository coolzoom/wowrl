/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Pathfinding source           */
/*                                        */
/*  ## : Contains the pathfinding         */
/*  function. It is yet to be perfected.  */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge.h"
#include "hgesprite.h"
#include <math.h>

#include "wowrl_point.h"
#include "wowrl_structs.h"
#include "wowrl_node.h"
#include "wowrl_global.h"
#include "wowrl_collision.h"
#include "wowrl_pathfinding.h"
#include "wowrl_zone.h"

#define PRECISION 8
#define MAXNODE 50000

extern HGE *hge;
extern Zone zone;

std::vector<Point> getShortestPath( float xi, float yi, float destx, float desty )
{
    /* [#] In this function, we use a pathfinding algorythm
    /*     that is close to A* :
    /*       - we divide the collision bitmap in nodes
    /*       - we analyse the first node (the one on which
    /*         the player is) and its surrounding nodes and
    /*         we choose the one which is closest to our
    /*         destination.
    /*       - then we set this node as the new base node
    /*         and we analyse each of its surrounding nodes
    /*         the same way we did with the first, and we
    /*         continue with the best node again, until the
    /*         destination node is reached or until there is
    /*         no more free node available (= no path).
    /*       - if the algorythm finds no path, it returns the
    /*         closest aligned node (could be better if it
    /*         returned the path to the closest node it found)
    /*       - if the destination node is reached, we go back
    /*         from node to parent until the first node is
    /*         reached : here is the path.
    */

	// Variable definition
    bool debug = false; // Set to true if you want log output

	std::vector<Point> path;
	path.reserve(100);

	int zw = toInt(zone.w);
	int zh = toInt(zone.h);

	float old_destx;
	float old_desty;

	int i=2, j, potentialNodes=8;
	bool noPath=false, originReached=false, unaccessible=false;
	int g, g1, g2, r=0, usefullNodes=0;
	Node* p = NULL; // Pointer to the parent node
	float f, h=0;
	int x, y;

	// testNode : used to test if the path used to reach the tested node is better
	// than the one already stored in the old node
	Node testNode;
	// actualNode : stores the adress of the node stored in node[x][y]
	Node* actualNode = NULL;

	// Create arays and maps
	std::map<int, Node> node; // used to get a node ID with its coordinates
	Node* childNode[8] = {NULL};
	std::map<int, Node*> closed;
	std::map<int, Node*> opened;
	Node* bestOpenedNode = NULL;
	Node* closestNode = NULL;

    // First, try to see if the path is wide open
	path.push_back(getNearestAlignedFreePoint(toInt(xi), toInt(yi), toInt(destx), toInt(desty)));
	if (debug) {hge->System_Log("Nearest : x : %f, y : %f", path.begin()->x, path.begin()->y);}
	// And if so, there is no need to calculate a path : return the destination
	if ( (path.begin()->x == destx) && (path.begin()->y == desty) )
	{
		if (debug) {hge->System_Log("No obstacle between destination and origin.\n No need to search for a path.");}
		return path;
	}

	// Convert destination to a multiple of "precision"
	old_destx = destx;
	old_desty = desty;
	destx = floor((destx-xi)/PRECISION)*PRECISION+xi;
	desty = floor((desty-yi)/PRECISION)*PRECISION+yi;

	if (debug)
	{
		hge->System_Log("Trying to go from : x: %d, y: %d ; to : x: %d, y: %d", toInt(xi), toInt(yi), toInt(destx), toInt(desty));
	}

	x=toInt(xi); y=toInt(yi);

	p = &node[x/PRECISION+y/PRECISION*zw/PRECISION];
	p->x = x;
	p->y = y;
	p->index = 1;

	bool searching=true;

    while (searching)
    {
        g1 = p->g+PRECISION;
        g2 = g1; // Change g2 value if you want to add a penalty to diagonal movement

        switch (r)
        {
            case 0:
				x+=PRECISION;
				g=g1;
            	break;
            case 1:
				y-=PRECISION;
				g=g2;
            	break;
            case 2:
				x-=PRECISION;
				g=g1;
				break;
            case 3:
				x-=PRECISION;
				g=g2;
				break;
            case 4:
				y+=PRECISION;
				g=g1;
				break;
            case 5:
				y+=PRECISION;
				g=g2;
				break;
            case 6:
				x+=PRECISION;
				g=g1;
            	break;
            case 7:
				x+=PRECISION;
				g=g2;
            	break;
        }

		actualNode = &node[x/PRECISION+y/PRECISION*zw/PRECISION];
        actualNode->x = x;
		actualNode->y = y;

        h = 10*(fabs(destx-x) + fabs(desty-y))/PRECISION; // Calculate heuristic

        if ( (fabs(destx-x)<PRECISION) && (fabs(desty-y)<PRECISION) )
        {
            actualNode->x = destx;
            actualNode->y = desty;
            actualNode->parent = p;
            if (debug)
            {
            	hge->System_Log("## : destination reached ! Building path...");
            }
            noPath = false;
            searching = false;
            break;
        }

        f = g + h;

        testNode.set(x, y, p, f, g);

        // Check if it collides with something or if it's in the closed list
        if (!CheckPointCollision(x, y))
        {
            if (!actualNode->closed)
            {
            	Point testPoint = getNearestAlignedFreePoint(toInt(p->x), toInt(p->y), toInt(testNode.x), toInt(testNode.y));
                // If there is no obstacle between the parent node and the tested one...
                // (ignore this test for the first node)
                if (testPoint == Point(testNode.x, testNode.y))
                {
                	// If the node is already opened...
					if (actualNode->opened)
					{
						// Check is its F is higher than the one found with the test node...
						if (testNode.f < actualNode->f)
						{
							// ... and if so, change its parent and its F and G value
							actualNode->parent = p;
							actualNode->f = f;
							actualNode->g = g;
							childNode[usefullNodes] = actualNode;
							if (debug)
							{
								hge->System_Log(" #1 : actual node is to be changed, new child[%d] (f:%f)", usefullNodes, childNode[usefullNodes]->f);
							}
							usefullNodes += 1;
						}
						else
						{
							childNode[usefullNodes] = actualNode;
							if (debug)
							{
								hge->System_Log(" #2 : actual node doesn't need to be changed, new child[%d] (f:%f)", usefullNodes, childNode[usefullNodes]->f);
							}
							usefullNodes += 1;
						}
					}
					else // Else, it's the first time this node is visited
					{
						actualNode->set(x, y, p, f, g);
						actualNode->opened = true;
						actualNode->closed = false;
						actualNode->walkable = true;
						actualNode->index = i;
						opened[i] = actualNode;
						childNode[usefullNodes] = actualNode;
						if (debug)
						{
							hge->System_Log(" #3 : new node found, new child[%d] (f:%f)", usefullNodes, childNode[usefullNodes]->f);
						}
						usefullNodes += 1;
					}
                }
                else // Else the node is not accessible
                {
                	if (debug)
                	{
                		hge->System_Log(" #6 : unaccessible node");
                	}
                	potentialNodes-=1;
                }
            }
            else // Else, it's a closed node
            {
                if (debug)
                {
                    hge->System_Log(" #4 : closed node");
                }
                potentialNodes-=1;
            }
        }
        else // Else, the node is not walkable
        {
            if (debug)
            {
                hge->System_Log(" #5 : unwalkable node");
            }
            potentialNodes-=1;
        }

        // If the 8 nodes that surrounds the base node are useless...
        if (potentialNodes == 0)
        {
            // ...flag the base node as useless and closed
            p->useless = true;
            p->closed = true;
            p->opened = false;
            opened.erase(p->index);
            if (debug)
            {
            	closed[p->index] = p;
            }
        }

        r++;

        // If we have parsed the 8 surrounding nodes...
        if (r==8)
        {
            if (debug)
            {
                hge->System_Log("## 1 : all surrounding nodes parsed");
            }
            if (potentialNodes != 0)
            {
                int index = childNode[0]->index, bestintind = -1;
                float best = childNode[0]->f;
                if (debug)
                {
                    hge->System_Log("## 2 : the parent node is not useless, analysing %d nodes (starting with a best value %f)", potentialNodes, best);
                }

                // ... we search for the node with the smallest F value
                for (j=0; j<potentialNodes; j++)
                {
                    index = childNode[j]->index;
                    if (debug)
                    {
                        hge->System_Log(" ## [%d] : analysing node [%d] (%f)", j, index, childNode[j]->f);
                    }
                    if (childNode[j]->f <= best)
                    {
                        if (debug)
                        {
                            hge->System_Log(" ###### : found new best node[%d] (x: %f, y: %f, f: %f)", index, childNode[j]->x, childNode[j]->y, childNode[j]->f);
                        }
                        best = childNode[j]->f;
                        bestintind = j;
                        p = childNode[j];
                        x = toInt(p->x);
                        y = toInt(p->y);
                    }
                }
                if (debug)
                {
                    hge->System_Log("## 5 : continue this path with node[%d] (%d) (x: %d, y: %d, f: %f)\n", p->index, bestintind, toInt(p->x), toInt(p->y), p->f);
                }
                p->closed = true;
                if (debug)
            	{
            		closed[p->index] = p;
            	}
                p->opened = false;
                opened.erase(p->index);
            }
            else
            {
            	if (!opened.empty())
            	{
					std::map<int, Node*>::iterator iter;
					float bestFValue = 1024;
					for (iter = opened.begin(); iter != opened.end(); iter++)
					{
						Node* n = iter->second;
						float f = n->f - n->g;
						if (f != 0)
						{
							if (f < bestFValue)
							{
								bestFValue = f;
								bestOpenedNode = n;
								if (debug)
								{
									hge->System_Log("#### : found new best opened node [%d] : f=%f", n->index, f);
								}
							}
						}
					}
					p = bestOpenedNode;
            	}
            	else
            	{
            		noPath = true;
            		searching = false;
                    break;
            	}

                if (debug)
                {
                    hge->System_Log("## 6 : parent node is useless, go back to node [%d]", p->index);
                }
                x = toInt(p->x);
                y = toInt(p->y);
            }
            // ... and we set some variables to their initial value, ready for another loop
            potentialNodes = 8;
            usefullNodes = 0;
            r=0;
        }
        i++;
    }

    // If we have found a path...
    if (!noPath)
    {
        j = 1;
        Node *temp, *prevNode;
        (*path.begin()) = Point(old_destx, old_desty);
        temp = actualNode->parent;
        if (temp == NULL)
        {
        	hge->System_Log("### : Path found (%1 node) !");
        	return path;
        }

        // ... store nodes by moving from child to parent until we reach the origin
        std::vector<Point>::iterator iter = path.begin();
        iter++;
        while (!originReached)
        {
			if ( temp->parent->getPoint() == Point(xi, yi) )
            {
            	path.push_back(temp->getPoint());
            	path.push_back(Point(xi, yi));
                originReached = true;
                break;
            }
            path.push_back(temp->getPoint());
            prevNode = temp;
            temp = prevNode->parent;
            iter++;
        }

        if (debug)
        {
        	hge->System_Log("### : Path found (%d nodes) !", path.size());
        }
    }
    else // Else if there is no path
    {
        if (debug)
        {
			hge->System_Log("### : No path found, listing closed nodes :");

			std::map<int, Node*>::iterator iter;
			for (iter = closed.begin(); iter != closed.end(); iter++)
			{
				hge->System_Log("%f, %f", iter->second->x, iter->second->y);
			}
			hge->System_Log(" ");
        }
    }

    if (path.size() > 1)
	{
		if (debug)
		{
			hge->System_Log(" ");
			std::vector<Point>::iterator iter1;
			for (iter1 = path.begin(); iter1 != path.end(); iter1++)
			{
				hge->System_Log(" %f, %f", iter1->x, iter1->y);
			}
			hge->System_Log(" ");
		}

		path = simplifyPath(path);
		//(*path.begin()) = Point(xi, yi);

		if (debug)
		{
			std::vector<Point>::iterator iter2;
			for (iter2 = path.begin(); iter2 != path.end(); iter2++)
			{
				hge->System_Log(" %f, %f", iter2->x, iter2->y);
			}
			hge->System_Log(" ", iter2->x, iter2->y);
		}

		return path;
    }
    else
    {
        if (debug)
        {
            std::vector<Point>::iterator iter;
			for (iter = path.begin(); iter != path.end(); iter++)
			{
				hge->System_Log(" %f, %f", iter->x, iter->y);
			}
        }

        return path;
    }
}

std::vector<Point> simplifyPath( std::vector<Point> path )
{
    /* [#] This function is used to reduce the number
    /*     of point contained in a path returned by
    /*     the above function.
    /*     The princip is simple :
    /*       - take a point as a base
    /*       - look at the next point to see if it is
    /*         reachable by going strait ahead and if
    /*         so, check with the next point.
    /*       - when a point is not reachable, the
    /*         previous point is stored in the new path
    /*         and we go on this way until the final
    /*         point is reached.
    /*     We also use the iteration to re-order the
    /*     path in the right way (the path returned by
    /*     the above function is to be followed from
    /*     the end to the beggining).
    /*     When the first simplification is done, all
    /*     useless points are removed. We then start
    /*     another simplification to shorten the path
    /*     even more.
    */

    bool debug = true;

    // If the path is only composed of 2 points, there is nothing to simplify
    if (path.size()==2)
    {
    	if (debug) {hge->System_Log("path can't be simplified", path.size());}
    	return path;
    }

    std::vector<Point> newPath;
    std::vector<Point> tempPath;
    std::vector<Point>::iterator iter1, iter2;
    iter1 = path.end();
    iter1--;
    tempPath.push_back(*iter1); // The first point is not to be changed anyway
    bool intFound;
    bool lastPointReached = false;

	if (debug) {hge->System_Log("path.size = %d", path.size());}
	if (debug) {hge->System_Log("Simplification 1");}
    // First simplification
    while (!lastPointReached)
    {
        intFound = false;
        iter2 = iter1;
        if (debug) {hge->System_Log(" iter2 = iter1 : (%f, %f)", iter2->x, iter2->y);}
        while (!intFound )
        {
        	iter2--;
        	if (debug) {hge->System_Log("  iter2-- : (%f, %f)", iter2->x, iter2->y);}
            Point nearest = getNearestAlignedFreePoint(toInt(iter1->x), toInt(iter1->y), toInt(iter2->x), toInt(iter2->y));
            if ( (nearest != *iter2)/* || (iter2 == path.begin()) */)
            {
            	if (debug) { if (nearest != *iter2) {hge->System_Log("  # nearest != (*iter2) : (%f, %f)", nearest.x, nearest.y);}}
                iter1 = iter2;
                if (debug) {hge->System_Log("    iter1 = iter2 : (%f, %f)", iter1->x, iter1->y);}
                iter1++;
                if (debug) {hge->System_Log("    iter1++ : (%f, %f)", iter1->x, iter1->y);}
                intFound = true;
            }
            else
            {
            	if (iter2 == path.begin())
                {
                	if (debug) {hge->System_Log("  # iter2 = path.begin()");}
                    lastPointReached = true;
                }
            }
        }
        if (debug) {hge->System_Log(" push iter1 : (%f, %f)", iter1->x, iter1->y);}
        tempPath.push_back(*iter1);
    }
    if (debug) {hge->System_Log("push path.begin() : (%f, %f)", path.begin()->x, path.begin()->y);}

    if (debug)
    {
    	hge->System_Log(" ");
		std::vector<Point>::iterator iter3;
		for (iter3 = tempPath.begin(); iter3 != tempPath.end(); iter3++)
		{
			hge->System_Log(" %f, %f", iter3->x, iter3->y);
		}
		hge->System_Log(" ");
    }

	if (tempPath.size() > 2)
	{
		// Second simplification
		if (debug) {hge->System_Log("tempPath.size = %d", tempPath.size());}
		lastPointReached = false;
		iter1 = tempPath.begin();
		hge->System_Log(" ");
		if (debug) {hge->System_Log("Simplification 2");}

		while (!lastPointReached)
		{
			newPath.push_back(*iter1);
			if (debug) {hge->System_Log(" push iter1 : (%f, %f)", iter1->x, iter1->y);}
			intFound = false;
			iter2 = iter1;
			if (debug) {hge->System_Log(" iter2 = iter1 : (%f, %f)", iter2->x, iter2->y);}
			while (!intFound)
			{
				iter2++;
				if (debug) {hge->System_Log("  iter2++ : (%f, %f)", iter2->x, iter2->y);}
				if (iter2 == tempPath.end())
				{
					if (debug) {hge->System_Log("  # iter2 = tempPath.end()");}
					lastPointReached = true;
					iter2--;
					newPath.push_back(*iter2);
					break;
				}
				Point nearest = getNearestAlignedFreePoint(toInt(iter1->x), toInt(iter1->y), toInt(iter2->x), toInt(iter2->y));
				if (nearest != (*iter2))
				{
					if (debug) {hge->System_Log("  # nearest != (*iter2) : (%f, %f)", nearest.x, nearest.y);}
					iter1 = iter2;
					if (debug) {hge->System_Log("    iter1 = iter2 : (%f, %f)", iter1->x, iter1->y);}
					iter1--;
					if (debug) {hge->System_Log("    iter1-- : (%f, %f)", iter1->x, iter1->y);}
					intFound = true;
				}
				else
				{
					if (debug) {hge->System_Log("  # nearest == (*iter2)");}
				}
			}
		}
		if (debug) {hge->System_Log("newPath.size = %d", newPath.size());}
		if (debug) {hge->System_Log(" ");}
		return newPath;
	}
	else
	{
		return tempPath;
	}
}

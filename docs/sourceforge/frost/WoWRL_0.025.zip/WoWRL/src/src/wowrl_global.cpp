/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             Global source              */
/*                                        */
/*  ## : Contains frequently used funcs.  */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hgesprite.h"
#include <math.h>
#include <string>
#include <sstream>
#include "wowrl_point.h"

extern HGE* hge;

// Converts an integer to a string
std::string toString( int i )
{
  std::ostringstream s;
  s << i;
  return s.str();
}

// Converts a rounded float to a integer
int toInt( float f )
{
    int i = static_cast<int>(round(f));
    return i;
}

// Returns the sign of a value (+1 or -1)
int signOf( float f )
{
	return toInt(f/(fabs(f)));
}

// Converts a char* to a bool
bool toBool( char* c )
{

    if ( (std::string(c) == std::string("true")) || (std::string(c) == std::string("1")) )
    {
		return true;
    }
	else
	{
		return false;
	}
}

// Quicker way to get square root, for lazy ones
float rac2( float f )
{
	return pow(f, 0.5);
}

float carre( float f )
{
	return pow(f, 2);
}

float dist( Point p1, Point p2 )
{
	float dist;
	dist = rac2(carre(p1.x-p2.x)+carre(p1.y-p2.y));
	return dist;
}

// Change alpha of a sprite so it seems to glow
void setGlowing( hgeSprite* sprite, float timerAlpha, float speed = 2.0f )
{
   DWORD color = sprite->GetColor();
   float alpha = 105*fabs(sin(speed*timerAlpha))+100;
   sprite->SetColor(ARGB(alpha, GETR(color), GETG(color), GETB(color)));
}

// Angle conversion functions
float radToDeg( float r, bool negativeDeg = true )
{
	float d = r/(2*M_PI) * 360;
	if ( (!negativeDeg) && (d<0) )
	{
		d = 360+d;
	}
	return d;
}
float degToRad( float d )
{
	float r = d/360 * 2*M_PI;
	return r;
}

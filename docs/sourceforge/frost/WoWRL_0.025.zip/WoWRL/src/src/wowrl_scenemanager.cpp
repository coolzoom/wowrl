/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          Scene manager source          */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the SceneManager class.            */
/*       A SceneManager is obviously a    */
/*  class that manages the scene and its  */
/*  components (units, background ...)    */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_scenemanager.h"
#include "wowrl_unit.h"

extern HGE *hge;

Unit* SceneManager::createUnit( std::string name )
{
    if (unitList.find(name) != unitList.end())
    {
        hge->System_Log("# A unit with the name %c already exists, returning pointer.", name.c_str());
    }
    else
    {
        unitList[name] = Unit(name);
    }
    return &unitList[name];
}

Unit* SceneManager::createUnit( std::string name,
                              float x, float y,
                              float speed )
{
    if (unitList.find(name) != unitList.end())
    {
        hge->System_Log("# A unit with the name %s already exists, returning pointer.", name.c_str());
    }
    else
    {
        unitList[name] = Unit(name, x, y, speed);
    }
	return &unitList[name];
}

Unit* SceneManager::getUnitByName( std::string name )
{
    if (unitList.find(name) != unitList.end())
    {
        Unit *u = &unitList[name];
        return u;
    }
    else
    {
        hge->System_Log("# ERROR # : No unit found with the name %s", name.c_str());
    }
}

Class* SceneManager::getClass( std::string name )
{
    if (classList.find(name) != classList.end())
    {
        Class *c = &classList[name];
        return c;
    }
    else
    {
        hge->System_Log("# ERROR # : No class found with the name %s", name.c_str());
    }
}

void SceneManager::createProjectile(std::string fxname, Unit* target, Unit* origin)
{
	std::string oname = origin->getName();
	if (projectileList.find(oname) == projectileList.end())
	{
		projectileList[oname] = Projectile(fxname, target, origin);
	}
	projectileList[oname].getPSys()->MoveTo(origin->getX()+particleFXList[fxname].offset_x, origin->getY()+particleFXList[fxname].offset_y);
	projectileList[oname].getPSys()->Stop(true);
	projectileList[oname].getPSys()->Fire();
}

void SceneManager::createStatusBar(Unit* parent)
{
	StatusBar tmpSB;
	tmpSB.parent = parent->getName();
	statusBarList[parent->getName()] = tmpSB;
}

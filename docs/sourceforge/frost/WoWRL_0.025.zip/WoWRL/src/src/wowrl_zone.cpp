/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Zone source               */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Zone class.                    */
/*       A Zone stores all the infos that */
/*  are used in a particular place. It    */
/*  contains the collision and distortion */
/*  maps, all the doodads that are ren-   */
/*  dered, the links between zones,
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_zone.h"

Zone::Zone()
{
}

Zone::~Zone()
{
}

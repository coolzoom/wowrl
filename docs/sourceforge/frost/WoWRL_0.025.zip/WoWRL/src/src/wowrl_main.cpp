/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               Main source              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge.h"
#include "hgesprite.h"
#include "hgefont.h"
#include "hgerect.h"
#include "hgevector.h"
#include "hgeanim.h"
#include "hgeparticle.h"
#include <math.h>
#include <string>
#include "keyhandler.h"

#include "wowrl_scenemanager.h"
#include "wowrl_point.h"
#include "wowrl_structs.h"
#include "wowrl_global.h"
#include "wowrl_pathfinding.h"
#include "wowrl_collision.h"
#include "wowrl_distortion.h"
#include "wowrl_movement.h"
#include "wowrl_doodad.h"
#include "wowrl_zone.h"

using namespace std;

// Global variables
HGE *hge = 0;
SceneManager mySceneManager;
hgeParticleManager myParticleManager;
KeyHandler myKeyHandler;
int sWidth, sHeight; // Screen dimensions
//float gx=0.0f, gy=0.0f; // Global pos
float dt;
float dx=0.0f, dy=0.0f; // Global variations
const float speed=400; // Speed factor
float pSpeed=150.0f; // Player speed
float invx, invy; // Invisble BB pos
float timerAlpha;

// System
hgeSprite*   		background; // BG sprite
hgeSprite*   		cursor; // Cursor sprite
hgeSprite*   		pixel; // Pixel sprite
hgeSprite*   		particle;
hgeSprite*   		p_shadow; // Shadow for units
hgeSprite*          selectionCircle; // Circle indicating selection
hgeSprite*          orderCircle; // Circle indicating selection (behind)
hgeSprite*          selectionSquare; // Square appearing when dragging left mouse button
hgeSprite*          selectionSquareLeftBorder; // Its borders
hgeSprite*          selectionSquareTopBorder;
hgeSprite*          selectionSquareRightBorder;
hgeSprite*          selectionSquareBottomBorder;
HTEXTURE   			bg_tex; // BG texture
HTEXTURE   			bg_col_tex; // BG collision texture
HTEXTURE   			bg_dist_tex; // BG distortion texture
HTEXTURE   			cur_gen_tex; // Cursor texture
HTEXTURE   			cur_atk_tex;
HTEXTURE   			cur_taxi_tex;
HTEXTURE            px_tex; // Singel pixel texture
HTEXTURE            pshadow_tex;
HTEXTURE            circle_tex;
HTEXTURE            ordercircle_tex;
HTEXTURE            selectionsquare_tex;
HTEXTURE			particle_tex;
HTEXTURE			status_bar_tex;
Zone				zone;

// Font
hgeFont*   fnt; // Font to display infos

// Bouding boxes and stuff to prevent the background to fly out of screen
hgeRect*            invRect = new hgeRect(); // Invisible Rect
hgeRect*            screenLTRect; // Top Left BB
hgeRect*            screenRTRect; // Top Right BB
hgeRect*            screenRBRect; // Bottom Right BB
hgeRect*            screenLBRect; // Bottom Left BB
hgeRect*            screenLRect2; // Top Left BB
hgeRect*            screenTRect2; // Top Right BB
hgeRect*            screenRRect2; // Bottom Right BB
hgeRect*            screenBRect2; // Bottom Left BB
bool screenLTRectINT; // Checks intersection between BG's BB and Top Left BB
bool screenRTRectINT; // Checks intersection between BG's BB and Top Right BB
bool screenRBRectINT; // Checks intersection between BG's BB and Bottom Right BB
bool screenLBRectINT; // Checks intersection between BG's BB and Bottom Left BB

// Bounding boxes and stuff for clicking
hgeRect*            mouseRect = new hgeRect(); // Mouse BB for click detection
hgeRect*            selectSquareRect = new hgeRect(); // Selection square's BB
bool selected=false;
bool squareSelection=false;
bool RenderSquare=false;
float squarex, squarey, squareXScale, squareYScale;
int unitSelected;
hgeVector mouseVec;

// Stuff for orders
bool orderGiven=false;
bool leadFound=false;
map<string, Unit*> orderList;

// Stuff for collision
bool destCollides=true;

// Input
hgeInputEvent inp;

// Background variables
float bgx, bgy; // BG initial pos and scale

// Bools and stuff for mouse input
bool mRButton=false;
bool mLButton=false;
bool lastRButton=false;
bool lastLButton=false;
int mRState;
int mLState;
float mSpeed=500.0f;
float mx=0, my=0; //mz=0; // Mouse pos and wheel state
float gmx=0,  gmy=0; // Global mouse pos (= mouse pos - global pos)
float dmx=0.0f, dmy=0.0f; //dmz=0.0f; // Mouse pos and wheel variation
float mx_old=0, my_old=0; // Old mouse pos, used to calculate the variation
float curx=0, cury=0; // Cursor pos

// Function called by HGE once per frame.
bool FrameFunc()
{
/* --------------------------------------------- */
/* Get inputs and store them in global variables */
/* --------------------------------------------- */

    dt = hge->Timer_GetDelta();

    // Get wheel state, not used atm
    //mz = hge->Input_GetMouseWheel();

    // Get mouse pos
    hge->Input_GetMousePos(&mx,&my);
    dmx = mx_old-mx;
    dmy = my_old-my;
    mx_old = mx;
    my_old = my;

    // Cursor pos
    curx=mx;
    cury=my;

    // Handle left mouse button
	if (myKeyHandler.keyIsDown(HGEK_LBUTTON))
	{
		if (myKeyHandler.keyIsPressed(HGEK_LBUTTON))
	   		mLState = 2; // single pressed
	   	else if(myKeyHandler.keyIsDoubleClicked(HGEK_LBUTTON))
	   		mLState = 4; // double clicked
		else
	   		mLState = 1; // dragged
	}
	else if (myKeyHandler.keyIsReleased(HGEK_LBUTTON))
	{
	    mLState = 3; // released
	}
	else
		mLState = 0; // no input

	// Handle right mouse button
	if (myKeyHandler.keyIsDown(HGEK_RBUTTON))
	{
		if (myKeyHandler.keyIsPressed(HGEK_RBUTTON))
	   		mRState = 2;
	   	else if (myKeyHandler.keyIsDoubleClicked(HGEK_RBUTTON))
	   		mRState = 4;
		else
	   		mRState = 1;
	}
	else if (myKeyHandler.keyIsReleased(HGEK_RBUTTON))
	{
	    mRState = 3;
	}
	else
		mRState = 0;

    if (myKeyHandler.keyIsPressed(HGEK_ESCAPE))
        return true;

    if (myKeyHandler.keyIsPressed(HGEK_G))
	{
		map<float, Object>::iterator iter;
		for (iter = mySceneManager.zSortedList.begin(); iter != mySceneManager.zSortedList.end(); iter++)
		{
			if ((*iter).second.type == "unit")
			{
				Unit *u = static_cast<Unit*>((*iter).second.ptr);
				if (u->isSelected())
					hge->System_Log("[%f] %s (S)", u->getZ(), u->getName().c_str());
				else
					hge->System_Log("[%f] %s", u->getZ(), u->getName().c_str());
			}
			else if ((*iter).second.type == "doodad")
			{
				Doodad *d = static_cast<Doodad*>((*iter).second.ptr);
				hge->System_Log("[%f] %s", d->getZ(), d->name.c_str());
			}
		}
	}

    // If the mouse enters a 20pixel band around the screen, pan the view in the direction
    // given by the mouse pointer and the center of the screen
    mouseRect->Set(curx-2,cury-2,curx+2,cury+2); // Set the mouse BB properties

/* ------------------------------------------------------- */
/* Apply the "movement" to the global values and collision */
/* detectors.                                              */
/* ------------------------------------------------------- */

    // ## Global values
    mySceneManager.gx += dx;
    mySceneManager.gy += dy;
    gmx = mx-mySceneManager.gx;
    gmy = my-mySceneManager.gy;

    // Detect loss of intersections between screen BBs and the Invisible One
    invRect->Set(invx-zone.w/2, invy-zone.h/2, invx+zone.w/2, invy+zone.h/2);
    screenLTRectINT = invRect->Intersect(screenLTRect);
    screenRTRectINT = invRect->Intersect(screenRTRect);
    screenRBRectINT = invRect->Intersect(screenRBRect);
    screenLBRectINT = invRect->Intersect(screenLBRect);

    // If the IO goes away from two screen bounding boxes, discard the previous changes
    if ( !(screenLTRectINT) && !(screenRTRectINT) && (dy > 0) )
    {
        mySceneManager.gy -= dy;
        invy -= dy;
        dy = 0;
    }
    if ( !(screenLBRectINT) && !(screenRBRectINT) && (dy < 0) )
    {
        mySceneManager.gy -= dy;
        invy -= dy;
        dy = 0;
    }
    if ( !(screenLTRectINT) && !(screenLBRectINT) && (dx > 0) )
    {
        mySceneManager.gx -= dx;
        invx -= dx;
        dx = 0;
    }
    if ( !(screenRTRectINT) && !(screenRBRectINT) && (dx < 0) )
    {
        mySceneManager.gx -= dx;
        invx -= dx;
        dx = 0;
    }

/* ------------------------------------------------------- */
/* Then apply the "movement" to different elements of the  */
/* scene.                                                  */
/* ------------------------------------------------------- */

    // ## Background
    bgx += dx;
    bgy += dy;

/* ---------------------------------------------------- */
/* Handle clicking : order                              */
/* ---------------------------------------------------- */

    // Define whether the mouse was on an obstruded zone or not
    destCollides = CheckPointCollision(toInt(mx), toInt(my));

	// Parse all hostile units to define wether the mouse is hovering one
    bool attack=false;
	Unit* target;
	map<string, Unit*>::iterator iterHostile;
    for (iterHostile = mySceneManager.hostileList.begin(); iterHostile != mySceneManager.hostileList.end(); iterHostile++)
	{
		attack = mouseRect->Intersect(iterHostile->second->getBox());
		if (attack)
		{
			target = iterHostile->second;
			cursor->SetTexture(cur_atk_tex); // If so, change the cursor's texture
			break;
		}
		else
		{
			cursor->SetTexture(cur_gen_tex); // Else set it to its default texture
		}
	}

    if ( (mRState==2) && (selected) )
    {
        if (attack) // It's obviously an attack order
        {
			map<string, Unit*>::iterator iter;
			for (iter = mySceneManager.selectedList.begin(); iter != mySceneManager.selectedList.end(); iter++)
			{
				iter->second->attack(target);
			}
        }
        else // It's a movement order
        {
			// Parse all selected units
			map<string, Point*> destPoint;
			Unit *tmpUnit = mySceneManager.selectedList.begin()->second;
			if (!destCollides) // If the path is not obstruded, do as usual
			{
				tmpUnit->destPoint.set(toInt(mx), toInt(my));
			}
			else // Else define whitch is the nearest free point to go
			{
				tmpUnit->destPoint = getNearestFreePoint(tmpUnit->getX(), tmpUnit->getY(), toInt(mx), toInt(my));
			}
			Point ipos = tmpUnit->getPoint();
			tmpUnit->setX(tmpUnit->destPoint.x);
			tmpUnit->setY(tmpUnit->destPoint.y);
			tmpUnit->getScale();
			hgeRect* tmpRect = tmpUnit->getBox();
			float space = tmpRect->x2-tmpRect->x1;
			tmpUnit->setX(ipos.x);
			tmpUnit->setY(ipos.y);

			map<string, Unit*>::iterator iter;
			for (iter = mySceneManager.selectedList.begin(); iter != mySceneManager.selectedList.end(); iter++)
			{
				Unit *u = iter->second;
				u->stopAttack();
				u->setAnimState("walk");

				if (!destCollides) // If the path is not obstruded, do as usual
				{
					u->destPoint.set(toInt(mx), toInt(my));
				}
				else // Else define whitch is the nearest free point to go
				{
					u->destPoint = getNearestFreePoint(u->getX(), u->getY(), toInt(mx), toInt(my));
				}

				if (!destPoint.empty())
				{
					Point tmpPoint(&u->destPoint);
					int i=1, j=0;
					int row=toInt(rac2(mySceneManager.selectedList.size()));
					map<string, Point*>::iterator iterPoint;
					for (iterPoint = destPoint.begin(); iterPoint != destPoint.end(); iterPoint++)
					{
						if (tmpPoint == iterPoint->second)
						{
							tmpPoint.set(toInt(u->destPoint.x+i*space), toInt(u->destPoint.y+j*space));
							i++;
							if (i>row)
							{
								i=0;
								j++;
							}
						}
					}
					bool col = CheckPointCollision(toInt(tmpPoint.x), toInt(tmpPoint.y));
					if (col)
					{
						u->destPoint = getNearestFreePoint(u->getX(), u->getY(), toInt(tmpPoint.x), toInt(tmpPoint.y));
					}
					else
					{
						u->destPoint = tmpPoint;
					}
				}
				destPoint[u->getName()] = &u->destPoint;
			}
			for (iter = mySceneManager.selectedList.begin(); iter != mySceneManager.selectedList.end(); iter++)
			{
				Unit *u = iter->second;
				u->path = getShortestPath
				(
					toInt(u->getX()),
					toInt(u->getY()),
					toInt(u->destPoint.x),
					toInt(u->destPoint.y)
				);
				u->following = false;

				if (orderList.find(u->getName()) == orderList.end())
				{
					orderList[u->getName()] = u;
				}

				orderGiven = true;
			}
        }
    }

    if (orderGiven)
    {
        setGlowing(orderCircle, timerAlpha);
		map<string, Unit*>::iterator iter, lastParsed;
		lastParsed = NULL;
		for (iter = orderList.begin(); iter != orderList.end(); iter++)
		{
			Unit *u = iter->second;
			bool moving = followPath(u, u->path);
			if (!moving)
			{
				orderList.erase(iter);
				if (orderList.empty())
				{
					orderGiven = false;
					break;
				}
				else
				{
					if (lastParsed == NULL)
					{
						iter = orderList.begin();
					}
					else
					{
						iter = lastParsed;
					}
				}
			}
			lastParsed = iter;
		}
    }

/* ---------------------------------------------------- */
/* Handle clicking : selection square                   */
/* ---------------------------------------------------- */

    if (mLState==1)
    {
        if (!squareSelection)
        {
            squarex = gmx;
            squarey = gmy;
            unitSelected = 0;
        }
        squareSelection = true;
        squareXScale = (gmx-squarex)/28;
        squareYScale = (gmy-squarey)/28;

        if (squareYScale==0.0f)
            RenderSquare = false; // Because HGE interprets Yscale = 0 as Yscale = 1
        else
            RenderSquare = true;

        selectionSquare->GetBoundingBoxEx(squarex+mySceneManager.gx, squarey+mySceneManager.gy, 0.0f, squareXScale, squareYScale, selectSquareRect);
        map<string, Unit>::iterator iter;
        for (iter = mySceneManager.unitList.begin(); iter != mySceneManager.unitList.end(); iter++)
        {
            Unit *u = &(*iter).second;
            if (!u->isHostile())
            {
				if (selectSquareRect->Intersect(u->getBox()))
				{
					if (!u->isSelected())
					{
						u->setSelected(true);
						unitSelected++;
					}
				}
				else
				{
					if (u->isSelected())
					{
						u->setSelected(false);
						unitSelected--;
					}
				}
            }
        }
        if (unitSelected != 0)
            selected = true;
    }
    else if (mLState==0)
        squareSelection = false;

/* ---------------------------------------------------- */
/* End loop maths                                       */
/* ---------------------------------------------------- */

    // Global alpha glow
    setGlowing(selectionCircle, timerAlpha);
    timerAlpha+=dt;
    if (timerAlpha>M_PI_2)
        timerAlpha=0;

    // Reset variation
    dx = 0;
    dy = 0;

/* ---------------------------------------------------- */
/* Updates                                              */
/* ---------------------------------------------------- */

    // Update keyhandler
	myKeyHandler.updateKeys(dt);

    // Update render order
	mySceneManager.zSortedList.clear();
	map<string, Doodad>::iterator iterDoodad;
    for (iterDoodad = zone.doodadList.begin(); iterDoodad != zone.doodadList.end(); iterDoodad++)
    {
    	Doodad *d = &iterDoodad->second;
		float z = d->getZ();
    	if (!d->inTop)
    	{
			Object obj;
			obj.type = "doodad";
			obj.ptr = d;
			mySceneManager.zSortedList[z] = obj;
    	}
    	else
    	{
    		mySceneManager.renderInTopList[z] = d;
    	}
    }

    map<string, Unit>::iterator iterAnim;
    for (iterAnim = mySceneManager.unitList.begin(); iterAnim != mySceneManager.unitList.end(); iterAnim++)
    {
        Unit *u = &iterAnim->second;
        map<float, Object> relZList;
        map<float, Object>::iterator iterZ;
        for (iterZ = mySceneManager.zSortedList.begin(); iterZ != mySceneManager.zSortedList.end(); iterZ++)
        {
        	// Check every unit or doodad that is in close range
        	if (u->intersects(iterZ->second))
        	{
        		// Get relative Z for each
        		float z;
        		if (iterZ->second.type == "unit")
        		{
        			Unit* tempUnit = static_cast<Unit*>(iterZ->second.ptr);
					z = tempUnit->getRelativeDepth(u->getPoint());
        		}
        		else if (iterZ->second.type == "doodad")
        		{
        			Doodad* tempDoodad = static_cast<Doodad*>(iterZ->second.ptr);
					z = tempDoodad->getRelativeDepth(u->getPoint());
        		}
				// A little offset to prevent duplicates
				while (relZList.find(z) != relZList.end())
				{
					z += 0.1f;
				}

				// ... and store it in a map
				relZList[z] = iterZ->second;
        	}
        }
        float z;
        if (relZList.empty())
        {
        	// If the map is empty, then set unit's Z to its global value
        	z = u->getZ();
			// ...and add little offset if needed to prevent duplicates
			while (mySceneManager.zSortedList.find(z) != mySceneManager.zSortedList.end())
			{
				z += 0.1f;
			}
        }
        else
        {
			if (relZList.size() == 1)
			{
				/* Else if there is only one object in range, set unit's Z to the
				   object's + a small offset that has the sign of the relative Z.
				*/
				if (relZList.begin()->second.type == "unit")
				{
					Unit* tempUnit = static_cast<Unit*>(relZList.begin()->second.ptr);
					z = tempUnit->rz+relZList.begin()->first*0.1f;
				}
				else if (relZList.begin()->second.type == "doodad")
				{
					Doodad* tempDoodad = static_cast<Doodad*>(relZList.begin()->second.ptr);
					z = tempDoodad->getZ()+relZList.begin()->first*0.1f;
				}
			}
			else if (relZList.size() > 1)
			{
				/* And if there is more than two objects, get the first relZ that
				   if greater than 0 and the one just before and do the same as
				   above.
				*/
				float z1, z2;
				map<float, Object>::iterator iter1, iter2, iter3;
				iter1 = relZList.end();
				iter1--;
				iter2 = relZList.begin();
				iter3 = relZList.upper_bound(0.0f);

				if (iter1->first <= 0.0f)
				{
					// There is no positive Z value, set Z to its global value
					if (iter1->second.type == "unit")
					{
						Unit* tempUnit = static_cast<Unit*>(iter1->second.ptr);
						z1 = tempUnit->rz;
					}
					else if (iter1->second.type == "doodad")
					{
						Doodad* tempDoodad = static_cast<Doodad*>(iter1->second.ptr);
						z1 = tempDoodad->getZ();
					}
					iter1--;
					if (iter1->second.type == "unit")
					{
						Unit* tempUnit = static_cast<Unit*>(iter1->second.ptr);
						z2 = tempUnit->rz;
					}
					else if (iter1->second.type == "doodad")
					{
						Doodad* tempDoodad = static_cast<Doodad*>(iter1->second.ptr);
						z2 = tempDoodad->getZ();
					}
					z = (z1+z2)/2;
				}
				else if (iter2->first >= 0.0f)
				{
					// There is no negative Z value, set Z to its global value
					if (iter2->second.type == "unit")
					{
						Unit* tempUnit = static_cast<Unit*>(iter2->second.ptr);
						z1 = tempUnit->rz;
					}
					else if (iter2->second.type == "doodad")
					{
						Doodad* tempDoodad = static_cast<Doodad*>(iter2->second.ptr);
						z1 = tempDoodad->getZ();
					}
					iter2++;
					if (iter2->second.type == "unit")
					{
						Unit* tempUnit = static_cast<Unit*>(iter2->second.ptr);
						z2 = tempUnit->rz;
					}
					else if (iter2->second.type == "doodad")
					{
						Doodad* tempDoodad = static_cast<Doodad*>(iter2->second.ptr);
						z2 = tempDoodad->getZ();
					}
					z = (z1+z2)/2;
				}
				else
				{
					// Else get the two closest Z value from 0
					if (iter3->second.type == "unit")
					{
						Unit* tempUnit = static_cast<Unit*>(iter3->second.ptr);
						z1 = tempUnit->rz;
					}
					else if (iter3->second.type == "doodad")
					{
						Doodad* tempDoodad = static_cast<Doodad*>(iter3->second.ptr);
						z1 = tempDoodad->getZ();
					}
					iter3--;
					if (iter3->second.type == "unit")
					{
						Unit* tempUnit = static_cast<Unit*>(iter3->second.ptr);
						z2 = tempUnit->rz;
					}
					else if (iter3->second.type == "doodad")
					{
						Doodad* tempDoodad = static_cast<Doodad*>(iter3->second.ptr);
						z2 = tempDoodad->getZ();
					}
					z = (z1+z2)/2;
				}
			}
        }
        Object obj;
        obj.type = "unit";
        obj.ptr = u;
        // A little offset to prevent duplicates
		while (mySceneManager.zSortedList.find(z) != mySceneManager.zSortedList.end())
		{
			z += 0.1f;
		}
		u->rz = z;
		mySceneManager.zSortedList[z] = obj;

        if (mySceneManager.attackerList.find(iterAnim->first) != mySceneManager.attackerList.end())
        {
        	(*iterAnim).second.updateAttack(dt); // Update the attack animation
        	if (u->FXPlaying)
        	{
        		u->getEffect()->Update(dt); // And the effect if there is one
        	}
        }
        if (mySceneManager.deadList.find(iterAnim->first) != mySceneManager.deadList.end())
        {
        	if ( (u->dying) && !(u->getAnimation()->IsPlaying()) )
        	{
        		u->dying = false;
        	}
        }
		u->getAnimation()->Update(dt);
    }

    // Update all projectiles and their particle system
    map<string, Projectile>::iterator iterProj, lastProj;
    lastProj = NULL;
    for (iterProj = mySceneManager.projectileList.begin(); iterProj != mySceneManager.projectileList.end(); iterProj++)
    {
    	Projectile *p = &iterProj->second;
    	if (!p->updatePos())
    	{
    		p->getPSys()->Stop();
    		mySceneManager.projectileList.erase(iterProj);
    		if (mySceneManager.projectileList.empty())
    		{
    			break;
    		}
    		if (lastProj == NULL)
    			iterProj = mySceneManager.projectileList.begin();
			else
    			iterProj = lastProj;
    	}
    	else
    	{
    		p->getPSys()->MoveTo(p->x, p->y);
    		p->getPSys()->Update(dt);
    	}
    	lastProj = iterProj;
    }

    return false;
}

bool RenderFunc()
{
    // Begin rendering.
    hge->Gfx_BeginScene();
	//hge->Gfx_SetTransform((sWidth-1024.0f)/2.0f, (sHeight-768.0f)/2.0f);
	//hge->System_Log("x = %f, y = %f", (sWidth-1024.0f)/2.0f, (sHeight-768.0f)/2.0f);

    // Clear screen with black color
    hge->Gfx_Clear(0);

	// Render the background first
    background->Render(bgx, bgy);

    // Render order circles
    if (orderGiven)
    {
        map<string, Unit*>::iterator iter;
    	for (iter = orderList.begin(); iter != orderList.end(); iter++)
    	{
    		Unit *u = iter->second;
			float mdist = getPointDistortion(toInt(u->destPoint.x), toInt(u->destPoint.y));
			float scale = zone.distortion_scale_min-mdist*(zone.distortion_scale_min-zone.distortion_scale_max);
			float s_scale = u->getClass()->shadow_scale;
			float vscale = zone.distortion_vscale_min-mdist*(zone.distortion_vscale_min-zone.distortion_vscale_max);
			orderCircle->RenderEx(u->destPoint.x, u->destPoint.y, 0.0f, 2.0f*scale*s_scale, 1.4f*scale*s_scale*vscale);
    	}
    }

	// Render selection circles
    map<float, Object>::iterator iterObj;
    for (iterObj = mySceneManager.zSortedList.begin(); iterObj != mySceneManager.zSortedList.end(); iterObj++)
    {
    	if (iterObj->second.type == "unit")
    	{
			Unit *u = static_cast<Unit*>(iterObj->second.ptr);
			float ux = u->getX();
			float uy = u->getY();
			float scale = u->getScale()*(u->getClass()->scale);
			float vscale = u->getVScale();
			float angle = u->getAngle();
			float shadow = u->getShadow();
			float s_scale = u->getClass()->shadow_scale;
			p_shadow->RenderEx(ux, uy, angle, scale*s_scale, scale*s_scale*vscale);
			if (u->isDead())
			{
				selectionCircle->SetColor(ARGB(180, 150, 150, 150));
				selectionCircle->RenderEx(ux, uy, 0.0f, 2.0f*scale*s_scale, 1.4f*scale*s_scale*vscale);
			}
			else
			{
				if (u->isSelected())
				{
					selectionCircle->SetColor(ARGB(180, 20, 220, 64));
					selectionCircle->RenderEx(ux, uy, 0.0f, 2.0f*scale*s_scale, 1.4f*scale*s_scale*vscale);
				}
				if (u->isHostile())
				{
					selectionCircle->SetColor(ARGB(180, 220, 64, 20));
					selectionCircle->RenderEx(ux, uy, 0.0f, 2.0f*scale*s_scale, 1.4f*scale*s_scale*vscale);
				}
			}
    	}
    }
    // Render units
    for (iterObj = mySceneManager.zSortedList.begin(); iterObj != mySceneManager.zSortedList.end(); iterObj++)
    {
    	if (iterObj->second.type == "unit")
    	{
			Unit *u = static_cast<Unit*>(iterObj->second.ptr);
			float ux = u->getX();
			float uy = u->getY();
			float scale = u->getScale()*(u->getClass()->scale);
			float vscale = u->getVScale();
			float angle = u->getAngle();
			float shadow = u->getShadow();
			RGB color = u->getColor();
			u->getAnimation()->SetColor(ARGB(255, shadow+color.R, shadow+color.G, shadow+color.B));
			u->getAnimation()->RenderEx(ux, uy, angle, scale, scale);
			u->getAnimation()->SetColor(ARGB(255, 255, 255, 255));
			// Render effects
			if (u->FXPlaying)
			{
				float fade_out = mySceneManager.animatedFXList[u->getEffectName()].fade_out;
				float fade_in = mySceneManager.animatedFXList[u->getEffectName()].fade_in;
				if (u->getAnimState() == "prepare_attack")
				{
					if ( (fade_in == 0.0f) || (u->FXFaded == true) )
					{
						// Render the effect, nothing special
						u->alphaFXTimer = 0.0f;
						u->getEffect()->RenderEx(ux, uy, angle, scale, scale);
					}
					else if ( (fade_in != 0.0f) && (u->FXFaded == false) )
					{
						// Fade in the effect
						u->alphaFXTimer += dt/fade_in;
						if (u->alphaFXTimer > fade_in)
						{
							u->alphaFXTimer = fade_in;
							u->FXFaded = true;
						}
						int alpha = toInt(sin(u->alphaFXTimer*M_PI_2)*255);
						u->getEffect()->SetColor(ARGB(alpha, 255, 255, 255));
						u->getEffect()->RenderEx(ux, uy, angle, scale, scale);
						u->getEffect()->SetColor(ARGB(255, 255, 255, 255));

						if (u->FXFaded == true)
						{
							u->alphaFXTimer = 0.0f;
						}
					}
				}
				else if ( (u->getAnimState() == "attack") && (u->FXFaded == false) && (fade_out != 0.0f) )
				{
					// Fade out the effect
					u->alphaFXTimer += dt/fade_out;
					if (u->alphaFXTimer > fade_out)
					{
						u->alphaFXTimer = fade_out;
						u->FXFaded = true;
					}
					int alpha = toInt(cos(u->alphaFXTimer*M_PI_2)*255);
					u->getEffect()->SetColor(ARGB(alpha, 255, 255, 255));
					u->getEffect()->RenderEx(ux, uy, angle, scale, scale);
					u->getEffect()->SetColor(ARGB(255, 255, 255, 255));

					if (u->FXFaded == true)
					{
						u->alphaFXTimer = 0.0f;
					}
				}
			}
    	}
    	else if (iterObj->second.type == "doodad")
    	{
    		Doodad* d = static_cast<Doodad*>(iterObj->second.ptr);
    		d->sprite->Render(d->getX(),d->getY());
    	}
    }
	// Render projectiles
    map<string, Projectile>::iterator iterProj;
    for (iterProj = mySceneManager.projectileList.begin(); iterProj != mySceneManager.projectileList.end(); iterProj++)
    {
    	iterProj->second.getPSys()->Render();
    }

    map<float, Doodad*>::iterator iterDoodad;
    for (iterDoodad = mySceneManager.renderInTopList.begin(); iterDoodad != mySceneManager.renderInTopList.end(); iterDoodad++)
    {
    	Doodad* d = iterDoodad->second;
    	d->sprite->Render(d->getX(), d->getY());
    }

    // Render status bars
    for (iterObj = mySceneManager.zSortedList.begin(); iterObj != mySceneManager.zSortedList.end(); iterObj++)
    {
    	if (iterObj->second.type == "unit")
    	{
			Unit *u = static_cast<Unit*>(iterObj->second.ptr);
			StatusBar* sb = u->getStatusBar();
			hgeRect* pBox = u->getStandBox();
			float bx = pBox->x1;
			float by = pBox->y1-8;
			DWORD color = ARGB(180, 0, 0, 0);

			sb->background_left->SetColor(color);
			sb->background_left->Render(bx, by);
			sb->background_right->SetColor(color);
			sb->background_right->Render(ceil(bx+sb->size-3), by);
			sb->background_middle->SetColor(color);
			sb->background_middle->RenderStretch(bx+3, by, ceil(bx+sb->size-3), by+8);
			sb->gauge->SetColor(ARGB(200, sb->color.R, sb->color.G, sb->color.B));
			sb->gauge->RenderStretch(bx+3, by+3, ceil(bx+(sb->size-3)*sb->state), by+5);
    	}
    }

	// Render the selection square
    if (squareSelection)
    {
        if (RenderSquare)
        {
            selectionSquare->RenderEx(squarex+mySceneManager.gx, squarey+mySceneManager.gy, 0.0f, squareXScale, squareYScale);
            selectionSquareLeftBorder->RenderEx(squarex+mySceneManager.gx, squarey+mySceneManager.gy, 0.0f, 1.0f, squareYScale);
            selectionSquareRightBorder->RenderEx(mx, squarey+mySceneManager.gy, 0.0f, 1.0f, squareYScale);
        }
        selectionSquareTopBorder->RenderEx(squarex+mySceneManager.gx, squarey+mySceneManager.gy, 0.0f, squareXScale, 1.0f);
        selectionSquareBottomBorder->RenderEx(squarex+mySceneManager.gx, my, 0.0f, squareXScale, 1.0f);
    }

    // Print infos
    fnt->printf(5, 5, HGETEXT_LEFT,
                   "FPS : %d\nmx : %f\nmy : %f\ncollides : %d",
                    hge->Timer_GetFPS(), mx, my, destCollides);
    //fnt->printf(5, 5, HGETEXT_LEFT, "FPS : %d", hge->Timer_GetFPS());

	/*// Debug render
    for (int x=1; x<sWidth; x++)
    {
    	for (int y=1; y<sHeight; y++)
    	{
			bool collides = CheckPointCollision(toInt(x), toInt(y));
			if (collides)
			{
    			pixel->SetColor(ARGB(255,0,0,0));
			}
			else
			{
				pixel->SetColor(ARGB(255,255,255,255));
			}
    		pixel->Render(x,y);
    	}
    }*/

	// Render the cursor above all
    cursor->Render(curx, cury);

    // End rendering, update the screen
    hge->Gfx_EndScene();

    return false;
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	srand((unsigned)time(0));

    hge = hgeCreate(HGE_VERSION);
    hge->System_SetState(HGE_LOGFILE, "WoWRL.log"); // Initialize the Log file
    hge->System_SetState(HGE_FRAMEFUNC, FrameFunc);
    hge->System_SetState(HGE_RENDERFUNC, RenderFunc);
    //hge->System_SetState(HGE_ZBUFFER, true); // Not used atm

    hge->System_SetState(HGE_TITLE, "WoW Raid Leader"); // Set the frame title

	hge->System_Log("Parsing config.ini...");
    hge->System_SetState(HGE_INIFILE, "config.ini");
    sWidth = toInt(hge->Ini_GetFloat("Display", "scr_width", 1024.0f));
    sHeight = toInt(hge->Ini_GetFloat("Display", "scr_height", 768.0f));
    int sDepth = toInt(hge->Ini_GetFloat("Display", "scr_depth", 32));
    int sMaxFPS = toInt(hge->Ini_GetFloat("Display", "max_fps", 60));
    bool windowed = toBool(hge->Ini_GetString("Display", "windowed", "false"));
    zone.name = hge->Ini_GetString("Game", "starting_zone", "");
    std::string classes_file = hge->Ini_GetString("Game", "classes", "");
    std::string effects_file = hge->Ini_GetString("Game", "effects", "");
    hge->System_Log("Parsing config : done.");

    hge->System_SetState(HGE_FPS, sMaxFPS); // Set max FPS
    hge->System_SetState(HGE_WINDOWED, windowed); // Set Windowed
    hge->System_SetState(HGE_SCREENWIDTH, toInt(sWidth)); // Set screen resolution
    hge->System_SetState(HGE_SCREENHEIGHT, toInt(sHeight));
    hge->System_SetState(HGE_SCREENBPP, sDepth); // Set screen bit per pixel value

    hge->System_SetState(HGE_ICON, MAKEINTRESOURCE (1));

    hge->System_SetState(HGE_USESOUND, false); // Disactivate sound, for the moment

    if(hge->System_Initiate())
    {
    	bool debug = false;

    	// Parse starting zone
    	hge->System_Log("Parsing %s...", zone.name.c_str());
    	hge->System_SetState(HGE_INIFILE, zone.name.c_str());
    	zone.background = hge->Ini_GetString("Ressources", "background", "");
    	zone.collision = hge->Ini_GetString("Ressources", "collision", "");
    	zone.distortion = hge->Ini_GetString("Ressources", "distortion", "");
    	zone.distortion_scale_max = hge->Ini_GetFloat("Parameters", "distortion_scale_max", 1.00f);
    	zone.distortion_scale_min = hge->Ini_GetFloat("Parameters", "distortion_scale_min", 1.00f);
    	zone.distortion_vscale_max = hge->Ini_GetFloat("Parameters", "distortion_vscale_max", 1.00f);
    	zone.distortion_vscale_min = hge->Ini_GetFloat("Parameters", "distortion_vscale_min", 1.00f);
    	zone.distortion_angle_max = hge->Ini_GetFloat("Parameters", "distortion_angle_max", 0.0f);
    	zone.distortion_angle_min = hge->Ini_GetFloat("Parameters", "distortion_angle_min", 0.0f);
    	zone.w = toInt(hge->Ini_GetFloat("Parameters", "width", 1024));
    	zone.h = toInt(hge->Ini_GetFloat("Parameters", "height", 1024));
    	// Parsing doodads
    	int doodad_nbr = toInt(hge->Ini_GetFloat("Doodads", "number", 0));
    	if (doodad_nbr != 0)
    	{
    		for (int i=1; i<=doodad_nbr; i++)
    		{
    			string d_name = hge->Ini_GetString("Doodads", string("doodad_" + toString(i)).c_str(), "");
    			string d_file = hge->Ini_GetString(d_name.c_str(), "file", "");
    			mySceneManager.textureList[d_file] = hge->Texture_Load(d_file.c_str());
    			float twsize = hge->Texture_GetWidth(mySceneManager.textureList[d_file], true);
    			float thsize = hge->Texture_GetHeight(mySceneManager.textureList[d_file], true);
    			hgeSprite* d_sprite = new hgeSprite(mySceneManager.textureList[d_file],0,0,twsize,thsize);
    			float d_x = hge->Ini_GetFloat(d_name.c_str(), "x", 0);
    			float d_y = hge->Ini_GetFloat(d_name.c_str(), "y", 0);
    			float d_hx = hge->Ini_GetFloat(d_name.c_str(), "hx", twsize/2);
    			float d_hy = hge->Ini_GetFloat(d_name.c_str(), "hy", thsize/2);
    			float d_orient = hge->Ini_GetFloat(d_name.c_str(), "orientation", 0.0f);
    			bool d_intop = toBool(hge->Ini_GetString(d_name.c_str(), "always_in_top", "false"));
    			bool d_locked = toBool(hge->Ini_GetString(d_name.c_str(), "locked", "true"));
    			d_sprite->SetHotSpot(d_hx, d_hy);
    			Doodad d;
    			d.name = d_name;
    			d.sprite = d_sprite;
    			d.setX(d_x);
    			d.setY(d_y);
    			d.orientation = d_orient;
    			d.locked = d_locked;
    			d.inTop = d_intop;
    			zone.doodadList[d_name] = d;
    		}
    	}

        // Load textures
        //  # system :
        bg_tex=hge->Texture_Load(zone.background.c_str());
        bg_col_tex=hge->Texture_Load(zone.collision.c_str());
        bg_dist_tex=hge->Texture_Load(zone.distortion.c_str());
        cur_gen_tex=hge->Texture_Load("cursor.png");
        cur_atk_tex=hge->Texture_Load("attack.png");
        cur_taxi_tex==hge->Texture_Load("taxi.png");
        circle_tex=hge->Texture_Load("circle.png");
        ordercircle_tex=hge->Texture_Load("order.png");
        selectionsquare_tex=hge->Texture_Load("select_square.png");
        px_tex=hge->Texture_Load("pixel.png");
        particle_tex=hge->Texture_Load("particles.png");
        status_bar_tex=hge->Texture_Load("status_bar.png");

        particle = new hgeSprite(particle_tex,96,32,32,32);
        particle->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHAADD | BLEND_NOZWRITE);

		//  # objects :
		pshadow_tex=hge->Texture_Load("p_shadow.png");

		// Parsing classes :
        hge->System_Log("Parsing %s...", classes_file.c_str());
        hge->System_SetState(HGE_INIFILE, classes_file.c_str());
        mySceneManager.class_nbr = toInt(hge->Ini_GetFloat("General", "class_nbr", 1));
        for (int i=1; i<=mySceneManager.class_nbr; i++)
        {
        	std::string c_name = hge->Ini_GetString("General", string("class_" + toString(i)).c_str(), "");
        	if (debug) {hge->System_Log(" Loading class \"%s\"...", c_name.c_str());}
        	std::string c_animfile = hge->Ini_GetString(c_name.c_str(), "animation", "");
        	int c_maxhealth = toInt(hge->Ini_GetFloat(c_name.c_str(), "max_health", 50));
        	int c_maxmana = toInt(hge->Ini_GetFloat(c_name.c_str(), "max_mana", 0));
        	// Parsing spells
        	int spellNbr = toInt(hge->Ini_GetFloat(c_name.c_str(), "spell_nbr", 1));
        	Class tmpclass;
        	for (int j=1; j<=spellNbr; j++)
        	{
        		std::string s_name = hge->Ini_GetString(c_name.c_str(), string("spell_" + toString(j)).c_str(), "");
        		if (debug) {hge->System_Log("  Loading spell \"%s\"...", s_name.c_str());}
				float s_castTime = hge->Ini_GetFloat(s_name.c_str(), "cast_time", 1.00f);
				int s_cost = toInt(hge->Ini_GetFloat(s_name.c_str(), "cost", 0));
				int s_dmgMin = toInt(hge->Ini_GetFloat(s_name.c_str(), "damage_min", 0));
				int s_dmgMax = toInt(hge->Ini_GetFloat(s_name.c_str(), "damage_max", 1));
				float s_crits = hge->Ini_GetFloat(s_name.c_str(), "crits", 0.00f);
				std::string s_school = hge->Ini_GetString(s_name.c_str(), "school", "physical");
				bool s_cfx = toBool(hge->Ini_GetString(s_name.c_str(), "cast_fx", "false"));
				std::string s_ceffect("");
				if (s_cfx)
				{
					s_ceffect = hge->Ini_GetString(s_name.c_str(), "cast_effect", "");
				}
				bool s_afx = toBool(hge->Ini_GetString(s_name.c_str(), "attack_fx", "false"));
				std::string s_aeffect("");
				if (s_afx)
				{
					s_aeffect = hge->Ini_GetString(s_name.c_str(), "attack_effect", "");
				}
				Spell tmpspell;
				tmpspell.name = s_name;
				tmpspell.cast_time = s_castTime;
				tmpspell.cost = s_cost;
				tmpspell.dmg_min = s_dmgMin;
				tmpspell.dmg_max = s_dmgMax;
				tmpspell.crits = s_crits;
				tmpspell.school = s_school;
				tmpspell.cast_fx = s_cfx;
				tmpspell.cast_effect = s_ceffect;
				tmpspell.attack_fx = s_afx;
				tmpspell.attack_effect = s_aeffect;
        		tmpclass.spell[s_name] = tmpspell;
        	}
        	// Parsing specialisations
        	int specNbr = toInt(hge->Ini_GetFloat(c_name.c_str(), "spec_nbr", 1));
        	for (int j=1; j<=specNbr; j++)
        	{
        		std::string sp_name = hge->Ini_GetString(c_name.c_str(), string("spec_" + toString(j)).c_str(), "");
        		if (debug) {hge->System_Log("  Loading spec \"%s\"...", sp_name.c_str());}
        		std::string sp_defaultspell = hge->Ini_GetString(sp_name.c_str(), "default_spell", "");
        		Specialisation tmpspec;
        		tmpspec.name = sp_name;
        		tmpspec.defaultSpell = sp_defaultspell;
        		tmpclass.spec[sp_name] = tmpspec;
        	}
        	std::string c_defaultspec = hge->Ini_GetString(c_name.c_str(), "default_spec", "");
        	tmpclass.defaultSpec = c_defaultspec;
        	tmpclass.name = c_name;
        	tmpclass.anim_file = c_animfile;
        	tmpclass.max_health = c_maxhealth;
        	tmpclass.max_mana = c_maxmana;
        	mySceneManager.classList[c_name] = tmpclass;
        }
		// Parsing animations
    	for (map<string, Class>::iterator iter = mySceneManager.classList.begin(); iter != mySceneManager.classList.end(); iter++)
    	{
    		hge->System_Log(" Parsing %s...", (*iter).second.anim_file.c_str());
    		hge->System_SetState(HGE_INIFILE, (*iter).second.anim_file.c_str());
    		PAnim c_anim;
    		c_anim.name = hge->Ini_GetString("AnimSet", "name", "");
        	int c_offx1 = toInt(hge->Ini_GetFloat("AnimSet", "offx1", 0));
        	int c_offy1 = toInt(hge->Ini_GetFloat("AnimSet", "offy1", 0));
        	int c_offx2 = toInt(hge->Ini_GetFloat("AnimSet", "offx2", 0));
        	int c_offy2 = toInt(hge->Ini_GetFloat("AnimSet", "offy2", 0));
        	float c_scale = hge->Ini_GetFloat("AnimSet", "scale", 1.00f);
        	float c_sscale = hge->Ini_GetFloat("AnimSet", "shadow_scale", 1.00f);

        	mySceneManager.classList[(*iter).second.name].scale = c_scale;
        	mySceneManager.classList[(*iter).second.name].shadow_scale = c_sscale;
        	mySceneManager.classList[(*iter).second.name].offx1 = c_offx1;
        	mySceneManager.classList[(*iter).second.name].offy1 = c_offy1;
        	mySceneManager.classList[(*iter).second.name].offx2 = c_offx2;
        	mySceneManager.classList[(*iter).second.name].offy2 = c_offy2;

    		if (debug) {hge->System_Log(" Loading AnimSet \"%s\"...", c_anim.name.c_str());}
    		int anim_nbr = toInt(hge->Ini_GetFloat("AnimSet", "anim_nbr", 1));
    		std::string animations[anim_nbr];

    		for (int i=1; i<=anim_nbr; i++)
    		{
    			animations[i-1] = hge->Ini_GetString("AnimSet", std::string("anim_" + toString(i)).c_str(), "");
    		}

    		for (int i=0; i<anim_nbr; i++)
    		{
    			if (debug) {hge->System_Log("  Loading SubAnimation \"%s\"...", animations[i].c_str());}
    			int a_size = toInt(hge->Ini_GetFloat(animations[i].c_str(), "size", 128));
    			int a_frames = toInt(hge->Ini_GetFloat(animations[i].c_str(), "frames", 1));
    			float a_fps = hge->Ini_GetFloat(animations[i].c_str(), "fps", 10.0f);
    			int a_animPerFile = toInt(hge->Ini_GetFloat(animations[i].c_str(), "anim_per_file", 1));
    			int a_fileNbr = toInt(hge->Ini_GetFloat(animations[i].c_str(), "file_nbr", 1));
    			int a_HSX = toInt(hge->Ini_GetFloat(animations[i].c_str(), "hot_spot_x", a_size/2));
    			int a_HSY = toInt(hge->Ini_GetFloat(animations[i].c_str(), "hot_spot_y", a_size/2));
    			bool a_offset = toBool(hge->Ini_GetString(animations[i].c_str(), "self_offset", "false"));
    			bool a_loop = toBool(hge->Ini_GetString(animations[i].c_str(), "loop", "false"));
    			std::string a_files[a_fileNbr];

    			for (int j=0; j<a_fileNbr; j++)
    			{
    				a_files[j] = hge->Ini_GetString(animations[i].c_str(), std::string("file_" + toString(j+1)).c_str(), "");
					if (debug) {hge->System_Log("   Loading texture \"%s\"...", a_files[j].c_str());}
    				mySceneManager.textureList[a_files[j]] = hge->Texture_Load(a_files[j].c_str());
    			}
				Animation a;

				if (a_offset)
				{
					a.offx1 = toInt(hge->Ini_GetFloat(animations[i].c_str(), "offx1", 0));
					a.offy1 = toInt(hge->Ini_GetFloat(animations[i].c_str(), "offy1", 0));
					a.offx2 = toInt(hge->Ini_GetFloat(animations[i].c_str(), "offx2", 0));
					a.offy2 = toInt(hge->Ini_GetFloat(animations[i].c_str(), "offy2", 0));
				}
				else
				{
					a.offx1 = a.offy1 = a.offx2 = a.offy2 = 0;
				}

				int animFound=0;
				for (int j=0; j<a_fileNbr; j++)
				{
					for (int k=0; k<a_animPerFile; k++)
					{
						a.state[animFound] = new hgeAnimation
						(
							mySceneManager.textureList[a_files[j]],
							a_frames,
							a_fps,
							0,
							k*hge->Texture_GetHeight(mySceneManager.textureList[a_files[j]])/a_animPerFile,
							a_size,
							a_size
						);
						a.state[animFound]->SetHotSpot(a_HSX,a_HSY);
						if (a_loop)
						{
							a.state[animFound]->Play();
						}
						else
						{
							a.state[animFound]->SetMode(HGEANIM_FWD | HGEANIM_NOLOOP);
						}
						animFound++;
					}
    			}
    			c_anim.animation[animations[i]] = a;
    		}
    		mySceneManager.pAnimList[c_anim.name] = c_anim;
    	}
		hge->System_Log("Parsing classes : done.");

		// Parsing Effects
		hge->System_Log("Parsing %s...", effects_file.c_str());
        hge->System_SetState(HGE_INIFILE, effects_file.c_str());
        int e_spell_filenbr = toInt(hge->Ini_GetFloat("Spells", "file_nbr", 1));
        for (int i=1; i<=e_spell_filenbr; i++)
        {
        	std::string e_spellfile = hge->Ini_GetString("Spells", string("file_" + toString(i)).c_str(), "");
        	hge->System_Log(" Parsing %s...", e_spellfile.c_str());
        	hge->System_SetState(HGE_INIFILE, e_spellfile.c_str());
        	int e_spell_fxnbr = toInt(hge->Ini_GetFloat("General", "effect_nbr", 1));
        	for (int j=1; j<=e_spell_fxnbr; j++)
        	{
        		std::string fx_name = hge->Ini_GetString("General", string("effect_" + toString(j)).c_str(), "");
        		std::string fx_type = hge->Ini_GetString(fx_name.c_str(), "type", "");

        		if (fx_type == "animation")
        		{
        			if (debug) {hge->System_Log("  Loading Animated Effect \"%s\"...", fx_name.c_str());}
					int a_size = toInt(hge->Ini_GetFloat(fx_name.c_str(), "size", 128));
					int a_frames = toInt(hge->Ini_GetFloat(fx_name.c_str(), "frames", 1));
					float a_fps = hge->Ini_GetFloat(fx_name.c_str(), "fps", 1.0f);
					int a_animPerFile = toInt(hge->Ini_GetFloat(fx_name.c_str(), "anim_per_file", 1));
					int a_fileNbr = toInt(hge->Ini_GetFloat(fx_name.c_str(), "file_nbr", 1));
					int a_HSX = toInt(hge->Ini_GetFloat(fx_name.c_str(), "hot_spot_x", a_size/2));
					int a_HSY = toInt(hge->Ini_GetFloat(fx_name.c_str(), "hot_spot_y", a_size/2));
					bool a_loop = toBool(hge->Ini_GetString(fx_name.c_str(), "loop", "false"));
					float a_fadein = hge->Ini_GetFloat(fx_name.c_str(), "fade_in", 0);
					float a_fadeout = hge->Ini_GetFloat(fx_name.c_str(), "fade_out", 0);
					std::string a_blendc = hge->Ini_GetString(fx_name.c_str(), "blend_color", "multiply");
					std::string a_blenda = hge->Ini_GetString(fx_name.c_str(), "blend_alpha", "blend");
					std::string a_files[a_fileNbr];

					for (int m=0; m<a_fileNbr; m++)
					{
						a_files[m] = hge->Ini_GetString(fx_name.c_str(), std::string("file_" + toString(m+1)).c_str(), "");
						if (debug) {hge->System_Log("   Loading texture \"%s\"...", a_files[m].c_str());}
						mySceneManager.textureList[a_files[m]] = hge->Texture_Load(a_files[m].c_str());
					}

        			AnimatedEffect a;
					a.name = fx_name;
					a.fade_in = a_fadein;
					a.fade_out = a_fadeout;
					int animFound=0;
					for (int l=0; l<a_fileNbr; l++)
					{
						for (int k=0; k<a_animPerFile; k++)
						{
							a.state[animFound] = new hgeAnimation
							(
								mySceneManager.textureList[a_files[l]],
								a_frames,
								a_fps,
								0,
								k*hge->Texture_GetHeight(mySceneManager.textureList[a_files[l]])/a_animPerFile,
								a_size,
								a_size
							);
							a.state[animFound]->SetHotSpot(a_HSX,a_HSY);
							if (a_loop)
							{
								a.state[animFound]->Play();
							}
							else
							{
								a.state[animFound]->SetMode(HGEANIM_FWD | HGEANIM_NOLOOP);
							}
							if (a_blendc == "multiply")
							{
								if (a_blenda == "add")
								{
									a.state[animFound]->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHAADD | BLEND_NOZWRITE);
								}
							}
							else if (a_blendc == "add")
							{
								if (a_blenda == "blend")
								{
									a.state[animFound]->SetBlendMode(BLEND_COLORADD | BLEND_ALPHABLEND | BLEND_NOZWRITE);
								}
								else if (a_blenda == "add")
								{
									a.state[animFound]->SetBlendMode(BLEND_COLORADD | BLEND_ALPHAADD | BLEND_NOZWRITE);
								}
							}
							animFound++;
						}
					}
					mySceneManager.animatedFXList[fx_name] = a;
        		}
        		if (fx_type == "particle_system")
        		{
        			float p_fps = hge->Ini_GetFloat(fx_name.c_str(), "fps", 0);
					std::string p_file = hge->Ini_GetString(fx_name.c_str(), "file", "");
					ParticleEffect pe;
					pe.name = fx_name;
					pe.delay = hge->Ini_GetFloat(fx_name.c_str(), "fire_delay", 0.00f);
					pe.offset_x = hge->Ini_GetFloat(fx_name.c_str(), "offset_x", 0.0f);
					pe.offset_y = hge->Ini_GetFloat(fx_name.c_str(), "offset_y", 0.0f);
					pe.psys = new hgeParticleSystem(p_file.c_str(), particle, p_fps);
					mySceneManager.particleFXList[fx_name] = pe;
        		}
        	}
        }

        if((!bg_tex) || (!cur_gen_tex))
        {
            MessageBox(NULL, "Can't load ressource.", "Error", MB_OK | MB_ICONERROR | MB_APPLMODAL);
            hge->System_Shutdown();
            hge->Release();
            return 0;
        }

        pixel = new hgeSprite(px_tex,0,0,1,1);
        p_shadow = new hgeSprite(pshadow_tex,0,0,128,128);
        p_shadow->SetHotSpot(64,64);

        int startPosX = toInt((hge->Texture_GetWidth(bg_tex, true)-zone.w)/2);
        int startPosY = toInt((hge->Texture_GetHeight(bg_tex, true)-zone.h)/2);

		hge->System_Log("Creating system sprites...");
        // Create the BG sprite
        background = new hgeSprite(bg_tex,startPosX,startPosY,zone.w,zone.h);
        background->SetHotSpot(zone.w/2,zone.h/2);
        // And read data from collision an distortion textures
        zone.col = getTextureData(bg_col_tex);
        zone.dist = getTextureData(bg_dist_tex);

        mySceneManager.statusB_bg_left = new hgeSprite(status_bar_tex,0,0,3,8);
        mySceneManager.statusB_bg_middle = new hgeSprite(status_bar_tex,3,0,29,8);
        mySceneManager.statusB_bg_right = new hgeSprite(status_bar_tex,0,0,3,8);
        mySceneManager.statusB_bg_right->SetFlip(true,false);
        mySceneManager.statusB_dead_bg_left = new hgeSprite(status_bar_tex,0,8,3,8);
        mySceneManager.statusB_dead_bg_middle = new hgeSprite(status_bar_tex,3,8,29,8);
        mySceneManager.statusB_dead_bg_right = new hgeSprite(status_bar_tex,0,8,3,8);
        mySceneManager.statusB_dead_bg_right->SetFlip(true,false);
		mySceneManager.statusB_gauge = new hgeSprite(status_bar_tex,3,18,29,2);

        // Create the selection circle
        selectionCircle = new hgeSprite(circle_tex,0,0,32,32);
        selectionCircle->SetColor(ARGB(255, 20, 220, 64));
        selectionCircle->SetHotSpot(16,16);

        // Create the order circle
        orderCircle = new hgeSprite(ordercircle_tex,0,0,32,32);
        orderCircle->SetColor(ARGB(255, 20, 220, 64));
        orderCircle->SetHotSpot(16,16);

        // Create the selection square
        selectionSquare = new hgeSprite(selectionsquare_tex,2,2,28,28);
        selectionSquare->SetHotSpot(0,0);
        selectionSquareLeftBorder = new hgeSprite(selectionsquare_tex,0,0,1,28);
        selectionSquareLeftBorder->SetHotSpot(0,0);
        selectionSquareRightBorder = new hgeSprite(selectionsquare_tex,0,0,1,28);
        selectionSquareRightBorder->SetHotSpot(0,0);
        selectionSquareTopBorder = new hgeSprite(selectionsquare_tex,0,0,28,1);
        selectionSquareTopBorder->SetHotSpot(0,0);
        selectionSquareBottomBorder = new hgeSprite(selectionsquare_tex,0,0,28,1);
        selectionSquareBottomBorder->SetHotSpot(0,0);

        // Create the screen BBs
        screenLTRect = new hgeRect(0, 0, sWidth/2, sHeight/2);
        screenRTRect = new hgeRect(sWidth/2, 0, sWidth, sHeight/2);
        screenRBRect = new hgeRect(sWidth/2, sHeight/2, sWidth, sHeight);
        screenLBRect = new hgeRect(0, sHeight/2, sWidth/2, sHeight);

        screenLRect2 = new hgeRect(0, 0, 4, sHeight);
        screenTRect2 = new hgeRect(0, 0, sWidth, 4);
        screenRRect2 = new hgeRect(sWidth-4, 0, sWidth, sHeight);
        screenBRect2 = new hgeRect(0, sHeight-4, sWidth, sHeight);

        // Load a font
        fnt = new hgeFont("font1.fnt");

        // Create the cursor
        cursor = new hgeSprite(cur_gen_tex,0,0,32,32);

        hge->System_Log("Creating system sprites : done.");
        hge->System_Log("Creating units...");

        // Create units
        Unit* p1 = mySceneManager.createUnit("Player1", 270, 560, pSpeed);
        p1->setClass(mySceneManager.getClass("mage"));

        Unit* p4 = mySceneManager.createUnit("Player4", 625, 410, pSpeed);
        p4->setClass(mySceneManager.getClass("mage"));

        Unit* p5 = mySceneManager.createUnit("Player5", 700, 700, pSpeed);
        p5->setClass(mySceneManager.getClass("mage"));

        Unit* p6 = mySceneManager.createUnit("Player6", 420, 340, pSpeed);
        p6->setClass(mySceneManager.getClass("mage"));

        Unit* p7 = mySceneManager.createUnit("Player7", 515, 630, pSpeed);
        p7->setClass(mySceneManager.getClass("mage"));

        Unit* p8 = mySceneManager.createUnit("Player8", 600, 590, pSpeed);
        p8->setClass(mySceneManager.getClass("mage"));

        Unit* p9 = mySceneManager.createUnit("Player9", 630, 160, pSpeed);
        p9->setClass(mySceneManager.getClass("mage"));

        Unit* p10 = mySceneManager.createUnit("Player10", 140, 660, pSpeed);
        p10->setClass(mySceneManager.getClass("mage"));

        Unit* p2 = mySceneManager.createUnit("Player2", 550, 460, pSpeed);
        p2->setClass(mySceneManager.getClass("hunter"));
        p2->setRot(3);
        p2->setHostile(true);

        Unit* p3 = mySceneManager.createUnit("Player3", 300, 500, pSpeed);
        p3->setClass(mySceneManager.getClass("hunter"));

        hge->System_Log("Creating units : done.");

        bgx = sWidth/2; bgy = sHeight/2;
		invx = sWidth/2; invy = sHeight/2;
		mySceneManager.gx = (sWidth-1024.0f)/2.0f; mySceneManager.gy = (sHeight-768.0f)/2.0f;

        hge->System_Log("Now playing...");

        // Start
        hge->System_Start();

        hge->System_Log("Game ended.");

        // End, delete sprites, free the textures
        delete background;
        delete cursor;
        delete selectionCircle;
        delete orderCircle;
        delete pixel;
        delete p_shadow;

        hge->Texture_Free(bg_tex);
        hge->Texture_Free(bg_col_tex);
        hge->Texture_Free(bg_dist_tex);
        hge->Texture_Free(cur_gen_tex);
        hge->Texture_Free(cur_atk_tex);
        hge->Texture_Free(cur_taxi_tex);
        hge->Texture_Free(circle_tex);
        hge->Texture_Free(px_tex);
        hge->Texture_Free(pshadow_tex);
        hge->Texture_Free(ordercircle_tex);
        hge->Texture_Free(selectionsquare_tex);

        map<string, HTEXTURE>::iterator iterTex;
        for (iterTex = mySceneManager.textureList.begin(); iterTex != mySceneManager.textureList.end(); iterTex++)
        {
        	hge->Texture_Free(iterTex->second);
        }
    }
    else
    {
        MessageBox(NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_APPLMODAL);
    }

    hge->System_Shutdown();

    hge->Release();

    return 0;
}

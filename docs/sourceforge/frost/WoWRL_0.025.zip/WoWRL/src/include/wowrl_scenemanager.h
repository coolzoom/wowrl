/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          Scene manager header          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_SCENEMANAGER_H
#define WOWRL_SCENEMANAGER_H

#include "wowrl_unit.h"
#include "wowrl_projectile.h"
#include "wowrl_structs2.h"


class SceneManager
{
public :

	float gx, gy;

	// Textures
	std::map<std::string, HTEXTURE> textureList;

    // Classes
    int class_nbr;
    std::map<std::string, Class> classList;
	Class* getClass(std::string name);

	// Z sorted object list for rendering
	std::map<float, Object> zSortedList;
	std::map<float, Doodad*> renderInTopList;

	// Units
	//  # functions
    Unit* createUnit(std::string name);
    Unit* createUnit
    (
    	std::string name,
		float x, float y,
		float speed
	);
    Unit* getUnitByName(std::string name);
    //  # lists
	std::map<std::string, Unit> unitList;
	std::map<std::string, Unit*> hostileList;
	std::map<std::string, Unit*> selectedList;
	std::map<std::string, Unit*> targetList;
	std::map<std::string, Unit*> attackerList;
	std::map<std::string, Unit*> deadList;

	// Animations
    std::map<std::string, PAnim> pAnimList;

    // Effects
    int particle_effect_nbr;
    int animated_effect_nbr;
    std::map<std::string, ParticleEffect> particleFXList;
    std::map<std::string, AnimatedEffect> animatedFXList;

    // Projectiles
    void createProjectile
    (
		std::string,
		Unit*,
		Unit*
	);
    std::map<std::string, Projectile> projectileList;

    // StatusBar
    void createStatusBar
    (
		Unit*
	);
    std::map<std::string, StatusBar> statusBarList;
    hgeSprite*          statusB_bg_left;
	hgeSprite*          statusB_bg_middle;
	hgeSprite*          statusB_bg_right;
	hgeSprite*          statusB_dead_bg_left;
	hgeSprite*          statusB_dead_bg_middle;
	hgeSprite*          statusB_dead_bg_right;
	hgeSprite*          statusB_gauge;

protected :

};

#endif

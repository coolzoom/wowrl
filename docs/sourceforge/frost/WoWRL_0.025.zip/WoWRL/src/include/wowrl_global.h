/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             Global header              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_GLOBAL_H
#define WOWRL_GLOBAL_H

#include "hgesprite.h"
#include <string>

std::string toString( int i );
int toInt( float f );
int signOf( float f );
bool toBool( char* c );
float rac2( float f );
float carre( float f );
float dist( Point p1, Point p2 );
void setGlowing( hgeSprite* Sprite, float timerAlpha, float speed = 2.0f );
float radToDeg( float r, bool negativeDeg = true );
float degToRad( float d );

#endif

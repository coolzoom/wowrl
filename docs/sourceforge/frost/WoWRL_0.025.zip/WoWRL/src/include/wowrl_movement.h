/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Movement header             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_MOVEMENT_H
#define WOWRL_MOVEMENT_H

bool goTo(Unit* unit, Point destPoint);
bool followPath(Unit* unit, std::vector<Point> path);

#endif

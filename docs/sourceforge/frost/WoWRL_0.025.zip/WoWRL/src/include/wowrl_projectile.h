/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Projectile header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_PROJECTILE_H
#define WOWRL_PROJECTILE_H

#include "hge.h"
#include "hgeparticle.h"

#include "wowrl_unit.h"

class Projectile
{
public :

    Projectile();
    Projectile(std::string, Unit*, Unit*);
    ~Projectile();

    hgeParticleSystem* getPSys();
    float getZ();
    Unit* getParent();
    Spell* getSpell();
    Unit* getDestination();

    void setDestination(Unit*);
    void stop();
    bool updatePos();

    float x;
    float y;

    bool arrived;

private :

	Unit* m_destination;
	Unit* m_origin;
	Spell* m_spell;
	hgeParticleSystem* m_psys;
	std::string m_psysname;
	std::string m_old_psysname;
};

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Unit header               */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_UNIT_H
#define WOWRL_UNIT_H

#include <map>
#include <string>
#include <vector>
#include "hge.h"
#include "hgeanim.h"

#include "wowrl_structs.h"
#include "wowrl_structs2.h"

class Unit
{
public :

    Unit();
    Unit(std::string);
    Unit(std::string name, float x, float y, float speed);
    ~Unit();

	// Graphic functions
	//  # outputs
	float getX();
    float getY();
	Point getPoint();
	int getRot();
    float getSpeed();
    float getScale();
    float getVScale();
    float getAngle();
    float getZ();
    float getRelativeDepth(Point);
    float getShadow();
    std::string getAnimState();
    hgeAnimation* getAnimation();
    hgeAnimation* getEffect();
    std::string getEffectName();
    hgeRect* getBox();
    hgeRect* getStandBox();
    RGB getColor();
    StatusBar* getStatusBar();
    bool intersects(Object);
    //  # inputs
    void setX(float);
    void setY(float);
    void setRot(int);
    void setRotFromAngle(float);
    void setSpeed(float);
    void setScale(float);
    void setAnimState(std::string);
    void updateAttack(float);
    void setEffect(std::string);
    void setColor(RGB);
    void setColor(int,int,int);

    Class* getClass();
	void setClass(Class*);

    // Gameplay functions
    //  # outputs
    std::string getName();
    bool isHostile();
	bool isSelected();
	Spell* getSpell();
	bool isAttacking();
	bool isDead();
    //  # inputs
    //void setName(std::string);
    void setHostile(bool);
    void setSelected(bool);
    void target(std::string);
    void target(Unit*);
    void attack(std::string);
    void attack(Unit*);
    void attack();
    void stopAttack();
    void hit(Spell*);
    void kill();

	// Public members
    bool hidden;
	bool dying;
    std::vector<Point> path;
    int pointIndice;
    bool following;
    Point destPoint;
	float alphaFXTimer;
	bool FXFaded;
	bool FXPlaying;
	float rz;

private :

    std::string m_name;
	float m_x;
	float m_y;
	float m_orientation;
	int m_rot;
	int m_old_rot;
	float m_speed;
	float m_scale;
	Class* m_class;
	Spell* m_spell;
	Specialisation* m_spec;
	hgeRect* m_box;
	std::string m_animstate;
	std::string m_old_animstate;
	hgeAnimation* m_animation;
	std::string m_effectstate;
	std::string m_old_effectstate;
	hgeAnimation* m_effect;
	RGB m_color;
	float m_shadow;
	StatusBar* m_status_bar;

	Unit* m_target;
	float m_attack_timer;
	bool m_hostile;
	bool m_selected;
	bool m_attacking;
	bool m_projectile;
	bool m_dead;
	bool m_finishAnim;
	float m_health;
	float m_mana;
	int m_max_health;
	int m_max_mana;
};

#endif

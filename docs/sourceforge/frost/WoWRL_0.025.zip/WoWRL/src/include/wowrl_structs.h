/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Structures header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_STRUCTS_H
#define WOWRL_STRUCTS_H

#include "hgeanim.h"
#include "hgeparticle.h"
#include <string>
#include <map>

#include "wowrl_point.h"
#include "wowrl_global.h"
#include "wowrl_doodad.h"

/*struct Path
{
	Point point[512];
	//std::vector<Point> point;
	int length;
};*/

struct RGB
{
	float R;
	float G;
	float B;
};

struct Spell
{
	std::string name;
	float cast_time;
	float cost;
	float dmg_min;
	float dmg_max;
	float crits;
	std::string school;
	bool cast_fx;
	std::string cast_effect;
	bool attack_fx;
	std::string attack_effect;
};

struct Specialisation
{
	std::string name;
	std::string defaultSpell;
};

struct Class
{
	std::string name;
	float scale;
	float shadow_scale;
	std::string anim_file;
	std::map<std::string, Spell> spell;
	std::map<std::string, Specialisation> spec;
	int offx1, offy1, offx2, offy2;
	std::string defaultSpec;
	int max_health;
	int max_mana;
};

struct StatusBar
{
	hgeSprite* background_left;
	hgeSprite* background_middle;
	hgeSprite* background_right;
	hgeSprite* gauge;
	float size;
	float state;
	RGB color;
	std::string parent;
};

struct Animation
{
    hgeAnimation* state[8];
    int offx1, offy1, offx2, offy2;
};

struct AnimatedEffect
{
	std::string name;
	float fade_in;
	float fade_out;
	hgeAnimation* state[8];
};

struct ParticleEffect
{
	std::string name;
	hgeParticleSystem* psys;
	float offset_x;
	float offset_y;
	float delay;
};

struct PAnim
{
	std::string name;
	int anim_nbr;
	std::map<std::string, Animation> animation;
};

#endif

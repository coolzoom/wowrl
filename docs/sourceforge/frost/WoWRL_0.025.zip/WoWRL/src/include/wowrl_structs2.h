#ifndef WOWRL_STRUCTS2_H
#define WOWRL_STRUCTS2_H

struct Object
{
	std::string type;
	void* ptr;
};

#endif

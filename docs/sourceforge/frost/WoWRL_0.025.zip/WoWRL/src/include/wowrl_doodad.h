/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Doodad header             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_DOODAD_H
#define WOWRL_DOODAD_H

#include <string>
#include "hgesprite.h"
#include "wowrl_point.h"

class Doodad
{
public :

    Doodad();
    ~Doodad();

    void setX(float);
	void setY(float);
	float getX();
	float getY();
    float getZ();
    hgeRect* getBox();
    float getRelativeDepth(Point);

	std::string name;
	hgeSprite* sprite;
	float z;
	float orientation;
	bool locked;
	bool inTop;

private :

	float m_x;
	float m_y;

};

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Collision header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_COLLISION_H
#define WOWRL_COLLISION_H

DWORD* getTextureData(HTEXTURE tex);
bool CheckPointCollision(int x, int y);
DWORD getColor(int x, int y);
Point getNearestAlignedFreePoint(int objx, int objy, int destx, int desty);
Point getNearestFreePoint(float xi, float yi, int destx, int desty, int precision = 10, int range = 512);

#endif

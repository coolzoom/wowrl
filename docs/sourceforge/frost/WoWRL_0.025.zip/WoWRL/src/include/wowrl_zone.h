/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Zone header               */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_ZONE_H
#define WOWRL_ZONE_H

#include "wowrl_structs.h"

class Zone
{
public :

    Zone();
    ~Zone();

    std::string name;
	std::string background;
	std::string collision;
	std::string distortion;
	float distortion_scale_max;
	float distortion_scale_min;
	float distortion_vscale_max;
	float distortion_vscale_min;
	float distortion_angle_max;
	float distortion_angle_min;
	std::map<std::string, Doodad> doodadList;
	int w;
	int h;
	float respawnTime;
	std::map<std::string, float> respawn;

	DWORD* col;
	DWORD* dist;

private :

};

#endif

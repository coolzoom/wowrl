-- Initialization script : executed once, just after zone loading

local pSpeed = 150;

UnitSpawn("Kalette", 2300, 1050, 70, "mage", pSpeed);
UnitSpawn("Kaloth", 2390, 1130, 65, "hunter", pSpeed);
UnitSpawn("Mercy", 2500, 1200, 45, "priest", pSpeed);
UnitSpawn("Insanity", 1738, 1600, 70, "hunter", pSpeed);
UnitSetHostile("Insanity", true);
--UnitSetMaxHP("Insanity", 50000, true);
UnitSetAggroRange("Insanity", 40);








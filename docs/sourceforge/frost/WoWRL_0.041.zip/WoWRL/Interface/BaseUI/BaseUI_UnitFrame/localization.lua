
if ( GetLocale() == "frFR" ) then
	
	-- FRANCAIS
	UNITFRAME_DEAD = "MORT";

else

	-- ENGLISH, default
	UNITFRAME_DEAD = "DEAD";

end

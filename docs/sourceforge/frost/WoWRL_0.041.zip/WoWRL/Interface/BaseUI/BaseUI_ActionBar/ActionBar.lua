
---------
function BUI_AB_OnLoad()
---------
	ActionBar:SetWidth(Display_screen_width);
	ActionBarTex:SetTexCoord(0, Display_screen_width/256, 0, 1);

end


ChangeToolTipContent = true;
AskingForTooltip = 0;
NewContent = nil;

---------
function BUI_GameTooltip_OnLoad()
---------
	GameTooltip.textNbr = 5;
	for i=1, GameTooltip.textNbr do
		local FString = GetGlobal("GameTooltipTextLeft" .. i)
		FString:SetWidth(GameTooltip:GetWidth()-26);
		FString:SetHeight(16);
		FString:SetPoint("TOPLEFT", "GameTooltip", "TOPLEFT", 13, -10-16*(i-1));
		FString:SetText(tostring(i));
	end
	
	for i=1, GameTooltip.textNbr do
		local FString = GetGlobal("GameTooltipTextRight" .. i)
		FString:SetWidth(GameTooltip:GetWidth()-26);
		FString:SetHeight(16);
		FString:SetPoint("TOPRIGHT", "GameTooltip", "TOPRIGHT", -13, -10-16*(i-1));
		FString:SetText(tostring(i));
	end
end

---------
function BUI_GameTooltip_OnUpdate()
---------
	if (AskingForTooltip == 0) then
		NewContent = nil;
	end
	
	-- Check if the tooltip must be updated
	if (ChangeToolTipContent) then
		if (NewContent ~= nil) then
			local nw = 250;
			local ny = 0;
		
			if (NewContent.type == "spell") then
				-- It's a spell tooltip, we fill the necessary data :
				local left = 1;
				local right = 1;
				local text;
				-- Name
				GameTooltipTextLeft1:Show();
				GameTooltipTextLeft1:SetFont("Fonts/CalibriBold.ttf", 16, "OUTLINE, BOLD");
				GameTooltipTextLeft1:SetTextColor(1,1,1);
				GameTooltipTextLeft1:SetText(GetLocalizedString(NewContent.content.display_name));
				left = left+1
				-- Rank
				if (NewContent.content.rank ~= -1) then
					GameTooltipTextRight1:Show();
					local rank = StrReplace(TT_SPELL_RANK, "[rank]", tostring(NewContent.content.rank));
					GameTooltipTextRight1:SetFont("Fonts/CalibriBold.ttf", 16, "OUTLINE, BOLD");
					GameTooltipTextRight1:SetTextColor(0.66,0.66,0.66);
					GameTooltipTextRight1:SetText(rank);
				else
					GameTooltipTextRight1:Hide();
				end
				right = right+1;
				-- Cost, only if there is one
				if ((NewContent.content.cost_percent ~= 0) or (NewContent.content.cost ~= 0)) then
					GameTooltipTextLeft2:Show();
					local cost;
					if (NewContent.content.cost_percent ~= 0) then
						cost = StrReplace(TT_SPELL_OFMAX, "[cost_percent]", tostring(NewContent.content.cost_percent*100));
					else
						cost = StrReplace(TT_SPELL_COST, "[cost]", tostring(NewContent.content.cost));
						cost = StrReplace(cost, "[cost_type]", tostring(NewContent.content.cost_type));
					end
					GameTooltipTextLeft2:SetFont("Fonts/Calibri.ttf", 13);
					GameTooltipTextLeft2:SetTextColor(1,1,1);
					GameTooltipTextLeft2:SetText(StrCapitalStart(cost));
					left = left+1;
				else
					GameTooltipTextLeft2:Hide();
				end
				-- Cast time
				text = GetGlobal("GameTooltipTextLeft" .. left);
				text:Show();
				local castTime;
				if (NewContent.content.cast_time > 0) then
					castTime = StrReplace(TT_SPELL_CASTTIME, "[cast_time]", tostring(NewContent.content.cast_time));
				else
					castTime = TT_SPELL_INSTANT;
				end
				text:SetFont("Fonts/Calibri.ttf", 13);
				text:SetTextColor(1,1,1);
				text:SetText(castTime);
				left = left+1;
				-- Range
				text = GetGlobal("GameTooltipTextRight" .. right);
				text:Show();
				local range = StrReplace(TT_SPELL_RANGE, "[range]", tostring(NewContent.content.range));
				text:SetFont("Fonts/Calibri.ttf", 13);
				text:SetTextColor(1,1,1);
				text:SetText(range);
				right = right+1;
				-- Description
				text = GetGlobal("GameTooltipTextLeft" .. math.max(left,right));
				text:Show();
				text:SetFont("Fonts/Calibri.ttf", 13);
				text:SetTextColor(1,0.86,0);			
				text:SetText(FillSpellInfo(GetLocalizedString(NewContent.content.description), Spells[NewContent.content.name]));
				local exclude = math.max(left,right);
				
				-- And we hide unused font strings
				for i=left, GameTooltip.textNbr do
					if (i ~= exclude) then
						GetGlobal("GameTooltipTextLeft" .. i):Hide();
					end
				end
				for i=right, GameTooltip.textNbr do
					GetGlobal("GameTooltipTextRight" .. i):Hide();
				end
				
			elseif (NewContent.type == "stop") then
				-- It's a stop button tooltip
				GameTooltipTextLeft1:Show();
				GameTooltipTextLeft1:SetFont("Fonts/CalibriBold.ttf", 16, "OUTLINE, BOLD");
				GameTooltipTextLeft1:SetTextColor(1,1,1);
				GameTooltipTextLeft1:SetText(GetLocalizedString("help_stop_title"));
				GameTooltipTextLeft2:Show();
				GameTooltipTextLeft2:SetFont("Fonts/Calibri.ttf", 13);
				GameTooltipTextLeft2:SetTextColor(1,0.86,0);
				GameTooltipTextLeft2:SetText(GetLocalizedString("help_stop_desc"));
				
				-- And we hide unused font strings
				for i=3, GameTooltip.textNbr do
					GetGlobal("GameTooltipTextLeft" .. i):Hide();
				end
				for i=1, GameTooltip.textNbr do
					GetGlobal("GameTooltipTextRight" .. i):Hide();
				end
				
			elseif (NewContent.type == "unit") then
				-- It's a unit tooltip
				GameTooltipTextLeft1:Show();
				GameTooltipTextLeft1:SetFont("Fonts/CalibriBold.ttf", 16, "OUTLINE, BOLD");
				GameTooltipTextLeft1:SetTextColor(1,1,1);
				GameTooltipTextLeft1:SetText(NewContent.id);
				
				for i=2, GameTooltip.textNbr do
					GetGlobal("GameTooltipTextLeft" .. i):Hide();
				end
				for i=1, GameTooltip.textNbr do
					GetGlobal("GameTooltipTextRight" .. i):Hide();
				end

				nw = GameTooltipTextLeft1:GetStringWidth() + 26;
				
			end
		
			-- We get the lowest line to determine the tooltip's height
			for i=1, 5 do
				local FString = GetGlobal("GameTooltipTextLeft" .. i)
				local anchor, parent, relativePt, x, y = FString:GetPoint();
				if ( (y-FString:GetHeight() < ny) and (FString:IsShown()) ) then
					ny = y-FString:GetHeight();
				end
			end
			for i=1, 5 do
				local FString = GetGlobal("GameTooltipTextRight" .. i)
				local anchor, parent, relativePt, x, y = FString:GetPoint();
				if ( (y-FString:GetHeight() < ny) and (FString:IsShown()) ) then
					ny = y-FString:GetHeight();
				end
			end
			
			ny = math.abs(ny) + 20;
			GameTooltip:SetHeight(ny);
			GameTooltip:SetWidth(nw);
			
			GameTooltip:Show();
		else
			GameTooltip:Hide();
		end
		
		ChangeToolTipContent = false;
	end
	
	if (GameTooltip:IsVisible()) then
		local anchorS;
		local mx, my = GetMousePos();
		
		if (mx < GameTooltip:GetWidth()/2) then
			mx = GameTooltip:GetWidth()/2;
		elseif (mx > Display_screen_width-GameTooltip:GetWidth()/2) then
			mx = Display_screen_width-GameTooltip:GetWidth()/2;
		end
		
		if (my < GameTooltip:GetHeight()) then
			my = GameTooltip:GetHeight();
		end
		
		GameTooltip:SetPoint("BOTTOM", "UIParent", "TOPLEFT", mx, -my);
	end
end

---------
function FillSpellInfo(description, spell)
---------
	description = StrReplace(description, "[display_name]", spell.display_name);
	description = StrReplace(description, "[rank]", tostring(spell.rank));
	description = StrReplace(description, "[cast_time]", tostring(spell.cast_time));
	local cost;
	if ( (spell.cost == 0) and (spell.cost_percent ~= 0) ) then
		cost = tostring(100*spell.cost_percent)..StrReplace(TT_SPELL_OFMAX, "[cost_percent]", "");
	else
		cost = tostring(spell.cost);
	end
	description = StrReplace(description, "[cost]", cost);
	description = StrReplace(description, "[cost_type]", spell.cost_type);
	description = StrReplace(description, "[range]", tostring(spell.range));
	description = StrReplace(description, "[crits]", tostring(spell.crits*100));
	description = StrReplace(description, "[school]", spell.school);
	description = StrReplace(description, "[damage_min]", tostring(spell.dmg_min));
	description = StrReplace(description, "[damage_max]", tostring(spell.dmg_max));
	description = StrReplace(description, "[heal_min]", tostring(spell.heal_min));
	description = StrReplace(description, "[heal_max]", tostring(spell.heal_max));
	description = StrReplace(description, "[health_recovered]", tostring(spell.health_recovered));
	description = StrReplace(description, "[mana_recovered]", tostring(spell.mana_recovered));

	return description;
end

-- Spell database

Spells = {
	-- # Default values :
	-- display_name : no default
	-- description : no default
	-- icon : "Icons/INV_Misc_QuestionMark.png"
	-- rank : -1 (no rank)
	-- cast_time : 0 (instant)
	-- cost : 0
	-- cost_proportion : 0
	-- cost_type : "" (only use if cost and cost_proportion = 0)
	-- range : 5 (melee)
	-- school : SPELL_SCHOOL_NONE (physical)
	-- crits : 0
	-- usable_in_combat : true
	-- puts_in_combat : true
	-- self_only : false
	-- loop : true
	-- cast_effect : "" (none)
	-- attack_effect : "" (none)
	-- projectile : false
	-- projectile_speed : 600
	-- channeled : false
	-- target : "hostiles"
	-- damage_min : 0
	-- damage_max : damage_min
	-- heal_min : 0
	-- heal_max : heal_min
	-- health_recovered : 1
	-- mana_recovered : 0
	-- buff : "" (none)
	-- scripts :
	-- -- OnCastBegin : "" (none)
	-- -- OnCasted : "" (none)
	-- -- OnImpact : "" (none)
	-- -- OnUpdate : "" (none)
	
	-- GENERAL
	["auto_shoot"] = {
		["display_name"] = "spell_autoshoot_name";
		["description"] = "spell_autoshoot_desc";
		["icon"] = "Icons/INV_Weapon_Rifle_08.png";
		["cast_time"] = 1.8;
		["range"] = 35;
		["crits"] = 0.30;
		["damage_min"] = 250;
		["damage_max"] = 400;
		["target"] = "hostiles";
		["scripts"] = {
			["OnCastBegin"] = "Spell_SetAttack(unit);";
			["OnImpact"] = "Spell_DirectDamage_Impact(unit, target, spell);";
		},
	},
	
	-- MAGE
	["frostbolt_rk11"] = {
		["display_name"] = "spell_frostbolt_name";
		["description"] = "spell_frostbolt_desc";
		["icon"] = "Icons/Spell_Frost_FrostBolt.png";
		["rank"] = 11;
		["cast_time"] = 3;
		["cost"] = 290;
		["cost_type"] = "mana";
		["range"] = 30;
		["school"] = SPELL_SCHOOL_FROST;
		["crits"] = 0.10;
		["damage_min"] = 515;
		["damage_max"] = 555;
		["projectile"] = true;
		["attack_effect"] = "mage_frostbolt";
		["cast_effect"] = "mage_casting_frost";
		["target"] = "hostiles";		
		["scripts"] = {
			["OnCastBegin"] = "Spell_SetAttack(unit);";
			["OnImpact"] = "Spell_DirectDamage_Impact(unit, target, spell);";
		},
	},
	["chilling_armor_rk1"] = {
		["display_name"] = "spell_chilling_armor_name";
		["description"] = "spell_chilling_armor_desc";
		["icon"] = "Icons/Spell_Frost_ChillingArmor.png";
		["rank"] = 1;
		["cost"] = 90;
		["cost_type"] = "mana";
		["self_only"] = true;
		["loop"] = false;
		["school"] = SPELL_SCHOOL_FROST;
		["buff_effect"] = "mage_chilling_armor";
		["buff"] = "chilling_armor_rk1";
		["scripts"] = {
			["OnCastBegin"] = "Spell_SetAttack(unit);";
			["OnImpact"] = "Spell_ApplyBuff(unit, target, spell); Spell_AddBuffEffect(target, spell);";
		},
	},
	
	-- PRIEST
	["greater_heal_rk5"] = {
		["display_name"] = "spell_greaterheal_name";
		["description"] = "spell_greaterheal_desc";
		["icon"] = "Icons/Spell_Holy_GreaterHeal.png";
		["rank"] = 5;
		["cast_time"] = 3;
		["cost"] = 710;
		["cost_type"] = "mana";
		["range"] = 40;
		["school"] = SPELL_SCHOOL_HOLY;
		["crits"] = 0.20;
		["heal_min"] = 1966;
		["heal_max"] = 2194;
		["puts_in_combat"] = false;
		["target"] = "friends";
		["scripts"] = {
			["OnCastBegin"] = "Spell_SetHeal(unit);";
			["OnImpact"] = "Spell_DirectHeal_Impact(unit, target, spell);";
		},
	},
	["resurrection_rk5"] = {
		["display_name"] = "spell_resurrection_name";
		["description"] = "spell_resurrection_desc";
		["icon"] = "Icons/Spell_Holy_Resurrection.png";
		["rank"] = 5;
		["cast_time"] = 10;
		["cost_percent"] = 0.60;
		["cost_type"] = "mana";
		["range"] = 30;
		["usable_in_combat"] = false;
		["loop"] = false;
		["school"] = SPELL_SCHOOL_HOLY;
		["health_recovered"] = 750;
		["mana_recovered"] = 1000;
		["puts_in_combat"] = false;
		["target"] = "dead_friends";
		["scripts"] = {
			["OnCastBegin"] = "Spell_SetRessurect(unit);";
			["OnImpact"] = "Spell_Resurrect_Impact(unit, target, spell);";
		},
	},
}
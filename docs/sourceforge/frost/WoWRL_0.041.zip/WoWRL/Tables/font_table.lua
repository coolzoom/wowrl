-- Bitmap fonts database

Fonts_default_font = "calibri";
Fonts = {
	[1] = {
	    ["name"] = "calibri";
	    ["tracking"] = 0;
	    ["subfonts"] = {
			[1] = {
				["size"] = 10;
				["file"] = "Fonts/Calibri/Calibri_10.fnt";
			},
		    [2] = {
				["size"] = 13;
				["file"] = "Fonts/Calibri/Calibri_13.fnt";
			},
			[3] = {
				["size"] = 15;
				["file"] = "Fonts/Calibri/Calibri_15.fnt";
			},
			[4] = {
				["size"] = 16;
				["file"] = "Fonts/Calibri/Calibri_16.fnt";
			},
			[5] = {
				["size"] = 20;
				["file"] = "Fonts/Calibri/Calibri_20.fnt";
			},
			[6] = {
				["size"] = 24;
				["file"] = "Fonts/Calibri/Calibri_24.fnt";
			},
			[7] = {
				["size"] = 32;
				["file"] = "Fonts/Calibri/Calibri_32.fnt";
			},
	    },
	},
	[2] = {
	    ["name"] = "calibri_bold";
	    ["tracking"] = 0;
	    ["subfonts"] = {
	    	[1] = {
				["size"] = 14;
				["file"] = "Fonts/Calibri_bold/Calibri_bold_14.fnt";
			},
			[2] = {
				["size"] = 16;
				["file"] = "Fonts/Calibri_bold/Calibri_bold_16.fnt";
			},
			[3] = {
				["size"] = 18;
				["file"] = "Fonts/Calibri_bold/Calibri_bold_18.fnt";
			},
			[4] = {
				["size"] = 20;
				["file"] = "Fonts/Calibri_bold/Calibri_bold_20.fnt";
			},
			[5] = {
				["size"] = 22;
				["file"] = "Fonts/Calibri_bold/Calibri_bold_22.fnt";
			},
	    },
	},
	[3] = {
	    ["name"] = "calibri_bold_out";
		["tracking"] = -4;
		["subfonts"] = {
			[1] = {
				["size"] = 16;
				["file"] = "Fonts/Calibri_bold_out/Calibri_bold_out_16.fnt";
			},
			[2] = {
				["size"] = 18;
				["file"] = "Fonts/Calibri_bold_out/Calibri_bold_out_18.fnt";
			},
			[3] = {
				["size"] = 20;
				["file"] = "Fonts/Calibri_bold_out/Calibri_bold_out_20.fnt";
			},
			[4] = {
				["size"] = 24;
				["file"] = "Fonts/Calibri_bold_out/Calibri_bold_out_24.fnt";
			},
			[5] = {
				["size"] = 32;
				["file"] = "Fonts/Calibri_bold_out/Calibri_bold_out_32.fnt";
			},
	    },
	},
}
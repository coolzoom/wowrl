-- Spell scripts database

-- Base functions :
-- DAMAGE :
---------
function Spell_SetAttack(unit)
---------
	UnitSetAttacking(unit);
end

---------
function Spell_DirectDamage_Impact(unit, target, spell)
---------
	if (RandomFloat(0,1) < spell.crits) then
		UnitDamage(target, unit, RandomInt(spell.damage_min*1.5, spell.damage_max*1.5), spell.school, true, true);
	else
		UnitDamage(target, unit, RandomInt(spell.damage_min, spell.damage_max), spell.school, true, true);
	end
end

-- HEALS :
---------
function Spell_SetHeal(unit)
---------
	UnitSetHealing(unit);
end

---------
function Spell_DirectHeal_Impact(unit, target, spell)
---------
	if (RandomFloat(0,1) < spell.crits) then
		UnitHeal(target, unit, RandomInt(spell.heal_min*1.5, spell.heal_max*1.5), true, true);
	else
		UnitHeal(target, unit, RandomInt(spell.heal_min, spell.heal_max), true, true);
	end
end

---------
function Spell_SetRessurect(unit)
---------
	UnitSetResurrecting(unit);
end

---------
function Spell_Resurrect_Impact(unit, target, spell)
---------
	UnitRes(target, unit, spell.health_recovered, spell.mana_recovered);
end

-- BUFFS :
---------
function Spell_ApplyBuff(unit, target, spell)
---------
	UnitAddBuff(target, unit, spell.buff);
end

-- EFFECTS :
---------
function Spell_AddBuffEffect(target, spell)
---------
	UnitAddEffect(target, spell.buff_effect);
end

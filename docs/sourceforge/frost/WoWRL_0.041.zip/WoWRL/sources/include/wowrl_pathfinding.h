/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Pathfinding header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_PATHFINDING_H
#define WOWRL_PATHFINDING_H

#include "wowrl.h"

std::vector<Point> getDestPoints(Unit* leader, int pointNumber, float space);
Point getNearestInRangePoint(float xi, float yi, float destx, float desty, float range);
Waypoint* findNearestWaypoint(float x, float y);
std::vector<Point> getWaypoints(float xi, float yi, float destx, float desty);
std::vector<Point> getShortestPath(float xi, float yi, float destx, float desty, float range = 0.0f);
std::vector<Point> simplifyPath(std::vector<Point> path);

#endif

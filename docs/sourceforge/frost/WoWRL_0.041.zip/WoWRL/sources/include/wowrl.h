#define GAMEVERSION 0.041

/***************/
/* GAME STATES */
/***************/
#define GAME    0
#define LOADING 1

/****************/
/* OBJECT TYPES */
/****************/
#define UNIT   0
#define DOODAD 1

/***********/
/* EFFECTS */
/***********/
// Fx types
#define FX_ANIMATED_EFFECT 0
#define FX_PARTICLE_SYSTEM 1

// Animated fx types
#define FX_MULTI_ANGLE_ANIM  0
#define FX_SINGLE_ANGLE_ANIM 1

/*******/
/* GUI */
/*******/
#define GUI_ART_TYPE_SPRITE    0
#define GUI_ART_TYPE_ANIMATION 1
#define GUI_ART_TYPE_TEXT      2

#define GUI_OBJECT_TYPE_FRAME      0
#define GUI_OBJECT_TYPE_TEXTURE    1
#define GUI_OBJECT_TYPE_FONTSTRING 2
#define GUI_OBJECT_TYPE_STATUSBAR  3
#define GUI_OBJECT_TYPE_TSTATUSBAR 4

#define GUI_ANCHOR_TOPLEFT     0
#define GUI_ANCHOR_TOP         1
#define GUI_ANCHOR_TOPRIGHT    2
#define GUI_ANCHOR_RIGHT       3
#define GUI_ANCHOR_BOTTOMRIGHT 4
#define GUI_ANCHOR_BOTTOM      5
#define GUI_ANCHOR_BOTTOMLEFT  6
#define GUI_ANCHOR_LEFT        7
#define GUI_ANCHOR_CENTER      8

#define GUI_LAYER_BACKGROUND 0
#define GUI_LAYER_BORDER     1
#define GUI_LAYER_ARTWORK    2
#define GUI_LAYER_OVERLAY    3
#define GUI_LAYER_HIGHLIGHT  4

#define GUI_STRATA_TOOLTIP           7
#define GUI_STRATA_FULLSCREEN_DIALOG 6
#define GUI_STRATA_FULLSCREEN        5
#define GUI_STRATA_DIALOG            4
#define GUI_STRATA_HIGH              3
#define GUI_STRATA_MEDIUM            2
#define GUI_STRATA_LOW               1
#define GUI_STRATA_BACKGROUND        0

#define GUI_CASTBUTTON_EMPTY -1
#define GUI_CASTBUTTON_SPELL 0
#define GUI_CASTBUTTON_STOP  1

#define GUI_SCRTXT_TYPE_PHYSICAL 0
#define GUI_SCRTXT_TYPE_HEAL     1
#define GUI_SCRTXT_TYPE_SPELL    2

/**********/
/* SPELLS */
/**********/
// Spell types
/*#define SPELL_OFFENSIVE_DIRECT    0
#define SPELL_OFFENSIVE_CHANNELED 1
#define SPELL_OFFENSIVE_OVER_TIME 2
#define SPELL_OFFENSIVE_MELEE     3
#define SPELL_HEAL_DIRECT         4
#define SPELL_HEAL_CHANNELED      5
#define SPELL_HEAL_OVER_TIME      6
#define SPELL_BUFF                7
#define SPELL_DEBUFF              8
#define SPELL_RESURRECTION        9*/
#define SPELL_TARGET_ALL           0
#define SPELL_TARGET_HOSTILES      1
#define SPELL_TARGET_FRIENDS       2
#define SPELL_TARGET_DEADS         3
#define SPELL_TARGET_DEAD_FRIENDS  4
#define SPELL_TARGET_DEAD_HOSTILES 5

// Spell school
#define SPELL_SCHOOL_HOLY   0
#define SPELL_SCHOOL_FROST  1
#define SPELL_SCHOOL_FIRE   2
#define SPELL_SCHOOL_NATURE 3
#define SPELL_SCHOOL_SHADOW 4
#define SPELL_SCHOOL_ARCANE 5
#define SPELL_SCHOOL_NONE   6

/*********/
/* ITEMS */
/*********/
// Item binding
#define ITEM_BINDS_NEVER  0
#define ITEM_BINDS_PICKUP 1
#define ITEM_BINDS_EQUIP  2
#define ITEM_BINDS_USE    3
// Item type
#define ITEM_TYPE_ARMOR   0
#define ITEM_TYPE_WAEPON  1
#define ITEM_TYPE_JEWELRY 2
#define ITEM_TYPE_SHIELD  3
#define ITEM_TYPE_TABARD  4
#define ITEM_TYPE_OFFHAND 5
#define ITEM_TYPE_BAG     6
#define ITEM_TYPE_CONS    7
// Item slot
#define ITEM_SLOT_SHIRT    0
#define ITEM_SLOT_CHEST    1
#define ITEM_SLOT_BACK     2
#define ITEM_SLOT_FEET     3
#define ITEM_SLOT_HANDS    4
#define ITEM_SLOT_LEGS     5
#define ITEM_SLOT_SHOULDER 6
#define ITEM_SLOT_WAIST    7
#define ITEM_SLOT_WRIST    8
#define ITEM_SLOT_1H       9
#define ITEM_SLOT_2H       10
#define ITEM_SLOT_MAIN     11
#define ITEM_SLOT_OFF      12
#define ITEM_SLOT_RANGED   13
#define ITEM_SLOT_RING     14
#define ITEM_SLOT_NECKLACE 15
#define ITEM_SLOT_TRINKET  16
// Item quality
#define ITEM_QUALITY_POOR      0
#define ITEM_QUALITY_COMMON    1
#define ITEM_QUALITY_UNCOMMON  2
#define ITEM_QUALITY_RARE      3
#define ITEM_QUALITY_EPIC      4
#define ITEM_QUALITY_LEGENDARY 5
#define ITEM_QUALITY_ARTIFACT  6

/*********/
/* UNITS */
/*********/
// Power type
#define POWER_TYPE_NONE      5
#define POWER_TYPE_MANA      0
#define POWER_TYPE_RAGE      1
#define POWER_TYPE_FOCUS     2
#define POWER_TYPE_ENERGY    3
#define POWER_TYPE_HAPPINESS 4

#include "dx9/d3dx9.h"

#include <math.h>
#include <string>
#include <map>
#include <ext/hash_map>
#include <vector>

#include "hge/hge.h"
#include "hge/hgesprite.h"
#include "hge/hgefont.h"
#include "hge/hgerect.h"
#include "hge/hgevector.h"
#include "hge/hgeanim.h"
#include "hge/hgeparticle.h"
#include "hge/hgestrings.h"

extern "C"
{
	#include "lua/lualib.h"
	#include "lua/lauxlib.h"
	#include "lua/lua.h"
}

#include "lua/lunar.h"

#include "xml/tinyxml.h"

#include "keyhandler.h"

class Unit;
class Doodad;
class StatusBar;
class Projectile;
class Point;
class Node;
class SceneManager;
class ToolTip;
class Zone;
//class CastBar;
class LoadingBar;
//class UnitFrame;
class Effect;
class Stats;
class Inventory;
class GUIBase;
class GUIElement;
class GUIArt;
class Font;

// lua classes
class l_UIObject;
class l_Region;
class l_Frame;
class l_LayeredRegion;
class l_Texture;
class l_FontString;

struct RGB;
struct FormatedString;
struct Buff;
struct Spell;
struct CSpell;
struct Specialisation;
struct Cursor;
struct Class;
struct Animation;
struct AnimatedEffect;
struct ParticleEffect;
struct SEffect;
struct PAnim;
struct ActionButton;
struct BFont;
struct Object;
struct ScrollingText;
struct ErrorText;
struct BGPart;
struct Waypoint;
struct Item;

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Node header               */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_NODE_H
#define WOWRL_NODE_H

#include "wowrl.h"

class Node
{
public :

    Node();
    ~Node();

    void set(float, float, Node*, float, float);

    Point getPoint();

	float x;
	float y;
	float f;
	float g;
	Node* parent;
	bool closed;
	bool opened;
	bool walkable;
	bool useless;

private :

};

#endif

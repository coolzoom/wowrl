/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Inventory header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_INVENTORY_H
#define WOWRL_INVENTORY_H

#include "wowrl.h"
#include "wowrl_structs.h"
#include "wowrl_stats.h"

struct Item
{
	int         id;
	std::string display_name;
	std::string description;
	hgeSprite*  icon;
	std::string iconPath;
	int         type;
	int         quality;
	int         binds;
	int         req_lvl;
	int         req_class;
	std::string req_skill;
	int         req_skill_lvl;
	float       cooldown;
	int 		unique;
	bool        quest;
	bool        conjured;
	std::string made_by;
	bool        container;
	bool        soulbound;
	int         charges;
	bool        sellable;
	int         price;
	// Quest* quest;

	// Effects
	Spell* on_equip;
	Spell* on_use;
	Spell* on_hit;
	Spell* on_cast;

	// Equipment
	int durability_max;
	int durability_cur;

	Stats bonus_stat;

	// # weapon
	float speed;
	int   dmg_min;
	int   dmg_max;
	int   add_dmg_school;
	int   add_dmg_min;
	int   add_dmg_max;

	// # sets
	std::map<std::string, Item*> set;
	std::string                  set_name;
	std::vector<Stats>           set_bonuses;

	// # enchant
	//Enchant ench;
	//Enchant tmp_ench;
};

class Inventory
{
public :

	Inventory();
	void Render(float x, float y);
	bool addItem(Item);

	std::map<int, Item> items;
	int size;
	Unit* parent;

	std::string title;
	hgeFont* font;

	float w, h;

	hgeSprite* background;
	hgeSprite* cornerTop;
	hgeSprite* cornerBottom;
	hgeSprite* borderVertical;
	hgeSprite* borderHorizontalTop;
	hgeSprite* borderHorizontalBottom;
	hgeSprite* emptySlot;
	hgeSprite* closeButton;

private :

};

#endif

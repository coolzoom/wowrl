/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               XML source               */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_XML_H
#define WOWRL_XML_H

#include "wowrl.h"
#include "wowrl_structs.h"

#include <string>

void mxml_initUI();
void mxml_parseUIFile( AddOn*, TiXmlDocument );
void mxml_parseFrame( TiXmlNode*, GUIElement*, int );
void mxml_parseTexture( TiXmlNode*, GUIElement*, int, int type = GUI_OBJECT_TYPE_TEXTURE );
void mxml_parseString( TiXmlNode*, GUIElement*, int );
void mxml_parseAnchor( TiXmlNode*, GUIBase* );
void mxml_parseBackdrop( TiXmlNode*, GUIElement* );

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Unit header               */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_UNIT_H
#define WOWRL_UNIT_H

#include "wowrl.h"
#include "wowrl_point.h"
#include "wowrl_structs.h"
#include "wowrl_effect.h"
#include "wowrl_inventory.h"

class Unit
{
public :

	// Unit initialisations
    Unit();
    //Unit(std::string);
    Unit(std::string, float, float, int, Class*, float);
    ~Unit();
    void initialize();

    // Rendering data
    float getX();
    void  setX(float);
    float getY();
    void  setY(float);
    float getGX();
    float getGY();
	Point getPoint();
	Point getGPoint();
	int   getRot();
	void  setRot(int);
	void  setRotFromAngle(float);
	float getScale();
	void  setScale(float);
    float getVScale();
    float getAngle();
    float getZ();
    float getRZ();
    float getRelativeDepth(Point);
    float getShadow();
    RGB   getColor();
    void  setColor(RGB);
    void  setColor(int,int,int);
    int   getTextNbr();
    void  deleteSelf();

    // UI
    std::multimap<float, Buff*> getBuffList();
    Inventory*                  getInventory();
    void                        initAB();
	ActionButton*               getABList();

    // Animation
    std::string   getAnimState();
    void          setAnimState(std::string, int frame = -1);
    hgeAnimation* setAnimation(int frame = -1, bool keepSameFrame = false);
    hgeAnimation* getAnimation();

    // Effect
    std::map<std::string, Effect> getEffectList();
    void                          addEffect(std::string);

    // Gameplay data
    std::string getName();
	//void        setName(std::string);
    float       getSpeed();
	void        setSpeed(float);
	Class*      getClass();
	void        setClass(Class*);
    int         getLvl();
    Spell*      getDefaultSpell();
    bool        isHostile(Unit* u = NULL);
    void        setHostile(bool);
	bool        isSelected();
	void        setSelected(bool);
	Spell*      getSpell();
	bool        isAttacking();
	bool        isCasting();
	bool        isActing();
	bool        isHealing();
	bool        isDead();
	float       getHealth();
	float       getMaxHealth();
	void        setMaxHealth(float,bool);
	float       getMana();
	float       getMaxMana();
	void        setMaxMana(float,bool);
	float       getActionState();
	void        setInCombat();
	bool        isInCombat();
	bool		isInSpellRange(float,float);
	bool		isTargetInRange(Spell* s = NULL);
	void        setAggroRange(float);
	int			getPowerType();

	// Actions
    void  target(Unit*);
    Unit* getTarget();
    void  incant(Spell*, Unit*);
    bool  cast(Spell*);
    bool  isCastable(Spell*, std::string* = NULL, bool ignoreRange = false, bool ignoreTargetType = false);
	void  receive(Spell*, Unit*);
	void  damage(Unit*, int, int, bool);
	void  heal(Unit*, int, bool);
    void  stop();
    void  die();
    void  res(int, int, Unit*);
    void  addBuff(std::string);

    // Aggro
    void addAggroTo(Unit*, float);
    bool isInAggroListOf(Unit*);
    void addUnitInAggroList(Unit*);
    void rebuildAggroList();
    void buildAggroList(bool);
    void rebuildAggroedList();
    void buildAggroedList();

    // Movement
    void moveInRange(Unit* target = NULL);
    bool goTo(Point destPoint);
	bool followPath();
	bool followWaypointPath();
    void goBackToOldState();

    // Interaction
    void     setBox();
    hgeRect* getBox();
    void     setStandBox();
    hgeRect* getStandBox();
    bool     intersects(Object);

    // Update
    void update(float);
    void updateEffects(float);
	void updateAction(float);
	void updateBuffs(float);
	void updateRegen(float);
	void updateMovement();
	void updateStats();
	void updateAggro(float);

    // GUI
    StatusBar* getStatusBar();

	// Public members
	bool attacking;
	bool healing;
	bool resurrecting;

    bool               hidden;
	bool               dying;
	bool               moving;
	bool               orderGiven;
	std::string        order;
    std::vector<Point> path;
    std::vector<Point> wPath;
    int                pointIndice;
    int                waypointIndice;
    bool               following;
    bool			   followingWp;
    Point              destPoint;
	bool               FXPlaying;
	float              rz;
	float			   placeInWPQueue;
	float			   placeInQueue;
	float			   placeInDQueue;
	bool               pathRequested;
	bool               pathObtained;

	std::multimap<float, Unit*> aggroList;
	std::map<Unit*, float>      aggroedList;

private :

	// Rendering data
	float m_x;
	float m_y;
	float m_orientation;
	int   m_rot;
	int   m_old_rot;
	float m_scale;
	float m_vscale;
	RGB   m_color;
	float m_shadow;
	float m_old_gx, m_old_gy;
	int   m_text_nbr;
	bool  m_projectile;

	// Animation
	std::string   m_animstate;
	std::string   m_old_animstate;
	hgeAnimation* m_animation;
	bool          m_finishAnim;

	// Effect
	std::string                   m_effectstate;
	std::string                   m_old_effectstate;
	std::map<std::string, Effect> m_effect;

	// Gameplay data
	// # Infos
    std::string     m_name;
	float           m_speed;
	Class*          m_class;
	Spell*          m_spell;
	Specialisation* m_spec;
	Unit*           m_target;
	int             m_lvl;
	bool            m_hostile;
	bool            m_selected;
	/*bool            m_attacking;
	bool            m_healing;
	bool            m_resurrecting;*/
	bool            m_dead;
	bool 			m_in_combat;

	std::map<std::string, Buff> m_buffList;

	// # Stats
	float m_health;
	float m_mana;
	float m_aggro_range;
	Stats m_stats;

	// # Inventory
	Inventory m_inventory;

	// # Aggro
	bool			       m_aggro;
	bool                   m_rebuildAggroList;
	bool                   m_rebuildAggroedList;
	Point                  old_pos;
	Point                  old_destPoint;
	std::vector<Point>     old_path;
    std::vector<Point>     old_wPath;
    int                    old_pointIndice;
    int                    old_waypointIndice;
    bool                   old_orderGiven;
    std::string            old_order;
    bool                   old_following;
	bool                   old_moving;

	// Interaction
	hgeRect* m_box;
	hgeRect* m_sbox;

	// GUI
	StatusBar*   m_status_bar;
	//CastBar*     m_cast_bar;
	//UnitFrame*   m_unit_frame;
	ActionButton m_ABList[121];

	// Update
	float m_action_timer;
	float m_regen_timer;
	float m_in_combat_timer;
	float m_pathfinding_timer;
};

#endif

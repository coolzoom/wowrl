/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Point header              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_FONT_H
#define WOWRL_FONT_H

#include "wowrl.h"
#include "dx9/d3dx9.h"
#include <string>

class Font
{
public :

    void printf(std::string, LPRECT, DWORD, D3DCOLOR, ID3DXSprite* sprite = NULL);

	ID3DXFont*   fnt;
	ID3DXSprite* spr;
	RECT*        pRect;
	bool         outlined;

private :



};

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               GUI header               */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_GUI_H
#define WOWRL_GUI_H

#include "wowrl.h"
#include "wowrl_structs.h"
#include "wowrl_lua.h"

struct Anchor
{
	int         anchorPt;
	int         relativePt;
	GUIBase*    parent;
	std::string parent_name;
	float       x, y;

	Anchor()
	{
		x = 0.0f;
		y = 0.0f;
		parent = NULL;
		parent_name = "";
		anchorPt = GUI_ANCHOR_TOPLEFT;
   		relativePt = GUI_ANCHOR_TOPLEFT;
	}
};

struct Backdrop
{
	bool tile;
	float edgeSize;
	float tileSize;
	float insL;
	float insR;
	float insT;
	float insB;

	float bgW;
	float bgH;
	float edgeOriginalSize;

	std::string bgFile;
	std::string edgeFile;

	bool edgeReady;
	hgeSprite* edgeL;
	hgeSprite* edgeR;
	hgeSprite* edgeT;
	hgeSprite* edgeB;
	hgeSprite* cornerTL;
	hgeSprite* cornerTR;
	hgeSprite* cornerBL;
	hgeSprite* cornerBR;
	bool bgReady;
	hgeSprite* background;

	// Cache
	HTARGET    target;
    hgeSprite* spr;
};

class GUIBase
{
public :

	float getX( bool relative = false );
    float getY( bool relative = false );
    bool  IsVisible();

    void _init();
    GUIBase* getHighestVirtParent();

	std::string name;
	std::string sname;
	std::string vname;
	int         type;
	bool        virt;
	float       x, y;
	float       w, h;
	float       alpha;
	bool        hidden;

	std::map<int, Anchor> anchors;
	Anchor* banchor;
	std::map<std::string, GUIBase*> parentList;

	GUIElement*    parent;
	std::string parent_name;
};

class GUIArt : public GUIBase
{
public :

	int id;

	hgeSprite*     sprite;
	hgeAnimation*  anim;
	FormatedString text;

	int   layer;
	float scale;
	float vscale;
	float angle;
	bool  box;
	bool  ready;
	DWORD color;
	int   blend;

	float ax, ay;

	std::string file;

	GUIArt() : GUIBase()
	{
		sprite = NULL;
		anim = NULL;
		parent = NULL;
		parent_name = "";
		name = "";
		vname = "";
		hidden = false;
		box = false;
		ready = false;
		color = ARGB(255, 255, 255, 255);
		x = 0.0f;
		y = 0.0f;
		layer = 0;
		angle = 0.0f;
		scale = 1.0f;
		vscale = 1.0f;
		banchor = NULL;
	}

	void Render();
};

class GUIElement : public GUIBase
{
public :

    void Render(bool);

    GUIElement() : GUIBase()
	{
		w = -1;
		h = -1;

		parent = NULL;
		parent_name = "";
		name = "";
		vname = "";
		hidden = false;
		virt = false;
		child = false;
		rebuildList = true;
		rebuildCache = true;
		rebuildBackdrop = true;
		recreateCache = false;
		frameStrata = 2;
		lastOn = false;
		baseUI = false;
		useBackdrop = false;
		enableMouse = false;

		OnLoadId = 0;
		OnMouseDownId = 0;
		OnMouseUpId = 0;
		OnDragStartId = 0;
		OnReceiveDragId = 0;
		OnEnterId = 0;
		OnLeaveId = 0;
		OnUpdateId = 0;

		OnLoadDef = false;
		OnMouseDownDef = false;
		OnMouseUpDef = false;
		OnDragStartDef = false;
		OnReceiveDragDef = false;
		registeredForDrag = false;
		OnEnterDef = false;
		OnLeaveDef = false;
		OnUpdateDef = false;

		value = 1.0f;
		min_value = 0.0f;
		max_value = 1.0f;

		spr = NULL;
		banchor = NULL;
	}

	void deleteMe();

	void CheckInput(float, float, int, int);

    void OnLoad();
    void SetOnLoadFunction(int);
    std::string OnLoadText;
    bool OnLoadDef;

    void OnMouseDown();
    void SetOnMouseDownFunction(int);
    std::string OnMouseDownText;
    bool OnMouseDownDef;

    void OnMouseUp();
    void SetOnMouseUpFunction(int);
    std::string OnMouseUpText;
    bool OnMouseUpDef;

    void OnDragStart();
    void SetOnDragStartFunction(int);
    std::string OnDragStartText;
    bool OnDragStartDef;

    void OnReceiveDrag();
    void SetOnReceiveDragFunction(int);
    std::string OnReceiveDragText;
    bool OnReceiveDragDef;

    void OnEnter();
    void SetOnEnterFunction(int);
    std::string OnEnterText;
    bool OnEnterDef;

    void OnLeave();
    void SetOnLeaveFunction(int);
    std::string OnLeaveText;
    bool OnLeaveDef;

    void OnUpdate();
    void SetOnUpdateFunction(int);
    std::string OnUpdateText;
    bool OnUpdateDef;

    void copyVirt(GUIElement*);

    std::map<std::string, GUIElement*> childs;
    std::map<std::string, GUIElement>  vchilds;
    bool 							   child;

    std::map<std::string, GUIArt> arts;

    // Backdrop
    Backdrop backdrop;
    bool useBackdrop;

    // Status bar specific variables
    int     frameStrata;
    float   value;
    float   min_value;
    float   max_value;
    float   base_width;
    GUIArt* barTexture;
    bool	rebuildList;

	// Parameters
    float gx, gy;
    bool  lastOn;
    bool  registeredForDrag;
    bool  enableMouse;
    bool  baseUI;

	// Cache
    HTARGET    target;
    hgeSprite* spr;
    bool       rebuildCache;
    bool       rebuildBackdrop;
    void       _rebuildCache( bool child = false );
	bool       recreateCache;

    void _print(int);
    void _init();

private :

	int OnLoadId;
	int OnMouseDownId;
    int OnMouseUpId;
    int OnDragStartId;
    int OnReceiveDragId;
    int OnEnterId;
    int OnLeaveId;
    int OnUpdateId;

    std::multimap<int, GUIElement*> sortedGUIList;
};

class l_UIObject
{
public :

	static const char className[];
	static Lunar<l_UIObject>::RegType methods[];

	/**/ int GetAlpha(lua_State*) {}
	/**/ int GetObjectType(lua_State*) {}
	/**/ int IsObjectType(lua_State*) {}
	/**/ int SetAlpha(lua_State*) {}

	int getDataTable(lua_State *L) {
		lua_getref(L, ref);
		return 1;
    }

	l_UIObject(lua_State* luaVM) {
		lua_newtable(luaVM);
		ref = luaL_ref(luaVM, LUA_REGISTRYINDEX);
		l = luaVM;
	}

	~l_UIObject() {
		luaL_unref(l, LUA_REGISTRYINDEX, ref);
	}

protected :

	std::string name;
	lua_State*  l;
    int         ref;
};

class l_Region : public l_UIObject
{
public :

	static const char className[];
	static Lunar<l_Region>::RegType methods[];

	int GetName(lua_State*);

	int GetBottom(lua_State*);
	int GetCenter(lua_State*);
	int GetHeight(lua_State*);
	int GetLeft(lua_State*);
	/**/ int GetNumPoint(lua_State*) {}
	/**/ int GetParent(lua_State*) {}
	int GetPoint(lua_State*);
	int GetRight(lua_State*);
	int GetTop(lua_State*);
	int GetWidth(lua_State*);
	int Hide(lua_State*);
	int IsShown(lua_State*);
	int IsVisible(lua_State*);
	/**/ int SetAllPoints(lua_State*) {}
	int SetHeight(lua_State*);
	/**/ int SetParent(lua_State*) {}
	int SetPoint(lua_State*);
	int SetWidth(lua_State*);
	int Show(lua_State*);

	l_Region(lua_State* luaVM) : l_UIObject(luaVM) {ebase=NULL; rbase=NULL;}

protected :

	GUIBase*    rbase;
	GUIElement* ebase;
};

class l_Frame : public l_Region
{
public :

	static const char className[];
	static Lunar<l_Frame>::RegType methods[];

	/**/ int CreateFontString(lua_State*) {}
	/**/ int CreateTexture(lua_State*) {}
	/**/ int CreateTitleRegion(lua_State*) {}
	/**/ int DisableDrawLayer(lua_State*) {}
	/**/ int EnableDrawLayer(lua_State*) {}
	/**/ int EnableKeyboard(lua_State*) {}
	/**/ int EnableMouse(lua_State*) {}
	/**/ int EnableMouseWheel(lua_State*) {}
	int GetBackdrop(lua_State*);
	/**/ int GetBackdropBorderColor(lua_State*) {}
	/**/ int GetBackdropColor(lua_State*) {}
	/**/ int GetChildren(lua_State*) {}
	/**/ int GetEffectiveAlpha(lua_State*) {}
	/**/ int GetEffectiveScale(lua_State*) {}
	/**/ int GetFrameLevel(lua_State*) {}
	/**/ int GetFrameStrata(lua_State*) {}
	/**/ int GetFrameType(lua_State*) {}
	/**/ int GetHitRectInsets(lua_State*) {}
	/**/ int GetID(lua_State*) {}
	/**/ int GetMaxResize(lua_State*) {}
	/**/ int GetMinResize(lua_State*) {}
	/**/ int GetNumChildren(lua_State*) {}
	/**/ int GetNumRegions(lua_State*) {}
	/**/ int GetScale(lua_State*) {}
	/**/ int GetScript(lua_State*) {}
	/**/ int GetTitleRegion(lua_State*) {}
	/**/ int HasScript(lua_State*) {}
	/**/ int HookScript(lua_State*) {}
	/**/ int IsClampedtoScreen(lua_State*) {}
	/**/ int IsFrameType(lua_State*) {}
	/**/ int IsKeyboardEnabled(lua_State*) {}
	/**/ int IsMouseEnabled(lua_State*) {}
	/**/ int IsMouseWheelEnabled(lua_State*) {}
	/**/ int IsMovable(lua_State*) {}
	/**/ int IsResizable(lua_State*) {}
	/**/ int IsTopLevel(lua_State*) {}
	/**/ int IsUserPlaced(lua_State*) {}
	/**/ int Lower(lua_State*) {}
	/**/ int Raise(lua_State*) {}
	/**/ int RegisterAllEvents(lua_State*) {}
	/**/ int RegisterEvent(lua_State*) {}
	/**/ int RegisterForDrag(lua_State*) {}
	int SetBackdrop(lua_State*);
	/**/ int SetBackdropBorderColor(lua_State*) {}
	/**/ int SetBackdropColor(lua_State*) {}
	/**/ int SetClampedToScreen(lua_State*) {}
	/**/ int SetFrameLevel(lua_State*) {}
	/**/ int SetFrameStrata(lua_State*) {}
	/**/ int SetHitRectInsets(lua_State*) {}
	/**/ int SetID(lua_State*) {}
	/**/ int SetMaxResize(lua_State*) {}
	/**/ int SetMinResize(lua_State*) {}
	/**/ int SetMovable(lua_State*) {}
	/**/ int SetResizable(lua_State*) {}
	/**/ int SetScale(lua_State*) {}
	/**/ int SetScript(lua_State*) {}
	/**/ int SetTopLevel(lua_State*) {}
	/**/ int SetUserPlaced(lua_State*) {}
	/**/ int StartMoving(lua_State*) {}
	/**/ int StartSizing(lua_State*) {}
	/**/ int StopMovingOrSizing(lua_State*) {}
	/**/ int UnregisterAllEvents(lua_State*) {}
	/**/ int UnregisterEvent(lua_State*) {}

	int _init(lua_State*);

	l_Frame(lua_State*);

protected :

	GUIElement* base;
};

class l_StatusBar : public l_Frame
{
public :

	static const char className[];
	static Lunar<l_StatusBar>::RegType methods[];

	/**/ int GetMinMaxValues(lua_State*) {}
	/**/ int GetOrientation(lua_State*) {}
	/**/ int GetStatusBarColor(lua_State*) {}
	/**/ int GetStatusBarTexture(lua_State*) {}
	/**/ int GetValue(lua_State*) {}
	int SetMinMaxValues(lua_State*);
	/**/ int SetOrientation(lua_State*) {}
	int SetStatusBarColor(lua_State*);
	/**/ int SetStatusBarTexture(lua_State*) {}
	int SetValue(lua_State*);

	l_StatusBar(lua_State*);
};

class l_LayeredRegion : public l_Region
{
public :

	static const char className[];
	static Lunar<l_LayeredRegion>::RegType methods[];

	/**/ int GetDrawLayer(lua_State*) {}
	/**/ int SetDrawLayer(lua_State*) {}

	int _init(lua_State*);

	l_LayeredRegion(lua_State* luaVM) : l_Region(luaVM) {base=NULL;}

protected :

	std::string pname;
	GUIArt* base;
};

class l_Texture : public l_LayeredRegion
{
public :

	static const char className[];
	static Lunar<l_Texture>::RegType methods[];

	/**/ int GetBlendMode(lua_State*) {}
	/**/ int GetTexCoord(lua_State*) {}
	/**/ int GetTexCoordModifiesRect(lua_State*) {}
	/**/ int GetTexture(lua_State*) {}
	/**/ int GetVertexColor(lua_State*) {}
	/**/ int GetDesaturated(lua_State*) {}
	/**/ int SetBlendMode(lua_State*) {}
	/**/ int SetDesaturated(lua_State*) {}
	/**/ int SetGradient(lua_State*) {}
	/**/ int SetGradientAlpha(lua_State*) {}
	int SetTexCoord(lua_State*);
	/**/ int SetTexCoordModifiesRect(lua_State*) {}
	int SetTexture(lua_State*);
	int SetVertexColor(lua_State*);

	l_Texture(lua_State*);

protected :
};

class l_FontString : public l_LayeredRegion
{
public :

	static const char className[];
	static Lunar<l_FontString>::RegType methods[];

	// Inherits from FontInstance
	/**/ int GetFont(lua_State*) {}
	/**/ int GetFontObject(lua_State*) {}
	/**/ int GetJustifyH(lua_State*) {}
	/**/ int GetJustifyV(lua_State*) {}
	/**/ int GetShadowColor(lua_State*) {}
	/**/ int GetShadowOffset(lua_State*) {}
	/**/ int GetSpacing(lua_State*) {}
	/**/ int GetTextColor(lua_State*) {}
	int SetFont(lua_State*);
	/**/ int SetFontObject(lua_State*) {}
	/**/ int SetJustifyH(lua_State*) {}
	/**/ int SetJustifyV(lua_State*) {}
	/**/ int SetShadowColor(lua_State*) {}
	/**/ int SetShadowOffset(lua_State*) {}
	/**/ int SetSpacing(lua_State*) {}
	int SetTextColor(lua_State*);

	/**/ int CanNonSpaceWrap(lua_State*) {}
	int GetStringWidth(lua_State*);
	/**/ int GetText(lua_State*) {}
	/**/ int SetAlphaGradient(lua_State*) {}
	/**/ int SetNonSpaceWrap(lua_State*) {}
	int SetText(lua_State*);
	/**/ int SetTextHeight(lua_State*) {}

	l_FontString(lua_State*);

protected :
};

#endif

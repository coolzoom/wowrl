/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Doodad header             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_DOODAD_H
#define WOWRL_DOODAD_H

#include "wowrl.h"

class Doodad
{
public :

    Doodad();

    void setX(float);
	void setY(float);
	float getX();
	float getY();
	Point getPoint();
    float getZ();
    void setBox();
    hgeRect* getBox();
    float getRelativeDepth(Point);
	void deleteSelf();
	bool intersects(Object);

	std::string name;
	hgeSprite* sprite;
	float z;
	float orientation;
	bool locked;
	bool inTop;

private :

	float m_x;
	float m_y;
	float old_x;
	float old_y;
	hgeRect* m_box;

};

#endif

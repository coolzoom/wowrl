/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Stats header              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_STATS_H
#define WOWRL_STATS_H

#include "wowrl.h"

class Stats
{
public :

	void clear();

	Stats operator+ (Stats);
    Stats operator- (Stats);

    int armor;
	int health;
	int mana;
	int power_type;
	int stamina;
	int intellect;
	int agility;
	int spirit;
	int strengh;
	int block;

	int resist_all;
	int resist_frost;
	int resist_fire;
	int resist_nature;
	int resist_shadow;
	int resist_arcane;

	int	spell_power;
	int	attack_power;
	int	regen_5s_health;
	int	regen_5s_mana;
	int crit;
	int crit_spell;
	int hit;
	int	penetration;

private :

};

#endif

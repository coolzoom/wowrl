/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          Scene manager header          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_SCENEMANAGER_H
#define WOWRL_SCENEMANAGER_H

#include "wowrl.h"
#include "wowrl_tooltip.h"
#include "wowrl_zone.h"
#include "wowrl_structs.h"
//#include "wowrl_castbar.h"
#include "wowrl_loadingbar.h"
//#include "wowrl_unitframe.h"
#include "wowrl_inventory.h"

class SceneManager
{
public :

	static SceneManager* getSingleton();
	void   initValues();

	// Global variables
	float 			  gx, gy, dt;
	float			  dgx, dgy;
	int				  sWidth, sHeight;
	IDirect3DDevice9* mDxDevice;
	int 			  gameState;
	hgeRect*          scrRect;
	bool              gamePaused;
	std::string       mouseButton;
	float             gameVersion;

	// Lua parser
	lua_State*  luaVM;
	// Used to communicate with LUA
	std::string tmpString;

	// Zones
	bool parseZoneDyn( int, int, bool*, float );
	void deleteDoodads();
	Zone actualZone;

	// Textures
	HTEXTURE loadTexture( std::string, bool mipmaps = false );
	void     freeTextures();

	// Sprites
	hgeSprite* createSprite( HTEXTURE tex, float x, float y, float w, float h, bool GUI = false );
	hgeSprite* createSprite( hgeSprite*, bool GUI = false );
	void       deleteSprites();

	// Animations
	hgeAnimation* createAnimation( HTEXTURE tex, int frames, float fps, float x, float y, float w, float h );
	void          deleteAnimations();
	bool          parseAnimationsDyn( int, int, bool*, float );

	// PSys
	hgeParticleSystem* createPSys( std::string file,  hgeSprite* spr );
	void               deletePSys();

	// Rects
	hgeRect* createRect( float x1, float y2, float x2, float y2 );
	void     deleteRects();

	// Fonts
	hgeFont* defaultFont;

	// String manipulation
	void                        replaceSpellValues( std::string*, Spell* );
	std::vector<FormatedString> createSpellInfos ( Spell* );
	hgeStringTable*				strTable;

	// Tables
	int             getBaseHealth( int, Class* );
	int             getBaseMana( int, Class* );
	int             getXPNeeded( int );
	hgeStringTable*	lvl_healthTable;
	hgeStringTable*	lvl_manaTable;
	hgeStringTable* lvl_xp_neededTable;
	std::string     locale;

	// Cursors
	void    parseCursors();
	Cursor* switchCursor(std::string);
	Cursor* cursor;

    // Classes
    bool   parseClassesDyn( int, bool*, float );
	Class* getClass( std::string );

	// Spells and buffs
	Spell*   parseSpell( std::string spell_name, bool regLUA );
    SBuff*   parseBuff( std::string buff_name );
	hgeFont* buffDurationFont;

	// Items
	Item parseItem( int item_id );

    // Effects
    void parseEffects();

	// Z sorted object list for rendering
	void                     buildRenderList( bool, bool );
	void                     forceUpdate();
	std::map<float, Object>  zSortedList;
	std::map<float, Unit*>   zSortedUnitList;
	std::map<float, Doodad*> renderInTopList;

	// Units
	//  # functions
    Unit* createUnit( std::string, float, float, int, Class*, float );
    Unit* getUnitByName( std::string );
    void  deselectAll();
    void  deleteUnits();
    Unit* leadingUnit;
    Unit* lastOvering;
    Unit* newOvering;
    //  # pathfinding management
    void                   requestWPPath( Unit* );
    void                   buildWPPaths();
    void                   requestPath( Unit* );
    void                   buildPaths();
    void                   requestDirectPath( Unit* );
    void                   buildDirectPaths();
    std::map<float, Unit*> requestWPList;
    std::map<float, Unit*> requestList;
    std::map<float, Unit*> requestDList;


    // Projectiles
    void       createProjectile( Spell*, Unit*, Unit* );
	hgeSprite* particle;

    // StatusBar
    void       createStatusBar( Unit* );
	hgeSprite* statusB_bg_left;
	hgeSprite* statusB_bg_middle;
	hgeSprite* statusB_bg_right;
	hgeSprite* statusB_dead_bg_left;
	hgeSprite* statusB_dead_bg_middle;
	hgeSprite* statusB_dead_bg_right;
	hgeSprite* statusB_gauge;

	// Inventory
	//Inventory  createInventory( Unit* );
	Inventory* mInventory;
	hgeSprite* inv_closeButton;
	hgeSprite* inv_emptySlot;
	float      invX, invY;

	// Scrolling combat text
	void     addScrollingText( Unit*, int, std::string );
	void     updateScrollingTexts();
	void     renderScrollingTexts();
	hgeFont* scrollingTextFont;

	// Game constants
	float aspectRatio;
	float regenTimer;
	float inCombatTimer;
	int   maxComputedPaths;

	// GUI
	void       parseUI( std::string );
	void       loadAddOn( std::string, std::string );
	void       loadUI();
	void       closeUI();
	void       reLoadUI();
	hgeSprite* bottomBar;
	hgeSprite* buttonBackground;
	hgeSprite* selectionCircle;
	hgeSprite* deathCircle;
	hgeSprite* hostileCircle;
	hgeSprite* p_shadow;
	hgeSprite* orderCircle;
	hgeSprite* selectionSquare;
	hgeSprite* selectionSquareLeftBorder;
	hgeSprite* selectionSquareTopBorder;
	hgeSprite* selectionSquareRightBorder;
	hgeSprite* selectionSquareBottomBorder;
	hgeSprite* stopButton;
	hgeSprite* aggroFrame;
	hgeSprite* loadingBackground;
	LoadingBar mLoadingBar;
	hgeQuad    targetLink1;
	hgeQuad    targetLink2;
	float      targetLinkTimer;
	DWORD      targetLinkColorF1;
	DWORD      targetLinkColorF2;
	DWORD      targetLinkColorF3;
	DWORD      targetLinkColorE1;
	DWORD      targetLinkColorE2;
	DWORD      targetLinkColorE3;


	void       addErrorMessage( std::string );
	void       updateErrorTexts();
	hgeFont*   errorFont;
	bool       rebuildGUIList;

	ActionButton* castedButton;
	bool          castingSpell;
	Unit*         casterUnit;

	std::string lScriptsStr;
	bool        lastDragged;
	bool        squareSelection;
	bool        mouseOverPlayField;

	std::map<std::string, GUIElement>  guiList;
	std::multimap<int, GUIElement*>    sortedGUIList;
	std::map<std::string, GUIElement>  templateList;
	std::map<std::string, GUIBase*>    parentList;
	std::map<std::string, AddOn>       addOnList;

	std::vector<ErrorText>               errorTextList;
	std::map<std::string, ScrollingText> scrollingTextList;


	// GUI constants
	float loadingBarX, loadingBarY;
	float unitFrameX, unitFrameY;
	float targetFrameX, targetFrameY;
	float toolTipX, toolTipY, toolTipW;
	float aButtonX, aButtonY;
	float aggroFrameX, aggroFrameY;
	float scrollingTextMaxLife;
	float scrollingTextSpeed;
	bool  scrollingTextFade;
	bool  showStatusBars;
	bool  showEnemiesStatusBars;
	float errorTextsDuration;
	float errorTextsFadeDelay;
	int   functionNbr;

	// Lists
	std::map<std::string, HTEXTURE> 	 textureList;
	std::map<std::string, Cursor> 		 cursorList;
	std::map<std::string, Spell>		 spellList;
	std::map<std::string, SBuff>		 buffList;
	std::map<std::string, Class> 		 classList;
	std::map<std::string, PAnim> 		 pAnimList;
    std::map<std::string, SEffect>       FXList;
    std::map<std::string, Projectile> 	 projectileList;
    std::map<std::string, StatusBar> 	 statusBarList;
    std::map<int, Item> 	         	 itemList;
    std::vector<hgeSprite*>				 spriteList;
    std::vector<hgeSprite*>				 GUIspriteList;
    std::vector<hgeAnimation*>			 animList;
    std::vector<hgeParticleSystem*>      psysList;
    std::vector<hgeRect*>				 rectList;

    std::map<std::string, hgeSprite*>	      mlua_spriteList;
    std::map<std::string, hgeAnimation*>      mlua_animList;
    std::map<std::string, hgeParticleSystem*> mlua_psysList;
    std::map<std::string, hgeRect*>		      mlua_rectList;

	std::map<std::string, Unit>  unitList;
	std::map<std::string, Unit*> orderList;
	std::map<std::string, Unit*> hostileList;
	std::map<std::string, Unit*> selectedList;
	std::map<std::string, Unit*> tempSelectedList;
	std::map<std::string, Unit*> actingList;
	std::map<std::string, Unit*> attackerList;
	std::map<std::string, Unit*> healerList;
	std::map<std::string, Unit*> reserList;
	std::map<std::string, Unit*> deadList;

protected :

	SceneManager();

private:

	static SceneManager* mSceneMgr;

	bool debugParser;
	bool debugRenderList;
	bool mForceUpdate;

};

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Status bar header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_STATUSBAR_H
#define WOWRL_STATUSBAR_H

#include "wowrl.h"

class StatusBar
{
public :

    StatusBar();
    ~StatusBar();

	hgeSprite* background_left;
	hgeSprite* background_middle;
	hgeSprite* background_right;
	hgeSprite* gauge;
	Unit* parent;
	float size;
	float state;
	RGB color;
	//std::string parent;

	void Render();

private :

};

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             ToolTip header             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_TOOLTIP_H
#define WOWRL_TOOLTIP_H

#include "wowrl.h"

class ToolTip
{
public :

	float x, y;
	float h, w;

	float descY;

	std::string type;

	hgeSprite* background;
	hgeSprite* cornerTop;
	hgeSprite* cornerBottom;
	hgeSprite* borderVertical;
	hgeSprite* borderHorizontalTop;
	hgeSprite* borderHorizontalBottom;

	std::vector<FormatedString> caption;

	Spell* spell;
	std::string itemName;

	void Render();
	ToolTip();
	~ToolTip();

private :

};

#endif

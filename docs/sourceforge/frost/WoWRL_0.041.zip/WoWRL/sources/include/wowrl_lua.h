/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Lua header                */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_LUA_H
#define WOWRL_LUA_H

#include "wowrl.h"
#include <string>

std::string mlua_concTable( std::string table );

void mlua_print( std::string str );
void mlua_printError( std::string error );

int mlua_getGlobalInt( std::string name, bool critical = true, int defaultValue = 0 );
float mlua_getGlobalFloat( std::string name, bool critical = true, float defaultValue = 0.0f );
std::string mlua_getGlobalString( std::string name, bool critical = true, std::string defaultValue = "" );
bool mlua_getGlobalBool( std::string name, bool critical = true, bool defaultValue = false );

int mlua_getFieldInt( std::string name, bool critical = true, int defaultValue = 0, bool setValue = false, lua_State* luaVM = NULL );
float mlua_getFieldFloat( std::string name, bool critical = true, float defaultValue = 0.0f, bool setValue = false, lua_State* luaVM = NULL );
std::string mlua_getFieldString( std::string name, bool critical = true, std::string defaultValue = "", bool setValue = false, lua_State* luaVM = NULL );
bool mlua_getFieldBool( std::string name, bool critical = true, bool defaultValue = false, bool setValue = false, lua_State* luaVM = NULL );

void mlua_setFieldInt( std::string name, int value, lua_State* luaVM = NULL );
void mlua_setFieldFloat( std::string name, float value, lua_State* luaVM = NULL );
void mlua_setFieldString( std::string name, std::string value, lua_State* luaVM = NULL );
void mlua_setFieldBool( std::string name, bool value, lua_State* luaVM = NULL );

void mlua_setIFieldInt( int id, int value, lua_State* luaVM = NULL );
void mlua_setIFieldFloat( int id, float value, lua_State* luaVM = NULL );
void mlua_setIFieldString( int id, std::string value, lua_State* luaVM = NULL );
void mlua_setIFieldBool( int id, bool value, lua_State* luaVM = NULL );

void mlua_registerAll();

/*********/
/* Glues */
/*********/

// Global functions
int l_logPrint( lua_State* luaVM );
int l_randomInt( lua_State* luaVM );
int l_randomFloat( lua_State* luaVM );
int l_strReplace( lua_State* luaVM );
int l_strCapitalStart( lua_State* luaVM );
int l_sendString( lua_State* luaVM );
int l_concTable( lua_State* luaVM );
int l_getDelta( lua_State* luaVM );
int l_getLeadingUnit( lua_State* luaVM );
int l_getLocale( lua_State* luaVM );
int l_getLocalizedString( lua_State* luaVM );
int l_getTime( lua_State* luaVM );
int l_getGlobal( lua_State* luaVM );
int l_getMousePos( lua_State* luaVM );

// Graphics functions
int l_Gfx_createSprite( lua_State* luaVM );
int l_Gfx_renderSprite( lua_State* luaVM );
int l_Gfx_createAnimation( lua_State* luaVM );
int l_Gfx_updateAnimation( lua_State* luaVM );
int l_Gfx_renderAnimation( lua_State* luaVM );
int l_Gfx_createPSys( lua_State* luaVM );
int l_Gfx_updatePSys( lua_State* luaVM );
int l_Gfx_renderPSys( lua_State* luaVM );

// GUI functions
int l_GUI_createElement( lua_State* luaVM );
/*int l_GUIElement_show( lua_State* luaVM );
int l_GUIElement_hide( lua_State* luaVM );
int l_GUIElement_addArt( lua_State* luaVM );
int l_GUIElement_setPosition( lua_State* luaVM );
int l_GUIElement_setLayer( lua_State* luaVM );
int l_GUIElement_setOnLoadFunction( lua_State* luaVM );
int l_GUIElement_setOnMouseDownFunction( lua_State* luaVM );
int l_GUIElement_setOnMouseUpFunction( lua_State* luaVM );
int l_GUIElement_setOnDragStartFunction( lua_State* luaVM );
int l_GUIElement_setOnReceiveDragFunction( lua_State* luaVM );
int l_GUIElement_setOnEnterFunction( lua_State* luaVM );
int l_GUIElement_setOnLeaveFunction( lua_State* luaVM );
int l_GUIElement_setOnUpdateFunction( lua_State* luaVM );
int l_GUIArt_setSprite( lua_State* luaVM );
int l_GUIArt_setAnimation( lua_State* luaVM );
int l_GUIArt_setText( lua_State* luaVM );
int l_GUIArt_setTextBox( lua_State* luaVM );
int l_GUIArt_setTextFont( lua_State* luaVM );
int l_GUIArt_setPosition( lua_State* luaVM );
int l_GUIArt_setScale( lua_State* luaVM );
int l_GUIArt_setAngle( lua_State* luaVM );
int l_GUIArt_setLayer( lua_State* luaVM );*/

// Unit functions
int l_Unit_spawn( lua_State* luaVM );
int l_Unit_addEffect( lua_State* luaVM );
int l_Unit_setHostile( lua_State* luaVM );
int l_Unit_setMaxHP( lua_State* luaVM );
int l_Unit_setAggroRange( lua_State* luaVM );
int l_Unit_setTarget( lua_State* luaVM );
int l_Unit_setX( lua_State* luaVM );
int l_Unit_setY( lua_State* luaVM );
int l_Unit_isHostile( lua_State* luaVM );
int l_Unit_isDead( lua_State* luaVM );
int l_Unit_isTargetInRange( lua_State* luaVM );
int l_Unit_getTarget( lua_State* luaVM );
int l_Unit_getX( lua_State* luaVM );
int l_Unit_getY( lua_State* luaVM );
int l_Unit_getLevel( lua_State* luaVM );
int l_Unit_getHealth( lua_State* luaVM );
int l_Unit_getMana( lua_State* luaVM );
int l_Unit_getMaxHealth( lua_State* luaVM );
int l_Unit_getMaxMana( lua_State* luaVM );
int l_Unit_getPowerType( lua_State* luaVM );
int l_Unit_addItem( lua_State* luaVM );
int l_Unit_getActionTexture( lua_State* luaVM );
int l_Unit_getActionInfo( lua_State* luaVM );
int l_Unit_castSpell( lua_State* luaVM );
int l_Unit_castSpellIndirect( lua_State* luaVM );
int l_Unit_isCasting( lua_State* luaVM );
int l_Unit_castingInfo( lua_State* luaVM );
int l_Unit_getSpellInfo( lua_State* luaVM );
int l_Unit_setAttacking( lua_State* luaVM );
int l_Unit_setHealing( lua_State* luaVM );
int l_Unit_setResurrecting( lua_State* luaVM );
int l_Unit_damage( lua_State* luaVM );
int l_Unit_heal( lua_State* luaVM );
int l_Unit_res( lua_State* luaVM );
int l_Unit_addBuff( lua_State* luaVM );
int l_Unit_addEffect( lua_State* luaVM );
int l_Unit_getBuffs( lua_State* luaVM );

#endif

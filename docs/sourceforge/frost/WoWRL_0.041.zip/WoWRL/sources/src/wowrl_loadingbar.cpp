/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           LoadingBar source            */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the LoadingBar class.              */
/*       A LoadingBar is a GUI element    */
/*  that displays the state of the game   */
/*  while loading data.                   */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_scenemanager.h"
#include "wowrl_fontmanager.h"

#include "wowrl_loadingbar.h"

extern SceneManager* mSceneMgr;
extern FontManager* mFontMgr;

void LoadingBar::initialize()
{
	captionFnt = mFontMgr->getFont(true, "Fonts/Calibri.ttf", 13, true, false);
}

void LoadingBar::Render()
{
	background->Render(mSceneMgr->loadingBarX, mSceneMgr->loadingBarY);
	gauge_active->RenderEx
	(
		mSceneMgr->loadingBarX+2-246.0f/2.0f, mSceneMgr->loadingBarY,
		0.0f,
		filling*242.0f/26.0f,
		1.0f
	);
	spark->Render
	(
		mSceneMgr->loadingBarX+2-246.0f/2.0f+filling*242.0f,
		mSceneMgr->loadingBarY+1
	);

	// The font is rendered twice with a small offset to simulate a shadow
	if (captionFnt != NULL)
	{
		captionFnt->SetColor(ARGB(255,0,0,0));
		captionFnt->printf
		(
			mSceneMgr->loadingBarX-113, mSceneMgr->loadingBarY+5, HGETEXT_LEFT, "%s",
			caption.c_str()
		);
		captionFnt->SetColor(ARGB(255,255,255,255));
		captionFnt->printf
		(
			mSceneMgr->loadingBarX-114, mSceneMgr->loadingBarY+4, HGETEXT_LEFT, "%s",
			caption.c_str()
		);
	}

	border->Render(mSceneMgr->loadingBarX, mSceneMgr->loadingBarY-2);
}

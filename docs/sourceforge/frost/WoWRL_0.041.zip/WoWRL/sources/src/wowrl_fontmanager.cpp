/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Font manager source          */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the FontManager class.             */
/*       A FontManager is obviously a     */
/*  class that manages font creation and  */
/*  storage.                              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_fontmanager.h"
#include "wowrl_global.h"

#include <sstream>
#include <fstream>
#include <ios>

#define MAX_TEXTURE_SIZE 1024

using namespace std;

extern HGE* hge;

struct CSymbolRange
{
	unsigned short	First;
	unsigned short	Last;
};

CHAR_DESC vChars[256];

//This is TTF file header
typedef struct _tagTT_OFFSET_TABLE
{
    unsigned short uMajorVersion;
    unsigned short uMinorVersion;
    unsigned short uNumOfTables;
    unsigned short uSearchRange;
    unsigned short uEntrySelector;
    unsigned short uRangeShift;
}TT_OFFSET_TABLE;

//Tables in TTF file and there placement and name (tag)
typedef struct _tagTT_TABLE_DIRECTORY
{
    char* szTag; //table name
    unsigned long uCheckSum; //Check sum
    unsigned long uOffset; //Offset from beginning of file
    unsigned long uLength; //length of the table in bytes

}TT_TABLE_DIRECTORY;

//Header of names table
typedef struct _tagTT_NAME_TABLE_HEADER
{
    unsigned short uFSelector; //format selector. Always 0
    unsigned short uNRCount; //Name Records count
    unsigned short uStorageOffset; //Offset for strings storage, from start of the table

}TT_NAME_TABLE_HEADER;

//Record in names table
typedef struct _tagTT_NAME_RECORD
{
    unsigned short uPlatformID;
    unsigned short uEncodingID;
    unsigned short uLanguageID;
    unsigned short uNameID;
    unsigned short uStringLength;
    unsigned short uStringOffset; //from start of storage area

}TT_NAME_RECORD;

extern HGE *hge;

using namespace std;

FontManager::FontManager() {}

FontManager* FontManager::mFontMgr = NULL;

FontManager* FontManager::getSingleton()
{
	if (mFontMgr == NULL)
		mFontMgr = new FontManager;
	return mFontMgr;
}

void FontManager::deleteFonts()
{
	hge->System_Log("1");
	// Delete fonts
	map<string, hgeFont*>::iterator iter;
	while (!fntList.empty())
	{
		iter = fntList.begin();
		hge->System_Log("1 : %s", iter->first.c_str());
		delete iter->second;
		fntList.erase(iter);
	}

	hge->System_Log("2");

	// Unreg TTF files
	vector<string>::iterator iter2;
	while (!ttfList.empty())
	{
		iter2 = ttfList.begin();
		hge->System_Log("2 : %s", iter2->c_str());
		RemoveFontResource(iter2->c_str());
		ttfList.erase(iter2);
	}

	hge->System_Log("3");
}

bool PlaceSymbols(int nWidth, int nHeight, CSymbolRange *pRanges, int nRangeCount)
{
	int i, j;
	int x=1, y=1;

	for(i=0; i<nRangeCount; i++)
	{
		for(j=pRanges[i].First; j<=pRanges[i].Last; j++ )
		{
			if(y+vChars[j].h+1 >= nHeight) return false;
			if(x+vChars[j].w+1 >= nWidth)
			{
				x=1;
				y+=vChars[j].h+1;
				if(y+vChars[j].h+1 >= nHeight) return false;
			}

			vChars[j].x = x;
			vChars[j].y = y;
			x+=vChars[j].w+1;
		}
	}

	return true;
}

HTEXTURE TextureGenerate(char *szFontName,
					  int nSize,
					  bool bBold,
					  bool bItalic,
					  CSymbolRange *pRanges,
					  int nRangeCount)
{
	int i,j;
	int nWidth, nHeight;

	HDC			hBMDC;
	HBITMAP		hBM;
	BITMAPINFO	bmi;
	HFONT		hFont;
	ABCFLOAT	abc;
	TEXTMETRIC	tTextMetrics;

	HTEXTURE	tex;
	DWORD		*pPixels, *pTexData, dwPixel;

	// create font
	hFont = CreateFont
	(
		-nSize, 0, 0, 0, (bBold) ? FW_BOLD : FW_NORMAL,
		bItalic, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		//ANTIALIASED_QUALITY,
		PROOF_QUALITY, // Renders much better small fonts !
		DEFAULT_PITCH | FF_DONTCARE, szFontName
	);

	if(!hFont) return 0;

	// create and setup compatible DC
	hBMDC = CreateCompatibleDC(0);
	SetTextColor(hBMDC, RGB(255,255,255));
	SetBkColor(hBMDC, RGB(0,0,0));
	SetBkMode(hBMDC, TRANSPARENT);
	SetMapMode(hBMDC, MM_TEXT);
    SetTextAlign(hBMDC, TA_TOP);
	SelectObject(hBMDC, hFont);

	// calculate symbols metrics
	GetTextMetrics(hBMDC, &tTextMetrics);

	for (i = 0; i < nRangeCount; i++ )
	{
		for (j = pRanges[i].First; j <= pRanges[i].Last; j++ )
		{
			GetCharABCWidthsFloat(hBMDC, j, j, &abc);

			// reserve pixels for antialiasing
			vChars[j].a = int(abc.abcfA)-1;
			vChars[j].c = int(abc.abcfC)-1;
			vChars[j].w = int(abc.abcfB)+2;
			vChars[j].h = tTextMetrics.tmHeight;
		}
	}

	// calculate symbols placement
	nWidth=32; nHeight=32;

	for(;;)
	{
		if(PlaceSymbols(nWidth, nHeight, pRanges, nRangeCount)) break;

		if(nWidth<=nHeight) nWidth<<=1;
		else nHeight<<=1;

		if(nWidth > MAX_TEXTURE_SIZE || nHeight > MAX_TEXTURE_SIZE)
		{
			DeleteObject(hFont);
			DeleteDC(hBMDC);
			return 0;
		}
	}

	// create DC bitmap
	memset(&bmi, 0, sizeof(BITMAPINFO));
	bmi.bmiHeader.biWidth = nWidth;
	bmi.bmiHeader.biHeight = -nHeight;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);

	hBM = CreateDIBSection(hBMDC, &bmi, DIB_RGB_COLORS, (void**)&pPixels, 0, 0);
	if(!hBM)
	{
		DeleteObject(hFont);
		DeleteDC(hBMDC);
		return 0;
	}

	SelectObject(hBMDC, hBM);

	// draw symbols onto DC bitmap
	for (i = 0; i < nRangeCount; i++ )
	{
		for (j = pRanges[i].First; j <= pRanges[i].Last; j++ )
		{
			char c = (char)j;
			TextOut(hBMDC, vChars[j].x-vChars[j].a, vChars[j].y, &c, 1);
		}
	}
	GdiFlush();

	// transfer DC bitmap onto HGE texture with alpha channel
	tex=hge->Texture_Create(nWidth, nHeight);
	pTexData=hge->Texture_Lock(tex, false);

	for (i=0; i<nHeight; i++)
	{
		for (j=0; j<nWidth; j++)
		{
			dwPixel = pPixels[i*nWidth+j];
			dwPixel = 0xFFFFFF | ((dwPixel & 0xFF) << 24);
			pTexData[i*nWidth+j] = dwPixel;
		}
	}

	hge->Texture_Unlock(tex);

	// clean up
	DeleteObject(hBM);
	DeleteObject(hFont);
	DeleteDC(hBMDC);

	return tex;
}

void GetErrors(fstream* f)
{
	if (f->eof())
		hge->System_Log("#Error parsing font file : end of file");
	if (f->bad())
		hge->System_Log("#Error parsing font file : bad");
	else if (f->fail())
		hge->System_Log("#Error parsing font file : fail");
}

unsigned short GetUSHORT(fstream* f, int* pos)
{
	if (f->good() && *pos != -1)
	{
		f->seekg(*pos);
		char* tmp = new char[256];
		f->read(tmp, sizeof(unsigned short));
		string s = "";
		int i1 = tmp[0]; int i2 = tmp[1];
		s += intToHex(i1);
		s += intToHex(i2);
		unsigned short u = hexToInt(s.c_str());

		//hge->System_Log("USHORT(%d) : %u, %s", *pos, u, s.c_str());

		*pos += sizeof(unsigned short);

		delete tmp;

		return u;
	}
	else
	{
		GetErrors(f);
		*pos = -1;
		return 0;
	}
}

unsigned long GetULONG(fstream* f, int* pos)
{
	if (f->good() && *pos != -1)
	{
		f->seekg(*pos);
		char* tmp = new char[256];
		f->read(tmp, sizeof(unsigned long));
		string s = "";
		int i1 = tmp[0]; int i2 = tmp[1];  int i3 = tmp[2];  int i4 = tmp[3];
		s += intToHex(i1);
		s += intToHex(i2);
		s += intToHex(i3);
		s += intToHex(i4);
		unsigned long u = hexToULong(s.c_str());

		//hge->System_Log("ULONG(%d) : %u, %s", *pos, u, s.c_str());

		*pos += sizeof(unsigned long);

		delete tmp;

		return u;
	}
	else
	{
		GetErrors(f);
		*pos = -1;
		return 0;
	}
}

string GetFontName(string lpszFilePath)
{
	fstream f(lpszFilePath.c_str(), ios::in | ios::binary);
	string csRetVal = "";

	//lpszFilePath is the path to our font file
	if (f.is_open())
	{
		//define and read file header
		TT_OFFSET_TABLE ttOffsetTable;
		int pos = ios::beg;

		ttOffsetTable.uMajorVersion = GetUSHORT(&f, &pos);
		ttOffsetTable.uMinorVersion = GetUSHORT(&f, &pos);
		ttOffsetTable.uNumOfTables = GetUSHORT(&f, &pos);
		ttOffsetTable.uSearchRange = GetUSHORT(&f, &pos);
		ttOffsetTable.uEntrySelector = GetUSHORT(&f, &pos);
		ttOffsetTable.uRangeShift = GetUSHORT(&f, &pos);

		if (pos == -1)
			return csRetVal;

		//check is this is a true type font and the version is 1.0
		if(ttOffsetTable.uMajorVersion != 1 || ttOffsetTable.uMinorVersion != 0)
			return csRetVal;

		TT_TABLE_DIRECTORY tblDir;
		bool bFound = false;
		string csTemp;

		for (int i=0; i< ttOffsetTable.uNumOfTables; i++)
		{
   			tblDir.szTag = new char[4];
   			f.read(tblDir.szTag, sizeof(char[4]));
   			pos += sizeof(char[4]);
   			tblDir.uCheckSum = GetULONG(&f, &pos);
   			tblDir.uOffset = GetULONG(&f, &pos);
   			tblDir.uLength = GetULONG(&f, &pos);

   			if (pos == -1)
   				return csRetVal;

			//table's tag cannot exceed 4 characters
			csTemp = tblDir.szTag;
			csTemp.erase(4);

			delete tblDir.szTag;

			if (csTemp == "name")
			{
				//we found our table
				bFound = true;
				break;
			}
		}

		if (bFound)
		{
			//move to offset we got from Offsets Table
			pos = tblDir.uOffset;
			TT_NAME_TABLE_HEADER ttNTHeader;
			ttNTHeader.uFSelector = GetUSHORT(&f, &pos);
			ttNTHeader.uNRCount = GetUSHORT(&f, &pos);
			ttNTHeader.uStorageOffset = GetUSHORT(&f, &pos);

			if (pos == -1)
   				return csRetVal;

			TT_NAME_RECORD ttRecord;
			bFound = true;
			for (int i=0; i<ttNTHeader.uNRCount; i++)
			{
				ttRecord.uPlatformID = GetUSHORT(&f, &pos);
				ttRecord.uEncodingID = GetUSHORT(&f, &pos);
				ttRecord.uLanguageID = GetUSHORT(&f, &pos);
				ttRecord.uNameID = GetUSHORT(&f, &pos);
				ttRecord.uStringLength = GetUSHORT(&f, &pos);
				ttRecord.uStringOffset = GetUSHORT(&f, &pos);

				if (pos == -1)
   					return csRetVal;

				//1 says that this is font name. 0 for example determines copyright info
				if (ttRecord.uNameID == 1)
				{
					//save file position, so we can return to continue with search
					int nPos = f.tellg();
					f.seekg(tblDir.uOffset + ttRecord.uStringOffset + ttNTHeader.uStorageOffset);

					char* lpszNameBuf = new char[ttRecord.uStringLength + 1];
					f.read(lpszNameBuf, ttRecord.uStringLength);
					csTemp = lpszNameBuf;

					//yes, still need to check if the font name is not empty
					//if it is, continue the search
					if (csTemp.length() > 0)
					{
						csRetVal = csTemp.erase(ttRecord.uStringLength);
						break;
					}
				}
			}
		}
	}

    return csRetVal;
}

bool fileExists(string fileName)
{
	fstream f;
	f.open(fileName.c_str(), ios::in);
	if (f.is_open())
	{
		f.close();
		return true;
	}
	f.close();
	return false;
}

hgeFont* FontManager::getFont(bool file, string szFontName, int nSize, bool bBold, bool bItalic)
{
	string fntName;
	if (file)
		fntName = GetFontName(szFontName);
	else
		fntName = szFontName;

	string id = fntName + "|" + toString(nSize) + "|" + toString(bBold) + "|" + toString(bItalic);
	if (fntList.find(id) != fntList.end())
	{
		return fntList[id];
	}
	else
	{
		if ( (fileExists(szFontName) && file) || !file)
		{
			bool fFound = false;
			vector<string>::iterator iter = ttfList.begin();
			while (iter != ttfList.end())
			{
				if (*iter == szFontName)
				{
					fFound = true;
					break;
				}
				iter++;
			}

			if (!fFound)
			{
				AddFontResource(szFontName.c_str());
				ttfList.push_back(szFontName);
			}

			CSymbolRange pRanges[2];
			pRanges[0].First = 32;
			pRanges[0].Last = 256;

			// Generate the glyphs
			HTEXTURE fntTex = TextureGenerate(
				(char*)fntName.c_str(),
				nSize, bBold, bItalic,
				pRanges, 1
			);

			// Create the hgeFont interface
			fntList[id] = new hgeFont(vChars, fntTex);

			return fntList[id];
		}
		else
		{
			hge->System_Log("#Error# : Unknown font file : \"%s\"", szFontName.c_str());
			return NULL;
		}
	}
}




/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               GUI source               */
/*                                        */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_gui.h"
#include "wowrl_lua.h"
#include "wowrl_scenemanager.h"
#include "wowrl_global.h"

extern SceneManager* mSceneMgr;
extern HGE* hge;
using namespace std;

bool debugGUI = false;

void GUIElement::deleteMe()
{
	hge->Target_Free(target);
	if (spr) delete spr;

	if (useBackdrop)
	{
		hge->Target_Free(backdrop.target);
		if (backdrop.spr) delete backdrop.spr;

		if (backdrop.edgeReady)
		{
			delete backdrop.edgeL;
			delete backdrop.edgeR;
			delete backdrop.edgeT;
			delete backdrop.edgeB;
			delete backdrop.cornerTL;
			delete backdrop.cornerTR;
			delete backdrop.cornerBL;
			delete backdrop.cornerBR;
		}

		if (backdrop.bgReady)
			delete backdrop.background;
	}
}

float GUIBase::getX( bool relative )
{
	if (banchor == NULL)
		banchor = &anchors[0];
	float px = 0.0f;
	float pw = 0.0f;
	if (banchor->parent != NULL)
	{
		pw = banchor->parent->w;
		if (!relative)
			px += banchor->parent->getX(false);
	}
	else
	{
		pw = mSceneMgr->sWidth;
	}

	switch (banchor->anchorPt)
	{
		case GUI_ANCHOR_TOPLEFT: px-=0; break;
		case GUI_ANCHOR_TOP: px-=w/2.0f; break;
		case GUI_ANCHOR_TOPRIGHT: px-=w; break;
		case GUI_ANCHOR_RIGHT: px-=w; break;
		case GUI_ANCHOR_BOTTOMRIGHT: px-=w; break;
		case GUI_ANCHOR_BOTTOM: px-=w/2.0f; break;
		case GUI_ANCHOR_BOTTOMLEFT: px-=0; break;
		case GUI_ANCHOR_LEFT: px-=0; break;
		case GUI_ANCHOR_CENTER: px-=w/2.0f; break;
	}

	switch (banchor->relativePt)
	{
		case GUI_ANCHOR_TOPLEFT: px+=0; break;
		case GUI_ANCHOR_TOP: px+=pw/2.0f; break;
		case GUI_ANCHOR_TOPRIGHT: px+=pw; break;
		case GUI_ANCHOR_RIGHT: px+=pw; break;
		case GUI_ANCHOR_BOTTOMRIGHT: px+=pw; break;
		case GUI_ANCHOR_BOTTOM: px+=pw/2.0f; break;
		case GUI_ANCHOR_BOTTOMLEFT: px+=0; break;
		case GUI_ANCHOR_LEFT: px+=0; break;
		case GUI_ANCHOR_CENTER: px+=pw/2.0f; break;
	}

	x = px+banchor->x;

	return x;
}

float GUIBase::getY( bool relative )
{
	if (banchor == NULL)
		banchor = &anchors[0];
	float py = 0.0f;
	float ph = 0.0f;
	if (banchor->parent != NULL)
	{
		ph = banchor->parent->h;
		if (!relative)
			py += banchor->parent->getY(false);
	}
	else
	{
		ph = mSceneMgr->sHeight;
	}

	switch (banchor->anchorPt)
	{
		case GUI_ANCHOR_TOPLEFT: py+=0; break;
		case GUI_ANCHOR_TOP: py+=0; break;
		case GUI_ANCHOR_TOPRIGHT: py+=0; break;
		case GUI_ANCHOR_RIGHT: py+=h/2.0f; break;
		case GUI_ANCHOR_BOTTOMRIGHT: py+=h; break;
		case GUI_ANCHOR_BOTTOM: py+=h; break;
		case GUI_ANCHOR_BOTTOMLEFT: py+=h; break;
		case GUI_ANCHOR_LEFT: py+=h/2.0f; break;
		case GUI_ANCHOR_CENTER: py+=h/2.0f; break;
	}

	switch (banchor->relativePt)
	{
		case GUI_ANCHOR_TOPLEFT: py-=0; break;
		case GUI_ANCHOR_TOP: py-=0; break;
		case GUI_ANCHOR_TOPRIGHT: py-=0; break;
		case GUI_ANCHOR_RIGHT: py-=ph/2.0f; break;
		case GUI_ANCHOR_BOTTOMRIGHT: py-=ph; break;
		case GUI_ANCHOR_BOTTOM: py-=ph; break;
		case GUI_ANCHOR_BOTTOMLEFT: py-=ph; break;
		case GUI_ANCHOR_LEFT: py-=ph/2.0f; break;
		case GUI_ANCHOR_CENTER: py-=ph/2.0f; break;
	}

	y = py+banchor->y;

	return y;
}

void GUIBase::_init()
{
	/* [#] This function takes care of initialization of the GUIBase class.
	/* It calls the _init() lua method which creates a pointer to this object in
	/* it's corresponding element in the LUA environnement.
	*/
	bool debugThis = false;

	// Initialize LUA class
	string exec = name + ":_init();";
	if (debugThis) hge->System_Log("%s", exec.c_str());
	int error = luaL_dostring(mSceneMgr->luaVM, exec.c_str());
	if (error) l_logPrint(mSceneMgr->luaVM);
	GUIBase* p = parent;
	string hierarchy = sname;
	string newObj;
	while (p != NULL)
	{
		newObj = p->name + "." + hierarchy;
		exec = newObj + " = " + name + ";\n";
		exec += newObj + ":_init();";
		if (debugThis) hge->System_Log("%s", exec.c_str());
		int error = luaL_dostring(mSceneMgr->luaVM, exec.c_str());
		if (error) l_logPrint(mSceneMgr->luaVM);
		hierarchy = p->sname + "." + hierarchy;
		p = p->parent;
	}

	// Initialize position and anchors
	banchor = &anchors[0];
	this->getX();
	this->getY();

}

void GUIElement::_init()
{
	/* [#] This function takes care of initialization of the GUIElement class.
	/* It calls the GUIBase::_init() function and creates the render target
	/* associated with this element.
	*/
	GUIBase* thisB = this;
	thisB->_init();

	map<string, GUIElement*>::iterator iterChild;
	for (iterChild = childs.begin(); iterChild != childs.end(); iterChild++)
	{
		GUIElement* g = iterChild->second;
		g->_init();

		map<string, GUIArt>::iterator iter;
		for (iter = g->arts.begin(); iter != g->arts.end(); iter++)
		{
			GUIArt* a = &iter->second;
			a->_init();
		}
	}

	// Initialize cache
	target = hge->Target_Create(toInt(w), toInt(h), false);
	spr = new hgeSprite(hge->Target_GetTexture(target), 0, 0, toInt(w), toInt(h));
}

void GUIElement::_rebuildCache( bool child )
{
	/* [#] This function is used to tell the program to re-draw the cache the
	/* next time Render() is called. When called, this function also calls itself
	/* on the element's parent, and on all of it's child if stated.
	*/
	if ( (type == GUI_OBJECT_TYPE_FRAME) || (type == GUI_OBJECT_TYPE_STATUSBAR) )
	{
		rebuildCache = true;
		if (child)
		{
			map<string, GUIElement*>::iterator iterChild;
			for (iterChild = childs.begin(); iterChild != childs.end(); iterChild++)
			{
				iterChild->second->_rebuildCache(true);
			}
		}
		if (parent != NULL)
			parent->_rebuildCache();
	}
}

bool GUIBase::IsVisible()
{
	/* [#] This function checks if this GUI object is visible or not. That means
	/* that it is shown, and all it's parent also.
	*/
	if (parent == NULL)
		return !hidden;
	else
	{
		return (!hidden && parent->IsVisible());
	}
}

void GUIArt::Render()
{
	// [#] This function renders a GUI art (texture or text).
	if (ready && !hidden)
	{
		// The coordinates are relative to its parent.
		ax = this->getX()-parent->getX();
		ay = parent->getY()-this->getY();
		if (type == GUI_OBJECT_TYPE_TEXTURE)
		{
			if (sprite != NULL)
			{
				sprite->RenderEx(ax, ay, angle, scale, vscale);
				sprite->RenderEx(ax, ay, angle, scale, vscale);
			}
		}
		else if (type == GUI_OBJECT_TYPE_FONTSTRING)
		{
			if (text.fnt != NULL)
			{
				if (text.outline != 0)
				{
					text.fnt->SetTracking(text.tracking);
					text.fnt->SetColor(ARGB(200, 0, 0, 0));

					// Render the text all around
					for (float f = 0.0f; f <= 2.0f; f += 0.1f)
					{
						text.fnt->printfb
						(
							false,
							ax+text.outline*cos(f*2*M_PI), ay+text.outline*sin(f*2*M_PI),
							w, h, text.align,
							text.str.c_str()
						);
					}

					text.fnt->SetColor(text.color);
					text.fnt->printfb(false, ax, ay, w, h, text.align, text.str.c_str());
					text.fnt->printfb(false, ax, ay, w, h, text.align, text.str.c_str());
				}
				else
				{
					if ( text.shadow && (text.sfnt != NULL) )
					{
						text.sfnt->SetTracking(text.tracking);
						text.sfnt->SetColor(text.scolor);
						text.sfnt->printfb(false, ax+text.sox, ay-text.soy, w, h, text.align, text.str.c_str());
						text.sfnt->printfb(false, ax+text.sox, ay-text.soy, w, h, text.align, text.str.c_str());
					}
					text.fnt->SetTracking(text.tracking);
					text.fnt->SetColor(text.color);
					text.fnt->printfb(false, ax, ay, w, h, text.align, text.str.c_str());
					text.fnt->printfb(false, ax, ay, w, h, text.align, text.str.c_str());
				}
			}
		}
		else if (type == GUI_OBJECT_TYPE_TSTATUSBAR)
		{
			if (sprite != NULL)
			{
				float x,y,w,h;
				sprite->GetTextureRect(&x, &y, &w, &h);
				// Here we adjust the texture coordinate to achieve the status bar effect.
				w = parent->base_width*((parent->value-parent->min_value)/(parent->max_value-parent->min_value));
				sprite->SetTextureRect(x, y, w, h);
				sprite->RenderEx(ax, ay, angle, scale, vscale);
				sprite->RenderEx(ax, ay, angle, scale, vscale);
			}
		}
	}
}

void GUIElement::Render( bool cache )
{
	/* [#] This function renders a GUI element on the screen or on it's parent
	/* cache depending on the provided boolean. The cache system is used to
	/* increase the GUI performance by re-drawing every element only if needed.
	*/

	if (this->IsVisible())
	{
		if (cache)
		{
			if (recreateCache)
			{
				// The cache needs to be re-created (size change, mainly)
				if (debugGUI) {hge->System_Log("%s : recreateCache...", name.c_str());}
				hge->Target_Free(target);
				target = hge->Target_Create(toInt(w), toInt(h), false);
				delete spr;
				spr = new hgeSprite(hge->Target_GetTexture(target), 0, 0, toInt(w), toInt(h));
				recreateCache = false;
				rebuildCache = true;
				if (useBackdrop)
				{
					hge->Target_Free(backdrop.target);
					backdrop.target = hge->Target_Create(toInt(w), toInt(h), false);
					delete backdrop.spr;
					backdrop.spr = new hgeSprite(hge->Target_GetTexture(backdrop.target), 0, 0, toInt(w), toInt(h));
					rebuildBackdrop = true;
				}
			}

			if (rebuildCache)
			{
				if (debugGUI) {hge->System_Log("%s : rebuildCache...", name.c_str());}
				if (useBackdrop && rebuildBackdrop)
				{
					// Cache the backdrop
					hge->Gfx_BeginScene(backdrop.target);
					hge->Gfx_Clear(ARGB(0,0,0,0));

					// Render the background
					if (backdrop.bgReady)
					{
						if (fabs(h-backdrop.insT-backdrop.insB) > 0.1f)
						{
							for (int i=0; i<2; i++)
								if (backdrop.tile)
									backdrop.background->Render(backdrop.insL, backdrop.insT);
								else
									backdrop.background->RenderEx(
										backdrop.insL,
										backdrop.insT,
										0.0f,
										(w-backdrop.insL-backdrop.insR)/backdrop.bgW,
										(h-backdrop.insT-backdrop.insB)/backdrop.bgH
									);
						}
					}

					// Render corners
					if (backdrop.edgeReady)
					{
						for (int i=0; i<2; i++)
						{
							backdrop.cornerTL->RenderEx(0, 0, 0.0f, backdrop.edgeSize/backdrop.edgeOriginalSize);
							backdrop.cornerTR->RenderEx(w-backdrop.edgeSize, 0, 0.0f, backdrop.edgeSize/backdrop.edgeOriginalSize);
							backdrop.cornerBL->RenderEx(0, h-backdrop.edgeSize, 0.0f, backdrop.edgeSize/backdrop.edgeOriginalSize);
							backdrop.cornerBR->RenderEx(w-backdrop.edgeSize, h-backdrop.edgeSize, 0.0f, backdrop.edgeSize/backdrop.edgeOriginalSize);
							// Render edges
							backdrop.edgeL->Render4V(
								0, backdrop.edgeSize,
								backdrop.edgeSize, backdrop.edgeSize,
								backdrop.edgeSize, h-backdrop.edgeSize,
								0, h-backdrop.edgeSize
							);
							backdrop.edgeR->Render4V(
								w-backdrop.edgeSize, backdrop.edgeSize,
								w, backdrop.edgeSize,
								w, h-backdrop.edgeSize,
								w-backdrop.edgeSize, h-backdrop.edgeSize
							);
							backdrop.edgeT->Render4V(
								w-backdrop.edgeSize, 0,
								w-backdrop.edgeSize, backdrop.edgeSize,
								backdrop.edgeSize, backdrop.edgeSize,
								backdrop.edgeSize, 0
							);
							backdrop.edgeB->Render4V(
								w-backdrop.edgeSize, h-backdrop.edgeSize,
								w-backdrop.edgeSize, h,
								backdrop.edgeSize, h,
								backdrop.edgeSize, h-backdrop.edgeSize
							);
						}
					}

					hge->Gfx_EndScene();

					rebuildBackdrop = false;
				}

				if (rebuildList)
				{
					sortedGUIList.clear();
					map<string, GUIElement*>::iterator iterChild;
					for (iterChild = childs.begin(); iterChild != childs.end(); iterChild++)
					{
						GUIElement* g = iterChild->second;
						sortedGUIList.insert(make_pair(g->frameStrata, g));
					}
					rebuildList = false;
				}

				multimap<int, GUIElement*>::iterator iterChild2;
				for (iterChild2 = sortedGUIList.begin(); iterChild2 != sortedGUIList.end(); iterChild2++)
				{
					iterChild2->second->Render(true);
				}

				hge->Gfx_BeginScene(target);
				hge->Gfx_Clear(ARGB(0,0,0,0));

				// First sort every art by their layer value
				multimap<int, GUIArt*> sortedMap;
				map<std::string, GUIArt>::iterator iterArt;
				for (iterArt = arts.begin(); iterArt != arts.end(); iterArt++)
				{
					sortedMap.insert(make_pair(iterArt->second.layer, &iterArt->second));
				}

				// Then render them in the proper order, after the backdrop if needed
				if (useBackdrop)
				{
					backdrop.spr->Render(0,0);
					//backdrop.spr->Render(0,0); // Debug alpha
				}

				multimap<int, GUIArt*>::iterator iterSArt;
				for (iterSArt = sortedMap.begin(); iterSArt != sortedMap.end(); iterSArt++)
				{
					GUIArt* a = iterSArt->second;
					a->Render();
					//a->Render(); // Debug alpha
				}

				for (iterChild2 = sortedGUIList.begin(); iterChild2 != sortedGUIList.end(); iterChild2++)
				{
					iterChild2->second->Render(false);
					iterChild2->second->Render(false); // Debug alpha
				}

				hge->Gfx_EndScene();

				rebuildCache = false;
			}
		}
		else
		{
			if (parent != NULL)
			{
				gx = this->getX()-parent->getX();
				gy = parent->getY()-this->getY();
			}
			else
			{
				gx = this->getX();
				gy = -this->getY();
			}

			spr->Render(gx, gy);
		}
	}
}

void GUIElement::copyVirt(GUIElement* frame)
{
	/* [#] This function copies this virtual frame's properties in the provided
	/* real frame. This function allows inheritance and templates.
	*/
	bool debugThis = false;
	if (frame == NULL)
	{
		if (debugThis) hge->System_Log("Error copying %s to unknown frame", vname.c_str());
	}
	else
	{
		if (debugThis) hge->System_Log("Copying %s to %s", vname.c_str(), frame->name.c_str());
		if (virt && !frame->virt)
		{
			// Copy base parameters
			if (debugThis) hge->System_Log("1");
			frame->hidden = hidden;
			frame->w = w;
			frame->h = h;
			frame->alpha = alpha;
			frame->enableMouse = enableMouse;

			frame->OnLoadDef = OnLoadDef;
			frame->OnMouseDownDef = OnMouseDownDef;
			frame->OnMouseUpDef = OnMouseUpDef;
			frame->OnDragStartDef = OnDragStartDef;
			frame->OnReceiveDragDef = OnReceiveDragDef;
			frame->OnEnterDef = OnEnterDef;
			frame->OnLeaveDef = OnLeaveDef;
			frame->OnUpdateDef = OnUpdateDef;

			frame->OnLoadText = OnLoadText;
			frame->OnMouseDownText = OnMouseDownText;
			frame->OnMouseUpText = OnMouseUpText;
			frame->OnDragStartText = OnDragStartText;
			frame->OnReceiveDragText = OnReceiveDragText;
			frame->OnEnterText = OnEnterText;
			frame->OnLeaveText = OnLeaveText;
			frame->OnUpdateText = OnUpdateText;

			// Copy and update backdrop
			frame->useBackdrop = useBackdrop;
			if (useBackdrop)
			{
				frame->backdrop = backdrop;

				// Load edges
				if (frame->backdrop.edgeFile != "")
				{
					HTEXTURE tex1 = mSceneMgr->loadTexture(frame->backdrop.edgeFile, false);
					float size = (int)floor(hge->Texture_GetWidth(tex1, true)/8.0f);
					frame->backdrop.edgeL = new hgeSprite(tex1, 0, 0, size, size);
					frame->backdrop.edgeR = new hgeSprite(tex1, size, 0, size, size);
					frame->backdrop.edgeT = new hgeSprite(tex1, 2*size, 0, size, size);
					frame->backdrop.edgeB = new hgeSprite(tex1, 3*size, 0, size, size);
					frame->backdrop.cornerTL = new hgeSprite(tex1, 4*size, 0, size, size);
					frame->backdrop.cornerTR = new hgeSprite(tex1, 5*size, 0, size, size);
					frame->backdrop.cornerBL = new hgeSprite(tex1, 6*size, 0, size, size);
					frame->backdrop.cornerBR = new hgeSprite(tex1, 7*size, 0, size, size);
					frame->backdrop.edgeOriginalSize = size;
					frame->backdrop.edgeReady = true;
				}
				else
					frame->backdrop.edgeReady = false;

				// Load background
				if (frame->backdrop.bgFile != "")
				{
					HTEXTURE tex2;
					tex2 = mSceneMgr->loadTexture(frame->backdrop.bgFile, false);

					frame->backdrop.bgW = hge->Texture_GetWidth(tex2, true);
					frame->backdrop.bgH = hge->Texture_GetHeight(tex2, true);

					if (frame->backdrop.tile)
						frame->backdrop.background = new hgeSprite(tex2, 0, 0, frame->w-frame->backdrop.insL-frame->backdrop.insR, frame->h-frame->backdrop.insT-frame->backdrop.insB);
					else
						frame->backdrop.background = new hgeSprite(tex2, 0, 0, frame->backdrop.bgW, frame->backdrop.bgH);

					frame->backdrop.bgReady = true;
				}
				else
					frame->backdrop.bgReady = false;

				frame->backdrop.target = hge->Target_Create(toInt(frame->w), toInt(frame->h), false);
				frame->backdrop.spr = new hgeSprite(hge->Target_GetTexture(frame->backdrop.target), 0, 0, toInt(frame->w), toInt(frame->h));
			}

			// Copy and update anchors
			map<int, Anchor>::iterator iter;
			for (iter = anchors.begin(); iter != anchors.end(); iter++)
			{
				Anchor a = iter->second;
				int i = a.parent_name.find("$parent");
				if (i != a.parent_name.npos)
				{
					a.parent_name = a.parent_name.erase(i, 7);
					if (frame->parent != NULL)
						a.parent_name.insert(i, frame->parent->name);
				}
				a.parent = mSceneMgr->parentList[a.parent_name];
				frame->anchors[iter->first] = a;
			}

			// Copy and update arts
			if (debugThis) hge->System_Log("2");
			map<string, GUIArt>::iterator iterArt;
			for (iterArt = arts.begin(); iterArt != arts.end(); iterArt++)
			{
				if (debugThis) hge->System_Log("2.1");
				GUIArt a = iterArt->second;
				a.virt = false;
				a.parent = frame;
				a.sname = a.name;
				int i = a.name.find("$parent");
				if (i != a.name.npos)
				{
					a.name = a.name.erase(i, 7);
					a.sname = a.name;
					a.name.insert(i, frame->name);
				}

				if (debugThis) hge->System_Log("2.2 %s", a.name.c_str());

				if ((frame->arts.find(a.name) == frame->arts.end()) && (a.name != ""))
				{
					if (debugThis) hge->System_Log("2.3");
					map<int, Anchor>::iterator iter;
					for (iter = a.anchors.begin(); iter != a.anchors.end(); iter++)
					{
						if (debugThis) hge->System_Log("2.3.1");
						Anchor* an = &iter->second;
						if (an->parent_name != "")
						{
							int i = an->parent_name.find("$parent");
							if (i != an->parent_name.npos)
							{
								an->parent_name = an->parent_name.erase(i, 7);
								an->parent_name.insert(i, frame->name);
							}
						}
					}
					if (debugThis) hge->System_Log("2.4");
					if ( (a.type == GUI_OBJECT_TYPE_TEXTURE) || (a.type == GUI_OBJECT_TYPE_TSTATUSBAR) )
					{
						if (debugThis) hge->System_Log("2.4.1");
						if (iterArt->second.ready)
							a.sprite = mSceneMgr->createSprite(iterArt->second.sprite, true);
						string exec = a.name + " = Texture(\"" + a.parent->name + "\", \"" + a.name + "\");";
						if (debugThis) hge->System_Log("2.4.2");
						luaL_dostring(mSceneMgr->luaVM, exec.c_str());
						if (debugThis) hge->System_Log("2.4.3");
					}
					else if (a.type == GUI_OBJECT_TYPE_FONTSTRING)
					{
						if (debugThis) hge->System_Log("2.4.4");
						string exec = a.name + " = FontString(\"" + a.parent->name + "\", \"" + a.name + "\");";
						if (debugThis) hge->System_Log("2.4.5");
						luaL_dostring(mSceneMgr->luaVM, exec.c_str());
						if (debugThis) hge->System_Log("2.4.6");
					}
					frame->arts[a.name] = a;
					mSceneMgr->parentList[a.name] = &frame->arts[a.name];
				}
			}
			if (debugThis) hge->System_Log("3");
			for (iterArt = frame->arts.begin(); iterArt != frame->arts.end(); iterArt++)
			{
				if (debugThis) hge->System_Log("3.1");
				GUIArt* a = &iterArt->second;
				map<int, Anchor>::iterator iter;
				for (iter = a->anchors.begin(); iter != a->anchors.end(); iter++)
				{
					if (debugThis) hge->System_Log("3.1.1");
					Anchor* an = &iter->second;
					if (an->parent_name != "")
						an->parent = mSceneMgr->parentList[an->parent_name];
				}
			}

			// Copy and update childs
			if (debugThis) hge->System_Log("4");
			map<string, GUIElement>::iterator iterChild;
			for (iterChild = vchilds.begin(); iterChild != vchilds.end(); iterChild++)
			{
				if (debugThis) hge->System_Log("4.1");
				GUIElement* base = &iterChild->second;
				GUIElement c;
				c.name = base->name;
				c.anchors = base->anchors;
				c.type = base->type;
				c.child = base->child;
				c.virt = false;
				c.parent = frame;
				c.parent_name = frame->name;
				c.sname = c.name;

				int i = c.name.find("$parent");
				if (i != c.name.npos)
				{
					c.name = c.name.erase(i, 7);
					c.sname = c.name;
					c.name.insert(i, frame->name);
				}
				if (debugThis) hge->System_Log("4.2 %s", c.name.c_str());

				if ((mSceneMgr->guiList.find(c.name) == mSceneMgr->guiList.end()) && (c.name != ""))
				{
					if (debugThis) hge->System_Log("4.3");
					map<int, Anchor>::iterator iter;
					for (iter = c.anchors.begin(); iter != c.anchors.end(); iter++)
					{
						if (debugThis) hge->System_Log("4.3.1");
						Anchor* a = &iter->second;
						if (a->parent_name != "")
						{
							int i = a->parent_name.find("$parent");
							if (i != a->parent_name.npos)
							{
								a->parent_name = a->parent_name.erase(i, 7);
								if (frame->parent != NULL)
									a->parent_name.insert(i, frame->parent->name);
								a->parent = mSceneMgr->parentList[a->parent_name];
							}
						}
					}
					if (debugThis) hge->System_Log("4.4");
					mSceneMgr->guiList[c.name] = c;
					mSceneMgr->parentList[c.name] = &mSceneMgr->guiList[c.name];
					frame->childs[c.name] = &mSceneMgr->guiList[c.name];

					base->copyVirt(&mSceneMgr->guiList[c.name]);

					if (debugThis) hge->System_Log("4.5");

					string exec;
					if (c.type == GUI_OBJECT_TYPE_STATUSBAR)
					{
						exec = c.name + " = StatusBar(\"" + c.name + "\");";
						luaL_dostring(mSceneMgr->luaVM, exec.c_str());
					}
					else
					{
						exec = c.name + " = Frame(\"" + c.name + "\");";
						luaL_dostring(mSceneMgr->luaVM, exec.c_str());
					}

					if (debugThis) hge->System_Log("4.6");
				}
			}
		}
	}
	if (debugThis) hge->System_Log("5");
}

GUIBase* GUIBase::getHighestVirtParent()
{
	// [#] This function returns the highest parent which is virtual.
	if (parent != NULL)
	{
		GUIElement* tparent = parent;
		while (tparent->virt)
		{
			if (tparent->parent == NULL)
				break;
			else
				tparent = tparent->parent;
		}
		return tparent;
	}
	else
	{
		if (type == GUI_OBJECT_TYPE_FRAME)
			return this;
		else
			return NULL;
	}
}

void GUIElement::_print(int level)
{
	/* [#] This function prints in the log a very detailed set of informations
	/* about itself, its arts and its childs. It's a recursive function.
	*/
	string tab = string(level*4, ' ');
	string lparent_name, aparent_name;
	if (parent == NULL)
		lparent_name = "no parent";
	else
		lparent_name = parent->name;
	if (anchors[0].parent == NULL)
		aparent_name = "no parent (" + anchors[0].parent_name + ")";
	else
		aparent_name = anchors[0].parent->name;
	hge->System_Log("%s - [%d] %s (%.0f, %.0f, %.2f, %.2f, %s, %s, %d, %d)", tab.c_str(), frameStrata, name.c_str(), gx, gx, w, h, lparent_name.c_str(), aparent_name.c_str(), anchors.size(), hidden);
	hge->System_Log("%s   # Arts :", tab.c_str());
	map<string, GUIArt>::iterator iter3;
	for (iter3 = arts.begin(); iter3 != arts.end(); iter3++)
	{
		GUIArt* a = &iter3->second;
		string parentname;
		if (a->anchors[0].parent == NULL)
			parentname = "no parent (" + a->anchors[0].parent_name + ")";
		else
			parentname = a->anchors[0].parent->name;
		hge->System_Log("%s    - %s : (anchor : %d, %s, %d)", tab.c_str(), a->name.c_str(), a->anchors[0].anchorPt, parentname.c_str(), a->anchors[0].relativePt);
		hge->System_Log("%s      %.0f, %.0f, %.2f, %.2f", tab.c_str(), a->ax, a->ay, a->scale, a->vscale);
	}
	hge->System_Log("%s   # Childs :", tab.c_str());
	map<string, GUIElement*>::iterator iterChild;
	for (iterChild = childs.begin(); iterChild != childs.end(); iterChild++)
	{
		iterChild->second->_print(level+1);
	}
}

void GUIElement::CheckInput(float mx, float my, int lbutton, int rbutton)
{
	/* [#] This function tracks inputs on this element, such as mouse overing,
	/* cliks, ...
	*/
	if (enableMouse)
	{
		if ( (mx >= x) && (mx < x+w) && (my >= -y) && (my < h-y) )
		{
			if (!baseUI)
				mSceneMgr->mouseOverPlayField = false;

			if (!lastOn)
				this->OnEnter();

			if ( (lbutton == 1) || (rbutton == 1) )
			{
				if (!mSceneMgr->lastDragged && registeredForDrag && !mSceneMgr->squareSelection)
				{
					this->OnDragStart();
					mSceneMgr->lastDragged = true;
				}
			}
			else if ( (lbutton == 2) || (rbutton == 2) )
			{
				this->OnMouseDown();
			}
			else if ( (lbutton == 3) || (rbutton == 3) )
			{
				this->OnMouseUp();
				if (mSceneMgr->lastDragged && !mSceneMgr->squareSelection)
				{
					if (registeredForDrag)
						this->OnReceiveDrag();
					mSceneMgr->lastDragged = false;
				}
			}

			lastOn = true;
		}
		else
		{
			if (lastOn)
				this->OnLeave();

			lastOn = false;
		}
	}
}

void GUIElement::OnLoad()
{
	if (OnLoadId != 0)
	{
		string str = "";
		str += "this = " + name + ";\n";
		luaL_dostring(mSceneMgr->luaVM, str.c_str());
		lua_getglobal(mSceneMgr->luaVM, "Functions");
		lua_rawgeti(mSceneMgr->luaVM, -1, OnLoadId);
		lua_call(mSceneMgr->luaVM, 0, 0);
		lua_pop(mSceneMgr->luaVM, 2);
	}
	else if (OnLoadDef)
	{
		string str = "";
		str += "this = " + name + ";\n";
		str += OnLoadText;
		int error = luaL_dostring(mSceneMgr->luaVM, str.c_str());
		if (error) l_logPrint(mSceneMgr->luaVM);
	}

	map<string, GUIElement*>::iterator iterChild;
	for (iterChild = childs.begin(); iterChild != childs.end(); iterChild++)
	{
		iterChild->second->OnLoad();
	}
}

void GUIElement::SetOnLoadFunction( int i )
{
	OnLoadId = i;
}

void GUIElement::OnMouseDown()
{
	if (OnMouseDownId != 0)
	{
		string str = "";
		str += "this = " + name + ";\n";
		str += "arg1 = \"" + mSceneMgr->mouseButton + "\";\n";
		luaL_dostring(mSceneMgr->luaVM, str.c_str());
		lua_getglobal(mSceneMgr->luaVM, "Functions");
		lua_rawgeti(mSceneMgr->luaVM, -1, OnMouseDownId);
		lua_pushstring(mSceneMgr->luaVM, mSceneMgr->mouseButton.c_str());
		lua_call(mSceneMgr->luaVM, 1, 0);
		lua_pop(mSceneMgr->luaVM, 3);
	}
	else if (OnMouseDownDef)
	{
		mSceneMgr->lScriptsStr += "\nthis = " + name + ";\n";
		mSceneMgr->lScriptsStr += "arg1 = \"" + mSceneMgr->mouseButton + "\";\n";
		mSceneMgr->lScriptsStr += OnMouseDownText;
	}
}

void GUIElement::SetOnMouseDownFunction( int i )
{
	OnMouseDownId = i;
}

void GUIElement::OnMouseUp()
{
	if (OnMouseUpId != 0)
	{
		string str = "";
		str += "this = " + name + ";\n";
		str += "arg1 = \"" + mSceneMgr->mouseButton + "\";\n";
		luaL_dostring(mSceneMgr->luaVM, str.c_str());
		lua_getglobal(mSceneMgr->luaVM, "Functions");
		lua_rawgeti(mSceneMgr->luaVM, -1, OnMouseUpId);
		lua_pushstring(mSceneMgr->luaVM, mSceneMgr->mouseButton.c_str());
		lua_call(mSceneMgr->luaVM, 1, 0);
		lua_pop(mSceneMgr->luaVM, 3);
	}
	else if (OnMouseUpDef)
	{
		mSceneMgr->lScriptsStr += "\nthis = " + name + ";\n";
		mSceneMgr->lScriptsStr += "arg1 = \"" + mSceneMgr->mouseButton + "\";\n";
		mSceneMgr->lScriptsStr += OnMouseUpText;
	}
}

void GUIElement::SetOnMouseUpFunction( int i )
{
	OnMouseUpId = i;
}

void GUIElement::OnDragStart()
{
	if (OnDragStartId != 0)
	{
		string str = "";
		str += "this = " + name + ";\n";
		str += "arg1 = \"" + mSceneMgr->mouseButton + "\";\n";
		luaL_dostring(mSceneMgr->luaVM, str.c_str());
		lua_getglobal(mSceneMgr->luaVM, "Functions");
		lua_rawgeti(mSceneMgr->luaVM, -1, OnDragStartId);
		lua_pushstring(mSceneMgr->luaVM, mSceneMgr->mouseButton.c_str());
		lua_call(mSceneMgr->luaVM, 1, 0);
		lua_pop(mSceneMgr->luaVM, 3);
	}
	else if (OnDragStartDef)
	{
		mSceneMgr->lScriptsStr += "\nthis = " + name + ";\n";
		mSceneMgr->lScriptsStr += "arg1 = \"" + mSceneMgr->mouseButton + "\";\n";
		mSceneMgr->lScriptsStr += OnDragStartText;
	}
}

void GUIElement::SetOnDragStartFunction( int i )
{
	OnDragStartId = i;
}

void GUIElement::OnReceiveDrag()
{
	if (OnReceiveDragId != 0)
	{
		string str = "";
		str += "this = " + name + ";\n";
		str += "arg1 = \"" + mSceneMgr->mouseButton + "\";\n";
		luaL_dostring(mSceneMgr->luaVM, str.c_str());
		lua_getglobal(mSceneMgr->luaVM, "Functions");
		lua_rawgeti(mSceneMgr->luaVM, -1, OnReceiveDragId);
		lua_pushstring(mSceneMgr->luaVM, mSceneMgr->mouseButton.c_str());
		lua_call(mSceneMgr->luaVM, 1, 0);
		lua_pop(mSceneMgr->luaVM, 3);
	}
	else if (OnReceiveDragDef)
	{
		mSceneMgr->lScriptsStr += "\nthis = " + name + ";\n";
		mSceneMgr->lScriptsStr += "arg1 = \"" + mSceneMgr->mouseButton + "\";\n";
		mSceneMgr->lScriptsStr += OnReceiveDragText;
	}
}

void GUIElement::SetOnReceiveDragFunction( int i )
{
	OnReceiveDragId = i;
}

void GUIElement::OnEnter()
{
	if (OnEnterId != 0)
	{
		string str = "";
		str += "this = " + name + ";\n";
		luaL_dostring(mSceneMgr->luaVM, str.c_str());
		lua_getglobal(mSceneMgr->luaVM, "Functions");
		lua_rawgeti(mSceneMgr->luaVM, -1, OnEnterId);
		lua_call(mSceneMgr->luaVM, 0, 0);
		lua_pop(mSceneMgr->luaVM, 2);
	}
	else if (OnEnterDef)
	{
		mSceneMgr->lScriptsStr += "\nthis = " + name + ";\n";
		mSceneMgr->lScriptsStr += OnEnterText;
	}
}

void GUIElement::SetOnEnterFunction( int i )
{
	OnEnterId = i;
}

void GUIElement::OnLeave()
{
	if (OnLeaveId != 0)
	{
		string str = "";
		str += "this = " + name + ";\n";
		luaL_dostring(mSceneMgr->luaVM, str.c_str());
		lua_getglobal(mSceneMgr->luaVM, "Functions");
		lua_rawgeti(mSceneMgr->luaVM, -1, OnLeaveId);
		lua_call(mSceneMgr->luaVM, 0, 0);
		lua_pop(mSceneMgr->luaVM, 2);
	}
	else if (OnLeaveDef)
	{
		mSceneMgr->lScriptsStr += "\nthis = " + name + ";\n";
		mSceneMgr->lScriptsStr += OnLeaveText;
	}
}

void GUIElement::SetOnLeaveFunction( int i )
{
	OnLeaveId = i;
}

void GUIElement::OnUpdate()
{
	if (OnUpdateId != 0)
	{
		string str = "";
		str += "this = " + name + ";\n";
		str += "arg1 = " + toString(mSceneMgr->dt) + ";\n";
		luaL_dostring(mSceneMgr->luaVM, str.c_str());
		lua_getglobal(mSceneMgr->luaVM, "Functions");
		lua_rawgeti(mSceneMgr->luaVM, -1, OnUpdateId);
		lua_pushnumber(mSceneMgr->luaVM, mSceneMgr->dt);
		lua_call(mSceneMgr->luaVM, 1, 0);
		lua_pop(mSceneMgr->luaVM, 3);
	}
	else if (OnUpdateDef)
	{
		mSceneMgr->lScriptsStr += "\nthis = " + name + ";\n";
		mSceneMgr->lScriptsStr += "arg1 = " + toString(mSceneMgr->dt) + ";\n";
		mSceneMgr->lScriptsStr += OnUpdateText;
	}
}

void GUIElement::SetOnUpdateFunction( int i )
{
	OnUpdateId = i;
}

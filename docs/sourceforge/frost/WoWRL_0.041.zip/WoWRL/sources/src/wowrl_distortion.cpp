/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Distortion source            */
/*                                        */
/*  ## : Contains all the functions that  */
/*  are related to distortion.            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge/hge.h"
#include "hge/hgesprite.h"
#include "hge/hgevector.h"

#include "wowrl_point.h"
#include "wowrl_global.h"
#include "wowrl_scenemanager.h"
#include "wowrl_structs.h"

extern HGE *hge;
extern SceneManager *mSceneMgr;

float getPointDistortion( int x, int y )
{
	/* [#] This function returns the distortion of a point. It is no longer used.
	*/

    float distortion;
	BGPart* part = mSceneMgr->actualZone.getBGPart(x, y);
	if (part->distData)
	{
		x -= toInt(part->x);
		y -= toInt(part->y);
		int colorIndex = toInt(y*mSceneMgr->actualZone.partSize + x);
		if ( (colorIndex >= 0) && (colorIndex < toInt(mSceneMgr->actualZone.partSize*mSceneMgr->actualZone.partSize+mSceneMgr->actualZone.partSize)) )
		{
			// Distortion is read on the RED chanel
        	distortion = GETR(part->dist[colorIndex]);
		}
		else
			distortion = 0.0f;
	}
	else
		distortion = 0.0f;

    return distortion/255.0f;
}

float getPointShadow( int x, int y )
{
	/* [#] This function returns the intensity of the shadow at the given coordi-
	/* nates.
	*/

    float shadow;
	BGPart* part = mSceneMgr->actualZone.getBGPart(x, y);
	if (part->distData)
	{
		x -= toInt(part->x);
		y -= toInt(part->y);
		int colorIndex = toInt(y*mSceneMgr->actualZone.partSize + x);
		if ( (colorIndex >= 0) && (colorIndex < toInt(mSceneMgr->actualZone.partSize*mSceneMgr->actualZone.partSize+mSceneMgr->actualZone.partSize)) )
		{
			// Shadow is read on the GREEN chanel
        	shadow = GETG(part->dist[colorIndex]);
		}
		else
			shadow = 0.0f;
	}
	else
	{
		shadow = GETG(part->globalDist);
	}

    return shadow;
}

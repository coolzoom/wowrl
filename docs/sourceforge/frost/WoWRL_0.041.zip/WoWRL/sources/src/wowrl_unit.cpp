/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Unit source               */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Unit class.                    */
/*       A Unit is a character that can   */
/*  move, attack, heal, resurrect, etc.   */
/*  It is the most important class of the */
/*  game. Most of the functions are self  */
/*  explanatory, so they are not heavily  */
/*  commented.                            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include <map>
#include <string>
#include <vector>
#include "hge/hge.h"
#include "hge/hgeanim.h"
#include "hge/hgevector.h"

#include "wowrl_global.h"
#include "wowrl_doodad.h"
#include "wowrl_distortion.h"
#include "wowrl_scenemanager.h"
#include "wowrl_statusbar.h"
#include "wowrl_pathfinding.h"
#include "wowrl_lua.h"

#include "wowrl_unit.h"

extern HGE *hge;
extern SceneManager *mSceneMgr;
extern float kalothDistance;

using namespace std;

Unit::Unit()
{
	m_speed = 150.0f;
	m_lvl = 1;
	this->initialize();
}

Unit::Unit( string name,
            float x, float y,
            int lvl, Class* c,
            float speed ) :
                m_name(name),
                m_x(x), m_y(y),
                m_lvl(lvl),
                m_speed(speed)
{
	this->initialize();
	this->setClass(c);
	this->updateStats();
}

Unit::~Unit()
{
}

void Unit::initialize()
{
	m_orientation = 0.0f;
	m_action_timer = 0.0f;
	m_regen_timer = 0.0f;
	pointIndice = 0;
	waypointIndice = 0;
	m_text_nbr = 0;
	m_animstate = "stand";
	m_old_animstate = "";
	rz = 0.0f;
	m_target = NULL;
	m_hostile = false;
	m_selected = false;
	attacking = false;
	healing = false;
	resurrecting = false;
	m_in_combat = false;
	FXPlaying = false;
	following = false;
	followingWp = false;
	orderGiven = false;
	m_dead = false;
	dying = false;
	m_finishAnim = true;
	hidden = false;
	moving = false;
	m_aggro = false;
	m_rebuildAggroList = false;
	pathRequested = false;
	pathObtained = false;
	m_animation = NULL;
	m_box = NULL;
	m_sbox = NULL;
	m_rot = hge->Random_Int(0,7);
	m_old_gx = mSceneMgr->gx;
	m_old_gy = mSceneMgr->gy;
	m_color.R = 0;
	m_color.G = 0;
	m_color.B = 0;

	m_stats.strengh = toInt(250*m_lvl/70.0f);
	m_stats.agility = toInt(250*m_lvl/70.0f);
	m_stats.stamina = toInt(250*m_lvl/70.0f);
	m_stats.intellect = toInt(250*m_lvl/70.0f);
	m_stats.spirit = toInt(250*m_lvl/70.0f);
	m_stats.spell_power = toInt(250*m_lvl/70.0f);
	m_stats.attack_power = toInt(250*m_lvl/70.0f);
	m_stats.regen_5s_health = toInt(15*m_lvl/70.0f);
	m_stats.regen_5s_mana = toInt(25*m_lvl/70.0f);
	m_stats.crit = toInt(0.20f*m_lvl/70.0f);
	m_stats.crit_spell = toInt(0.20f*m_lvl/70.0f);
	m_stats.hit = toInt(0.10f*m_lvl/70.0f);
	m_stats.penetration = toInt(30*m_lvl/70.0f);

	m_stats.health = 0;
	m_stats.mana = 0;
	m_health = 1;
	m_mana = 1;
	m_aggro_range = 35.0f;

}

/********* Graphic funcs **********/

float Unit::getX()
{
	return m_x+mSceneMgr->gx;
}

float Unit::getY()
{
	return m_y+mSceneMgr->gy;
}

float Unit::getGX()
{
	return m_x;
}

float Unit::getGY()
{
	return m_y;
}

Point Unit::getPoint()
{
	Point p;
	p.x = this->getX();
	p.y = this->getY();
	return p;
}

Point Unit::getGPoint()
{
	Point p;
	p.x = m_x;
	p.y = m_y;
	return p;
}

int Unit::getRot()
{
	return m_rot;
}

float Unit::getSpeed()
{
	return m_speed;
}

// Return the scale factor given by the distortion map
float Unit::getScale()
{
	float mdist = getPointDistortion(toInt(m_x), toInt(m_y));
	float scale = mSceneMgr->actualZone.distortion_scale_min-mdist*(mSceneMgr->actualZone.distortion_scale_min-mSceneMgr->actualZone.distortion_scale_max);
	m_scale = scale;
	m_scale = m_scale*this->getClass()->scale;
	return m_scale;
}

// Return the vertical scale factor the same way
float Unit::getVScale()
{
	float mdist = getPointDistortion(toInt(m_x), toInt(m_y));
	float vscale = mSceneMgr->actualZone.distortion_vscale_min-mdist*(mSceneMgr->actualZone.distortion_vscale_min-mSceneMgr->actualZone.distortion_vscale_max);
	m_vscale = vscale;
	return m_vscale;
}

// And the rotation of the sprite, the same way too
float Unit::getAngle()
{
	float mdist = getPointDistortion(toInt(m_x), toInt(m_y));
	float angle = mSceneMgr->actualZone.distortion_angle_min-mdist*(mSceneMgr->actualZone.distortion_angle_min-mSceneMgr->actualZone.distortion_angle_max);
	angle = angle*2*M_PI/360;
	return angle;
}

// Return the global depth acording to the depth map
float Unit::getZ()
{
	return m_y;
}

float Unit::getRZ()
{
	if (rz == 0.0f)
		return m_y;
	else
		return rz;
}

// The relative depth is just a difference between two global depth
float Unit::getRelativeDepth(Point p)
{
	return p.y-m_y;
}

// Return the shadow color to apply the sprite when rendering
float Unit::getShadow()
{
	m_shadow = getPointShadow(toInt(m_x), toInt(m_y));
	return m_shadow;
}

string Unit::getAnimState()
{
	return m_animstate;
}

hgeAnimation* Unit::setAnimation( int frameNbr, bool keepSameFrame )
{
	int old_frame;
	if (m_animation != NULL)
		old_frame = m_animation->GetFrame();
	else
		old_frame = 0;

	if (m_animation != NULL) {delete m_animation;}
		m_animation = new hgeAnimation(*mSceneMgr->pAnimList[m_class->anim_set].animation[m_animstate].state[m_rot]);
	if (frameNbr == -1 && !keepSameFrame)
	{
		frameNbr = hge->Random_Int(0, m_animation->GetFrames());
	}
	else if (keepSameFrame)
	{
		if (old_frame > m_animation->GetFrames())
		{
			frameNbr = 0;
		}
		else
		{
			frameNbr = old_frame;
		}
	}

	m_animation->SetFrame(frameNbr);
}

// Return the actual animation of the unit an update it if needed
hgeAnimation* Unit::getAnimation()
{
	if (m_animation == NULL)
		this->setAnimation();

	return m_animation;
}

// The same kind of function for animated effects
map<string, Effect> Unit::getEffectList()
{
	return m_effect;
}


/*string Unit::getEffectName()
{
	return m_effectstate;
}*/

// Initialise the unit's bounding box
void Unit::setBox()
{
	if (m_box != NULL) {delete m_box;}
	m_box = new hgeRect();
	this->getScale();
	this->getAnimation()->GetBoundingBoxEx(this->getX(), this->getY(), 0.0f, m_scale, m_scale, m_box);
	m_box->Set
	(
		m_box->x1/*+(m_class->offx1+mSceneMgr->pAnimList[m_class->name].animation[m_animstate].offx1)*m_scale*/,
		m_box->y1/*+(m_class->offy1+mSceneMgr->pAnimList[m_class->name].animation[m_animstate].offy1)*m_scale*/,
		m_box->x2/*+(m_class->offx2+mSceneMgr->pAnimList[m_class->name].animation[m_animstate].offx2)*m_scale*/,
		m_box->y2/*+(m_class->offy2+mSceneMgr->pAnimList[m_class->name].animation[m_animstate].offy2)*m_scale*/
	);
	m_box->Set
	(
		m_box->x1+mSceneMgr->gx-m_old_gx,
		m_box->y1+mSceneMgr->gy-m_old_gy,
		m_box->x2+mSceneMgr->gx-m_old_gx,
		m_box->y2+mSceneMgr->gy-m_old_gy
	);
	m_old_gx = mSceneMgr->gx;
	m_old_gy = mSceneMgr->gy;
}

// And retrieve it, updating when needed
hgeRect* Unit::getBox()
{
	if (m_box == NULL)
		this->setBox();

	return m_box;
}

void Unit::setStandBox()
{
	if (m_sbox != NULL) {delete m_sbox;}
	m_sbox = new hgeRect();
	this->getScale();
	mSceneMgr->pAnimList[m_class->anim_set].animation["stand"].state[m_rot]->GetBoundingBoxEx(this->getX(), this->getY(), 0.0f, m_scale, m_scale, m_sbox);
	m_sbox->Set
	(
		m_sbox->x1/*+(m_class->offx1+mSceneMgr->pAnimList[m_class->name].animation["stand"].offx1)*m_scale*/,
		m_sbox->y1/*+(m_class->offy1+mSceneMgr->pAnimList[m_class->name].animation["stand"].offy1)*m_scale*/,
		m_sbox->x2/*+(m_class->offx2+mSceneMgr->pAnimList[m_class->name].animation["stand"].offx2)*m_scale*/,
		m_sbox->y2/*+(m_class->offy2+mSceneMgr->pAnimList[m_class->name].animation["stand"].offy2)*m_scale*/
	);
}

hgeRect* Unit::getStandBox()
{
	if (m_sbox != NULL) {delete m_sbox;}
	m_sbox = new hgeRect();
	mSceneMgr->pAnimList[m_class->anim_set].animation["stand"].state[m_rot]->GetBoundingBoxEx(this->getX(), this->getY(), 0.0f, m_scale, m_scale, m_sbox);
	m_sbox->Set
	(
		m_sbox->x1/*+(m_class->offx1+mSceneMgr->pAnimList[m_class->name].animation["stand"].offx1)*m_scale*/,
		m_sbox->y1/*+(m_class->offy1+mSceneMgr->pAnimList[m_class->name].animation["stand"].offy1)*m_scale*/,
		m_sbox->x2/*+(m_class->offx2+mSceneMgr->pAnimList[m_class->name].animation["stand"].offx2)*m_scale*/,
		m_sbox->y2/*+(m_class->offy2+mSceneMgr->pAnimList[m_class->name].animation["stand"].offy2)*m_scale*/
	);
	return m_sbox;
}

// Get the unit's color (shadow)
RGB Unit::getColor()
{
	if (m_shadow+m_color.R > 255)
	{
		m_color.R = 255-m_shadow;
	}
	if (m_shadow+m_color.G > 255)
	{
		m_color.G = 255-m_shadow;
	}
	if (m_shadow+m_color.B > 255)
	{
		m_color.B = 255-m_shadow;
	}
	return m_color;
}

// Get the status bar taking into account the unit state
StatusBar* Unit::getStatusBar()
{
	if (mSceneMgr->statusBarList.find(m_name) == mSceneMgr->statusBarList.end())
	{
		// If the status bar does not yet exists, add it to the statusBarList
		mSceneMgr->createStatusBar(this);
		m_status_bar = &mSceneMgr->statusBarList[m_name];
		if (m_status_bar->gauge != NULL) {delete m_status_bar->gauge;}
		m_status_bar->gauge = new hgeSprite(*mSceneMgr->statusB_gauge);
		m_status_bar->background_left = new hgeSprite(*mSceneMgr->statusB_dead_bg_left);
		m_status_bar->background_middle = new hgeSprite(*mSceneMgr->statusB_dead_bg_middle);
		m_status_bar->background_right = new hgeSprite(*mSceneMgr->statusB_dead_bg_right);

		m_status_bar->size = m_class->status_bar_size*m_scale;

		if (m_status_bar->size<18)
		{
			m_status_bar->size = 18;
		}

		DWORD color = ARGB(180, 255, 255, 255);
		m_status_bar->background_left->SetColor(color);
		m_status_bar->background_right->SetColor(color);
		m_status_bar->background_middle->SetColor(color);
	}

	RGB color;

	if (this->isDead())
	{
		//m_status_bar->state = zone.respawn[m_name]/zone.respawnTime;
		m_status_bar->state = 1.0f;
		color.R = 150; color.G = 150; color.B = 150;
		m_status_bar->color = color;
	}
	else
	{
		m_status_bar->state = m_health/m_stats.health;
		if (m_status_bar->state >= 0.5f)
		{
			RGB color;
			color.R = (1-m_status_bar->state)*2*255; color.G = 255; color.B = 0;
			m_status_bar->color = color;
		}
		if (m_status_bar->state < 0.5f)
		{
			RGB color;
			color.R = 255; color.G = m_status_bar->state*2*255; color.B = 0;
			m_status_bar->color = color;
		}
	}
	return m_status_bar;
}

// Determine whether the unit collides with a given object
bool Unit::intersects( Object o )
{
	if (o.type == UNIT)
	{
		Unit* u = static_cast<Unit*>(o.ptr);
		return this->getBox()->Intersect(u->getBox());
	}
	else if (o.type == DOODAD)
	{
		Doodad* d = static_cast<Doodad*>(o.ptr);
		return this->getBox()->Intersect(d->getBox());
	}
}


void Unit::setX( float x )
{
	m_x = x-mSceneMgr->gx;
}

void Unit::setY( float y )
{
	m_y = y-mSceneMgr->gy;
}

void Unit::setRot( int rot )
{
	if (m_rot != rot)
	{
		m_rot = rot;
		this->setAnimation(-1, true);
	}
}

void Unit::setRotFromAngle( float angle )
{
	angle = angle/(2*M_PI);

	if (angle<0)
	{
		angle = 1+angle;
	}
	angle = 360*angle;

	if ((angle>22.5) && (angle<=67.5))
		this->setRot(5);
	else if ((angle>67.5) && (angle<=112.5))
		this->setRot(4);
	else if ((angle>112.5) && (angle<=157.5))
		this->setRot(3);
	else if ((angle>157.5) && (angle<=202.5))
		this->setRot(2);
	else if ((angle>202.5) && (angle<=247.5))
		this->setRot(1);
	else if ((angle>247.5) && (angle<=292.5))
		this->setRot(0);
	else if ((angle>292.5) && (angle<=337.5))
		this->setRot(7);
	else if ((angle>337.5) || (angle<=22.5))
		this->setRot(6);
}

void Unit::setSpeed( float speed )
{
	m_speed = speed;
}

void Unit::setScale( float scale )
{
	m_scale = scale;
}

void Unit::setAnimState( string animstate, int frame )
{
	if (m_animstate != animstate)
	{
		m_animstate = animstate;
		this->setAnimation(frame);
	}
}

void Unit::addEffect( string effectstate )
{
	FXPlaying = true;
	if (m_effect.find(effectstate) != m_effect.end())
	{
		Effect* e = &m_effect[effectstate];
		e->ended = false;
		if (e->fade_in != 0.0f)
			e->fade = true;
		e->faded_in = false;
		e->faded_out = false;
		e->fade_out = mSceneMgr->FXList[effectstate].afx.fade_out;
		e->lifeTimer = 0.0f;
		e->fadeTimer = 0.0f;
		if (e->type == FX_ANIMATED_EFFECT)
			e->anim->Play();
		else if (e->type == FX_PARTICLE_SYSTEM)
			e->psys->Fire();
	}
	else
	{
		Effect e;
		SEffect* se = &mSceneMgr->FXList[effectstate];
		e.name = se->name;
		e.type = se->type;
		e.life = se->life;
		e.ended = false;
		e.lifeTimer = 0.0f;
		e.offset_x = se->offset_x;
		e.offset_y = se->offset_y;
		if (se->type == FX_ANIMATED_EFFECT)
		{
			e.fade_in = se->afx.fade_in;
			e.fade_out = se->afx.fade_out;
			e.scale = se->afx.scale;
			if (e.fade_in != 0.0f)
				e.fade = true;
			e.faded_in = false;
			e.faded_out = false;
			e.fadeTimer = 0.0f;
			if (se->afx.type == FX_SINGLE_ANGLE_ANIM)
				e.anim = new hgeAnimation(*mSceneMgr->FXList[effectstate].afx.anim);
			else if (se->afx.type == FX_MULTI_ANGLE_ANIM)
			{
				e.anim = new hgeAnimation(*mSceneMgr->FXList[effectstate].afx.state[m_rot]);
				e.rot = m_rot;
			}
			e.anim->Play();
		}
		else if (se->type == FX_PARTICLE_SYSTEM)
		{
			e.delay = se->pfx.delay;
			e.psys = new hgeParticleSystem(*mSceneMgr->FXList[effectstate].pfx.psys);
			e.psys->Fire();
		}

		m_effect[effectstate] = e;
	}
}

void Unit::setColor( RGB color )
{
	m_color = color;
}

void Unit::setColor( int R, int G, int B )
{
	m_color.R = R;
	m_color.G = G;
	m_color.B = B;
}

void Unit::deleteSelf()
{
	if (m_box != NULL) {delete m_box;}
	if (m_sbox != NULL) {delete m_sbox;}
	if (m_animation != NULL) {delete m_animation;}
	map<string, Effect>::iterator iterFX;
	while (!m_effect.empty())
	{
		iterFX = m_effect.begin();
		Effect* e = &iterFX->second;
		if (e->anim != NULL) {delete e->anim;}
		if (e->psys != NULL) {delete e->psys;}
		m_effect.erase(iterFX);
	}
}

/********** Mixed funcs ***********/

Class* Unit::getClass()
{
	return m_class;
}

void Unit::setClass( Class* c )
{
	m_class = c;
	m_spec = m_class->defaultSpec;
	m_spell = m_spec->defaultSpell;
	m_stats.power_type = m_class->power_type;
}

/********* Gameplay funcs **********/

string Unit::getName()
{
	return m_name;
}

int Unit::getLvl()
{
	return m_lvl;
}

Spell* Unit::getDefaultSpell()
{
	return this->m_class->defaultSpec->defaultSpell;
}

bool Unit::isHostile( Unit* u )
{
	if (u == NULL)
		return m_hostile;
	else
		return ((u->isHostile() && !m_hostile) || (!u->isHostile() && m_hostile));
}

bool Unit::isSelected()
{
	return m_selected;
}

bool Unit::isAttacking()
{
	return attacking;
}

bool Unit::isActing()
{
	return (attacking || healing || resurrecting);
}

bool Unit::isDead()
{
	return m_dead;
}

float Unit::getHealth()
{
	return m_health;
}

float Unit::getMaxHealth()
{
	return m_stats.health;
}

float Unit::getMana()
{
	return m_mana;
}

float Unit::getMaxMana()
{
	return m_stats.mana;
}

float Unit::getActionState()
{
	if (m_animstate != "attack")
	{
		return m_action_timer/m_spell->cast_time;
	}
	else
	{
		return 1.0f;
	}
}

Spell* Unit::getSpell()
{
	return m_spell;
}

void Unit::setHostile( bool hostile )
{
	if (m_hostile != hostile)
	{
		if (hostile == true)
		{
			mSceneMgr->hostileList[m_name] = this;
			map<Unit*, float>::iterator iter;
			for (iter = aggroedList.begin(); iter != aggroedList.end(); iter++)
			{
				iter->first->rebuildAggroList();
			}
			aggroedList.clear();
			m_hostile = true;

			this->setSelected(false);
		}
		else
		{
			if (mSceneMgr->hostileList.find(m_name) != mSceneMgr->hostileList.end())
			{
				mSceneMgr->hostileList.erase(m_name);
				m_hostile = false;
			}
			else
			{
				hge->System_Log("# WARNING # : Trying to remove \"%s\" from hostile unit list : not found.", m_name.c_str());
				return;
			}
		}
	}
}

void Unit::setSelected( bool selected )
{
	if (m_selected != selected)
	{
		if (selected == true)
		{
			mSceneMgr->selectedList[m_name] = this;
			m_selected = true;
		}
		else
		{
			if (mSceneMgr->selectedList.find(m_name) != mSceneMgr->selectedList.end())
			{
				mSceneMgr->selectedList.erase(m_name);
				m_selected = false;
			}
			else
			{
				hge->System_Log("# WARNING # : Trying to remove \"%s\" from selected unit list : not found.", m_name.c_str());
				return;
			}
		}
	}
}

void Unit::setMaxHealth( float u_max_health, bool fill )
{
	if (u_max_health > 0)
	{
		m_stats.health = toInt(u_max_health);
		if (fill || m_health > m_stats.health)
			m_health = m_stats.health;

		//m_force_max_health = true;
	}
}

void Unit::setMaxMana( float u_max_mana, bool fill )
{
	if (u_max_mana > 0)
	{
		m_stats.mana = toInt(u_max_mana);
		if (fill || m_mana > m_stats.mana)
			m_mana = m_stats.mana;

		//m_force_max_mana = true;
	}
}

// Order the unit to target another
void Unit::target( Unit* u_target )
{
	m_target = u_target;
}

Unit* Unit::getTarget()
{
	return m_target;
}

// Order the unit to beggin casting a given spell
void Unit::incant( Spell* spell, Unit* target = NULL )
{
	if (orderGiven && (spell->cast_time > 0.0f))
	{
		mSceneMgr->orderList.erase(m_name);
		orderGiven = false;
	}
	string reason;
	if (this->isCastable(spell, &reason))
	{
		m_spell = spell;
		if (target != NULL)
			this->target(target);
		if (m_target != NULL)
		{
			if (!m_spell->self_only)
			{
				hgeVector target_vec;
				target_vec.x = m_target->getX()-this->getX();
				target_vec.y = m_target->getY()-this->getY();
				this->setRotFromAngle(target_vec.Angle());
			}

			this->setAnimState("prepare_attack");

			string exec = "";
			exec += "local unit = \"" + m_name + "\";\n";
			exec += "local target = \"" + m_target->getName() + "\";\n";
			exec += "local spell = Spells[\"" + m_spell->name + "\"];\n";
			exec += m_spell->OnCastBegin + "\n";
			int error = luaL_dostring(mSceneMgr->luaVM, exec.c_str());
			if (error) l_logPrint(mSceneMgr->luaVM);

			if (m_spell->cast_fx)
			{
				FXPlaying = true;
				this->addEffect(m_spell->cast_effect);
			}
		}
	}
	else
	{
		if (!this->isHostile())
			mSceneMgr->addErrorMessage(m_name + " : " + mSceneMgr->strTable->GetString(reason.c_str()));
	}
}

// Tell the unit to cast its spell if it has enough mana/rage/energy
// and if it is in range.
bool Unit::cast( Spell* spell )
{
	bool casted;

	if (spell->self_only || isTargetInRange(spell))
	{
		if (spell->cost == 0.0f && spell->costp == 0.0f)
		{
			if (spell->puts_in_combat)
				this->setInCombat();
			casted = true;
		}
		else if (spell->costp != 0.0f)
		{
			if ( (m_mana-spell->costp*m_stats.mana) < 0.0f)
				casted = false;
			else
			{
				m_mana -= toInt(spell->costp*m_stats.mana);
				if (spell->puts_in_combat)
					this->setInCombat();
				casted = true;
			}
		}
		else
		{
			if ( (m_mana-spell->cost) < 0.0f)
				casted = false;
			else
			{
				m_mana -= toInt(spell->cost);
				if (spell->puts_in_combat)
					this->setInCombat();
				casted = true;
			}
		}
	}
	else
		casted = false;

	if (casted)
	{
		string exec = "";
		exec += "local unit = \"" + m_name + "\";\n";
		exec += "local target = \"" + m_target->getName() + "\";\n";
		exec += "local spell = Spells[\"" + m_spell->name + "\"];\n";
		exec += m_spell->OnCasted + "\n";
		int error = luaL_dostring(mSceneMgr->luaVM, exec.c_str());
		if (error) l_logPrint(mSceneMgr->luaVM);
		return true;
	}
	else
		return false;
}

// Return true if the spell is castable
bool Unit::isCastable( Spell* spell, string* reason, bool ignoreRange, bool ignoreTargetType )
{
	if (this->isDead())
	{
		if (reason != NULL)
			*reason = "error_is_dead";
		return false;
	}

	if (!spell->in_combat)
	{
		if (m_in_combat)
		{
			if (reason != NULL)
				*reason = "error_is_in_combat";
			return false;
		}
	}

	if (spell->costp != 0.0f)
	{
		if ( (m_mana-spell->costp*m_stats.mana) < 0.0f)
		{
			if (reason != NULL)
				*reason = "error_out_of_mana";
			return false;
		}
	}
	else if (spell->cost != 0.0f)
	{
		if ( (m_mana-spell->cost) < 0.0f)
		{
			if (reason != NULL)
				*reason = "error_out_of_mana";
			return false;
		}
	}

	if (!spell->self_only && !ignoreRange)
	{
		if (!this->isTargetInRange(spell))
		{
			if (reason != NULL)
				*reason = "error_out_of_range";
			return false;
		}
	}

	if ( ((m_target != NULL) || (spell->target == SPELL_TARGET_ALL)) && !ignoreTargetType )
	{
		if (m_target->isDead())
		{
			if ( (spell->target == SPELL_TARGET_HOSTILES) ||
				 (spell->target == SPELL_TARGET_FRIENDS) )
			{
				if (reason != NULL)
					*reason = "error_wrong_ttype_dead";
				return false;
			}
			if ( (spell->target == SPELL_TARGET_DEAD_FRIENDS) &&
				 (m_target->isHostile(this)) )
			{
				if (reason != NULL)
					*reason = "error_wrong_ttype_h";
				return false;
			}
			if ( (spell->target == SPELL_TARGET_DEAD_HOSTILES) &&
				 (!m_target->isHostile(this)) )
			{
				if (reason != NULL)
					*reason = "error_wrong_ttype_f";
				return false;
			}
		}
		else
		{
			if ( (spell->target == SPELL_TARGET_DEADS) ||
				 (spell->target == SPELL_TARGET_DEAD_FRIENDS) ||
				 (spell->target == SPELL_TARGET_DEAD_HOSTILES) )
			{
				if (reason != NULL)
					*reason = "error_wrong_ttype_living";
				return false;
			}
			if ( (spell->target == SPELL_TARGET_HOSTILES) &&
				 (!m_target->isHostile(this)) )
			{
				if (reason != NULL)
					*reason = "error_wrong_ttype_f";
				return false;
			}
			if ( (spell->target == SPELL_TARGET_FRIENDS) &&
				 (m_target->isHostile(this)) )
			{
				if (reason != NULL)
					*reason = "error_wrong_ttype_h";
				return false;
			}
		}
	}

	return true;
}

// Cast a spell on the unit
void Unit::receive( Spell* spell, Unit* caster )
{
	string exec = "";
	exec += "local unit = \"" + caster->getName() + "\";\n";
	exec += "local target = \"" + m_name + "\";\n";
	exec += "local spell = Spells[\"" + spell->name + "\"];\n";
	exec += spell->OnImpact + "\n";
	int error = luaL_dostring(mSceneMgr->luaVM, exec.c_str());
	if (error) l_logPrint(mSceneMgr->luaVM);
}

void Unit::damage( Unit* caster, int value, int school, bool aggro )
{
	this->setInCombat();
	m_health -= value;
	if (m_health <= 0)
	{
		this->die();
	}
	if ( aggro && this->isHostile() && !caster->isHostile() )
	{
		if (caster == m_target)
			caster->addAggroTo(this, value);
		else
		{
			if (!caster->isInAggroListOf(this))
				this->addUnitInAggroList(caster);
			float distance = dist
			(
				this->getX(), this->getY()*mSceneMgr->aspectRatio,
				caster->getX(), caster->getY()*mSceneMgr->aspectRatio
			);

			if (distance <= 5.0f) // melee range
				caster->addAggroTo(this, value*0.9f);
			else
				caster->addAggroTo(this, value*0.7f);
		}
	}
}

void Unit::heal( Unit* caster, int value, bool aggro )
{
	if (caster->isInCombat())
		this->setInCombat();
	m_health += value;
	if (m_health > m_stats.health)
	{
		m_health = m_stats.health;
	}
	if ( aggro && !this->isHostile() && !caster->isHostile() )
	{
		if (!this->aggroedList.empty())
		{
			caster->setInCombat();
			map<Unit*, float>::iterator iter;
			for (iter = this->aggroedList.begin(); iter != this->aggroedList.end(); iter++)
			{
				Unit* u = iter->first;
				if (!caster->isInAggroListOf(u))
				{
					u->addUnitInAggroList(caster);
				}
				if (caster == u->getTarget())
					caster->addAggroTo(u, value);
				else
				{
					float distance = dist
					(
						u->getX(), u->getY()*mSceneMgr->aspectRatio,
						caster->getX(), caster->getY()*mSceneMgr->aspectRatio
					);

					if (distance <= 5.0f) // melee range
						caster->addAggroTo(u, value*0.9f);
					else
						caster->addAggroTo(u, value*0.7f);
				}
			}
		}
	}
}

int Unit::getTextNbr()
{
	m_text_nbr++;
	return m_text_nbr;
}

int	Unit::getPowerType()
{
	return m_stats.power_type;
}

// Order the unit to stop doing what it does
void Unit::stop()
{
	if (attacking == true)
	{
		if (m_spell->cast_fx)
		{
			Effect* e = &m_effect[m_spell->cast_effect];
			if (e->fade_out == 0.0f)
			{
				e->ended = true;
			}
			else
			{
				e->faded_in = true;
				e->fade = true;
			}
		}
		this->setAnimState("stand");
		m_action_timer = 0.0f;
		mSceneMgr->attackerList.erase(m_name);
		mSceneMgr->actingList.erase(m_name);
		attacking = false;
	}
	if (healing == true)
	{
		if (m_spell->cast_fx)
		{
			Effect* e = &m_effect[m_spell->cast_effect];
			if (e->fade_out == 0.0f)
			{
				e->ended = true;
			}
			else
			{
				e->faded_in = true;
				e->fade = true;
			}
		}
		this->setAnimState("stand");
		m_action_timer = 0.0f;
		mSceneMgr->healerList.erase(m_name);
		mSceneMgr->actingList.erase(m_name);
		healing = false;
	}
	if (resurrecting == true)
	{
		if (m_spell->cast_fx)
		{
			Effect* e = &m_effect[m_spell->cast_effect];
			if (e->fade_out == 0.0f)
			{
				e->ended = true;
			}
			else
			{
				e->faded_in = true;
				e->fade = true;
			}
		}
		this->setAnimState("stand");
		m_action_timer = 0.0f;
		mSceneMgr->reserList.erase(m_name);
		mSceneMgr->actingList.erase(m_name);
		resurrecting = false;
	}
	if ( (this->following == true) || (this->moving == true) )
	{
		mSceneMgr->orderList.erase(m_name);
	}

	this->followingWp = false;
	this->orderGiven = false;
	this->following = false;
	this->moving = false;
	this->path.clear();
	this->wPath.clear();
}

// Tells the unit to die
void Unit::die()
{
	if (!this->isDead())
	{
		this->setSelected(false);
		this->stop();
		map<Unit*, float>::iterator iter;
		for (iter = aggroedList.begin(); iter != aggroedList.end(); iter++)
		{
			iter->first->rebuildAggroList();
		}
		aggroedList.clear();
		multimap<float, Unit*>::iterator iter2;
		for (iter2 = aggroList.begin(); iter2 != aggroList.end(); iter2++)
		{
			iter2->second->rebuildAggroedList();
		}
		aggroList.clear();
		m_health = 0;
		m_mana = 0;
		mSceneMgr->deadList[m_name] = this;
		this->setAnimState("death", 0);
		m_animation->Play();
		dying = true;
		m_dead = true;
	}
	else
	{
		this->setSelected(false);
	}
}

// Tells the unit to resurrect
void Unit::res( int health, int mana, Unit* u )
{
	if (this->isDead())
	{
		m_health = health;
		m_mana = mana;
		mSceneMgr->deadList.erase(m_name);
		this->setAnimState("stand");
		this->getAnimation()->Play();
		m_dead = false;
		this->setX(u->getX());
		this->setY(u->getY());
	}
}

// Update the attack : animation, cast time, effect
void Unit::updateAction( float dt )
{
	bool debugThis = false;
	if (this->isActing())
	{
		if (debugThis) hge->System_Log("2");
		if (!m_spell->self_only)
		{
			if (m_target->isHostile(this))
			{
				if ((m_spell->target == SPELL_TARGET_DEAD_FRIENDS) ||
					(m_spell->target == SPELL_TARGET_FRIENDS))
					this->stop();
			}
			else
			{
				if ((m_spell->target == SPELL_TARGET_DEAD_HOSTILES) ||
					(m_spell->target == SPELL_TARGET_HOSTILES))
					this->stop();
			}
			if (m_target->isDead())
			{
				if ((m_spell->target != SPELL_TARGET_DEADS) &&
					(m_spell->target != SPELL_TARGET_DEAD_FRIENDS) &&
					(m_spell->target != SPELL_TARGET_DEAD_HOSTILES))
					this->stop();
			}
		}

		if (this->isActing())
		{
			if (debugThis) hge->System_Log("2.2");
			if (m_target != NULL && !m_spell->self_only)
			{
				if (debugThis) hge->System_Log("2.2.1");
				hgeVector target_vec;
				target_vec.x = m_target->getX()-this->getX();
				target_vec.y = m_target->getY()-this->getY();
				this->setRotFromAngle(target_vec.Angle());
			}
			if (m_animstate == "prepare_attack")
			{
				if (debugThis) hge->System_Log("2.2.2");
				m_action_timer += dt;
				if (m_action_timer >= m_spell->cast_time)
				{
					if (debugThis) hge->System_Log("2.2.2.1");
					this->getAnimation()->Stop();
					if (this->cast(m_spell))
					{
						if (debugThis) hge->System_Log("2.2.2.1.1");
						this->setAnimState("attack", 0);
						m_animation->Play();
						m_action_timer = 0.0f;
						m_projectile = false;

						if (m_spell->cast_fx)
						{
							if (debugThis) hge->System_Log("2.2.2.1.1.1");
							if (m_effect[m_spell->cast_effect].fade_out == 0.0f)
							{
								m_effect[m_spell->cast_effect].ended = true;
							}
							else
							{
								m_effect[m_spell->cast_effect].fade = true;
								m_effect[m_spell->cast_effect].fade_out = 0.2f;
							}
						}
						if (!m_spell->attack_fx)
						{
							if (debugThis) hge->System_Log("2.2.2.1.1.2");
							m_target->receive(m_spell, this);
						}
						if (m_target->isDead() && (m_spell->target != SPELL_TARGET_DEADS))
						{
							if (debugThis) hge->System_Log("2.2.2.1.1.3");
							m_finishAnim = false;
						}
					}
					else
					{
						if (debugThis) hge->System_Log("2.2.2.1.2");
						this->stop();
					}
				}
			}
			if (m_animstate == "attack")
			{
				if (debugThis) hge->System_Log("2.2.3");
				m_action_timer += dt;
				if ( (m_action_timer >= mSceneMgr->FXList[m_spell->attack_effect].pfx.delay) && !(m_projectile) && (m_spell->attack_fx) )
				{
					if (debugThis) hge->System_Log("2.2.3.1");
					mSceneMgr->createProjectile(m_spell, m_target, this);
					m_projectile = true;
				}

				if (!this->getAnimation()->IsPlaying())
				{
					if (debugThis) hge->System_Log("2.2.3.2");
					if (!m_spell->loop)
					{
						if (debugThis) hge->System_Log("2.2.3.2.1");
						this->stop();
					}
					else
					{
						if (debugThis) hge->System_Log("2.2.3.2.2");
						if (this->isCastable(m_spell))
						{
							if (debugThis) hge->System_Log("2.2.3.2.2.1");
							this->setAnimState("prepare_attack");
						}
						else
						{
							if (debugThis) hge->System_Log("2.2.3.2.2.2");
							this->stop();
						}
					}

					m_action_timer = 0.0f;
					m_finishAnim = true;
					if (m_spell->cast_fx)
					{
						if (debugThis) hge->System_Log("2.2.3.2.3");
						this->addEffect(m_spell->cast_effect);
					}
				}
			}
		}
	}
}

// Updates everything related to the unit
void Unit::update( float dt )
{
	this->updateBuffs(dt);
	this->updateEffects(dt);
	this->updateAction(dt);
	if (!this->isDead())
		this->updateRegen(dt);
	this->updateMovement();
	this->updateAggro(dt);
	this->setBox();

	if ( (dying) && !(m_animation->IsPlaying()) )
		dying = false;

	m_animation->Update(dt);

	if (aggroedList.empty() && aggroList.empty())
	{
		if (m_in_combat)
		{
			m_in_combat_timer -= dt;
			if (m_in_combat_timer <= 0.0f)
				m_in_combat = false;
		}
	}

	/*static bool plop = false;
	if ((m_name == "Kaloth" && m_aggro) || (m_name == "Kaloth" && plop))
	{
		plop = true;
		hge->System_Log("# %s :", m_name.c_str());
		hge->System_Log(" - orderGiven = %d", orderGiven);
		hge->System_Log(" - moving = %d", moving);
		hge->System_Log(" - following = %d", following);
		hge->System_Log(" - pointIndice = %d", pointIndice);
		hge->System_Log(" - path.size() = %d", path.size());
		hge->System_Log(" - followingWp = %d", followingWp);
		hge->System_Log(" - waypointIndice = %d", waypointIndice);
		hge->System_Log(" - wPath.size() = %d", wPath.size());
		hge->System_Log(" - isActing() = %d", isActing());
		if (m_target != NULL)
			hge->System_Log(" - m_target = %s", m_target->getName().c_str());
		else
			hge->System_Log(" - m_target = null");
	}*/
}

void Unit::updateBuffs( float dt )
{
	map<string, Buff>::iterator iterBuff, lastParsed;
	lastParsed = NULL;
	for (iterBuff = m_buffList.begin(); iterBuff != m_buffList.end(); iterBuff++)
	{
		Buff* b = &iterBuff->second;
		b->life += dt;
		if (b->life >= b->buff->duration)
		{
			m_buffList.erase(iterBuff);
			if (m_buffList.empty())
				break;
			if (lastParsed == NULL)
			{
				iterBuff = m_buffList.begin();
				continue;
			}
			else
				iterBuff = lastParsed;
		}
		lastParsed = iterBuff;
	}
}

void Unit::updateEffects( float dt )
{
	map<string, Effect>::iterator iterFX, lastParsed;
	lastParsed = NULL;
	for (iterFX = m_effect.begin(); iterFX != m_effect.end(); iterFX++)
	{
		Effect* e = &iterFX->second;
		if (e->ended)
		{
			if (e->anim != NULL) {delete e->anim;}
			if (e->psys != NULL) {delete e->psys;}
			m_effect.erase(iterFX);
			if (m_effect.empty())
				break;
			if (lastParsed == NULL)
			{
				iterFX = m_effect.begin();
				continue;
			}
			else
				iterFX = lastParsed;
		}
		else
		{
			if (mSceneMgr->FXList[e->name].type == FX_ANIMATED_EFFECT)
			{
				if (mSceneMgr->FXList[e->name].afx.type == FX_MULTI_ANGLE_ANIM)
				{
					if (m_rot != e->rot)
					{
						int frame = e->anim->GetFrame();
						delete e->anim;
						e->anim = new hgeAnimation(*mSceneMgr->FXList[e->name].afx.state[m_rot]);
						e->anim->SetFrame(frame);
						e->anim->Play();
						e->rot = m_rot;
					}
				}
			}
			e->Update(dt);
			if (e->life != 0.0f)
				e->lifeTimer += dt;
			if (e->lifeTimer > e->life)
			{
				if (e->anim != NULL) {delete e->anim;}
				if (e->psys != NULL) {delete e->psys;}
				m_effect.erase(iterFX);
				if (m_effect.empty())
					break;
				if (lastParsed == NULL)
				{
					iterFX = m_effect.begin();
					continue;
				}
				else
					iterFX = lastParsed;
			}
			else
			{
				if ( ((e->fade_in == 0.0f) && (e->fade_out == 0.0f))
				  || ((e->faded_in == true) && (e->fade == false)) )
				{
					// Render the effect, nothing special
					e->SetColor(ARGB(255, 255, 255, 255));
				}
				else if ( (e->fade_in != 0.0f) && (e->faded_in == false) && (e->fade == true)  )
				{
					// Fade in the effect
					e->fadeTimer += dt/e->fade_in;
					if (e->fadeTimer > 1.0f)
					{
						e->fadeTimer = 1.0f;
						e->faded_in = true;
						e->fade = false;
					}
					int alpha = toInt(e->fadeTimer*255);
					e->SetColor(ARGB(alpha, 255, 255, 255));
				}
				else if ( (e->fade_out != 0.0f) && (e->faded_in == true) && (e->fade == true) )
				{
					// Fade out the effect
					e->fadeTimer -= dt/e->fade_out;
					if (e->fadeTimer <= 0.0f)
					{
						if (e->anim != NULL) {delete e->anim;}
						if (e->psys != NULL) {delete e->psys;}
						m_effect.erase(iterFX);
						if (m_effect.empty())
							break;
						if (lastParsed == NULL)
						{
							iterFX = m_effect.begin();
							continue;
						}
						else
							iterFX = lastParsed;
					}
					else
					{
						int alpha = toInt(e->fadeTimer*255);
						e->SetColor(ARGB(alpha, 255, 255, 255));
					}
				}
			}
			lastParsed = iterFX;
		}
	}

	if (m_effect.empty())
		FXPlaying = false;
}

void Unit::updateRegen( float dt )
{
	float m_regen_health = m_class->health_gained_per_spirit*m_stats.spirit + m_class->health_gained_per_tick;
	float m_regen_mana = m_class->mana_gained_per_spirit*m_stats.spirit + m_class->mana_gained_per_tick;

	if (m_in_combat)
	{
		m_regen_health *= m_class->regen_health_in_combat;
		m_regen_mana *= m_class->regen_mana_in_combat;
	}

	m_regen_timer += dt;
	if (m_regen_timer >= mSceneMgr->regenTimer)
	{
		m_regen_timer = 0.0f;

		m_health += toInt(m_regen_health);
		if (m_health > m_stats.health)
		{
			m_health = m_stats.health;
		}
		m_mana += toInt(m_regen_mana);
		if (m_mana > m_stats.mana)
		{
			m_mana = m_stats.mana;
		}
	}
}

void Unit::updateStats()
{
	int stam_health;
	if (m_stats.stamina*10-180 < 0)
		stam_health = 0;
	else
		stam_health = m_stats.stamina*10-180;

	int n_max_health = stam_health + mSceneMgr->getBaseHealth(m_lvl, m_class);

	if (m_stats.health == 0)
	{
		m_stats.health = n_max_health;
		m_health = n_max_health;
	}
	else
		m_stats.health = n_max_health;

	int intel_mana;
	if (m_stats.intellect*15-280 < 0)
		intel_mana = 0;
	else
		intel_mana = m_stats.intellect*15-280;

	int n_max_mana = intel_mana + mSceneMgr->getBaseMana(m_lvl, m_class);

	if (m_stats.mana != n_max_mana)
	{
		if (m_stats.mana == 0)
		{
			m_stats.mana = n_max_mana;
			m_mana = n_max_mana;
		}
		else
			m_stats.mana = n_max_mana;
	}
}

void Unit::updateMovement()
{
	if (orderGiven)
	{
		setAnimState("walk");
		if (order == "leashing")
		{
			bool move = this->followWaypointPath();
			if (!move)
			{
				orderGiven = old_orderGiven;
				destPoint = old_destPoint;
				order = old_order;
				path = old_path;
				pointIndice = old_pointIndice;
				wPath = old_wPath;
				waypointIndice = old_waypointIndice;
				following = old_following;
				moving = old_moving;
				order == "move";
			}
		}
		else if (order == "approach")
		{
			bool move = this->followWaypointPath();
			if (!move || this->isTargetInRange(m_spell))
			{
				order == "move";
				this->stop();
				this->incant(m_spell, m_target);
			}
		}
		else if (order == "approach_aggro")
		{
			bool move = this->followPath();
			float distance = dist
			(
				this->getX(), this->getY()*mSceneMgr->aspectRatio,
				m_target->getX(), m_target->getY()*mSceneMgr->aspectRatio
			);
			if ( !move || (distance <= m_spell->range*0.75f*10.0f) )
			{
				this->stop();
				this->incant(m_spell, m_target);
			}
		}
		else if (order == "move")
		{
			bool move = this->followWaypointPath();
			if (!move)
			{
				orderGiven = false;
				mSceneMgr->orderList.erase(m_name);
			}
		}
	}
	else
	{
		if (!this->isActing() && !this->isDead())
			setAnimState("stand");
	}
}

void Unit::updateAggro(float dt)
{
	if (!this->isDead())
	{
		if (this->isHostile())
		{
			if (m_aggro)
			{
				if (m_target->isDead())
				{
					this->stop();
					this->buildAggroList(true);
					if (aggroList.empty())
					{
						this->goBackToOldState();
						m_aggro = false;
					}
				}
				else if (m_target->isHostile())
				{
					this->stop();
					this->buildAggroList(true);
					if (aggroList.empty())
					{
						this->goBackToOldState();
						m_aggro = false;
					}
				}
				else
				{
					this->buildAggroList(false);
					float distance = dist
					(
						this->getX(), this->getY()*mSceneMgr->aspectRatio,
						m_target->getX(), m_target->getY()*mSceneMgr->aspectRatio
					);
					if (distance <= m_spell->range*0.75f*10.0f)
					{
						if (!this->isActing())
						{
							this->stop();
							this->incant(m_spell, m_target);
						}
					}
					else if (distance > m_spell->range*10.0f)
					{
						if (!this->isActing())
						{
							if (m_pathfinding_timer >= 1.0f || !orderGiven)
							{
								this->path = getShortestPath
								(
									toInt(this->getGX()),
									toInt(this->getGY()),
									toInt(m_target->getGX()),
									toInt(m_target->getGY()),
									(m_spell->range*0.75f)*10.0f
								);
								this->destPoint = this->path.back();
								m_pathfinding_timer = 0.0f;
								orderGiven = true;
							}
							m_pathfinding_timer += dt;
						}
					}
				}
			}

			if ( this->isHostile() && !m_aggro && (order != "leashing") )
			{
				map<string, Unit>::iterator iterUnit;
				for (iterUnit = mSceneMgr->unitList.begin(); iterUnit != mSceneMgr->unitList.end(); iterUnit++)
				{
					Unit* u = &iterUnit->second;
					if ( !u->isHostile() && !u->isDead() && (u != this) )
					{
						float distance = dist
						(
							this->getX(), this->getY()*mSceneMgr->aspectRatio,
							u->getX(), u->getY()*mSceneMgr->aspectRatio
						);
						if (distance <= m_aggro_range*10.0f)
						{
							// Storing old state
							old_pos.set(this->getGX(), this->getGY());
							old_orderGiven = orderGiven;
							old_destPoint = destPoint;
							old_order = order;
							old_path = path;
							old_pointIndice = pointIndice;
							old_wPath = wPath;
							old_waypointIndice = waypointIndice;
							old_following = following;
							old_moving = moving;
							following = false;
							moving = false;

							if (distance <= m_spell->range*10.0f)
							{
								this->incant(m_spell, u);
								orderGiven = false;
							}
							else
							{
								this->path = getShortestPath
								(
									toInt(this->getGX()),
									toInt(this->getGY()),
									toInt(u->getGX()),
									toInt(u->getGY()),
									(m_spell->range*0.75f)*10.0f
								);
								this->destPoint = this->path.back();
								this->target(u);
								order = "approach_aggro";
								orderGiven = true;
							}

							u->setInCombat();
							this->addUnitInAggroList(u);
							u->addAggroTo(this, 10.0f);
							m_aggro = true;
							break;
						}
					}
				}
			}
		}
		else
		{
			buildAggroedList();
		}
	}
}

void Unit::setInCombat()
{
	m_in_combat = true;
	m_in_combat_timer = mSceneMgr->inCombatTimer;
}

bool Unit::isInCombat()
{
	return m_in_combat;
}

bool Unit::isInSpellRange( float x, float y )
{
	float distance = dist(this->getX(), this->getY()*mSceneMgr->aspectRatio, x, y*mSceneMgr->aspectRatio);
	return (distance <= m_spell->range*10.0f);
}

bool Unit::isTargetInRange( Spell* s )
{
	if (s == NULL)
		s = m_spell;

	if (m_target == NULL)
		return true;

	float distance = dist
	(
		this->getX(), this->getY()*mSceneMgr->aspectRatio,
		m_target->getX(), m_target->getY()*mSceneMgr->aspectRatio
	);
	return (distance <= s->range*10.0f);
}

void Unit::moveInRange( Unit* target )
{
	if (target == NULL)
		target = m_target;

	destPoint = target->getGPoint();
	order = "approach";
	orderGiven = false;
	mSceneMgr->requestWPPath(this);
	pathRequested = false;
	pathObtained = false;
	following = false;
	followingWp = false;
}

void Unit::goBackToOldState()
{
	destPoint = old_pos;
	mSceneMgr->requestWPPath(this);
	this->aggroList.clear();
	order = "leashing";
}

void Unit::setAggroRange( float aRange )
{
	if (aRange > 0.0f)
		m_aggro_range = aRange;
}

void Unit::addAggroTo( Unit* u, float aggro )
{
	//hge->System_Log("%s adds %.0f threat points to %s's threatList (total : %.0f)", m_name.c_str(), aggro, u->getName().c_str(), aggroedList[u] + aggro);
	u->rebuildAggroList();
	aggroedList[u] += aggro;
}

bool Unit::isInAggroListOf( Unit* u )
{
	if (aggroedList.find(u) != aggroedList.end())
	{
		return true;
	}
	else
	{
		return false;
	}
}

void Unit::addUnitInAggroList( Unit* u )
{
	this->aggroList.insert(make_pair(0.0f, u));
	u->aggroedList[this] = 0.0f;
}

void Unit::rebuildAggroedList()
{
	m_rebuildAggroedList = true;
}

void Unit::buildAggroedList()
{
	if (m_rebuildAggroedList)
	{
		map<Unit*, float>::iterator iter, lastParsed = NULL;
		for (iter = aggroedList.begin(); iter != aggroedList.end(); iter++)
		{
			if (iter->first->isDead() || !iter->first->isHostile())
			{
				aggroedList.erase(iter);
				if (aggroedList.empty())
					break;
				if (lastParsed == NULL)
				{
					iter = aggroedList.begin();
					continue;
				}
				else
					iter = lastParsed;
			}
			else
				lastParsed = iter;
		}
	}

	m_rebuildAggroedList = false;
}

void Unit::rebuildAggroList()
{
	m_rebuildAggroList = true;
}

void Unit::buildAggroList( bool rebuild )
{
	multimap<float, Unit*>::iterator iter;

	if ( m_rebuildAggroList || rebuild )
	{
		multimap<float, Unit*> tempAggroList = aggroList;
		aggroList.clear();
		//hge->System_Log(" # %s's threat list :", m_name.c_str());
		//int i = 1;
		for (iter = tempAggroList.begin(); iter != tempAggroList.end(); iter++)
		{
			if (!iter->second->isDead() && !iter->second->isHostile())
			{
				//hge->System_Log("[%d] %s : %.0f", i, iter->second->getName().c_str(), iter->second->aggroedList[this]);
				aggroList.insert(make_pair(iter->second->aggroedList[this], iter->second));
				//i++;
			}
		}
	}

	if (!aggroList.empty())
	{
		// Check if there is several units at the top of the aggro list
		Unit* old_target = m_target;
		iter = aggroList.end(); iter--;

		pair<multimap<float, Unit*>::iterator, multimap<float, Unit*>::iterator> iPair;
		iPair = aggroList.equal_range(iter->first);

		if (iPair.first == iPair.second)
			this->target(iter->second);
		else
		{
			// ... and if we find the old target
			for (iter = iPair.first; iter != iPair.second; iter++)
			{
				if (iter->second == old_target)
				{
					this->target(old_target);
					break;
				}
				else
					this->target(iter->second);
			}
		}
	}
	else
		m_aggro = false;

	m_rebuildAggroList = false;
}

// Make a unit walk to a point
bool Unit::goTo( Point destPoint )
{
	hgeVector orderVec;
	float speed = this->getSpeed()*this->getScale()/this->getClass()->scale;
	orderVec.x = destPoint.x-this->getGX();
	orderVec.y = destPoint.y-this->getGY();

	float coefx, coefy;
	coefx = (speed/1.4142f)*cos(orderVec.Angle());
	coefy = (speed/1.4142f)*sin(orderVec.Angle());

	if ( !((fabs(destPoint.x-this->getGX()) < 1) && (fabs(destPoint.y-this->getGY()) < 1)) )
	{
		this->setX(this->getX()+coefx*mSceneMgr->dt);
		this->setY(this->getY()+coefy*mSceneMgr->dt);
		this->setRotFromAngle(orderVec.Angle());
		moving = true;
		return true;
	}
	else
	{
		// Unit is arrived at detination
		this->setX(destPoint.x+mSceneMgr->gx);
		this->setY(destPoint.y+mSceneMgr->gy);
		moving = false;
		return false;
	}
}

// Make a unit follow a path
bool Unit::followPath()
{
	if (path.size() == 1)
	{
		bool moving = this->goTo(*path.begin());
		following = moving;
		return moving;
	}
	else
	{
		if (!following)
		{
			pointIndice = 0;
			following = true;
		}

		std::vector<Point>::iterator iter = path.begin();
		for (int i=0; i < pointIndice; i++)
		{
			iter++;
		}

		if (pointIndice == path.size())
		{
			// Unit has followed the whole path
			following = false;
			return false;
		}
		else
		{
			if (!this->goTo(*iter))
			{
				pointIndice++;
			}
			return true;
		}
	}
}

bool Unit::followWaypointPath()
{
	if ( (wPath.size() == 0) || (waypointIndice == -1) )
	{
		if (!pathRequested && !pathObtained)
		{
			mSceneMgr->requestDirectPath(this);
		}
		if (pathObtained)
		{
			bool moving = this->followPath();
			if (!moving)
			{
				followingWp = false;
				pathObtained = false;
				return false;
			}
			else
				return true;
		}
		else
			return true;
	}
	else
	{
		if (!followingWp)
		{
			waypointIndice = 0;
			followingWp = true;
		}
		if (!pathRequested && !pathObtained)
		{
			mSceneMgr->requestPath(this);
		}

		if (this->pathObtained)
		{
			bool moving = this->followPath();
			if (!moving)
			{
				waypointIndice++;
				if (waypointIndice == wPath.size())
					waypointIndice = -1;
				pathObtained = false;
			}
		}

		return true;
	}
}

void Unit::addBuff( string buff_name )
{
	if (m_buffList.find(buff_name) != m_buffList.end())
	{
		Buff* b = &m_buffList[buff_name];
		b->count++;
		if (b->count > b->buff->max_count)
			b->count = b->buff->max_count;
		b->life = 0.0f;
	}
	else
	{
		Buff b;
		SBuff* sb = &mSceneMgr->buffList[buff_name];
		b.name = sb->name;
		b.buff = sb;
		b.count = 1;
		b.life = 0.0f;

		m_buffList[buff_name] = b;
	}
}

multimap<float, Buff*> Unit::getBuffList()
{
	multimap<float, Buff*> buffList;
	map<string, Buff>::iterator iterBuff;
	for (iterBuff = m_buffList.begin(); iterBuff != m_buffList.end(); iterBuff++)
	{
		buffList.insert(make_pair(-iterBuff->second.buff->duration+iterBuff->second.life, &iterBuff->second));
	}

	return buffList;
}

Inventory* Unit::getInventory()
{
	if (m_inventory.parent == NULL)
	{
		//m_inventory = mSceneMgr->createInventory(this);
	}

	return &m_inventory;
}

void Unit::initAB()
{
	ActionButton ab;
	ab.type = GUI_CASTBUTTON_STOP;
	m_ABList[0] = ab;
	int i = 1;
	map<std::string, CSpell>::iterator iterSpell;
	for (iterSpell = m_class->spell.begin(); iterSpell != m_class->spell.end(); iterSpell++)
	{
		if (i>120)
			break;

		ab.type = GUI_CASTBUTTON_SPELL;
		ab.spell = iterSpell->second.spell;

		m_ABList[i] = ab;
		i++;
	}
	for (i; i<=120; i++)
	{
		ActionButton ab;
		ab.type = GUI_CASTBUTTON_EMPTY;
		ab.spell = NULL;
		ab.item = NULL;
		m_ABList[i] = ab;
	}
}

ActionButton* Unit::getABList()
{
	return m_ABList;
}

bool Unit::isCasting()
{
	if (m_spell != NULL)
	{
		if ( isActing() && (m_spell->cast_time > 0.0f) )
			return true;
	}

	return false;
}

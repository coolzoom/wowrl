/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             Global source              */
/*                                        */
/*  ## : Contains frequently used funcs.  */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge/hgesprite.h"
#include <math.h>
#include <string>
#include <sstream>

#include "wowrl_structs.h"
#include "wowrl_point.h"

extern HGE* hge;

using namespace std;


string toString( float f )
{
	// [#] This function converts an integer to a string.
	ostringstream s;
	s << f;
	return s.str();
}

string BtoString( bool b )
{
	// [#] This function converts a bool to a string.
	if (b)
		return "true";
	else
		return "false";
}

int strReplace( string* baseStr, string pattern, string replacement )
{
	/* [#] This function replaces a part of a string by another.
	/* This version returns the number of occurences replaced and modifies the
	/* string at which the provided baseStr points at.
	*/
	size_t pos = baseStr->find(pattern);
	if (pos == string::npos)
		return 0;
	else
	{
		int count = 0;
		while (pos != string::npos)
		{
			baseStr->replace(pos, pattern.length(), replacement);
			pos = baseStr->find(pattern);
			count++;
		}
		return count;
	}
}

string strReplace( string baseStr, string pattern, string replacement )
{
	/* [#] This function replaces a part of a string by another.
	/* This version returns the replaced string directly and does
	/* not need you to provide a pointer.
	*/
	size_t pos = baseStr.find(pattern);
	if (pos == string::npos)
		return baseStr;
	else
	{
		while (pos != string::npos)
		{
			baseStr.replace(pos, pattern.length(), replacement);
			pos = baseStr.find(pattern);
		}
		return baseStr;
	}
}

int strCountOccurence( string baseStr, string pattern )
{
	// [#] This function counts the number of time a string is found in another.
	size_t pos = baseStr.find(pattern);
	if (pos == string::npos)
		return 0;
	else
	{
		int count = 0;
		while (pos != string::npos)
		{
			count++;
			pos++;
			pos = baseStr.find(pattern, pos);
		}
		return count;
	}
}

string strPrintIn( string baseStr, ... )
{
	/* [#] This function replaces the printf specificators of a string by some
	/* values.
	*/
	va_list args;
	va_start(args, baseStr);
	char buffer[baseStr.length()+sizeof(args)];
	vsprintf(buffer, baseStr.c_str(), args);
	va_end(args);
	return buffer;
}

string strCapitalStart( string baseStr, bool capital )
{
	// [#] This function edits a string to make its first letter CAPITAL or not.
	char c = baseStr.c_str()[0];
	char* str = (char*)baseStr.c_str();
	if (capital)
		str[0] = toupper(c);
	else
		str[0] = tolower(c);

	baseStr = str;
	return baseStr;
}

void strRemoveSurChar( string* baseStr, char c )
{
	/* [#] This function removes all the occurences of the given character sur-
	/* rounding the given string.
	*/
	while ((*baseStr)[0] == c)
	{
		*baseStr = baseStr->erase(0, 1);
	}
	while ((*baseStr)[baseStr->size()-1] == c)
	{
		*baseStr = baseStr->substr(0, baseStr->size()-1);
	}
}

int toInt( float f )
{
	// [#] This function converts a rounded float to an integer.
    int i = (int)round(f);
    return i;
}

int toInt( const char* s )
{
	// [#] This function converts a char to an integer.
    int i = atoi(s);
    return i;
}

string intToHex( int i )
{
	// [#] This function converts an integer to an hexadecimal number (formated).
	if (i < 0) i = 256+i;
	char* c = new char[256];
	itoa(i, c, 16);
	string s = c;
	delete c;

	if (s.size() == 1)
		s = "0" + s;

	return s;
}

int hexToInt( const char* c )
{
	// [#] This function converts an hexadecimal char* to a decimal int.
	int i;
	stringstream iss;
	iss << c;
	iss >> hex >> i;

	return i;
}

unsigned long hexToULong( const char* c )
{
	// [#] This function converts an hexadecimal char* to a decimal unsigned long.
	unsigned long u;
	stringstream iss;
	iss << c;
	iss >> hex >> u;

	return u;
}

int toInt( string s )
{
	// [#] This function converts a string to an integer
    int i = atoi(s.c_str());
    return i;
}

int signOf( float f )
{
	// [#] This function returns the sign of a value (+1 or -1)
	return toInt(f/(fabs(f)));
}

bool toBool( char* c )
{
	// [#] This function converts a char* to a bool.
    if ( (string(c) == string("true"))
	  || (string(c) == string("1"))
	  || (string(c) == string("yes")) )
		return true;
	else
		return false;
}

float rac2( float f )
{
	// [#] This function returns the square root. In french we say "racine de f"
	return pow(f, 0.5);
}

float dist( Point p1, Point p2 )
{
	// [#] This function returns the distance between two points.
	float dist;
	dist = rac2((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y));
	return dist;
}
float dist( float x1, float y1, float x2, float y2 )
{
	// [#] This version returns the distance between two sets of coordinates.
	float dist;
	dist = rac2((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	return dist;
}

void setGlowing( hgeSprite* sprite, float timerAlpha, float speed )
{
	/* [#] This function changes alpha of a sprite so it seems to glow, depending
	/* on the provided timerAlpha.
	*/
	DWORD color = sprite->GetColor();
	float alpha = 105*fabs(sin(speed*timerAlpha))+100;
	sprite->SetColor(ARGB(alpha, GETR(color), GETG(color), GETB(color)));
}

float radToDeg( float r, bool negativeDeg )
{
	// [#] This function converts radians to degrees (angles).
	float d = r/(2*M_PI) * 360;
	if ( (!negativeDeg) && (d<0) )
		d = 360+d;
	return d;
}
float degToRad( float d )
{
	// [#] This function does the opposite.
	float r = d/360 * 2*M_PI;
	return r;
}

float getTime()
{
	// [#] This function returns the time elapsed since boot in seconds.
	return GetTickCount()/1000.0f;
}

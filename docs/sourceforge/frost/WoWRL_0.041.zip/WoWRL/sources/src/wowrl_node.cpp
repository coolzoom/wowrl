/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Node source               */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Node class.                    */
/*       The Node is only used for the    */
/*  pathfinding function. Its use may be  */
/*  extended later on.                    */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_global.h"
#include "wowrl_point.h"

#include "wowrl_node.h"

Node::Node() : x(0.0f), y(0.0f),
               f(0.0f),
               g(0),
               closed(false),
               opened(false),
               walkable(false),
               useless(false)
{
	parent = NULL;
}

Node::~Node()
{
    x = 0.0f; y = 0.0f;
    f = 0.0f;
    g = 0;
    parent = NULL;
    closed = false;
    opened = false;
    walkable = false;
    useless = false;
}


void Node::set( float nx, float ny, Node* nparent=0, float nf=0, float ng=0 )
{
	x = nx;
	y = ny;
	parent = nparent;
	f = nf;
	g = ng;
}

Point Node::getPoint()
{
	Point p;
	p.x = x;
	p.y = y;
	return p;
}

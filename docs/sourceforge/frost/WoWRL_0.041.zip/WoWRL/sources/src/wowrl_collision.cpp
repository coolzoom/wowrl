/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Collision source            */
/*                                        */
/*  ## : Contains all the functions that  */
/*  are related to collision detection.   */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include <math.h>
#include <vector>
#include "hge/hge.h"
#include "hge/hgesprite.h"
#include "hge/hgevector.h"

#include "wowrl_global.h"
#include "wowrl_point.h"
#include "wowrl_node.h"
#include "wowrl_zone.h"
#include "wowrl_structs.h"
#include "wowrl_scenemanager.h"

#include "wowrl_collision.h"

extern HGE *hge;
extern SceneManager *mSceneMgr;


bool CheckPointCollision( int x, int y )
{
	/* [#] This function checks if the point at the given coordinates is walkable
	/* or not.
	*/

	bool collides;
	BGPart* part = mSceneMgr->actualZone.getBGPart(x, y);

	if (part->colData)
	{
		x -= toInt(part->x);
		y -= toInt(part->y);
		int colorIndex = y*mSceneMgr->actualZone.partSize + x;
		if ( (colorIndex >= 0) && (colorIndex < mSceneMgr->actualZone.partSize*(mSceneMgr->actualZone.partSize+1)) )
		{
			int red = GETR(part->col[colorIndex]);
			int green = GETG(part->col[colorIndex]);
			int blue = GETB(part->col[colorIndex]);
			// A point is walkable if the pixel is pure white (255,255,255)
			if (red+green+blue == 765)
				collides = false;
			else
				collides = true;
		}
		else
			return true;
	}
	else
	{
		int red = GETR(part->globalCol);
		int green = GETG(part->globalCol);
		int blue = GETB(part->globalCol);

		if (red+green+blue == 765)
			collides = false;
		else
			collides = true;
	}

	return collides;
}


DWORD getColor( int x, int y )
{
	/* [#] This function is only used for debugging purposes. It reads the pixel
	/* color of a locked texture at the given coordinates.
	*/

	BGPart* part = mSceneMgr->actualZone.getBGPart(x, y);
	if (part->distData)
	{
		x -= toInt(part->x);
		y -= toInt(part->y);
		int colorIndex = toInt(y*mSceneMgr->actualZone.partSize + x);
		if ( (colorIndex >= 0) && (colorIndex < toInt(mSceneMgr->actualZone.partSize*mSceneMgr->actualZone.partSize+mSceneMgr->actualZone.partSize)) )
		{
			int red = GETR(part->dist[colorIndex]);
			int green = GETG(part->dist[colorIndex]);
			int blue = GETB(part->dist[colorIndex]);
			return ARGB(255,red,green,blue);
		}
		else
			return ARGB(0,0,0,0);
	}
	else
		return ARGB(0,0,0,0);
}

Point getNearestAlignedFreePoint( float objx, float objy, float destx, float desty )
{
	/* [#] This function returns the nearest walkable point from the destination,
	/* aligned with the destination and the origin. This point is also accessible
	/* in a straight line from the origin.
	/* [#] The method used here is to get the angle made by the mouse position,
	/* the player and the X axis [1], then to draw an abstract line from the player
	/* using the angle we got before. The line is drawn pixel per pixel [2] (not
	/* realy but it works the same) and the collision test is done every time [3].
	/* When it collides, we stop drawing the line and return the point where it
	/* collides.
	*/

	hgeVector vec;
	Point p;
	vec.x = toInt(destx)-toInt(objx); // [1]
	vec.y = toInt(desty)-toInt(objy); // [1]
	float coefx = cos(vec.Angle());
	float coefy = sin(vec.Angle());
	vec.x = toInt(objx);
	vec.y = toInt(objy);

	bool collides = false;
	while (collides == false)
	{
		vec.x += coefx; // [2]
		vec.y += coefy; // [2]
		collides = CheckPointCollision(toInt(vec.x), toInt(vec.y)); // [3]
		if ( (fabs(vec.x-toInt(destx))<1) && (fabs(vec.y-toInt(desty))<1) )
		{
			// There is no obstacle
			collides = true;
			vec.x = toInt(destx);
			vec.y = toInt(desty);
		}
	}

	p = Point(toInt(vec.x),toInt(vec.y));

	return p;
}

Point getNearestFreePoint( float xi, float yi, float destx, float desty, int precision, int range )
{
	/* [#] This function returns the nearest walkable point from the destination
	/* when the destination is obstruded.
	/* [#] The method used here is to create a little circle centered on the
	/* coodinates entered in the function and check if its pixels are colliding
	/* the background. If they aren't, we enlarge the circle and check again
	/* until we've found a free point.
	*/

	Point p;
	int i=10, j;
	int x, y;
	bool collision=true;
	hgeVector vec;
	if ( (xi != destx) && (yi != desty) )
	{
		vec.x = xi-destx;
		vec.y = yi-desty;
	}
	else
	{
		vec.x = 1;
		vec.y = 0;
	}

	// This angle is used to ensure the given point is one of the closest from
	// the origin.
	float angle = vec.Angle();

	while ( (collision == true) && (i < range) )
	{
		j = 0;
		while ( (collision == true) && (j < 36) )
		{
			x = toInt(cos(j*2*M_PI/36+angle)*i)+toInt(destx);
			y = toInt(sin(j*2*M_PI/36+angle)*i)+toInt(desty);
			collision = CheckPointCollision(x, y);
			j++;
		}
		i += precision;
	}

	if (!collision)
    {
        j--;
        // Add a little offset to prevent the returned point to be too close to the unwalkable area
        p.x = x/*+round(cos(j*2*M_PI/36+vec.Angle()))*/;
        p.y = y/*+round(sin(j*2*M_PI/36+vec.Angle()))*/;
    }
    else
    {
    	p.x = xi;
        p.y = yi;
    }

	return p;
}

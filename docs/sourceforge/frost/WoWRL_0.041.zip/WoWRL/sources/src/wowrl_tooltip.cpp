/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             ToolTip source             */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Tolltip class.                 */
/*       A Tooltip is used to display     */
/*  infos on the screen about what is     */
/*  under the player's mouse.             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include <vector>
#include <string>
#include "hge/hge.h"
#include "hge/hgesprite.h"

#include "wowrl_structs.h"
#include "wowrl_scenemanager.h"

#include "wowrl_tooltip.h"


extern HGE* hge;
extern SceneManager* mSceneMgr;

ToolTip::ToolTip()
{
	spell = NULL;
	background = NULL;
	cornerTop = NULL;
	cornerBottom = NULL;
	borderVertical = NULL;
	borderHorizontalTop = NULL;
	borderHorizontalBottom = NULL;
}

ToolTip::~ToolTip()
{
	if (background != NULL) {delete background;}
	if (cornerTop != NULL) {delete cornerTop;}
	if (cornerBottom != NULL) {delete cornerBottom;}
	if (borderVertical != NULL) {delete borderVertical;}
	if (borderHorizontalTop != NULL) {delete borderHorizontalTop;}
	if (borderHorizontalBottom != NULL) {delete borderHorizontalBottom;}
}

void ToolTip::Render()
{
	// Adjust values
	/*if (h < 96.0f)
		h = 96.0f;*/
	// Render the tooltip background and borders
	hge->System_SetState(HGE_TEXTUREFILTER, false);
	cornerBottom->SetFlip(true, false, true);
	cornerBottom->Render(x-32, y);
	borderHorizontalBottom->RenderStretch(x-32, y-32, x-w+32, y);
	cornerBottom->SetFlip(false, false, true);
	cornerBottom->Render(x-w, y);
	borderVertical->SetFlip(false, false, true);
	borderVertical->RenderStretch(x-w, y-32, x-w+32, y-h+32);
	borderVertical->SetFlip(true, false, true);
	borderVertical->RenderStretch(x-32, y-32, x, y-h+32);
	cornerTop->SetFlip(true, false, true);
	cornerTop->Render(x-32, y-h);
	cornerTop->SetFlip(false, false, true);
	cornerTop->Render(x-w, y-h);
	borderHorizontalTop->RenderStretch(x-32, y-h, x-w+32, y-h+32);
	background->RenderStretch(x-32, y-32, x-w+32, y-h+32);
	hge->System_SetState(HGE_TEXTUREFILTER, true);

	if (!caption.empty())
	{
		std::vector<FormatedString>::iterator iter;
		if (type == "help")
		{
			for (iter = caption.begin(); iter != caption.end(); iter++)
			{
				if (iter->type == "Help1Title")
				{
					iter->fnt->SetColor(iter->color);
					iter->fnt->printf
					(
						x-w+12, y-h+8, HGETEXT_LEFT,
						iter->str.c_str()
					);
				}
				if (iter->type == "Help2Desc")
				{
					iter->fnt->SetColor(iter->color);
					iter->fnt->printfb
					(
						false, x-w+14, y-h+26, w-28, h-30, HGETEXT_LEFT,
						iter->str.c_str()
					);
				}
			}
		}
		if (type == "spell")
		{
			for (iter = caption.begin(); iter != caption.end(); iter++)
			{
				if (iter->type == "Spell1Name")
				{
					iter->fnt->SetColor(iter->color);
					iter->fnt->printf
					(
						x-w+12, y-h+8, HGETEXT_LEFT,
						iter->str.c_str()
					);
				}
				if (iter->type == "Spell2Rank")
				{
					iter->fnt->SetColor(iter->color);
					iter->fnt->printf
					(
						x-16, y-h+8, HGETEXT_RIGHT,
						iter->str.c_str()
					);
				}
				if (iter->type == "Spell3Infos")
				{
					iter->fnt->SetColor(iter->color);
					float length = iter->fnt->printfb
					(
						true, x-w+14, y-h+26, w-28, mSceneMgr->sWidth, HGETEXT_LEFT,
						iter->str.c_str()
					) * iter->fnt->GetHeight();
					iter->fnt->printfb
					(
						false, x-w+14, y-h+26, w-28, length, HGETEXT_LEFT,
						iter->str.c_str()
					);
					descY = length+y-h+26;
				}
				if (iter->type == "Spell4Desc")
				{
					iter->fnt->SetColor(iter->color);
					iter->fnt->printfb
					(
						false, x-w+14, descY, w-28, h-descY, HGETEXT_LEFT,
						iter->str.c_str()
					);
				}
			}
		}
	}
}


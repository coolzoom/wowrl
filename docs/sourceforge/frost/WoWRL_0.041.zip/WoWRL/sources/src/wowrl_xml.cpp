/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               XML source               */
/*                                        */
/*  ## : This file contains xml related   */
/*  functions.                            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_xml.h"
#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_scenemanager.h"
#include "wowrl_fontmanager.h"
#include "wowrl_global.h"

using namespace std;

extern SceneManager* mSceneMgr;
extern FontManager* mFontMgr;
extern HGE* hge;

bool debugXML = false;

void mxml_initUI()
{
	string s = "";
	s += "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n";
	s += "<Ui>\n";
	s += "    <Frame name=\"UIParent\">\n";
	s += "        <Size>\n";
    s += "            <AbsDimension x=\"" + toString(mSceneMgr->sWidth) + "\" y=\"" + toString(mSceneMgr->sHeight) + "\"/>\n";
    s += "        </Size>\n";
	s += "        <Anchors>\n";
	s += "            <Anchor point=\"TOPLEFT\">\n";
	s += "                <Offset>\n";
	s += "                    <AbsDimension x=\"0\" y=\"0\"/>\n";
	s += "                </Offset>\n";
	s += "            </Anchor>\n";
	s += "        </Anchors>\n";
	s += "    <Frame>\n";
	s += "</Ui>\n";

	TiXmlDocument doc;
	doc.Parse(s.c_str());
  	mxml_parseUIFile(NULL, doc);

  	mSceneMgr->guiList["UIParent"].baseUI = true;
}

void mxml_parseUIFile( AddOn* a, TiXmlDocument doc )
{
	/* [#] This function parses an XML UI file.
	/* To be considered as valid, an XML UI file must contain the <Ui> tag in
	/* its root. Everything else wont be parsed.
	*/
	if (debugXML) hge->System_Log("# 0");
	GUIElement* eParent = NULL;
	GUIArt* aParent = NULL;

	if (string(doc.RootElement()->Value()) == string("Ui"))
	{
		for (TiXmlNode* node = doc.RootElement()->FirstChild(); node; node = node->NextSibling())
		{
			if (string(node->Value()) == string("Script"))
			{
				if (node->ToElement())
				{
					TiXmlElement* elem = node->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("file"))
						{
							string lFile = a->folder + "/" + attr->Value();
							int error = luaL_dofile(mSceneMgr->luaVM, lFile.c_str());
							if (error) l_logPrint(mSceneMgr->luaVM);
						}
					}
				}
			}
			else if (string(node->Value()) == string("Frame"))
			{
				mxml_parseFrame(node, NULL, GUI_OBJECT_TYPE_FRAME);
			}
			else if (string(node->Value()) == string("StatusBar"))
			{
				mxml_parseFrame(node, NULL, GUI_OBJECT_TYPE_STATUSBAR);
			}
		}
	}
	else
		hge->System_Log("# XML Error # : invalid root node %s", doc.RootElement()->Value());

	if (debugXML) hge->System_Log("# 0.");
}

void mxml_parseFrame( TiXmlNode* node, GUIElement* parent, int type )
{
	/* [#] This very long function parses a Frame object in an XML file. The Frame
	/* is the base of the GUI. It is a container in which you can put as many
	/* objects as you want, would it be other Frames, Textures, ...
	/* [#] Be carefull when setting a Frame size : every child which is too large will
	/* not be rendered completely (or even not at all).
	/* [#] The Frame object has some derivations : the only one implemented right
	/* now is the StatusBar. The StatusBar can do whatever a Frame can do, plus it
	/* has a special texture which adjust itself its parameters to fit the filling
	/* value.
	*/
	bool debugThis = false;
	if (debugXML) {hge->System_Log("1");}
	if (node->ToElement())
	{
		GUIElement g;
		GUIElement* frame;
		g.parent = parent;
		g.type = type;
		string inherits = "";
		string pname = "";
		bool hidden = false;
		bool hiddenD = false;
		bool virt = false;
		bool newFrame = true;
		bool barTexFound = false;

		TiXmlElement* elem = node->ToElement();
		for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
		{
			if (string(attr->Name()) == string("name"))
			{
				if (debugThis) {hge->System_Log("1.1");}
				g.name = attr->Value();
				g.sname = g.name;
			}
			else if (string(attr->Name()) == string("hidden"))
			{
				if (debugThis) {hge->System_Log("1.2");}
				if (string(attr->Value()) == string("true"))
					hidden = true;

				hiddenD = true;
			}
			else if (string(attr->Name()) == string("parent"))
			{
				if (debugThis) {hge->System_Log("1.3");}
				pname = attr->Value();
			}
			else if (string(attr->Name()) == string("virtual"))
			{
				virt = toBool((char*)attr->Value());
			}
			else if (string(attr->Name()) == string("inherits"))
			{
				if ((mSceneMgr->templateList.find(attr->Value()) != mSceneMgr->templateList.end()))
				{
					inherits = attr->Value();
				}
				else
				{
					newFrame = false;
					hge->System_Log("# XML Error # : unknown template %s", attr->Value());
				}
			}
			else if (string(attr->Name()) == string("frameStrata"))
			{
				if (string(attr->Value()) == string("TOOLTIP"))
					g.frameStrata = GUI_STRATA_TOOLTIP;
				else if (string(attr->Value()) == string("FULLSCREEN_DIALOG"))
					g.frameStrata = GUI_STRATA_FULLSCREEN_DIALOG;
				else if (string(attr->Value()) == string("FULLSCREEN"))
					g.frameStrata = GUI_STRATA_FULLSCREEN;
				else if (string(attr->Value()) == string("DIALOG"))
					g.frameStrata = GUI_STRATA_DIALOG;
				else if (string(attr->Value()) == string("HIGH"))
					g.frameStrata = GUI_STRATA_HIGH;
				else if (string(attr->Value()) == string("MEDIUM"))
					g.frameStrata = GUI_STRATA_MEDIUM;
				else if (string(attr->Value()) == string("LOW"))
					g.frameStrata = GUI_STRATA_LOW;
				else if (string(attr->Value()) == string("BACKGROUND"))
					g.frameStrata = GUI_STRATA_BACKGROUND;
			}
			else if (string(attr->Name()) == string("movable"))
			{
			}
			else if (string(attr->Name()) == string("enableMouse"))
			{
				g.enableMouse = toBool((char*)attr->Value());
			}
			else if (string(attr->Name()) == string("toplevel"))
			{
			}
			else if (string(attr->Name()) == string("clampedToScreen"))
			{
			}
		}

		if (newFrame)
		{
			if (g.name == "")
			{
				newFrame = false;
				hge->System_Log("# XML Error # : a frame must have a name");
			}
		}

		if (newFrame)
		{
			if (debugThis) {hge->System_Log("1.4");}
			if (parent != NULL)
			{
				if (parent->virt)
					virt = true;
				else if (virt)
					newFrame = false;
			}
			if (debugThis) {hge->System_Log("1.5");}
			if (pname != "")
			{
				if (!virt)
				{
					int i = pname.find("$parent");
					if (i != pname.npos)
					{
						pname = pname.erase(i, 7);
						if (parent != NULL)
							pname.insert(i, parent->name);
					}
					if (mSceneMgr->guiList.find(pname) != mSceneMgr->guiList.end())
					{
						g.parent_name = pname;
					}
					else
					{
						newFrame = false;
						hge->System_Log("# XML Error # : unknown parent frame %s", pname.c_str());
					}
				}
				else
				{
					string pvname = pname;
					int i = pvname.find("$parent");
					if (i != pvname.npos)
					{
						pvname = pvname.erase(i, 7);
						if (parent != NULL)
							pvname.insert(i, parent->vname);
					}
					GUIBase* hparent = parent->getHighestVirtParent();
					if ( (hparent->parentList.find(pvname) != hparent->parentList.end()) ||
						(mSceneMgr->templateList.find(pvname) != mSceneMgr->templateList.end()) )
					{
						g.parent_name = pname;
					}
					else
					{
						newFrame = false;
						hge->System_Log("# XML Error # : unknown template frame %s", pvname.c_str());
					}
				}
			}
			if (debugThis) {hge->System_Log("1.6");}
		}

		if (newFrame)
		{
			if (debugThis) {hge->System_Log("1.7");}
			if (!virt)
			{
				if (parent == NULL)
				{
					if (g.parent_name != "")
					{
						g.parent = &mSceneMgr->guiList[g.parent_name];
						parent = g.parent;
					}
				}
				else
				{
					g.parent = parent;
				}
			}
			else
			{
				if (parent != NULL)
				{
					g.parent = parent;
				}
			}
			if (debugThis) {hge->System_Log("1.7.");}
		}

		if (newFrame)
		{
			if (debugThis) {hge->System_Log("1.8");}
			if (virt)
			{
				g.virt = true;

				if (parent == NULL)
				{
					int i = g.name.find("$parent");
					if (i != g.name.npos)
						g.name = g.name.erase(i, 7);

					g.vname = g.name;

					if (mSceneMgr->templateList.find(g.name) == mSceneMgr->templateList.end())
					{
						mSceneMgr->templateList[g.name] = g;
						frame = &mSceneMgr->templateList[g.name];
					}
					else
					{
						newFrame = false;
						hge->System_Log("# XML Error # : a template with the name %s already exists", g.name.c_str());
					}
				}
				else
				{
					g.vname = g.name;
					int i = g.vname.find("$parent");
					if (i != g.vname.npos)
					{
						g.vname = g.vname.erase(i, 7);
						g.vname.insert(i, parent->vname);
					}

					GUIBase* hparent = parent->getHighestVirtParent();
					if (hparent->parentList.find(g.vname) == hparent->parentList.end())
					{
						g.child = true;
						parent->vchilds[g.vname] = g;
						hparent->parentList[g.vname] = frame = &parent->vchilds[g.vname];
					}
					else
					{
						newFrame = false;
						hge->System_Log("# XML Error # : a template object with the name %s already exists", g.vname.c_str());
					}
				}
			}
			else
			{
				g.sname = g.name;
				int i = g.name.find("$parent");
				if (i != g.name.npos)
				{
					g.name = g.name.erase(i, 7);
					g.sname = g.name;
					if (parent != NULL)
						g.name.insert(i, parent->name);
				}

				if (mSceneMgr->parentList.find(g.name) == mSceneMgr->parentList.end())
				{
					if (parent == NULL)
					{
						mSceneMgr->guiList[g.name] = g;
						frame = &mSceneMgr->guiList[g.name];
						mSceneMgr->parentList[g.name] = frame;

					}
					else
					{
						g.child = true;
						mSceneMgr->guiList[g.name] = g;
						frame = &mSceneMgr->guiList[g.name];
						parent->childs[g.name] = frame;
						mSceneMgr->parentList[g.name] = frame;
					}
				}
				else
				{
					newFrame = false;
					hge->System_Log("# XML Error # : an object with the name %s already exists", g.name.c_str());
				}
			}
			if (debugThis) {hge->System_Log("1.8.");}
		}

		if (newFrame)
		{
			if (debugThis)
			{
				if (!virt)
					hge->System_Log("1.9 %s", frame->name.c_str());
				else
					hge->System_Log("1.9 %s", frame->vname.c_str());
			}

			if (inherits != "")
			{
				GUIElement* inh = &mSceneMgr->templateList[inherits];

				if (!frame->virt)
				{
					if (debugThis) {hge->System_Log("1.9.1");}
					inh->copyVirt(frame);
					if (debugThis) {hge->System_Log("1.9.2");}
				}
				else
				{
					if (debugThis) {hge->System_Log("1.9.3");}
					frame->hidden = inh->hidden;
					frame->w = inh->w;
					frame->h = inh->h;
					frame->alpha = inh->alpha;

					frame->OnLoadDef = inh->OnLoadDef;
					frame->OnMouseDownDef = inh->OnMouseDownDef;
					frame->OnMouseUpDef = inh->OnMouseUpDef;
					frame->OnDragStartDef = inh->OnDragStartDef;
					frame->OnReceiveDragDef = inh->OnReceiveDragDef;
					frame->OnEnterDef = inh->OnEnterDef;
					frame->OnLeaveDef = inh->OnLeaveDef;
					frame->OnUpdateDef = inh->OnUpdateDef;

					frame->OnLoadText = inh->OnLoadText;
					frame->OnMouseDownText = inh->OnMouseDownText;
					frame->OnMouseUpText = inh->OnMouseUpText;
					frame->OnDragStartText = inh->OnDragStartText;
					frame->OnReceiveDragText = inh->OnReceiveDragText;
					frame->OnEnterText = inh->OnEnterText;
					frame->OnLeaveText = inh->OnLeaveText;
					frame->OnUpdateText = inh->OnUpdateText;

					frame->childs = inh->childs;
					frame->arts = inh->arts;
					frame->anchors = inh->anchors;

					frame->useBackdrop = inh->useBackdrop;
					if (frame->useBackdrop)
						frame->backdrop = inh->backdrop;

					if (debugThis) {hge->System_Log("1.9.4");}
				}
			}

			if (debugThis) {hge->System_Log("1.10");}

			if (hiddenD)
				frame->hidden = hidden;

			for (TiXmlNode* node2 = node->FirstChild(); node2; node2 = node2->NextSibling())
			{
				if (string(node2->Value()) == string("Scripts"))
				{
					if (debugThis) {hge->System_Log("1.10.1");}
					for (TiXmlNode* node3 = node2->FirstChild(); node3; node3 = node3->NextSibling())
					{
						if (string(node3->Value()) == string("OnLoad"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
							{
								frame->OnLoadText = node4->Value();
								frame->OnLoadDef = true;
							}
						}
						else if (string(node3->Value()) == string("OnEnter"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
							{
								frame->OnEnterText = node4->Value();
								frame->OnEnterDef = true;
							}
						}
						else if (string(node3->Value()) == string("OnLeave"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
							{
								frame->OnLeaveText = node4->Value();
								frame->OnLeaveDef = true;
							}
						}
						else if (string(node3->Value()) == string("OnDragStart"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
							{
								frame->OnDragStartText = node4->Value();
								frame->OnDragStartDef = true;
							}
						}
						else if (string(node3->Value()) == string("OnReceiveDrag"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
							{
								frame->OnReceiveDragText = node4->Value();
								frame->OnReceiveDragDef = true;
							}
						}
						else if (string(node3->Value()) == string("OnUpdate"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
							{
								frame->OnUpdateText = node4->Value();
								frame->OnUpdateDef = true;
							}
						}
						else if (string(node3->Value()) == string("OnMouseUp"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
							{
								frame->OnMouseUpText = node4->Value();
								frame->OnMouseUpDef = true;
							}
						}
						else if (string(node3->Value()) == "OnMouseDown")
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
							{
								frame->OnMouseDownText = node4->Value();
								frame->OnMouseDownDef = true;
							}
						}
					}
				}
				else if (string(node2->Value()) == string("Size"))
				{
					if (debugThis) {hge->System_Log("1.10.2");}
					TiXmlNode* node3 = node2->FirstChild();
					if (node3)
					{
						if (string(node3->Value()) == string("AbsDimension"))
						{
							TiXmlElement* elem = node3->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("x"))
								{
									frame->w = atof(attr->Value());
								}
								else if (string(attr->Name()) == string("y"))
								{
									frame->h = atof(attr->Value());
								}
							}
						}
					}
				}
				else if (string(node2->Value()) == string("Anchors"))
				{
					mxml_parseAnchor(node2, frame);
				}
				else if (string(node2->Value()) == string("Frames"))
				{
					if (debugThis) {hge->System_Log("1.10.3");}
					for (TiXmlNode* node3 = node2->FirstChild(); node3; node3 = node3->NextSibling())
					{
						if (string(node3->Value()) == string("Frame"))
						{
							mxml_parseFrame(node3, frame, GUI_OBJECT_TYPE_FRAME);
						}
						else if (string(node3->Value()) == string("StatusBar"))
						{
							mxml_parseFrame(node3, frame, GUI_OBJECT_TYPE_STATUSBAR);
						}
					}
				}
				else if (string(node2->Value()) == string("Layers"))
				{
					if (debugThis) {hge->System_Log("1.10.4");}
					for (TiXmlNode* node3 = node2->FirstChild(); node3; node3 = node3->NextSibling())
					{
						if (string(node3->Value()) == string("Layer"))
						{
							int layer = 0;
							TiXmlElement* elem = node3->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("level"))
								{
									if (string(attr->Value()) == string("BACKGROUND"))
										layer = GUI_LAYER_BACKGROUND;
									else if (string(attr->Value()) == string("BORDER"))
										layer = GUI_LAYER_BORDER;
									else if (string(attr->Value()) == string("ARTWORK"))
										layer = GUI_LAYER_ARTWORK;
									else if (string(attr->Value()) == string("OVERLAY"))
										layer = GUI_LAYER_OVERLAY;
									else if (string(attr->Value()) == string("HIGHLIGHT"))
										layer = GUI_LAYER_HIGHLIGHT;
								}
							}

							for (TiXmlNode* node4 = node3->FirstChild(); node4; node4 = node4->NextSibling())
							{
								if (string(node4->Value()) == string("Texture"))
								{
									mxml_parseTexture(node4, frame, layer);
								}
								else if (string(node4->Value()) == string("FontString"))
								{
									mxml_parseString(node4, frame, layer);
								}
							}
						}
					}
				}
				else if (string(node2->Value()) == string("Backdrop"))
				{
					mxml_parseBackdrop(node2, frame);
				}
				else if (frame->type == GUI_OBJECT_TYPE_STATUSBAR)
				{
					if (string(node2->Value()) == string("BarTexture"))
					{
						mxml_parseTexture(node2, frame, GUI_LAYER_BACKGROUND, GUI_OBJECT_TYPE_TSTATUSBAR);
					}
					else if (string(node2->Value()) == string("BarColor"))
					{
						if (barTexFound)
						{
							float r = 1.0f; float g = 1.0f; float b = 1.0f; float al = 1.0f;
							TiXmlElement* elem = node2->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("r"))
									r = atof(attr->Value());
								else if (string(attr->Name()) == string("g"))
									g = atof(attr->Value());
								else if (string(attr->Name()) == string("b"))
									b = atof(attr->Value());
								else if (string(attr->Name()) == string("a"))
									al = atof(attr->Value());
							}

							GUIArt* a = &frame->arts[frame->name + "BarTexture"];
							a->color = ARGB(255*al, 255*r, 255*g, 255*b);
							a->sprite->SetColor(a->color);
						}
					}
				}
			}

			if (debugThis) {hge->System_Log("1.11");}

			if (!virt)
			{
				string exec;
				if (frame->type == GUI_OBJECT_TYPE_STATUSBAR)
				{
					exec = frame->name + " = StatusBar(\"" + frame->name + "\");";
					luaL_dostring(mSceneMgr->luaVM, exec.c_str());
				}
				else
				{
					exec = frame->name + " = Frame(\"" + frame->name + "\");";
					luaL_dostring(mSceneMgr->luaVM, exec.c_str());
				}
			}

			if (frame->parent != NULL)
			{
				if (frame->w < 0)
					frame->w = frame->parent->w;
				if (frame->h < 0)
					frame->h = frame->parent->h;
			}
			else
			{
				if (frame->w < 0)
					frame->w = mSceneMgr->sWidth;
				if (frame->h < 0)
					frame->h = mSceneMgr->sHeight;
			}

			if (debugThis) {hge->System_Log("1.12");}

			if ( (!frame->virt) && (frame->anchors.size() == 0) )
			{
				frame->anchors[0].parent = parent;
				frame->anchors[0].parent_name = "$parent";
			}
		}
	}
	if (debugXML) {hge->System_Log("2");}
}

void mxml_parseTexture( TiXmlNode* node, GUIElement* parent, int layer, int type )
{
	/* [#] This function parses a Texture object in an XML file. A Texture is
	/* the most important part of the GUI. It is used to display bitmap files
	/* on the screen. A Texture object must be contained in a Frame (or one of
	/* its derivation).
	*/
	bool debugThis = false;
	if (debugXML) {hge->System_Log("3");}
	GUIArt a;
	a.layer = layer;
	a.parent_name = parent->name;
	a.parent = parent;
	a.type = type;
	HTEXTURE tex;
	int blend = BLEND_ALPHABLEND;
	float sx = 0.0f; float sy = 0.0f; float sw = 0.0f; float sh = 0.0f;
	float x1 = 0.0f; float y1 = 0.0f;
	float x2 = 1.0f; float y2 = 1.0f;
	float r = 1.0f; float g = 1.0f; float b = 1.0f; float al = 1.0f;
	bool fileFound = false;

	TiXmlElement* elem = node->ToElement();
	for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
	{
		if (string(attr->Name()) == string("name"))
		{
			if (debugThis) {hge->System_Log("3.1");}
			a.name = attr->Value();
			a.sname = a.name;
			if (!parent->virt)
			{
				int i = a.name.find("$parent");
				if (i != a.name.npos)
				{
					a.name = a.name.erase(i, 7);
					a.sname = a.name;
					a.name.insert(i, parent->name);
				}
			}
			else
			{
				a.vname = a.name;
				int i = a.vname.find("$parent");
				if (i != a.vname.npos)
				{
					a.vname = a.vname.erase(i, 7);
					a.vname.insert(i, parent->vname);
				}
			}
		}
		else if (string(attr->Name()) == string("file"))
		{
			if (debugThis) {hge->System_Log("3.2");}
			a.file = attr->Value();
			tex = mSceneMgr->loadTexture(a.file, false);
			fileFound = true;
		}
		else if ( (type == GUI_OBJECT_TYPE_TEXTURE) && (string(attr->Name()) == string("alphaMode")) )
		{
			if (debugThis) {hge->System_Log("3.3");}
			if (string(attr->Value()) == string("DISABLE"))
				blend = BLEND_ALPHABLEND;
			else if (string(attr->Value()) == string("BLEND"))
				blend = BLEND_ALPHABLEND;
			else if (string(attr->Value()) == string("ALPHAKEY"))
				blend = BLEND_ALPHABLEND;
			else if (string(attr->Value()) == string("ADD"))
				blend = BLEND_ALPHABLEND;
			else if (string(attr->Value()) == string("MOD"))
				blend = BLEND_ALPHABLEND;
		}
	}

	for (TiXmlNode* node2 = node->FirstChild(); node2; node2 = node2->NextSibling())
	{
		if (string(node2->Value()) == string("Size"))
		{
			if (debugThis) {hge->System_Log("3.4");}
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsDimension"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("x"))
						{
							a.w = atof(attr->Value());
						}
						else if (string(attr->Name()) == string("y"))
						{
							a.h = atof(attr->Value());
						}
					}
				}
			}
		}
		else if ( (type == GUI_OBJECT_TYPE_TEXTURE) && (string(node2->Value()) == string("Anchors")) )
		{
			if (debugThis) {hge->System_Log("3.4");}
			mxml_parseAnchor(node2, &a);
		}
		else if (string(node2->Value()) == string("TexCoords"))
		{
			if (debugThis) {hge->System_Log("3.5");}
			TiXmlElement* elem = node2->ToElement();
			for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
			{
				if (string(attr->Name()) == string("left"))
					x1 = atof(attr->Value());
				else if (string(attr->Name()) == string("right"))
					x2 = atof(attr->Value());
				else if (string(attr->Name()) == string("top"))
					y1 = atof(attr->Value());
				else if (string(attr->Name()) == string("bottom"))
					y2 = atof(attr->Value());
			}
		}
		else if ( (type == GUI_OBJECT_TYPE_TEXTURE) && (string(node2->Value()) == string("Color")) )
		{
			if (debugThis) {hge->System_Log("3.6");}
			TiXmlElement* elem = node2->ToElement();
			for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
			{
				if (string(attr->Name()) == string("r"))
					r = atof(attr->Value());
				else if (string(attr->Name()) == string("g"))
					g = atof(attr->Value());
				else if (string(attr->Name()) == string("b"))
					b = atof(attr->Value());
				else if (string(attr->Name()) == string("a"))
					al = atof(attr->Value());
			}
		}
		else if ( (type == GUI_OBJECT_TYPE_TEXTURE) && (string(node2->Value()) == string("Gradient")) )
		{
		}
	}

	if (a.name != "")
	{
		if (fileFound)
		{
			if (debugThis) {hge->System_Log("3.7");}
			float tw = hge->Texture_GetWidth(tex, true);
			float th = hge->Texture_GetHeight(tex, true);
			sx = tw*x1;
			sy = th*y1;
			sw = tw*(x2-x1);
			sh = th*(y2-y1);

			if (type == GUI_OBJECT_TYPE_TSTATUSBAR)
				parent->base_width = sw;

			a.scale = a.w/sw;
			a.vscale = a.h/sh;

			a.sprite = mSceneMgr->createSprite(tex, sx, sy, sw, sh, true);
			a.blend = blend;
			a.color = ARGB(255*al, 255*r, 255*g, 255*b);
			a.sprite->SetBlendMode(BLEND_COLORMUL | a.blend | BLEND_NOZWRITE);
			a.sprite->SetColor(a.color);
			a.ready = true;
		}

		if (!parent->virt)
		{
			if (debugThis) {hge->System_Log("3.8");}
			string exec = a.name + " = Texture(\"" + parent->name + "\", \"" + a.name + "\");";
			luaL_dostring(mSceneMgr->luaVM, exec.c_str());
			if (debugThis) {hge->System_Log("3.8.");}
		}

		if (!parent->virt)
		{
			if (debugThis) {hge->System_Log("3.9");}
			if (mSceneMgr->parentList.find(a.name) == mSceneMgr->parentList.end()) // ?
			{
				parent->arts[a.name] = a;
				if (type == GUI_OBJECT_TYPE_TSTATUSBAR)
					parent->barTexture = &parent->arts[a.name];
				mSceneMgr->parentList[a.name] = &parent->arts[a.name];
				if (parent->arts[a.name].anchors.size() == 0)
				{
					parent->arts[a.name].anchors[0].parent = parent;
					parent->arts[a.name].anchors[0].parent_name = "$parent";
				}
			}
			else
			{
				hge->System_Log("# XML Error # : an object with the name %s already exists", a.name.c_str());
			}
		}
		else
		{
			if (debugThis) {hge->System_Log("3.10");}
			GUIBase* hparent = parent->getHighestVirtParent();
			if (hparent->parentList.find(a.vname) == hparent->parentList.end())
			{
				parent->arts[a.name] = a;
				hparent->parentList[a.vname] = &parent->arts[a.name];
				if (parent->arts[a.name].anchors.size() == 0)
				{
					parent->arts[a.name].anchors[0].parent = parent;
					parent->arts[a.name].anchors[0].parent_name = "$parent";
				}
			}
			else
			{
				hge->System_Log("# XML Error # : a template object with the name %s already exists", a.vname.c_str());
			}
		}
	}
	if (debugXML) {hge->System_Log("4");}
}

void mxml_parseString( TiXmlNode* node, GUIElement* parent, int layer )
{
	/* [#] This function parses a FontString object in an XML file. A FontString
	/* is basicaly a tool to display some text. You can display as many lines as
	/* you want, except if a text box is defined. A FontString object must be
	/* contained in a Frame (or one of its derivation).
	*/
	if (debugXML) {hge->System_Log("5");}
	GUIArt a;
	a.layer = layer;
	a.parent = parent;
	a.type = GUI_OBJECT_TYPE_FONTSTRING;
	FormatedString text;
	text.shadow = false;
	text.outline = 0;
	text.str = "";
	float space = 0.0f;
	int size = 0;
	string font = "";

	TiXmlElement* elem = node->ToElement();
	for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
	{
		if (string(attr->Name()) == string("name"))
		{
			a.name = attr->Value();
			a.sname = a.name;
			if (!parent->virt)
			{
				int i = a.name.find("$parent");
				if (i != a.name.npos)
				{
					a.name = a.name.erase(i, 7);
					a.sname = a.name;
					a.name.insert(i, parent->name);
				}
			}
			else
			{
				a.vname = a.name;
				int i = a.vname.find("$parent");
				if (i != a.vname.npos)
				{
					a.vname = a.vname.erase(i, 7);
					a.vname.insert(i, parent->vname);
				}
			}
		}
		else if (string(attr->Name()) == string("font"))
		{
			font = attr->Value();
		}
		else if (string(attr->Name()) == string("outline"))
		{
			if (string(attr->Value()) == string("NORMAL"))
				text.outline = 2;
			else if (string(attr->Value()) == string("THICK"))
				text.outline = 3;
		}
		else if (string(attr->Name()) == string("text"))
			text.str = attr->Value();
		else if (string(attr->Name()) == string("justifyH"))
		{
			if (string(attr->Value()) == string("LEFT"))
				text.align = HGETEXT_LEFT;
			else if (string(attr->Value()) == string("CENTER"))
				text.align = HGETEXT_CENTER;
			else if (string(attr->Value()) == string("RIGHT"))
				text.align = HGETEXT_RIGHT;
		}
		else if (string(attr->Name()) == string("spacing"))
			space = atof(attr->Value());
	}

	for (TiXmlNode* node2 = node->FirstChild(); node2; node2 = node2->NextSibling())
	{
		if (string(node2->Value()) == string("Size"))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsDimension"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("x"))
						{
							a.w = atof(attr->Value());
						}
						else if (string(attr->Name()) == string("y"))
						{
							a.h = atof(attr->Value());
						}
					}
				}
			}
		}
		else if (string(node2->Value()) == string("Anchors"))
		{
			mxml_parseAnchor(node2, &a);
		}
		else if (string(node2->Value()) == string("FontHeight"))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsValue"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("val"))
						{
							size = atoi(attr->Value());
						}
					}
				}
			}
		}
		else if (string(node2->Value()) == string("Color"))
		{
			float r, g, b = 0.0f;
			float al = 255.0f;
			TiXmlElement* elem = node2->ToElement();
			for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
			{
				if (string(attr->Name()) == string("r"))
					r = 255.0f*atof(attr->Value());
				else if (string(attr->Name()) == string("g"))
					g = 255.0f*atof(attr->Value());
				else if (string(attr->Name()) == string("b"))
					b = 255.0f*atof(attr->Value());
				else if (string(attr->Name()) == string("a"))
					al = 255.0f*atof(attr->Value());
			}
			text.color = ARGB(al, r, g, b);
		}
		else if (string(node2->Value()) == string("Shadow"))
		{
			text.shadow = true;
			for (TiXmlNode* node3 = node2->FirstChild(); node3; node3 = node3->NextSibling())
			{
				if (string(node3->Value()) == string("Offset"))
				{
					TiXmlNode* node4 = node3->FirstChild();
					if (node4)
					{
						if (string(node4->Value()) == string("AbsDimension"))
						{
							TiXmlElement* elem = node4->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("x"))
								{
									text.sox = atof(attr->Value());
								}
								else if (string(attr->Name()) == string("y"))
								{
									text.soy = atof(attr->Value());
								}
							}
						}
					}
				}
				else if (string(node3->Value()) == string("Color"))
				{
					float r, g, b = 0.0f;
					float al = 255.0f;
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("r"))
							r = 255.0f*atof(attr->Value());
						else if (string(attr->Name()) == string("g"))
							g = 255.0f*atof(attr->Value());
						else if (string(attr->Name()) == string("b"))
							b = 255.0f*atof(attr->Value());
						else if (string(attr->Name()) == string("a"))
							al = 255.0f*atof(attr->Value());
					}
					text.scolor = ARGB(al, r, g, b);
				}
			}
		}
	}

	a.text = text;

	if (a.name != "")
	{
		hgeFont* tmpFnt = NULL;
		if (font != "")
		{
			tmpFnt = mFontMgr->getFont(true, font, size, false, false);
		}

		if (tmpFnt != NULL)
		{
			a.ready = true;
			a.text.fnt = tmpFnt;
			a.text.tracking = space;

			if (a.text.shadow)
				a.text.sfnt = tmpFnt;
		}
		else
			a.ready = false;

		if (!parent->virt)
		{
			string exec = a.name + " = FontString(\"" + parent->name + "\", \"" + a.name + "\");";
			luaL_dostring(mSceneMgr->luaVM, exec.c_str());

			if (mSceneMgr->parentList.find(a.name) == mSceneMgr->parentList.end())
			{
				parent->arts[a.name] = a;
				mSceneMgr->parentList[a.name] = &parent->arts[a.name];
				if (parent->arts[a.name].anchors.size() == 0)
				{
					parent->arts[a.name].anchors[0].parent = parent;
					parent->arts[a.name].anchors[0].parent_name = "$parent";
				}
			}
			else
			{
				hge->System_Log("# XML Error # : an object with the name %s already exists", a.name.c_str());
			}
		}
		else
		{
			GUIBase* hparent = parent->getHighestVirtParent();
			if (hparent->parentList.find(a.vname) == hparent->parentList.end())
			{
				parent->arts[a.name] = a;
				hparent->parentList[a.vname] = &parent->arts[a.name];
				if (parent->arts[a.name].anchors.size() == 0)
				{
					parent->arts[a.name].anchors[0].parent = parent;
					parent->arts[a.name].anchors[0].parent_name = "$parent";
				}
			}
			else
			{
				hge->System_Log("# XML Error # : a template object with the name %s already exists", a.vname.c_str());
			}
		}
	}
	if (debugXML) {hge->System_Log("6");}
}

void mxml_parseAnchor( TiXmlNode* node, GUIBase* parent )
{
	/* [#] This function parses an Anchor object in an XML file.
	/* An Anchor must be contained in another object, such as a Frame or a Texture.
	*/
	if (debugXML) {hge->System_Log("7");}
	TiXmlNode* node2 = node->FirstChild();
	if (node2)
	{
		if (string(node2->Value()) == string("Anchor"))
		{
			Anchor a;
			TiXmlElement* elem = node2->ToElement();
			for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
			{
				if (string(attr->Name()) == string("point"))
				{
					if (string(attr->Value()) == string("TOPLEFT"))
						a.anchorPt = GUI_ANCHOR_TOPLEFT;
					else if (string(attr->Value()) == string("TOP"))
						a.anchorPt = GUI_ANCHOR_TOP;
					else if (string(attr->Value()) == string("TOPRIGHT"))
						a.anchorPt = GUI_ANCHOR_TOPRIGHT;
					else if (string(attr->Value()) == string("RIGHT"))
						a.anchorPt = GUI_ANCHOR_RIGHT;
					else if (string(attr->Value()) == string("BOTTOMRIGHT"))
						a.anchorPt = GUI_ANCHOR_BOTTOMRIGHT;
					else if (string(attr->Value()) == string("BOTTOM"))
						a.anchorPt = GUI_ANCHOR_BOTTOM;
					else if (string(attr->Value()) == string("BOTTOMLEFT"))
						a.anchorPt = GUI_ANCHOR_BOTTOMLEFT;
					else if (string(attr->Value()) == string("LEFT"))
						a.anchorPt = GUI_ANCHOR_LEFT;
					else if (string(attr->Value()) == string("CENTER"))
						a.anchorPt = GUI_ANCHOR_CENTER;
				}
				else if (string(attr->Name()) == string("relativeTo"))
				{
					a.parent_name = attr->Value();
				}
				else if (string(attr->Name()) == string("relativePoint"))
				{
					if (string(attr->Value()) == string("TOPLEFT"))
						a.relativePt = GUI_ANCHOR_TOPLEFT;
					else if (string(attr->Value()) == string("TOP"))
						a.relativePt = GUI_ANCHOR_TOP;
					else if (string(attr->Value()) == string("TOPRIGHT"))
						a.relativePt = GUI_ANCHOR_TOPRIGHT;
					else if (string(attr->Value()) == string("RIGHT"))
						a.relativePt = GUI_ANCHOR_RIGHT;
					else if (string(attr->Value()) == string("BOTTOMRIGHT"))
						a.relativePt = GUI_ANCHOR_BOTTOMRIGHT;
					else if (string(attr->Value()) == string("BOTTOM"))
						a.relativePt = GUI_ANCHOR_BOTTOM;
					else if (string(attr->Value()) == string("BOTTOMLEFT"))
						a.relativePt = GUI_ANCHOR_BOTTOMLEFT;
					else if (string(attr->Value()) == string("LEFT"))
						a.relativePt = GUI_ANCHOR_LEFT;
					else if (string(attr->Value()) == string("CENTER"))
						a.relativePt = GUI_ANCHOR_CENTER;
				}
			}

			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("Offset"))
				{
					TiXmlNode* node4 = node3->FirstChild();
					if (node4)
					{
						if (string(node4->Value()) == string("AbsDimension"))
						{
							TiXmlElement* elem = node4->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("x"))
								{
									a.x = atof(attr->Value());
								}
								else if (string(attr->Name()) == string("y"))
								{
									a.y = atof(attr->Value());
								}
							}
						}
					}
				}
			}

			bool newAnchor = true;

			if (parent->virt)
			{
				if (a.parent_name == "")
				{
					if (parent->parent != NULL)
					{
						a.parent = parent->parent;
						a.parent_name = "$parent";
					}
				}
				else
				{
					if (mSceneMgr->guiList.find(a.parent_name) != mSceneMgr->guiList.end())
					{
						a.parent = &mSceneMgr->guiList[a.parent_name];
					}
					else
					{
						GUIBase* hparent = parent->getHighestVirtParent();
						string tpname = a.parent_name;
						int i = tpname.find("$parent");
						if (i != tpname.npos)
						{
							tpname = tpname.erase(i, 7);
							if (parent->parent != NULL)
								tpname.insert(i, parent->parent->vname);
						}
						if (hparent->parentList.find(tpname) != hparent->parentList.end())
						{
							a.parent = hparent->parentList[tpname];
						}
						else
						{
							newAnchor = false;
							hge->System_Log("# XML Error # : unknown parent %s\n# Listing %s parents :", tpname.c_str(), hparent->vname.c_str());
							map<string, GUIBase*>::iterator iter;
							for (iter = hparent->parentList.begin(); iter != hparent->parentList.end(); iter++)
							{
								hge->System_Log("   - %s", iter->first.c_str());
							}
						}
					}
				}
			}
			else
			{
				if (a.parent_name == "")
				{
					if (parent->parent != NULL)
					{
						a.parent = parent->parent;
						a.parent_name = parent->parent->name;
					}
				}
				else
				{
					int i = a.parent_name.find("$parent");
					if (i != a.parent_name.npos)
					{
						a.parent_name = a.parent_name.erase(i, 7);
						if (parent != NULL)
						{
							if (parent->parent != NULL)
								a.parent_name.insert(i, parent->parent->name);
						}
					}
					if (mSceneMgr->guiList.find(a.parent_name) != mSceneMgr->guiList.end())
					{
						a.parent = &mSceneMgr->guiList[a.parent_name];
					}
					else
					{
						newAnchor = false;
						hge->System_Log("# XML Error # : unknown parent %s", a.parent_name.c_str());
					}
				}
			}

			parent->anchors[parent->anchors.size()] = a;
		}
	}
	if (debugXML) {hge->System_Log("8");}
}

void mxml_parseBackdrop( TiXmlNode* node, GUIElement* parent )
{
	/* [#] This function parses a Backdrop object in an XML file.
	/* A Backdrop must be contained in a Frame.
	*/
	if (debugXML) {hge->System_Log("9");}
	Backdrop bd;
	bd.bgFile = "";
	bd.edgeFile = "";
	bd.tile = false;
	bd.edgeSize = -1.0f;
	bd.tileSize = -1.0f;
	bd.insL = 0.0f;
	bd.insR = 0.0f;
	bd.insT = 0.0f;
	bd.insB = 0.0f;

	TiXmlElement* elem = node->ToElement();
	for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
	{
		if (string(attr->Name()) == string("bgFile"))
		{
			bd.bgFile = attr->Value();
		}
		if (string(attr->Name()) == string("edgeFile"))
		{
			bd.edgeFile = attr->Value();
		}
		if (string(attr->Name()) == string("tile"))
		{
			bd.tile = toBool((char*)attr->Value());
		}
	}

	for (TiXmlNode* node2 = node->FirstChild(); node2; node2 = node2->NextSibling())
	{
		if (string(node2->Value()) == string("EdgeSize"))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsValue"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("val"))
						{
							bd.edgeSize = atoi(attr->Value());
						}
					}
				}
			}
		}
		if (string(node2->Value()) == string("TileSize"))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsValue"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("val"))
						{
							bd.tileSize = atoi(attr->Value());
						}
					}
				}
			}
		}
		if (string(node2->Value()) == string("BackgroundInsets"))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsInset"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("left"))
						{
							bd.insL = atoi(attr->Value());
						}
						if (string(attr->Name()) == string("right"))
						{
							bd.insR = atoi(attr->Value());
						}
						if (string(attr->Name()) == string("top"))
						{
							bd.insT = atoi(attr->Value());
						}
						if (string(attr->Name()) == string("bottom"))
						{
							bd.insB = atoi(attr->Value());
						}
					}
				}
			}
		}
	}

	// Load edges
	if ( (bd.edgeFile != "") && (!parent->virt) )
	{
		HTEXTURE tex1 = mSceneMgr->loadTexture(bd.edgeFile, false);
		float size = (int)floor(hge->Texture_GetWidth(tex1, true)/8.0f);
		bd.edgeL = new hgeSprite(tex1, 0, 0, size, size);
		bd.edgeR = new hgeSprite(tex1, size, 0, size, size);
		bd.edgeT = new hgeSprite(tex1, 2*size, 0, size, size);
		bd.edgeB = new hgeSprite(tex1, 3*size, 0, size, size);
		bd.cornerTL = new hgeSprite(tex1, 4*size, 0, size, size);
		bd.cornerTR = new hgeSprite(tex1, 5*size, 0, size, size);
		bd.cornerBL = new hgeSprite(tex1, 6*size, 0, size, size);
		bd.cornerBR = new hgeSprite(tex1, 7*size, 0, size, size);
		bd.edgeOriginalSize = size;
		bd.edgeReady = true;
	}
	else
		bd.edgeReady = false;

	// Load background
	if ( (bd.bgFile != "") && (!parent->virt) )
	{
		HTEXTURE tex2;
		tex2 = mSceneMgr->loadTexture(bd.bgFile, false);

		bd.bgW = hge->Texture_GetWidth(tex2, true);
		bd.bgH = hge->Texture_GetHeight(tex2, true);

		if (bd.tile)
			bd.background = new hgeSprite(tex2, 0, 0, parent->w-bd.insL-bd.insR, parent->h-bd.insT-bd.insB);
		else
			bd.background = new hgeSprite(tex2, 0, 0, bd.bgW, bd.bgH);

		bd.bgReady = true;
	}
	else
		bd.bgReady = false;

	if (!parent->virt)
	{
		bd.target = hge->Target_Create(toInt(parent->w), toInt(parent->h), false);
		bd.spr = new hgeSprite(hge->Target_GetTexture(bd.target), 0, 0, toInt(parent->w), toInt(parent->h));
	}

	parent->backdrop = bd;
	parent->useBackdrop = true;

	if (debugXML) {hge->System_Log("10");}
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               GUI source               */
/*                                        */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_gui.h"
#include "wowrl_scenemanager.h"
#include "wowrl_fontmanager.h"

using namespace std;

extern SceneManager* mSceneMgr;
extern FontManager* mFontMgr;
extern bool debugGUI;

#define method(class, name) {#name, &class::name}

/****************/
/* Constructors */
/****************/
l_Frame::l_Frame(lua_State* luaVM) : l_Region(luaVM)
{
	name = lua_tostring(luaVM, 1);
	base = NULL;
}

l_StatusBar::l_StatusBar(lua_State* luaVM) : l_Frame(luaVM)
{
	name = lua_tostring(luaVM, 1);
}

l_Texture::l_Texture(lua_State* luaVM) : l_LayeredRegion(luaVM)
{
	pname = lua_tostring(luaVM, 1);
	name = lua_tostring(luaVM, 2);
}

l_FontString::l_FontString(lua_State* luaVM) : l_LayeredRegion(luaVM)
{
	pname = lua_tostring(luaVM, 1);
	name = lua_tostring(luaVM, 2);
}


/**************************/
/* Methods implementation */
/**************************/

/* [#] The following functions are called "glues". They aren't used in C++ but
/* in the LUA environnement. To get a description of what they do, you can refer
/* to :
/*                     http://www.wowwiki.com/Widget_API
/*
/* They are all described there. (Some aren't, but their use if obvious)
*/

/**********/
/* REGION */
/**********/
int l_Region::GetBottom(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushnumber(luaVM, mSceneMgr->sHeight+rbase->getY(false)+rbase->h);
	return 1;
}

int l_Region::GetCenter(lua_State* luaVM)
{
	if (rbase != NULL)
	{
		lua_pushnumber(luaVM, rbase->getX(false)+rbase->w/2);
		lua_pushnumber(luaVM, mSceneMgr->sHeight+rbase->getY(false)+rbase->h/2);
	}
	return 2;
}

int l_Region::GetHeight(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushnumber(luaVM, rbase->h);
	return 1;
}

int l_Region::GetLeft(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushnumber(luaVM, rbase->getX(false));
	return 1;
}

int l_Region::GetName(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushstring(luaVM, rbase->name.c_str());
	return 1;
}

int l_Region::GetPoint(lua_State* luaVM)
{
	if (rbase != NULL)
	{
		Anchor a = rbase->anchors[0];
		switch (a.anchorPt)
		{
			case GUI_ANCHOR_TOPLEFT: lua_pushstring(luaVM, "TOPLEFT"); break;
			case GUI_ANCHOR_TOP: lua_pushstring(luaVM, "TOPL"); break;
			case GUI_ANCHOR_TOPRIGHT: lua_pushstring(luaVM, "TOPRIGHT"); break;
			case GUI_ANCHOR_RIGHT: lua_pushstring(luaVM, "RIGHT"); break;
			case GUI_ANCHOR_BOTTOMRIGHT: lua_pushstring(luaVM, "BOTTOMRIGHT"); break;
			case GUI_ANCHOR_BOTTOM: lua_pushstring(luaVM, "BOTTOM"); break;
			case GUI_ANCHOR_BOTTOMLEFT: lua_pushstring(luaVM, "BOTTOMLEFT"); break;
			case GUI_ANCHOR_LEFT: lua_pushstring(luaVM, "LEFT"); break;
			case GUI_ANCHOR_CENTER: lua_pushstring(luaVM, "CENTER"); break;
		}
		lua_pushstring(luaVM, a.parent_name.c_str());
		switch (a.relativePt)
		{
			case GUI_ANCHOR_TOPLEFT: lua_pushstring(luaVM, "TOPLEFT"); break;
			case GUI_ANCHOR_TOP: lua_pushstring(luaVM, "TOPL"); break;
			case GUI_ANCHOR_TOPRIGHT: lua_pushstring(luaVM, "TOPRIGHT"); break;
			case GUI_ANCHOR_RIGHT: lua_pushstring(luaVM, "RIGHT"); break;
			case GUI_ANCHOR_BOTTOMRIGHT: lua_pushstring(luaVM, "BOTTOMRIGHT"); break;
			case GUI_ANCHOR_BOTTOM: lua_pushstring(luaVM, "BOTTOM"); break;
			case GUI_ANCHOR_BOTTOMLEFT: lua_pushstring(luaVM, "BOTTOMLEFT"); break;
			case GUI_ANCHOR_LEFT: lua_pushstring(luaVM, "LEFT"); break;
			case GUI_ANCHOR_CENTER: lua_pushstring(luaVM, "CENTER"); break;
		}
		lua_pushnumber(luaVM, a.x);
		lua_pushnumber(luaVM, a.y);
	}
	return 5;
}

int l_Region::GetRight(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushnumber(luaVM, rbase->getX(false)+rbase->w);
	return 1;
}

int l_Region::GetTop(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushnumber(luaVM, mSceneMgr->sHeight+rbase->getY(false));
	return 1;
}

int l_Region::GetWidth(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushnumber(luaVM, rbase->w);
	return 1;
}

int l_Region::Hide(lua_State* luaVM)
{
	if (rbase != NULL)
	{
		if (!rbase->hidden)
		{
			rbase->hidden = true;
			if (ebase != NULL)
				ebase->_rebuildCache();
			else
				rbase->parent->_rebuildCache();
		}
	}
	return 0;
}

int l_Region::IsShown(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushboolean(luaVM, !rbase->hidden);
	return 1;
}

int l_Region::IsVisible(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushboolean(luaVM, rbase->IsVisible());
	return 1;
}

int l_Region::SetHeight(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		mlua_printError("Too few argument in \"Region:SetHeight\" (one expected : region height)");
		return 0;
	}
	else if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument of Region:SetHeight must be a number (region height)");
		error++;
	}

	if (error == 0)
	{
		float h = lua_tonumber(luaVM, 1);
		if (h != rbase->h)
		{
			rbase->h = h;
			if (ebase != NULL)
			{
				if (ebase->useBackdrop)
				{
					if (ebase->backdrop.tile)
						ebase->backdrop.background->SetTextureRect(
							0, 0,
							ebase->w-ebase->backdrop.insL-ebase->backdrop.insR,
							ebase->h-ebase->backdrop.insT-ebase->backdrop.insB
						);
					if (ebase->h < 2*ebase->backdrop.edgeSize)
					{
						ebase->h = 2*ebase->backdrop.edgeSize;
					}
				}
				ebase->recreateCache = true;
				ebase->parent->_rebuildCache();
			}
			else
				rbase->parent->_rebuildCache();
		}
	}

	return 0;
}

int l_Region::SetPoint(lua_State* luaVM)
{
	int error = 0;
	bool offsetDefined = false;
	if (lua_gettop(luaVM) < 3)
	{
		mlua_printError("Too few argument in \"Region:SetPoint\" (3 or 5 expected : point, relativeTo, relativePoint [, offx, offy])");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of Region:SetPoint must be a string (anchor point)");
		error++;
	}
	if (!lua_isstring(luaVM, 2) && !lua_isnil(luaVM, 2))
	{
		mlua_printError("Argument 2 of Region:SetPoint must be a string (or nil) (anchor parent)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		mlua_printError("Argument 3 of Region:SetPoint must be a string (parent point)");
		error++;
	}
	if (lua_gettop(luaVM) >= 5)
	{
		offsetDefined = true;
		if (!lua_isnumber(luaVM, 4))
		{
			mlua_printError("Argument 4 of Region:SetPoint must be a number (x offset)");
			error++;
		}
		if (!lua_isnumber(luaVM, 5))
		{
			mlua_printError("Argument 5 of Region:SetPoint must be a number (y offset)");
			error++;
		}
	}

	if (error == 0)
	{
		bool noParent;
		if (lua_isnil(luaVM, 2))
			noParent = true;
		else
			noParent = false;

		string point, relativeTo, relativePoint;
		float ox, oy;

		point = lua_tostring(luaVM, 1);

		if (!noParent)
			relativeTo = lua_tostring(luaVM, 2);

		relativePoint = lua_tostring(luaVM, 3);

		if (offsetDefined)
		{
			ox = lua_tonumber(luaVM, 4);
			oy = lua_tonumber(luaVM, 5);
		}

		if ( (mSceneMgr->guiList.find(relativeTo) != mSceneMgr->guiList.end())
		  || (noParent) )
		{
			Anchor a;
			if (point == string("TOPLEFT"))
				a.anchorPt = GUI_ANCHOR_TOPLEFT;
			else if (point == string("TOP"))
				a.anchorPt = GUI_ANCHOR_TOP;
			else if (point == string("TOPRIGHT"))
				a.anchorPt = GUI_ANCHOR_TOPRIGHT;
			else if (point == string("RIGHT"))
				a.anchorPt = GUI_ANCHOR_RIGHT;
			else if (point == string("BOTTOMRIGHT"))
				a.anchorPt = GUI_ANCHOR_BOTTOMRIGHT;
			else if (point == string("BOTTOM"))
				a.anchorPt = GUI_ANCHOR_BOTTOM;
			else if (point == string("BOTTOMLEFT"))
				a.anchorPt = GUI_ANCHOR_BOTTOMLEFT;
			else if (point == string("LEFT"))
				a.anchorPt = GUI_ANCHOR_LEFT;
			else if (point == string("CENTER"))
				a.anchorPt = GUI_ANCHOR_CENTER;

			if (!noParent)
			{
				a.parent_name = relativeTo;
				a.parent = &mSceneMgr->guiList[relativeTo];
			}

			if (relativePoint == string("TOPLEFT"))
				a.relativePt = GUI_ANCHOR_TOPLEFT;
			else if (relativePoint == string("TOP"))
				a.relativePt = GUI_ANCHOR_TOP;
			else if (relativePoint == string("TOPRIGHT"))
				a.relativePt = GUI_ANCHOR_TOPRIGHT;
			else if (relativePoint == string("RIGHT"))
				a.relativePt = GUI_ANCHOR_RIGHT;
			else if (relativePoint == string("BOTTOMRIGHT"))
				a.relativePt = GUI_ANCHOR_BOTTOMRIGHT;
			else if (relativePoint == string("BOTTOM"))
				a.relativePt = GUI_ANCHOR_BOTTOM;
			else if (relativePoint == string("BOTTOMLEFT"))
				a.relativePt = GUI_ANCHOR_BOTTOMLEFT;
			else if (relativePoint == string("LEFT"))
				a.relativePt = GUI_ANCHOR_LEFT;
			else if (relativePoint == string("CENTER"))
				a.relativePt = GUI_ANCHOR_CENTER;

			if (offsetDefined)
			{
				a.x = ox;
				a.y = oy;
			}

			if (rbase != NULL)
			{
				Anchor a2 = rbase->anchors[0];
				if ( (a.x != a2.x) ||
					 (a.y != a2.y) ||
					 (a.anchorPt != a2.anchorPt) ||
					 (a.parent != a2.parent) ||
					 (a.relativePt != a2.relativePt) )
				{
					rbase->anchors[0] = a;
					rbase->parent->_rebuildCache();
				}
			}
		}
		else
			mlua_printError("Error in " + rbase->name + ":SetPoint : unknown object \"" + relativeTo + "\"");
	}

	return 0;
}

int l_Region::SetWidth(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		mlua_printError("Too few argument in \"Region:SetWidth\" (one expected : region width)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument of Region:SetWidth must be a number (region width)");
		error++;
	}

	if (error == 0)
	{
		float w = lua_tonumber(luaVM, 1);
		if (w != rbase->w)
		{
			rbase->w = w;
			if (ebase != NULL)
			{
				if (ebase->useBackdrop)
				{
					if (ebase->backdrop.tile)
						ebase->backdrop.background->SetTextureRect(
							0, 0,
							ebase->w-ebase->backdrop.insL-ebase->backdrop.insR,
							ebase->h-ebase->backdrop.insT-ebase->backdrop.insB
						);
					if (ebase->w < 2*ebase->backdrop.edgeSize)
					{
						ebase->w = 2*ebase->backdrop.edgeSize;
					}
				}
				ebase->recreateCache = true;
				ebase->parent->_rebuildCache();
			}
			else
				rbase->parent->_rebuildCache();
		}
	}

	return 0;
}

int l_Region::Show(lua_State* luaVM)
{
	if (rbase != NULL)
	{
		if (rbase->hidden)
		{
			rbase->hidden = false;
			if (ebase != NULL)
				ebase->_rebuildCache(true);
			else
				rbase->parent->_rebuildCache(true);
		}
	}
	return 0;
}

/**********/
/* FRAME  */
/**********/

int l_Frame::_init(lua_State* luaVM)
{
	if (name != "")
	{
		if (mSceneMgr->guiList.find(name) != mSceneMgr->guiList.end())
		{
			base = &mSceneMgr->guiList[name];
			rbase = base;
			ebase = base;
		}
	}

	return 0;
}

int l_Frame::GetBackdrop(lua_State* luaVM)
{
	/* Creates a tables containing backdrop informations :
	/* {
	/*    ["bgFile"]
	/*    ["edgeFile"]
	/*    ["tile"]
	/*    ["tileSize"]
	/*    ["edgeSize"]
	/*    ["insets"] = {
	/*         ["left"]
	/*         ["right"]
	/*         ["top"]
	/*         ["bottom"]
	/*    },
	/* },
	*/
	if (base != NULL)
	{
		if (ebase->useBackdrop)
		{
			Backdrop* b = &base->backdrop;
			lua_createtable(luaVM, 3, 3);
			mlua_setFieldString("bgFile", b->bgFile, luaVM);
			mlua_setFieldString("edgeFile", b->edgeFile, luaVM);
			mlua_setFieldBool("tile", b->tile, luaVM);
			mlua_setFieldFloat("tileSize", b->tileSize, luaVM);
			mlua_setFieldFloat("edgeSize", b->edgeSize, luaVM);
			lua_pushstring(luaVM, "insets");
			lua_createtable(luaVM, 0, 4);
			mlua_setFieldFloat("left", b->insL, luaVM);
			mlua_setFieldFloat("right", b->insR, luaVM);
			mlua_setFieldFloat("top", b->insT, luaVM);
			mlua_setFieldFloat("bottom", b->insB, luaVM);
			lua_settable(luaVM, -3);
		}
		else
			lua_pushnil(luaVM);
	}

	return 1;
}

int l_Frame::SetBackdrop(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		mlua_printError("Too few argument in \"Frame:SetBackdrop\" (one expected : backdrop table)");
		return 0;
	}
	else if ( !lua_istable(luaVM, 1) && !lua_isnil(luaVM, 1) )
	{
		mlua_printError("Argument 1 of StatusBar:SetBackdrop must be a table (or nil) (backdrop table)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			if (lua_isnil(luaVM, 1))
			{
				base->useBackdrop = false;
			}
			else
			{
				lua_settop(luaVM, 1); // Remove possible junk

				Backdrop bd;
				bd.bgFile = mlua_getFieldString("bgFile", false, "", false, luaVM);
				bd.edgeFile = mlua_getFieldString("edgeFile", false, "", false, luaVM);
				bd.tile = mlua_getFieldBool("tile", false, false, false, luaVM);
				bd.tileSize = mlua_getFieldFloat("tileSize", false, -1, false, luaVM);
				bd.edgeSize = mlua_getFieldFloat("edgeSize", false, -1, false, luaVM);

				lua_getfield(luaVM, 1, "insets");
				bd.insL = mlua_getFieldFloat("left", false, 0, false, luaVM);
				bd.insR = mlua_getFieldFloat("right", false, 0, false, luaVM);
				bd.insT = mlua_getFieldFloat("top", false, 0, false, luaVM);
				bd.insB = mlua_getFieldFloat("bottom", false, 0, false, luaVM);

				// Create edges
				if (bd.edgeFile != "")
				{
					HTEXTURE tex1 = mSceneMgr->loadTexture(bd.edgeFile, false);
					float size = (int)floor(hge->Texture_GetWidth(tex1, true)/8.0f);
					if (base->useBackdrop && base->backdrop.edgeReady)
					{
						delete base->backdrop.edgeL;
						delete base->backdrop.edgeR;
						delete base->backdrop.edgeT;
						delete base->backdrop.edgeB;
						delete base->backdrop.cornerTL;
						delete base->backdrop.cornerTR;
						delete base->backdrop.cornerBL;
						delete base->backdrop.cornerBR;
					}
					bd.edgeL = new hgeSprite(tex1, 0, 0, size, size);
					bd.edgeR = new hgeSprite(tex1, size, 0, size, size);
					bd.edgeT = new hgeSprite(tex1, 2*size, 0, size, size);
					bd.edgeB = new hgeSprite(tex1, 3*size, 0, size, size);
					bd.cornerTL = new hgeSprite(tex1, 4*size, 0, size, size);
					bd.cornerTR = new hgeSprite(tex1, 5*size, 0, size, size);
					bd.cornerBL = new hgeSprite(tex1, 6*size, 0, size, size);
					bd.cornerBR = new hgeSprite(tex1, 7*size, 0, size, size);
					bd.edgeOriginalSize = size;
					if (bd.edgeSize == -1)
						bd.edgeSize = bd.edgeOriginalSize;
					bd.edgeReady = true;
				}
				else
					bd.edgeReady = false;

				// Create background
				if (bd.bgFile != "")
				{
					HTEXTURE tex2;
					tex2 = mSceneMgr->loadTexture(bd.bgFile, false);

					bd.bgW = hge->Texture_GetWidth(tex2, true);
					bd.bgH = hge->Texture_GetHeight(tex2, true);

					if (base->useBackdrop && base->backdrop.bgReady)
						delete base->backdrop.background;
					if (bd.tile)
						bd.background = new hgeSprite(tex2, 0, 0, base->w-bd.insL-bd.insR, base->h-bd.insT-bd.insB);
					else
						bd.background = new hgeSprite(tex2, 0, 0, bd.bgW, bd.bgH);

					bd.bgReady = true;
				}
				else
					bd.bgReady = false;

				if (base->useBackdrop)
				{
					hge->Target_Free(base->backdrop.target);
					delete base->backdrop.spr;
				}
				bd.target = hge->Target_Create(toInt(ebase->w), toInt(ebase->h), false);
				bd.spr = new hgeSprite(hge->Target_GetTexture(bd.target), 0, 0, toInt(base->w), toInt(base->h));

				base->backdrop = bd;
				base->useBackdrop = true;

				base->_rebuildCache();
				base->rebuildBackdrop = true;
			}
		}
	}

	return 0;
}

/**************/
/* STATUS BAR */
/**************/

int l_StatusBar::SetMinMaxValues(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 2)
	{
		mlua_printError("Too few argument in \"StatusBar:SetMinMaxValues\" (2 expected : min, max)");
		return 0;
	}
	else if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of StatusBar:SetMinMaxValues must be a number (min)");
		error++;
	}
	else if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of StatusBar:SetMinMaxValues must be a number (max)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			float min_value = lua_tonumber(luaVM, 1);
			float max_value = lua_tonumber(luaVM, 2);
			if (min_value != base->min_value)
			{
				base->min_value = min_value;
				base->_rebuildCache();
			}
			if (max_value != base->max_value)
			{
				base->max_value = max_value;
				base->_rebuildCache();
			}
		}
	}

	return 0;
}

int l_StatusBar::SetStatusBarColor(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 3)
	{
		mlua_printError("Too few argument in \"StatusBar:SetStatusBarColor\" (3 or 4 expected : red, green, blue (+alpha))");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of StatusBar:SetStatusBarColor must be a number (red)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of StatusBar:SetStatusBarColor must be a number (green)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of StatusBar:SetStatusBarColor must be a number (blue)");
		error++;
	}
	if ( (lua_gettop(luaVM) >= 4) && (!lua_isnumber(luaVM, 4)) )
	{
		mlua_printError("Argument 4 of StatusBar:SetStatusBarColor must be a number (alpha)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			float a, r, g, b;
			r = lua_tonumber(luaVM, 1);
			g = lua_tonumber(luaVM, 2);
			b = lua_tonumber(luaVM, 3);
			if (lua_gettop(luaVM) >= 4)
				a = lua_tonumber(luaVM, 4);
			else
				a = GETA(base->barTexture->sprite->GetColor())/255.0f;

			DWORD color = ARGB(a*255, r*255, g*255, b*255);
			if (color != base->barTexture->color)
			{
				base->barTexture->color = color;
				base->barTexture->sprite->SetColor(base->barTexture->color);
				base->_rebuildCache();
			}
		}
	}

	return 0;
}

int l_StatusBar::SetValue(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) == 0)
	{
		mlua_printError("Too few argument in \"StatusBar:SetValue\" (one expected : value)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument of StatusBar:SetValue must be a number (value)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			float value = lua_tonumber(luaVM, 1);
			if (value != base->value)
			{
				base->value = value;
				base->_rebuildCache();
			}
		}
	}

	return 0;
}

/******************/
/* LAYERED REGION */
/******************/

int l_LayeredRegion::_init(lua_State* luaVM)
{
	if ( (name != "") && (pname != "") )
	{
		if (mSceneMgr->guiList.find(pname) != mSceneMgr->guiList.end())
		{
			base = &mSceneMgr->guiList[pname].arts[name];
			rbase = base;
		}
	}

	return 0;
}

/***********/
/* TEXTURE */
/***********/

int l_Texture::SetTexCoord(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 4)
	{
		mlua_printError("Too few argument in \"Texture:SetTexCoord\" (4 expected : left, right, top, bottom)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of Texture:SetTexCoord must be a number (left)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of Texture:SetTexCoord must be a number (right)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of Texture:SetTexCoord must be a number (top)");
		error++;
	}
	if (!lua_isnumber(luaVM, 4))
	{
		mlua_printError("Argument 4 of Texture:SetTexCoord must be a number (bottom)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			if (base->sprite != NULL)
			{
				float tw = hge->Texture_GetWidth(base->sprite->GetTexture(), true);
				float th = hge->Texture_GetHeight(base->sprite->GetTexture(), true);
				float sx = tw*lua_tonumber(luaVM, 1);
				float sy = th*lua_tonumber(luaVM, 3);
				float sw = tw*(lua_tonumber(luaVM, 2)-lua_tonumber(luaVM, 1));
				float sh = th*(lua_tonumber(luaVM, 4)-lua_tonumber(luaVM, 3));

				base->sprite->SetTextureRect(sx, sy, sw, sh);

				base->parent->_rebuildCache();
			}
		}
	}

	return 0;
}

int l_Texture::SetTexture(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		mlua_printError("Too few argument in \"Texture:SetTexture\" (one expected : texture file)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of Texture:SetTexture must be a string (texture file)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			string nfile = lua_tostring(luaVM, 1);
			if (nfile != base->file)
			{
				base->file = nfile;

				if (base->file == "")
					base->ready = false;
				else
				{
					HTEXTURE tex = mSceneMgr->loadTexture(base->file, false);
					if (tex)
					{
						float sw, sh;
						sw = hge->Texture_GetWidth(tex);
						sh = hge->Texture_GetHeight(tex);
						base->sprite = mSceneMgr->createSprite
						(
							tex, 0, 0, sw, sh, true
						);
						if (base->sprite != NULL)
						{
							base->sprite->SetColor(base->color);
							base->scale = base->w/sw;
							base->vscale = base->h/sh;
							base->ready = true;
						}
						else
							base->ready = false;
					}
					else
						base->ready = false;
				}
				base->parent->_rebuildCache();
			}
		}
	}

	return 0;
}

int l_Texture::SetVertexColor(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 3)
	{
		mlua_printError("Too few argument in \"Texture:SetVertexColor\" (3 or 4 expected : red, green, blue (+alpha))");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of Texture:SetVertexColor must be a number (red)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of Texture:SetVertexColor must be a number (green)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of Texture:SetVertexColor must be a number (blue)");
		error++;
	}
	if ( (lua_gettop(luaVM) >= 4) && (!lua_isnumber(luaVM, 4)) )
	{
		mlua_printError("Argument 4 of Texture:SetVertexColor must be a number (alpha)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			float a, r, g, b;
			r = lua_tonumber(luaVM, 1);
			g = lua_tonumber(luaVM, 2);
			b = lua_tonumber(luaVM, 3);
			if (lua_gettop(luaVM) >= 4)
				a = lua_tonumber(luaVM, 4);
			else
				a = GETA(base->color)/255.0f;

			DWORD color = ARGB(a*255, r*255, g*255, b*255);

			if (base->color != color)
			{
				base->color = color;
				if (base->sprite != NULL)
				{
					base->sprite->SetColor(base->color);
				}
				base->parent->_rebuildCache();
			}
		}
	}

	return 0;
}

/***************/
/* FONT STRING */
/***************/

int l_FontString::SetFont(lua_State* luaVM)
{int error = 0;
	if (lua_gettop(luaVM) < 2)
	{
		mlua_printError("Too few argument in \"FontString:SetFont\" (2 or 3 expected : font, size (+flags))");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of FontString:SetFont must be a string (font)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of FontString:SetFont must be a number (size)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			bool bold = false;
			bool italic = false;

			// Read flags
			if (lua_isstring(luaVM, 3))
			{
				string s = lua_tostring(luaVM, 3);
				int i = s.find("OUTLINE");
				if (i != s.npos)
				{
					i = s.find("THICKOUTLINE");
					if (i != s.npos)
						base->text.outline = 3;
					else
						base->text.outline = 2;
				}
				i = s.find("BOLD");
				if (i != s.npos)
				{
					bold = true;
				}
				i = s.find("ITALIC");
				if (i != s.npos)
				{
					italic = true;
				}
			}

			hgeFont* tmpFnt = NULL;
			tmpFnt = mFontMgr->getFont(true, lua_tostring(luaVM, 1), toInt(lua_tonumber(luaVM, 2)), bold, italic);

			if (tmpFnt == NULL)
			{
				base->parent->_rebuildCache();
				base->ready = false;
			}
			else if (tmpFnt != base->text.fnt)
			{
				base->text.fnt = tmpFnt;
				base->text.tracking = tmpFnt->GetTracking();
				if (base->text.shadow)
				{
					base->text.sfnt = tmpFnt;
				}
				// We get the new text box's height to adjust the GUIArt's height
				base->h = base->text.fnt->printfb
				(
					true,
					0, 0,
					base->w, base->h,
					base->text.align,
					base->text.str.c_str()
				)*base->text.fnt->GetHeight();

				base->parent->_rebuildCache();
				base->ready = true;
			}
		}
	}

	return 0;
}

int l_FontString::SetTextColor(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 3)
	{
		mlua_printError("Too few argument in \"FontString:SetTextColor\" (3 or 4 expected : red, green, blue (+alpha))");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of FontString:SetTextColor must be a number (red)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of FontString:SetTextColor must be a number (green)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of FontString:SetTextColor must be a number (blue)");
		error++;
	}
	if ( (lua_gettop(luaVM) >= 4) && (!lua_isnumber(luaVM, 4)) )
	{
		mlua_printError("Argument 4 of FontString:SetTextColor must be a number (alpha)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			float a, r, g, b;
			r = lua_tonumber(luaVM, 1);
			g = lua_tonumber(luaVM, 2);
			b = lua_tonumber(luaVM, 3);
			if (lua_gettop(luaVM) >= 4)
				a = lua_tonumber(luaVM, 4);
			else
				a = GETA(base->text.color)/255.0f;

			DWORD color = ARGB(a*255, r*255, g*255, b*255);

			if (base->text.color != color)
			{
				base->text.color = color;
				if (base->ready)
					base->parent->_rebuildCache();
			}
		}
	}

	return 0;
}

int l_FontString::GetStringWidth(lua_State* luaVM)
{
	if (base != NULL)
	{
		if (base->ready)
		{
			lua_pushnumber(luaVM, base->text.fnt->GetStringWidth(base->text.str.c_str()));
		}
		else
			lua_pushnil(luaVM);
	}

	return 1;
}

int l_FontString::SetText(lua_State* luaVM)
{
	if (!lua_isstring(luaVM, 1) && !lua_isnil(luaVM, 1))
	{
		mlua_printError("Argument of FontString:SetText must be a string or nil (text)");
		return 0;
	}

	if (base != NULL)
	{
		string old = base->text.str;
		if (lua_isnil(luaVM, 1))
			base->text.str = "";
		else
			base->text.str = lua_tostring(luaVM, 1);

		if (old != base->text.str)
		{
			// We get the new text box's height to adjust the GUIArt's height
			if (base->ready)
			{
				base->h = base->text.fnt->printfb
				(
					true,
					0, 0,
					base->w, base->h,
					base->text.align,
					base->text.str.c_str()
				)*base->text.fnt->GetHeight();

				base->parent->_rebuildCache();
			}
		}
	}

	return 0;
}

/****************/
/* Methods list */
/****************/

/* [#] Here we register every member function of each class. As Lunar doesn't
/* know about inheritance, you're obliged to register every member function of a
/* C++ class, including the ones inherited. Else you won't be able to call them
/* in LUA.
*/

const char l_UIObject::className[] = "UIObject";
Lunar<l_UIObject>::RegType l_UIObject::methods[] = {
	{"dt", &l_UIObject::getDataTable},
  	method(l_UIObject, GetAlpha),
	method(l_UIObject, GetObjectType),
	method(l_UIObject, IsObjectType),
	method(l_UIObject, SetAlpha),
	{0,0}
};

const char l_Region::className[] = "Region";
Lunar<l_Region>::RegType l_Region::methods[] = {
	{"dt", &l_Region::getDataTable},
	method(l_Region, GetAlpha),
	method(l_Region, GetName),
	method(l_Region, GetObjectType),
	method(l_Region, IsObjectType),
	method(l_Region, SetAlpha),

	method(l_Region, GetBottom),
	method(l_Region, GetCenter),
	method(l_Region, GetHeight),
	method(l_Region, GetLeft),
	method(l_Region, GetNumPoint),
	method(l_Region, GetParent),
	method(l_Region, GetPoint),
	method(l_Region, GetRight),
	method(l_Region, GetTop),
	method(l_Region, GetWidth),
	method(l_Region, Hide),
	method(l_Region, IsShown),
	method(l_Region, IsVisible),
	method(l_Region, SetAllPoints),
	method(l_Region, SetHeight),
	method(l_Region, SetParent),
	method(l_Region, SetPoint),
	method(l_Region, SetWidth),
	method(l_Region, Show),
	{0,0}
};

const char l_Frame::className[] = "Frame";
Lunar<l_Frame>::RegType l_Frame::methods[] = {
	{"dt", &l_Frame::getDataTable},
	method(l_Frame, GetAlpha),
	method(l_Frame, GetName),
	method(l_Frame, GetObjectType),
	method(l_Frame, IsObjectType),
	method(l_Frame, SetAlpha),

	method(l_Frame, GetBottom),
	method(l_Frame, GetCenter),
	method(l_Frame, GetHeight),
	method(l_Frame, GetLeft),
	method(l_Frame, GetNumPoint),
	method(l_Frame, GetParent),
	method(l_Frame, GetPoint),
	method(l_Frame, GetRight),
	method(l_Frame, GetTop),
	method(l_Frame, GetWidth),
	method(l_Frame, Hide),
	method(l_Frame, IsShown),
	method(l_Frame, IsVisible),
	method(l_Frame, SetAllPoints),
	method(l_Frame, SetHeight),
	method(l_Frame, SetParent),
	method(l_Frame, SetPoint),
	method(l_Frame, SetWidth),
	method(l_Frame, Show),

	method(l_Frame, CreateFontString),
	method(l_Frame, CreateTexture),
	method(l_Frame, CreateTitleRegion),
	method(l_Frame, DisableDrawLayer),
	method(l_Frame, EnableDrawLayer),
	method(l_Frame, EnableKeyboard),
	method(l_Frame, EnableMouse),
	method(l_Frame, EnableMouseWheel),
	method(l_Frame, GetBackdrop),
	method(l_Frame, GetBackdropBorderColor),
	method(l_Frame, GetBackdropColor),
	method(l_Frame, GetChildren),
	method(l_Frame, GetEffectiveAlpha),
	method(l_Frame, GetEffectiveScale),
	method(l_Frame, GetFrameLevel),
	method(l_Frame, GetFrameStrata),
	method(l_Frame, GetFrameType),
	method(l_Frame, GetHitRectInsets),
	method(l_Frame, GetID),
	method(l_Frame, GetMaxResize),
	method(l_Frame, GetMinResize),
	method(l_Frame, GetNumChildren),
	method(l_Frame, GetNumRegions),
	method(l_Frame, GetScale),
	method(l_Frame, GetScript),
	method(l_Frame, GetTitleRegion),
	method(l_Frame, HasScript),
	method(l_Frame, HookScript),
	method(l_Frame, IsClampedtoScreen),
	method(l_Frame, IsFrameType),
	method(l_Frame, IsKeyboardEnabled),
	method(l_Frame, IsMouseEnabled),
	method(l_Frame, IsMouseWheelEnabled),
	method(l_Frame, IsMovable),
	method(l_Frame, IsResizable),
	method(l_Frame, IsTopLevel),
	method(l_Frame, IsUserPlaced),
	method(l_Frame, Lower),
	method(l_Frame, Raise),
	method(l_Frame, RegisterAllEvents),
	method(l_Frame, RegisterEvent),
	method(l_Frame, RegisterForDrag),
	method(l_Frame, SetBackdrop),
	method(l_Frame, SetBackdropBorderColor),
	method(l_Frame, SetBackdropColor),
	method(l_Frame, SetClampedToScreen),
	method(l_Frame, SetFrameLevel),
	method(l_Frame, SetFrameStrata),
	method(l_Frame, SetHitRectInsets),
	method(l_Frame, SetID),
	method(l_Frame, SetMaxResize),
	method(l_Frame, SetMinResize),
	method(l_Frame, SetMovable),
	method(l_Frame, SetResizable),
	method(l_Frame, SetScale),
	method(l_Frame, SetScript),
	method(l_Frame, SetTopLevel),
	method(l_Frame, SetUserPlaced),
	method(l_Frame, StartMoving),
	method(l_Frame, StartSizing),
	method(l_Frame, StopMovingOrSizing),
	method(l_Frame, UnregisterAllEvents),
	method(l_Frame, UnregisterEvent),

	method(l_Frame, _init),
	{0,0}
};

const char l_StatusBar::className[] = "StatusBar";
Lunar<l_StatusBar>::RegType l_StatusBar::methods[] = {
	{"dt", &l_StatusBar::getDataTable},
	method(l_StatusBar, GetAlpha),
	method(l_StatusBar, GetName),
	method(l_StatusBar, GetObjectType),
	method(l_StatusBar, IsObjectType),
	method(l_StatusBar, SetAlpha),

	method(l_StatusBar, GetBottom),
	method(l_StatusBar, GetCenter),
	method(l_StatusBar, GetHeight),
	method(l_StatusBar, GetLeft),
	method(l_StatusBar, GetNumPoint),
	method(l_StatusBar, GetParent),
	method(l_StatusBar, GetPoint),
	method(l_StatusBar, GetRight),
	method(l_StatusBar, GetTop),
	method(l_StatusBar, GetWidth),
	method(l_StatusBar, Hide),
	method(l_StatusBar, IsShown),
	method(l_StatusBar, IsVisible),
	method(l_StatusBar, SetAllPoints),
	method(l_StatusBar, SetHeight),
	method(l_StatusBar, SetParent),
	method(l_StatusBar, SetPoint),
	method(l_StatusBar, SetWidth),
	method(l_StatusBar, Show),

	method(l_StatusBar, CreateFontString),
	method(l_StatusBar, CreateTexture),
	method(l_StatusBar, CreateTitleRegion),
	method(l_StatusBar, DisableDrawLayer),
	method(l_StatusBar, EnableDrawLayer),
	method(l_StatusBar, EnableKeyboard),
	method(l_StatusBar, EnableMouse),
	method(l_StatusBar, EnableMouseWheel),
	method(l_StatusBar, GetBackdrop),
	method(l_StatusBar, GetBackdropBorderColor),
	method(l_StatusBar, GetBackdropColor),
	method(l_StatusBar, GetChildren),
	method(l_StatusBar, GetEffectiveAlpha),
	method(l_StatusBar, GetEffectiveScale),
	method(l_StatusBar, GetFrameLevel),
	method(l_StatusBar, GetFrameStrata),
	method(l_StatusBar, GetFrameType),
	method(l_StatusBar, GetHitRectInsets),
	method(l_StatusBar, GetID),
	method(l_StatusBar, GetMaxResize),
	method(l_StatusBar, GetMinResize),
	method(l_StatusBar, GetNumChildren),
	method(l_StatusBar, GetNumRegions),
	method(l_StatusBar, GetScale),
	method(l_StatusBar, GetScript),
	method(l_StatusBar, GetTitleRegion),
	method(l_StatusBar, HasScript),
	method(l_StatusBar, HookScript),
	method(l_StatusBar, IsClampedtoScreen),
	method(l_StatusBar, IsFrameType),
	method(l_StatusBar, IsKeyboardEnabled),
	method(l_StatusBar, IsMouseEnabled),
	method(l_StatusBar, IsMouseWheelEnabled),
	method(l_StatusBar, IsMovable),
	method(l_StatusBar, IsResizable),
	method(l_StatusBar, IsTopLevel),
	method(l_StatusBar, IsUserPlaced),
	method(l_StatusBar, Lower),
	method(l_StatusBar, Raise),
	method(l_StatusBar, RegisterAllEvents),
	method(l_StatusBar, RegisterEvent),
	method(l_StatusBar, RegisterForDrag),
	method(l_StatusBar, SetBackdrop),
	method(l_StatusBar, SetBackdropBorderColor),
	method(l_StatusBar, SetBackdropColor),
	method(l_StatusBar, SetClampedToScreen),
	method(l_StatusBar, SetFrameLevel),
	method(l_StatusBar, SetFrameStrata),
	method(l_StatusBar, SetHitRectInsets),
	method(l_StatusBar, SetID),
	method(l_StatusBar, SetMaxResize),
	method(l_StatusBar, SetMinResize),
	method(l_StatusBar, SetMovable),
	method(l_StatusBar, SetResizable),
	method(l_StatusBar, SetScale),
	method(l_StatusBar, SetScript),
	method(l_StatusBar, SetTopLevel),
	method(l_StatusBar, SetUserPlaced),
	method(l_StatusBar, StartMoving),
	method(l_StatusBar, StartSizing),
	method(l_StatusBar, StopMovingOrSizing),
	method(l_StatusBar, UnregisterAllEvents),
	method(l_StatusBar, UnregisterEvent),
	method(l_StatusBar, _init),

	method(l_StatusBar, GetMinMaxValues),
	method(l_StatusBar, GetOrientation),
	method(l_StatusBar, GetStatusBarColor),
	method(l_StatusBar, GetStatusBarTexture),
	method(l_StatusBar, GetValue),
	method(l_StatusBar, SetMinMaxValues),
	method(l_StatusBar, SetOrientation),
	method(l_StatusBar, SetStatusBarColor),
	method(l_StatusBar, SetStatusBarTexture),
	method(l_StatusBar, SetValue),
	{0,0}
};

const char l_LayeredRegion::className[] = "LayeredRegion";
Lunar<l_LayeredRegion>::RegType l_LayeredRegion::methods[] = {
	{"dt", &l_LayeredRegion::getDataTable},
	method(l_LayeredRegion, GetAlpha),
	method(l_LayeredRegion, GetName),
	method(l_LayeredRegion, GetObjectType),
	method(l_LayeredRegion, IsObjectType),
	method(l_LayeredRegion, SetAlpha),

	method(l_LayeredRegion, GetBottom),
	method(l_LayeredRegion, GetCenter),
	method(l_LayeredRegion, GetHeight),
	method(l_LayeredRegion, GetLeft),
	method(l_LayeredRegion, GetNumPoint),
	method(l_LayeredRegion, GetParent),
	method(l_LayeredRegion, GetPoint),
	method(l_LayeredRegion, GetRight),
	method(l_LayeredRegion, GetTop),
	method(l_LayeredRegion, GetWidth),
	method(l_LayeredRegion, Hide),
	method(l_LayeredRegion, IsShown),
	method(l_LayeredRegion, IsVisible),
	method(l_LayeredRegion, SetAllPoints),
	method(l_LayeredRegion, SetHeight),
	method(l_LayeredRegion, SetParent),
	method(l_LayeredRegion, SetPoint),
	method(l_LayeredRegion, SetWidth),
	method(l_LayeredRegion, Show),

	method(l_LayeredRegion, GetDrawLayer),
	method(l_LayeredRegion, SetDrawLayer),

	method(l_LayeredRegion, _init),
	{0,0}
};

const char l_Texture::className[] = "Texture";
Lunar<l_Texture>::RegType l_Texture::methods[] = {
	{"dt", &l_Texture::getDataTable},
	method(l_Texture, GetAlpha),
	method(l_Texture, GetName),
	method(l_Texture, GetObjectType),
	method(l_Texture, IsObjectType),
	method(l_Texture, SetAlpha),

	method(l_Texture, GetBottom),
	method(l_Texture, GetCenter),
	method(l_Texture, GetHeight),
	method(l_Texture, GetLeft),
	method(l_Texture, GetNumPoint),
	method(l_Texture, GetParent),
	method(l_Texture, GetPoint),
	method(l_Texture, GetRight),
	method(l_Texture, GetTop),
	method(l_Texture, GetWidth),
	method(l_Texture, Hide),
	method(l_Texture, IsShown),
	method(l_Texture, IsVisible),
	method(l_Texture, SetAllPoints),
	method(l_Texture, SetHeight),
	method(l_Texture, SetParent),
	method(l_Texture, SetPoint),
	method(l_Texture, SetWidth),
	method(l_Texture, Show),

	method(l_Texture, GetDrawLayer),
	method(l_Texture, SetDrawLayer),

	method(l_Texture, GetBlendMode),
	method(l_Texture, GetTexCoord),
	method(l_Texture, GetTexCoordModifiesRect),
	method(l_Texture, GetTexture),
	method(l_Texture, GetVertexColor),
	method(l_Texture, GetDesaturated),
	method(l_Texture, SetBlendMode),
	method(l_Texture, SetDesaturated),
	method(l_Texture, SetGradient),
	method(l_Texture, SetGradientAlpha),
	method(l_Texture, SetTexCoord),
	method(l_Texture, SetTexCoordModifiesRect),
	method(l_Texture, SetTexture),
	method(l_Texture, SetVertexColor),

	method(l_Texture, _init),
	{0,0}
};

const char l_FontString::className[] = "FontString";
Lunar<l_FontString>::RegType l_FontString::methods[] = {
	{"dt", &l_FontString::getDataTable},
	method(l_FontString, GetAlpha),
	method(l_FontString, GetName),
	method(l_FontString, GetObjectType),
	method(l_FontString, IsObjectType),
	method(l_FontString, SetAlpha),

	method(l_FontString, GetBottom),
	method(l_FontString, GetCenter),
	method(l_FontString, GetHeight),
	method(l_FontString, GetLeft),
	method(l_FontString, GetNumPoint),
	method(l_FontString, GetParent),
	method(l_FontString, GetPoint),
	method(l_FontString, GetRight),
	method(l_FontString, GetTop),
	method(l_FontString, GetWidth),
	method(l_FontString, Hide),
	method(l_FontString, IsShown),
	method(l_FontString, IsVisible),
	method(l_FontString, SetAllPoints),
	method(l_FontString, SetHeight),
	method(l_FontString, SetParent),
	method(l_FontString, SetPoint),
	method(l_FontString, SetWidth),
	method(l_FontString, Show),

	method(l_FontString, GetDrawLayer),
	method(l_FontString, SetDrawLayer),

	method(l_FontString, GetFont),
	method(l_FontString, GetFontObject),
	method(l_FontString, GetJustifyH),
	method(l_FontString, GetJustifyV),
	method(l_FontString, GetShadowColor),
	method(l_FontString, GetShadowOffset),
	method(l_FontString, GetSpacing),
	method(l_FontString, GetTextColor),
	method(l_FontString, SetFont),
	method(l_FontString, SetFontObject),
	method(l_FontString, SetJustifyH),
	method(l_FontString, SetJustifyV),
	method(l_FontString, SetShadowColor),
	method(l_FontString, SetShadowOffset),
	method(l_FontString, SetSpacing),
	method(l_FontString, SetTextColor),

	method(l_FontString, CanNonSpaceWrap),
	method(l_FontString, GetStringWidth),
	method(l_FontString, GetText),
	method(l_FontString, SetAlphaGradient),
	method(l_FontString, SetNonSpaceWrap),
	method(l_FontString, SetText),
	method(l_FontString, SetTextHeight),

	method(l_FontString, _init),
	{0,0}
};

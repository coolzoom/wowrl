/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          Scene manager source          */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the SceneManager class.            */
/*       A SceneManager is obviously a    */
/*  class that manages the scene and its  */
/*  components (units, background ...)    */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge/hgestrings.h"

#include "wowrl_global.h"
#include "wowrl_zone.h"
#include "wowrl_unit.h"
#include "wowrl_doodad.h"
#include "wowrl_projectile.h"
#include "wowrl_tooltip.h"
#include "wowrl_statusbar.h"
#include "wowrl_collision.h"
#include "wowrl_pathfinding.h"
#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_xml.h"

#include "wowrl_scenemanager.h"

#include <vector>
#include <fstream>
#include <ios>

extern HGE *hge;

using namespace std;

SceneManager::SceneManager()
{
}

void SceneManager::initValues()
{
	// Default values
	defaultFont = NULL;
	leadingUnit = NULL;
	mInventory = NULL;
	castedButton = NULL;
	casterUnit = NULL;
	cursor = NULL;
	loadingBarX = sWidth/2.0f;
	loadingBarY = sHeight-160;
	unitFrameX = 0;
	unitFrameY = 0;
	targetFrameX = 227;
	targetFrameY = 0;
	toolTipX = sWidth-4;
	toolTipY = sHeight-126;
	toolTipW = 300.0f;
	aButtonX = 13.0f;
	aButtonY = sHeight-9.0f;
	aggroFrameX = 20.0f;
	aggroFrameY = sHeight-250.0f;
	invX = sWidth/2.0f;
	invY = sHeight-200;
	functionNbr = 1;


	targetLink1.tex = 0;
	targetLink1.blend = 0;
	targetLink2.tex = 0;
	targetLink2.blend = 0;
	targetLinkTimer = 0.0f;

	lastDragged = false;
	squareSelection = false;
	castingSpell = false;
	mouseOverPlayField = true;

	mForceUpdate = true;
	gamePaused = false;

	debugParser = false;
	debugRenderList = false;

	rebuildGUIList = true;
}

SceneManager* SceneManager::mSceneMgr = NULL;

SceneManager* SceneManager::getSingleton()
{
	if (mSceneMgr == NULL)
		mSceneMgr = new SceneManager;
	return mSceneMgr;
}

void SceneManager::parseUI( string file )
{
	// Default UI
	string status_bar_file = "UI/ui_default_status_bar.png";
	string circle_file = "UI/ui_default_circle.png";
	string order_file = "UI/ui_default_order.png";
	string select_square_file = "UI/ui_default_select_square.png";
	string shadow_file = "UI/ui_default_shadow.png";
	string stop_icon_file = "Icons/stop.png";

	//  -- loading textures
	this->loadTexture(status_bar_file);
	this->loadTexture(circle_file, true);
	this->loadTexture(order_file, true);
	this->loadTexture(select_square_file);
	this->loadTexture(shadow_file, true);
	this->loadTexture(stop_icon_file);
	//  -- statusbar
	this->statusB_bg_left = createSprite(this->textureList[status_bar_file],0,0,3,8);
	this->statusB_bg_middle = createSprite(this->textureList[status_bar_file],3,0,29,8);
	this->statusB_bg_right = createSprite(this->textureList[status_bar_file],0,0,3,8);
	this->statusB_bg_right->SetFlip(true,false);
	this->statusB_dead_bg_left = createSprite(this->textureList[status_bar_file],0,8,3,8);
	this->statusB_dead_bg_middle = createSprite(this->textureList[status_bar_file],3,8,29,8);
	this->statusB_dead_bg_right = createSprite(this->textureList[status_bar_file],0,8,3,8);
	this->statusB_dead_bg_right->SetFlip(true,false);
	this->statusB_gauge = createSprite(this->textureList[status_bar_file],3,18,29,2);
	// -- stop button
	this->stopButton = this->createSprite(this->textureList[stop_icon_file],0,0,64,64);
	// -- player shadow
	this->p_shadow = this->createSprite(this->textureList[shadow_file],0,0,128,128);
	this->p_shadow->SetHotSpot(64,64);
	// -- selection circle
	this->selectionCircle = this->createSprite(this->textureList[circle_file],0,0,32,32);
	this->selectionCircle->SetColor(ARGB(255, 20, 220, 64));
	this->selectionCircle->SetHotSpot(16,16);
	this->deathCircle = this->createSprite(this->textureList[circle_file],0,0,32,32);
	this->deathCircle->SetColor(ARGB(120, 100, 100, 100));
	this->deathCircle->SetHotSpot(16,16);
	this->hostileCircle = this->createSprite(this->textureList[circle_file],0,0,32,32);
	this->hostileCircle->SetColor(ARGB(180, 220, 64, 20));
	this->hostileCircle->SetHotSpot(16,16);
	// -- order circle
	this->orderCircle = this->createSprite(this->textureList[order_file],0,0,32,32);
	this->orderCircle->SetColor(ARGB(255, 20, 220, 64));
	this->orderCircle->SetHotSpot(16,16);
	// -- selection square
	this->selectionSquare = this->createSprite(this->textureList[select_square_file],2,2,28,28);
	this->selectionSquare->SetHotSpot(0,0);
	this->selectionSquareLeftBorder = this->createSprite(this->textureList[select_square_file],0,0,1,28);
	this->selectionSquareLeftBorder->SetHotSpot(0,0);
	this->selectionSquareRightBorder = this->createSprite(this->textureList[select_square_file],0,0,1,28);
	this->selectionSquareRightBorder->SetHotSpot(0,0);
	this->selectionSquareTopBorder = this->createSprite(this->textureList[select_square_file],0,0,28,1);
	this->selectionSquareTopBorder->SetHotSpot(0,0);
	this->selectionSquareBottomBorder = this->createSprite(this->textureList[select_square_file],0,0,28,1);
	this->selectionSquareBottomBorder->SetHotSpot(0,0);
}

bool SceneManager::parseZoneDyn( int state1, int state2, bool* finished, float filling )
{
	static int part_nbr = 0;
	static int doodad_nbr = 0;

	if (state1 == 1)
	{
		hge->System_Log("Parsing %s...",  actualZone.name.c_str());
		int error = luaL_dofile(luaVM,  actualZone.name.c_str());
		if (error) l_logPrint(luaVM);
		lua_getglobal(luaVM, "Zone");
		actualZone.w = mlua_getFieldInt("width");
		actualZone.h = mlua_getFieldInt("height");
		actualZone.distortion_scale_max = actualZone.distortion_scale_min = mlua_getFieldFloat("scale", false, 1.0f);
		actualZone.distortion_vscale_max = actualZone.distortion_vscale_min = mlua_getFieldFloat("vscale", false, 1.0f);
		actualZone.distortion_angle_max = actualZone.distortion_angle_min = 0.0f;
		gx = -mlua_getFieldFloat("start_x", false, actualZone.w/2.0f);
		gy = -mlua_getFieldFloat("start_y", false, actualZone.h/2.0f);
		actualZone.partSize = 1024;
		lua_getfield(luaVM, -1, "Background");

		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			part_nbr++;
		}

		*finished = false;
		mSceneMgr->mLoadingBar.filling += 0.01f;
		return true;
	}
	else if (state1 == 2)
	{
		if (state2 > part_nbr)
		{
			lua_pop(luaVM, 1);
			*finished = false;
			return true;
		}

		static float x = 0.0f;
		static float y = 0.0f;
		int i = state2;

		BGPart tmpBGPart;
		tmpBGPart.i = i;
		tmpBGPart.x = x;
		tmpBGPart.y = y;

		lua_rawgeti(luaVM, -1, i);

		string bg = mlua_getFieldString("background");
		string col = mlua_getFieldString("collisions", false, "");
		string dist = mlua_getFieldString("distortion", false, "");

		// Loading textures
		HTEXTURE bg_tex = this->loadTexture(bg);
		tmpBGPart.bg = createSprite(bg_tex, 0, 0, 1024.0f, 1024.0f);

		if ( (col == "0") || (col == "none") || (col == "") )
		{
			tmpBGPart.colData = false;
			tmpBGPart.globalCol = ARGB(255, 0, 0, 0);
		}
		else if (col == "1")
		{
			tmpBGPart.colData = false;
			tmpBGPart.globalCol = ARGB(255, 255, 255, 255);
		}
		else
		{
			tmpBGPart.colData = true;
			HTEXTURE col_tex = this->loadTexture(col);
			tmpBGPart.col = hge->Texture_Lock(col_tex);
			hge->Texture_Unlock(col_tex);
		}

		if ( (dist == "0") || (dist == "none") || (dist == "") )
		{
			tmpBGPart.distData = false;
			tmpBGPart.globalDist = ARGB(255, 255, 255, 255);
		}
		else
		{
			tmpBGPart.distData = true;
			HTEXTURE dist_tex = this->loadTexture(dist);
			tmpBGPart.dist = hge->Texture_Lock(dist_tex);
			hge->Texture_Unlock(dist_tex);
		}

		float index = (y/1024.0f) * (actualZone.w/1024.0f) + (x/1024.0f);

		this->actualZone.parts[index] = tmpBGPart;

		i++;
		x += 1024.0f;
		if (x >= actualZone.w)
		{
			x = 0.0f;
			y += 1024.0f;
		}

		mSceneMgr->mLoadingBar.filling += ((filling-0.02f)/2)/part_nbr;

		lua_pop(luaVM, 1);
		*finished = false;
		return false;
	}
	else if (state1 == 3)
	{
		this->parseUI(mlua_getFieldString("UI", false, ""));

		//lua_getglobal(luaVM, "Zone");
		lua_getfield(luaVM, -1, "Doodads");

		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			doodad_nbr++;
		}

		lua_pushnil(luaVM);

		*finished = false;
		mSceneMgr->mLoadingBar.filling += 0.01f;
		return true;
	}
	else if (state1 == 4)
	{
		if (doodad_nbr == 0)
		{
			mSceneMgr->mLoadingBar.filling += ((filling-0.02f)/2);
			*finished = false;
			return true;
		}

		if (!lua_next(luaVM, -2))
		{
			lua_pop(luaVM, 1);

			*finished = false;
			return true;
		}

		Doodad d;
		d.name = mlua_getFieldString("name");
		if (this->debugParser) {hge->System_Log(" Loading doodad \"%s\"...", d.name.c_str());}
		d.sprite = mlua_spriteList[mlua_getFieldString("sprite")];
		d.setX(mlua_getFieldFloat("x", false, 0.0f));
		d.setY(mlua_getFieldFloat("y", false, 0.0f));
		d.inTop = mlua_getFieldBool("always_in_top", false, false);
		if (!d.inTop)
			d.orientation = mlua_getFieldFloat("orientation");

		this->actualZone.doodadList[d.name] = d;
		this->actualZone.doodadList[d.name].setBox();

		lua_pop(luaVM, 1);

		mSceneMgr->mLoadingBar.filling += ((filling-0.02f)/2)/doodad_nbr;

		*finished = false;
		return false;
	}
	else if (state1 == 5)
	{
		lua_getfield(luaVM, -1, "Waypoints");
		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			Waypoint w;
			w.name = mlua_getFieldString("name");
			w.x = mlua_getFieldFloat("x");
			w.y = mlua_getFieldFloat("y");
			w.size = mlua_getFieldFloat("size");
			w.useless = false;
			w.opened = false;
			w.closed = false;
			w.parent = NULL;

			actualZone.wPntList[w.name] = w;
		}
		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			string wpName = mlua_getFieldString("name");
			Waypoint* w = &actualZone.wPntList[wpName];

			lua_getfield(luaVM, -1, "childs");
			for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
			{
				string childName = mlua_getFieldString("name");
				float dist = mlua_getFieldFloat("distance");

				w->childs.insert(make_pair(dist, &actualZone.wPntList[childName]));
			}
			lua_pop(luaVM, 1);
		}
		lua_pop(luaVM, 1);

		*finished = false;
		return true;
	}
	else
	{
		lua_pop(luaVM, 1);
		hge->System_Log("Parsing %s : done.", actualZone.name.c_str());
		*finished = true;
		return true;
	}
}

void SceneManager::parseCursors()
{
	hge->System_Log("Parsing Tables/cursor_table.lua...");

	int error = luaL_dofile(luaVM, "Tables/cursor_table.lua");
	if (error) l_logPrint(luaVM);

	lua_getglobal(luaVM, "Cursors");
	for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
	{
		if (!lua_isnil(luaVM, -1))
		{
			Cursor tmpCur;
			tmpCur.name = mlua_getFieldString("name");
			tmpCur.rot = 0.0f;
			tmpCur.animated = mlua_getFieldBool("animated", false, false);
			if (tmpCur.animated)
				tmpCur.anim = mlua_animList[mlua_getFieldString("anim")];
			else
				tmpCur.sprite = mlua_spriteList[mlua_getFieldString("sprite")];

			this->cursorList[tmpCur.name] = tmpCur;
		}
	}

	lua_pop(luaVM, 1);

	hge->System_Log("Parsing Tables/cursor_table.lua : done.");
}

Spell* SceneManager::parseSpell( string spell_name, bool regLUA = false )
{
	Spell s = this->spellList[spell_name];

	if (regLUA || !s.loaded)
	{
		if (this->debugParser && !regLUA) hge->System_Log(" Parsing %s...", spell_name.c_str());

		lua_getglobal(luaVM, "Spells");
		lua_getfield(luaVM, -1, spell_name.c_str());

		s.name = spell_name;
		mlua_setFieldString("name", spell_name.c_str());
		s.display_name = mlua_getFieldString("display_name");
		s.description = mlua_getFieldString("description");
		s.rank = mlua_getFieldInt("rank", false, -1, true);
		s.cast_time = mlua_getFieldFloat("cast_time", false, -1.0f, true);
		s.crits = mlua_getFieldFloat("crits", false, 0.0f, true);
		s.cost = mlua_getFieldInt("cost", false, 0, true);
		s.costp = mlua_getFieldFloat("cost_percent", false, 0.0f, true);
		s.cost_type = mlua_getFieldString("cost_type", false, "", true);
		if ( s.cost_type != "mana" && s.cost_type != "rage" && s.cost_type != "energy" && (s.cost_type == "" && (s.cost != 0.0f || s.costp != 0.0f)) )
			hge->System_Log("# Error # : wrong cost_type value in %s's (possible values : mana, rage, energy or blank if cost is nul).", spell_name.c_str());
		s.range = mlua_getFieldFloat("range", false, 5.0f, true);
		s.self_only = mlua_getFieldBool("self_only", false, false, true);
		s.in_combat = mlua_getFieldBool("usable_in_combat", false, true, true);
		s.puts_in_combat = mlua_getFieldBool("puts_in_combat", false, true, true);
		s.loop = mlua_getFieldBool("loop", false, true, true);
		s.school = mlua_getFieldInt("school", false, 0, true);

		s.cast_effect = mlua_getFieldString("cast_effect", false, "", true);
		if (s.cast_effect == "")
			s.cast_fx = false;
		else
			s.cast_fx = true;
		s.attack_effect = mlua_getFieldString("attack_effect", false, "", true);
		if (s.attack_effect == "")
			s.attack_fx = false;
		else
			s.attack_fx = true;
		string icon_file = mlua_getFieldString("icon", false, "Icons/INV_Misc_QuestionMark.png", true);
		s.iconPath = icon_file;
		s.icon = createSprite
		(
			loadTexture(icon_file, true),
			0, 0, 64, 64, true
		);

		s.proj = mlua_getFieldBool("projectile", false, false, true);
		if (s.proj)
			s.proj_speed = mlua_getFieldFloat("projectile_speed", false, 600.0f, true);

		s.channeled = mlua_getFieldBool("channeled", false, false, true);

		string target = mlua_getFieldString("target", false, "hostiles", true);

		if (target == "hostiles")
			s.target = SPELL_TARGET_HOSTILES;
		else if (target == "all")
			s.target = SPELL_TARGET_ALL;
		else if (target == "friends")
			s.target = SPELL_TARGET_FRIENDS;
		else if (target == "deads")
			s.target = SPELL_TARGET_DEADS;
		else if (target == "dead_friends")
			s.target = SPELL_TARGET_DEAD_FRIENDS;
		else if (target == "dead_hostiles")
			s.target = SPELL_TARGET_DEAD_HOSTILES;
		else
		{
			s.target = SPELL_TARGET_HOSTILES;
			hge->System_Log("# Error # : unknown target value \"%s\" in %s.", target.c_str(), spell_name.c_str());
		}

		s.dmg_min = mlua_getFieldInt("damage_min", false, 0, true);
		if (s.dmg_min<0) {hge->System_Log("# Warning # : %s's damage_min parameter can't be negative.", spell_name.c_str()); s.dmg_min = 0;}
		s.dmg_max = mlua_getFieldInt("damage_max", false, s.dmg_min, true);
		if (s.dmg_max<0) {hge->System_Log("# Warning # : %s's damage_max parameter can't be negative.", spell_name.c_str()); s.dmg_max = 0;}
		if (s.dmg_max<s.dmg_min) {hge->System_Log("# Warning # : %s's damage_max parameter can't be smaller than damage_min.", spell_name.c_str()); s.dmg_max = s.dmg_min;}

		s.heal_min = mlua_getFieldInt("heal_min", false, 0, true);
		if (s.heal_min<0) {hge->System_Log("# Warning # : %s's heal_min parameter can't be negative.", spell_name.c_str()); s.heal_min = 0;}
		s.heal_max = mlua_getFieldInt("heal_max", false, s.heal_min, true);
		if (s.heal_max<0) {hge->System_Log("# Warning # : %s's heal_max parameter can't be negative.", spell_name.c_str()); s.heal_max = 0;}
		if (s.heal_max<s.heal_min) {hge->System_Log("# Warning # : %s's heal_max parameter can't be smaller than damage_min.", spell_name.c_str()); s.heal_max = s.heal_min;}

		s.health_recovered = mlua_getFieldInt("health_recovered", false, 1, true);
		if (s.health_recovered<1) {hge->System_Log("# Warning # : %s's health_recovered parameter can't be smaller than 1.", spell_name.c_str()); s.health_recovered = 1;}
		s.mana_recovered = mlua_getFieldInt("mana_recovered", false, 0, true);
		if (s.mana_recovered<0) {hge->System_Log("# Warning # : %s's mana_recovered parameter can't be negative.", spell_name.c_str()); s.mana_recovered = 0;}

		string buff = mlua_getFieldString("buff", false, "", true);
		if (buff != "")
			s.buff = parseBuff(buff);
		else
			s.buff = NULL;

		lua_getfield(luaVM, -1, "scripts");

		s.OnCastBegin = mlua_getFieldString("OnCastBegin", false, "", true);
		s.OnCasted = mlua_getFieldString("OnCasted", false, "", true);
		s.OnImpact = mlua_getFieldString("OnImpact", false, "", true);
		s.OnUpdate = mlua_getFieldString("OnUpdate", false, "", true);

		lua_pop(luaVM, 3);

		this->spellList[spell_name] = s;

		s.loaded = true;
	}

	// Register the spell in LUA

		/*lua_getglobal(luaVM, "Spells");
		lua_getfield(luaVM, -1, spell_name.c_str());
		mlua_setFieldString("name", spell_name.c_str());
		lua_pop(luaVM, 2);*/
		/*string exec = "";
		exec += s.name + " = {};\n";
		exec += s.name + ".name = \"" + s.name + "\";\n";
		exec += s.name + ".displayName = \"" + s.display_name + "\";\n";
		exec += s.name + ".description = \"" + s.description + "\";\n";
		exec += s.name + ".rank = " + toString(s.rank) + ";\n";
		exec += s.name + ".castTime = " + toString(s.cast_time) + ";\n";
		exec += s.name + ".cost = " + toString(s.cost) + ";\n";
		exec += s.name + ".costPercent = " + toString(s.costp) + ";\n";
		exec += s.name + ".costType = \"" + s.cost_type + "\";\n";
		exec += s.name + ".range = " + toString(s.range) + ";\n";
		exec += s.name + ".selfOnly = " + BtoString(s.self_only) + ";\n";
		exec += s.name + ".crits = " + toString(s.crits) + ";\n";
		exec += s.name + ".usableInCombat = " + BtoString(s.in_combat) + ";\n";
		exec += s.name + ".putsInCombat = " + BtoString(s.puts_in_combat) + ";\n";
		//exec += s.name + ".school = " + toString(s.school) + ";\n";
		if (s.school == SPELL_SCHOOL_HOLY)
			exec += s.name + ".school = \"" + strTable->GetString("school_holy") + "\";\n";
		else if (s.school == SPELL_SCHOOL_FROST)
			exec += s.name + ".school = \"" + strTable->GetString("school_frost") + "\";\n";
		else if (s.school == SPELL_SCHOOL_FIRE)
			exec += s.name + ".school = \"" + strTable->GetString("school_fire") + "\";\n";
		else if (s.school == SPELL_SCHOOL_NATURE)
			exec += s.name + ".school = \"" + strTable->GetString("school_nature") + "\";\n";
		else if (s.school == SPELL_SCHOOL_SHADOW)
			exec += s.name + ".school = \"" + strTable->GetString("school_shadow") + "\";\n";
		else if (s.school == SPELL_SCHOOL_ARCANE)
			exec += s.name + ".school = \"" + strTable->GetString("school_arcane") + "\";\n";
		else
			exec += s.name + ".school = \"\";\n";
		exec += s.name + ".icon = \"" + s.iconPath + "\";\n";
		if (s.buff != NULL)
			exec += s.name + ".buff = \"" + s.buff->name + "\";\n";
		else
			exec += s.name + ".buff = \"\";\n";
		exec += s.name + ".dmgMin = " + toString(s.dmg_min) + ";\n";
		exec += s.name + ".dmgMax = " + toString(s.dmg_max) + ";\n";
		//exec += s.name + ".addDmg = " + toString(s.add_dmg) + ";\n";
		exec += s.name + ".healMin = " + toString(s.heal_min) + ";\n";
		exec += s.name + ".healMax = " + toString(s.heal_max) + ";\n";
		//exec += s.name + ".addHeal = " + toString(s.add_heal) + ";\n";
		//exec += s.name + ".duration = " + toString(s.duration) + ";\n";
		exec += s.name + ".healthRecovered = " + toString(s.health_recovered) + ";\n";
		exec += s.name + ".manaRecovered = " + toString(s.mana_recovered) + ";\n";
		exec += s.name + ".channeled = " + BtoString(s.channeled) + ";\n";
		exec += s.name + ".targetType = " + toString(s.target) + ";\n";
		int error = luaL_dostring(luaVM, exec.c_str());
		if (error) l_logPrint(luaVM);*/

		/*if (!s.loaded)
			hge->System_Log(exec.c_str());*/

	return &this->spellList[spell_name];
}

SBuff* SceneManager::parseBuff( string buff_name )
{
	if (this->buffList[buff_name].name == "")
	{
		if (this->debugParser) hge->System_Log(" Parsing %s...", buff_name.c_str());

		lua_getglobal(luaVM, "Buffs");
		lua_getfield(luaVM, -1, buff_name.c_str());

		SBuff b;
		b.name = buff_name;
		b.display_name = mlua_getFieldString("display_name");
		b.description = mlua_getFieldString("description");
		b.duration = mlua_getFieldFloat("duration", false, -1.0f);
		b.max_count = mlua_getFieldInt("max_count", false, 50);

		b.icon_file = mlua_getFieldString("icon", false, "Icons/INV_Misc_QuestionMark.png");
		b.icon = createSprite
		(
			loadTexture(b.icon_file, true),
			0, 0, 64, 64
		);

		lua_pop(luaVM, 2);

		this->buffList[buff_name] = b;
	}

	return &this->buffList[buff_name];
}

Item SceneManager::parseItem( int item_id )
{
	if (itemList.find(item_id) == itemList.end())
	{
		if (this->debugParser) hge->System_Log(" Parsing item %d...", item_id);

		lua_getglobal(luaVM, "Items");
		lua_rawgeti(luaVM, -1, item_id);

		Item item;

		item.id = item_id;
		item.display_name = mlua_getFieldString("display_name");
		item.description = mlua_getFieldString("description");
		string icon = mlua_getFieldString("icon", false, "Icons/INV_Misc_QuestionMark.png");
		item.iconPath = icon;
		item.icon = createSprite
		(
			loadTexture(icon, true),
			5, 5, 56, 56
		);
		item.type = mlua_getFieldInt("type");
		item.quality = mlua_getFieldInt("quality");
		item.binds = mlua_getFieldInt("binds", false, 0);
		item.req_lvl = mlua_getFieldInt("requieres_lvl", false, 0);
		item.unique = mlua_getFieldInt("unique", false, 0);
		item.charges = mlua_getFieldInt("charges", false, -1);
		item.sellable = mlua_getFieldBool("sellable", false, false);
		item.price = mlua_getFieldInt("price");

		item.req_class = -1;
		item.req_skill = "";
		item.req_skill_lvl = 0;
		item.cooldown = 0.0f;
		//item.quest = NULL;
		item.conjured = false;
		item.made_by = "";
		item.container = false;
		item.soulbound = false;
		item.on_equip = NULL;
		item.on_use = NULL;
		item.on_hit = NULL;
		item.on_cast = NULL;
		item.durability_max = 0;
		item.durability_cur = 0;
		item.bonus_stat.clear();
		item.speed = 0.0f;
		item.dmg_min = 0;
		item.dmg_max = 0;
		item.add_dmg_school = 0;
		item.add_dmg_min = 0;
		item.add_dmg_max = 0;

		lua_pop(luaVM, 2);

		itemList[item_id] = item;
		return item;
	}
	else
		return itemList[item_id];
}

bool SceneManager::parseClassesDyn( int state1, bool* finished, float filling )
{
	static int class_nbr = 0;

	if (state1 == 1)
	{
		hge->System_Log("Parsing Tables/buff_table.lua...");
		int error = luaL_dofile(mSceneMgr->luaVM, "Tables/buff_table.lua");
		if (error) l_logPrint(mSceneMgr->luaVM);
		hge->System_Log("Parsing Tables/buff_table.lua : done.");
		hge->System_Log("Parsing Tables/spell_scripts_table.lua...");
		error = luaL_dofile(mSceneMgr->luaVM, "Tables/spell_scripts_table.lua");
		if (error) l_logPrint(mSceneMgr->luaVM);
		hge->System_Log("Parsing Tables/spell_scripts_table.lua : done.");
		hge->System_Log("Parsing Tables/spell_table.lua...");
		error = luaL_dofile(mSceneMgr->luaVM, "Tables/spell_table.lua");
		if (error) l_logPrint(mSceneMgr->luaVM);
		hge->System_Log("Parsing Tables/spell_table.lua : done.");
		hge->System_Log("Parsing Tables/item_table.lua...");
		error = luaL_dofile(mSceneMgr->luaVM, "Tables/item_table.lua");
		if (error) l_logPrint(mSceneMgr->luaVM);
		hge->System_Log("Parsing Tables/item_table.lua : done.");
		hge->System_Log("Parsing Tables/class_table.lua...");
		error = luaL_dofile(luaVM, "Tables/class_table.lua");
		if (error) l_logPrint(luaVM);
		int n = lua_gettop(luaVM);
		lua_getglobal(luaVM, "Classes");

		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			class_nbr++;
		}

		lua_pushnil(luaVM);
		*finished = false;
		n = lua_gettop(luaVM);
		return true;
	}
	else if (state1 == 2)
	{
		if (!lua_next(luaVM, -2))
		{
			*finished = false;
			return true;
		}

		Class c;

		c.name = mlua_getFieldString("name");
		c.display_name = mlua_getFieldString("display_name");
		c.id = mlua_getFieldInt("id");
		string icon_file = mlua_getFieldString("icon", false, "Icons/INV_Misc_QuestionMark.png");
		c.icon = createSprite(loadTexture(icon_file, true), 0, 0, 64, 64);
		c.anim_set = mlua_getFieldString("animset");
		c.health_gained_per_spirit = mlua_getFieldFloat("health_gained_per_spirit", false, 0.0f);
		c.health_gained_per_tick = mlua_getFieldFloat("health_gained_per_tick", false, 0.0f);
		c.mana_gained_per_spirit = mlua_getFieldFloat("mana_gained_per_spirit", false, 0.0f);
		c.mana_gained_per_tick = mlua_getFieldFloat("mana_gained_per_tick", false, 0.0f);
		c.power_type = mlua_getFieldInt("power_type", false, 5);
		c.regen_health_in_combat = mlua_getFieldFloat("regen_health_in_combat", false, 0.0f);
		c.regen_mana_in_combat = mlua_getFieldFloat("regen_mana_in_combat", false, 0.0f);

		lua_getfield(luaVM, -1, "spells");
		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			if (!lua_isnil(luaVM, -1))
			{
				CSpell cs;
				string spell_name = mlua_getFieldString("name");
				cs.spell = parseSpell(spell_name);
				cs.cost = mlua_getFieldInt("cost", false, 0);
				cs.lvl = mlua_getFieldInt("available_at_lvl", false, 1);
				c.spell[spell_name] = cs;
			}
		}
		lua_pop(luaVM, 1);

		lua_getfield(luaVM, -1, "talent_trees");
		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			if (!lua_isnil(luaVM, -1))
			{
				Specialisation s;
				s.name = mlua_getFieldString("name");
				s.displayName = mlua_getFieldString("display_name");
				s.role = mlua_getFieldString("role");
				s.defaultSpell = &spellList[mlua_getFieldString("default_spell")];
				c.spec[s.name] = s;
			}
		}
		lua_pop(luaVM, 1);

		classList[c.name] = c;
		classList[c.name].defaultSpec = &classList[c.name].spec[mlua_getFieldString("default_spec")];

		mSceneMgr->mLoadingBar.filling += filling/class_nbr;

		lua_pop(luaVM, 1);
		*finished = false;
		return false;
	}
	else
	{
		lua_pop(luaVM, 1);
		hge->System_Log("Parsing Tables/class_table.lua : done.");
		*finished = true;
		return true;
	}
}

bool SceneManager::parseAnimationsDyn(int state1, int state2, bool* finished, float filling)
{
	static map<string, Class>::iterator iterC = this->classList.begin();
	static PAnim anim;
	static int anim_nbr = 0;

	if (state1 == 1)
	{
		hge->System_Log("Parsing Tables/animset_table.lua...");
		int error = luaL_dofile(luaVM,"Tables/animset_table.lua");
		if (error) l_logPrint(luaVM);

		lua_getglobal(luaVM, "AnimSets");

		*finished = false;
		return true;
	}
	else
	{
		if (state2 == 0)
		{
			Class* c = &iterC->second;
			if (this->debugParser) hge->System_Log("  Loading %s's animset...", c->name.c_str());
			lua_getfield(luaVM, -1, c->anim_set.c_str());
			c->scale = mlua_getFieldFloat("scale", false, 1.0f);
			c->shadow_scale = mlua_getFieldFloat("shadow_scale", false, 1.0f);
			c->status_bar_size = mlua_getFieldFloat("status_bar_size");
			c->status_bar_y_offset = mlua_getFieldFloat("status_bar_y_offset");

			if (pAnimList.find(c->anim_set) != pAnimList.end())
			{
				lua_pop(luaVM, 1);
				mSceneMgr->mLoadingBar.filling += filling/this->classList.size();
				iterC++;
				if (iterC == this->classList.end())
				{
					hge->System_Log("Parsing Tables/animset_table.lua : done.");
					lua_pop(luaVM, 1);
					*finished = true;
					return true;
				}
				else
				{
					*finished = false;
					return true;
				}
			}

			anim.name = c->anim_set;

			lua_getfield(luaVM, -1, "states");

			anim_nbr = 0;
			for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
			{
				anim_nbr++;
			}

			lua_pushnil(luaVM);

			*finished = false;
			return false;
		}
		else
		{
			if (!lua_next(luaVM, -2))
			{
				pAnimList[iterC->second.anim_set] = anim;
				anim.animation.clear();

				lua_pop(luaVM, 2);

				iterC++;
				if (iterC == this->classList.end())
				{
					hge->System_Log("Parsing Tables/animset_table.lua : done.");
					lua_pop(luaVM, 1);
					*finished = true;
					return true;
				}
				else
				{
					*finished = false;
					return true;
				}
			}

			string a_name = mlua_getFieldString("name");
			if (this->debugParser) hge->System_Log("   Loading state : %s", a_name.c_str());
			bool loop = mlua_getFieldBool("loop", false, true);

			lua_getfield(luaVM, -1, "sub_animations");

			Animation a;
			for (int i=0; i <= 7; i++)
			{
				lua_rawgeti(mSceneMgr->luaVM, -1, i);
				if (lua_isnil(mSceneMgr->luaVM, -1))
					mlua_print("Missing subanimation " + toString(i));
				else if (!lua_isstring(mSceneMgr->luaVM, -1))
					mlua_print("Field is expected to be a string");
				else
				{
					string str = lua_tostring(mSceneMgr->luaVM, -1);
					a.state[i] = mlua_animList[str];
					if (loop)
						a.state[i]->Play();
					else
					{
						a.state[i]->SetMode(HGEANIM_FWD | HGEANIM_NOLOOP);
						a.state[i]->Play();
					}
				}
				lua_pop(luaVM, 1);
			}

			anim.animation[a_name] = a;

			mSceneMgr->mLoadingBar.filling += (filling/this->classList.size())/anim_nbr;

			lua_pop(luaVM, 2);

			*finished = false;
			return false;
		}
	}
}

void SceneManager::parseEffects()
{
	hge->System_Log("Parsing Tables/fx_table.lua...");
	int error = luaL_dofile(luaVM, "Tables/fx_table.lua");
	if (error) l_logPrint(luaVM);

	lua_getglobal(luaVM, "Effects");

	for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
	{
		SEffect e;
		e.name = mlua_getFieldString("name");
		e.life = mlua_getFieldFloat("life_duration", false, 0.0f);
		string type = mlua_getFieldString("type");
		e.offset_x = mlua_getFieldFloat("offset_x", false, 0.0f);
		e.offset_y = mlua_getFieldFloat("offset_y", false, 0.0f);
		if (type == "multi_angle_anim")
		{
			e.type = FX_ANIMATED_EFFECT;
			e.afx.type = FX_MULTI_ANGLE_ANIM;
			e.afx.fade_in = mlua_getFieldFloat("fade_in", false, 0.0f);
			e.afx.fade_out = mlua_getFieldFloat("fade_out", false, 0.0f);
			e.afx.scale = mlua_getFieldFloat("scale", false, 1.0f);
			string blend_mode = mlua_getFieldString("blend_mode", false, "");
			bool loop = mlua_getFieldBool("loop", false, true);

			lua_getfield(mSceneMgr->luaVM, -1, "sub_animations");
			for (int i=0; i <= 7; i++)
			{
				lua_rawgeti(mSceneMgr->luaVM, -1, i);
				if (lua_isnil(mSceneMgr->luaVM, -1))
					mlua_print("Missing subanimation " + toString(i));
				else if (!lua_isstring(mSceneMgr->luaVM, -1))
					mlua_print("Field is expected to be a string");
				else
				{
					string str = lua_tostring(mSceneMgr->luaVM, -1);
					e.afx.state[i] = mlua_animList[str];
					if (loop)
						e.afx.state[i]->Play();
					else
					{
						e.afx.state[i]->SetMode(HGEANIM_FWD | HGEANIM_NOLOOP);
						e.afx.state[i]->Play();
					}
					if (blend_mode == "add")
						e.afx.state[i]->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHAADD | BLEND_NOZWRITE);
				}
				lua_pop(luaVM, 1);
			}
			lua_pop(luaVM, 1);
		}
		else if (type == "single_angle_anim")
		{
			e.type = FX_ANIMATED_EFFECT;
			e.afx.type = FX_SINGLE_ANGLE_ANIM;
			e.afx.fade_in = mlua_getFieldFloat("fade_in", false, 0.0f);
			e.afx.fade_out = mlua_getFieldFloat("fade_out", false, 0.0f);
			e.afx.scale = mlua_getFieldFloat("scale", false, 1.0f);
			string blend_mode = mlua_getFieldString("blend_mode", false, "");
			bool loop = mlua_getFieldBool("loop", false, true);

			e.afx.anim = mlua_animList[mlua_getFieldString("animation")];
			if (loop)
				e.afx.anim->Play();
			else
			{
				e.afx.anim->SetMode(HGEANIM_FWD | HGEANIM_NOLOOP);
				e.afx.anim->Play();
			}
			if (blend_mode == "add")
				e.afx.anim->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHAADD | BLEND_NOZWRITE);
		}
		else if (type == "psys")
		{
			e.type = FX_PARTICLE_SYSTEM;
			e.pfx.delay = mlua_getFieldFloat("delay", false, 0.0f);
			string blend_mode = mlua_getFieldString("blend_mode", false, "");
			hgeSprite* spr = mlua_spriteList[mlua_getFieldString("sprite")];
			if (blend_mode == "add")
				spr->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHAADD | BLEND_NOZWRITE);
			string file = mlua_getFieldString("file");
			e.pfx.psys = new hgeParticleSystem(file.c_str(), spr);
		}
		else
		{
			hge->System_Log("# Error # : Unknown effect type : \"%s\".", type.c_str());
			continue;
		}

		this->FXList[e.name] = e;
	}

	lua_pop(luaVM, 1);

	hge->System_Log("Parsing Tables/fx_table.lua : done.");
}

void SceneManager::buildRenderList( bool rebuild, bool debug )
{
	if ( (mForceUpdate == true) || (rebuild) )
	{
		debugRenderList = debug;
		zSortedList.clear();
		zSortedUnitList.clear();
		map<string, Unit>::iterator iterUnit;
		for (iterUnit = unitList.begin(); iterUnit != unitList.end(); iterUnit++)
		{
			Unit *u = &iterUnit->second;
			if (!gamePaused)
				u->update(dt);
			else
				u->setBox();
			if (u->getBox()->Intersect(scrRect))
			{
				float z = u->getZ();
				Object obj;
				obj.type = UNIT;
				obj.ptr = u;
				while (this->zSortedList.find(z) != this->zSortedList.end())
				{
					z += 0.01f;
				}
				this->zSortedList[z] = obj;
				this->zSortedUnitList[z] = u;
			}
		}

		map<float, Object> relZList;

		map<string, Doodad>::iterator iterDoodad;
		for (iterDoodad = actualZone.doodadList.begin(); iterDoodad != actualZone.doodadList.end(); iterDoodad++)
		{
			relZList.clear();
			Doodad *d = &iterDoodad->second;
			if (this->debugRenderList) {hge->System_Log("#Doodad %s :", d->name.c_str());}

			if (d->getBox()->Intersect(scrRect))
			{
				if (d->inTop)
					this->renderInTopList[d->getZ()] = d;
				else
				{
					map<float, Object>::iterator iterZ;
					for (iterZ = this->zSortedList.begin(); iterZ != this->zSortedList.end(); iterZ++)
					{
						// Check every unit or doodad that is in close range
						if (d->intersects(iterZ->second))
						{
							// Get relative Z for each
							float z;
							if (iterZ->second.type == UNIT)
							{
								Unit* tempUnit = static_cast<Unit*>(iterZ->second.ptr);
								if (this->debugRenderList) {hge->System_Log("  %s :", tempUnit->getName().c_str());}
								z = - d->getRelativeDepth(tempUnit->getGPoint());
							}
							else if (iterZ->second.type == DOODAD)
							{
								Doodad* tempDoodad = static_cast<Doodad*>(iterZ->second.ptr);
								if (this->debugRenderList) {hge->System_Log("  %s :", tempDoodad->name.c_str());}
								z = tempDoodad->getRelativeDepth(d->getPoint());
							}

							if (z != 0.0f)
							{
								// A little offset to prevent duplicates
								while (relZList.find(z) != relZList.end())
								{
									z += 0.01f;
								}

								if (this->debugRenderList) {hge->System_Log("   relZ = %f :", z);}

								// ... and store it in a map
								relZList[z] = iterZ->second;
							}
							else
							{
								if (this->debugRenderList) {hge->System_Log("   relZ = 0");}
							}
						}
					}
					float z;
					if (relZList.empty())
					{
						// If the map is empty, then set unit's Z to its global value
						z = d->getZ();
						// ...and add little offset if needed to prevent duplicates
						while (this->zSortedList.find(z) != this->zSortedList.end())
						{
							z += 0.01f;
						}

						if (this->debugRenderList) {hge->System_Log(" relZ is empty : z = %f", z);}
					}
					else
					{
						if (relZList.size() == 1)
						{
							// Else if there is only one object in range, set unit's Z to the
							// object's + the relative Z.
							if (relZList.begin()->second.type == UNIT)
							{
								Unit* tempUnit = static_cast<Unit*>(relZList.begin()->second.ptr);
								if (relZList.begin()->first >= 0.0f)
								{
									if (d->getZ() >= tempUnit->getZ())
										z = d->getZ();
									else
										z = tempUnit->getRZ()+0.01f;
								}
								else if (relZList.begin()->first < 0.0f)
								{
									if (d->getZ() < tempUnit->getZ())
										z = d->getZ();
									else
										z = tempUnit->getRZ()-0.01f;
								}
								if (this->debugRenderList) {hge->System_Log(" relZ contains only one object (%s) : z = %f", tempUnit->getName().c_str(), z);}
							}
							else if (relZList.begin()->second.type == DOODAD)
							{
								Doodad* tempDoodad = static_cast<Doodad*>(relZList.begin()->second.ptr);
								if (relZList.begin()->first >= 0.0f)
								{
									if (d->getZ() >= tempDoodad->getZ())
										z = d->getZ();
									else
										z = tempDoodad->getZ()+0.01f;
								}
								else if (relZList.begin()->first < 0.0f)
								{
									if (d->getZ() < tempDoodad->getZ())
										z = d->getZ();
									else
										z = tempDoodad->getZ()-0.01f;
								}
								if (this->debugRenderList) {hge->System_Log(" relZ contains only one object (%s) : z = %f", tempDoodad->name.c_str(), z);}
							}
						}
						else if (relZList.size() > 1)
						{
							// And if there is more than two objects...
							float z1, z2;
							map<float, Object>::iterator iter0, iter1, iter2, iter3;

							// We get the two objects with the highest and lowest Z value
							float bestZ, worstZ;
							iter0 = relZList.begin();
							if (iter0->second.type == UNIT)
								bestZ = worstZ = static_cast<Unit*>(iter0->second.ptr)->getZ();
							else if (iter0->second.type == DOODAD)
								bestZ = worstZ = static_cast<Doodad*>(iter0->second.ptr)->getZ();
							iter1 = iter2 = iter0;
							for (iter0 = relZList.begin(); iter0 != relZList.end(); iter0++)
							{
								float z;
								if (iter0->second.type == UNIT)
									z = static_cast<Unit*>(iter0->second.ptr)->getZ();
								else if (iter0->second.type == DOODAD)
									z = static_cast<Doodad*>(iter0->second.ptr)->getZ();

								if (z < worstZ)
								{
									worstZ = z;
									iter1 = iter0;
								}
								if (z > bestZ)
								{
									bestZ = z;
									iter2 = iter0;
								}
							}

							iter3 = relZList.upper_bound(0.0f);
							if (this->debugRenderList) {hge->System_Log(" relZ contains more than one object :");}

							if (iter1->first <= 0.0f)
							{
								// There is no positive Z value, set Z to the nearest from zero + relZ
								if (this->debugRenderList) {hge->System_Log("  none of them have a positive relZ,");}
								if (iter1->second.type == UNIT)
								{
									Unit* tempUnit = static_cast<Unit*>(iter1->second.ptr);
									z = tempUnit->getZ()+iter1->first;
									if (this->debugRenderList) {hge->System_Log(" take the latest object (%s) : z = %f+%f = %f", tempUnit->getName().c_str(), tempUnit->getZ(), iter1->first, z);}
								}
								else if (iter1->second.type == DOODAD)
								{
									Doodad* tempDoodad = static_cast<Doodad*>(iter1->second.ptr);
									z = tempDoodad->getZ()+iter1->first*0.01f;
									if (this->debugRenderList) {hge->System_Log(" take the latest object (%s) : z = %f+%f = %f", tempDoodad->name.c_str(), tempDoodad->getZ(), iter1->first*0.01f, z);}
								}
							}
							else if (iter2->first >= 0.0f)
							{
								if (this->debugRenderList) {hge->System_Log(" none of them have a negative relZ");}
								// There is no negative Z value, set Z to the nearest from zero + relZ
								if (iter2->second.type == UNIT)
								{
									Unit* tempUnit = static_cast<Unit*>(iter2->second.ptr);
									z = tempUnit->getZ()+iter2->first;
									if (this->debugRenderList) {hge->System_Log(" take the first object (%s) : z = %f+%f = %f", tempUnit->getName().c_str(), tempUnit->getZ(), iter2->first, z);}
								}
								else if (iter2->second.type == DOODAD)
								{
									Doodad* tempDoodad = static_cast<Doodad*>(iter2->second.ptr);
									z = tempDoodad->getZ()+iter2->first*0.01f;
									if (this->debugRenderList) {hge->System_Log(" take the first object (%s) : z = %f+%f = %f", tempDoodad->name.c_str(), tempDoodad->getZ(), iter2->first*0.01f, z);}
								}
							}
							else
							{
								if (this->debugRenderList) {hge->System_Log(" there are positive and negative relZ");}
								// Else get the average of the two closest from 0
								if (iter3->second.type == UNIT)
								{
									Unit* tempUnit = static_cast<Unit*>(iter3->second.ptr);
									z1 = tempUnit->getZ();
									if (this->debugRenderList) {hge->System_Log("  take the nearest from 0 (%s) : z1 = %f", tempUnit->getName().c_str(), z1);}
								}
								else if (iter3->second.type == DOODAD)
								{
									Doodad* tempDoodad = static_cast<Doodad*>(iter3->second.ptr);
									z1 = tempDoodad->getZ();
									if (this->debugRenderList) {hge->System_Log("  take the nearest from 0 (%s) : z1 = %f", tempDoodad->name.c_str(), z1);}
								}
								iter3--;
								if (iter3->second.type == UNIT)
								{
									Unit* tempUnit = static_cast<Unit*>(iter3->second.ptr);
									z2 = tempUnit->getZ();
									if (this->debugRenderList) {hge->System_Log("  and the one just before (%s) : z2 = %f", tempUnit->getName().c_str(), z2);}
								}
								else if (iter3->second.type == DOODAD)
								{
									Doodad* tempDoodad = static_cast<Doodad*>(iter3->second.ptr);
									z2 = tempDoodad->getZ();
									if (this->debugRenderList) {hge->System_Log("  and the one just before (%s) : z2 = %f", tempDoodad->name.c_str(), z2);}
								}
								z = (z1+z2)/2;
								if (this->debugRenderList) {hge->System_Log(" and get the average between those two : z = %f", z);}
							}
						}
					}
					Object obj;
					obj.type = DOODAD;
					obj.ptr = d;
					// A little offset to prevent duplicates
					while (this->zSortedList.find(z) != this->zSortedList.end())
					{
						z += 0.01f;
					}
					if (this->debugRenderList) {hge->System_Log(" %s : z = %f", d->name.c_str(), z);}
					this->zSortedList[z] = obj;
				}
			}
		}
	}
	else if (!gamePaused)
	{
		// Just update all units.
		map<string, Unit>::iterator iterUnit;
		for (iterUnit = mSceneMgr->unitList.begin(); iterUnit != mSceneMgr->unitList.end(); iterUnit++)
		{
			iterUnit->second.update(dt);
		}
	}
	mForceUpdate = false;
}

void SceneManager::forceUpdate()
{
	mForceUpdate = true;
}

HTEXTURE SceneManager::loadTexture( string file, bool mipmaps )
{
	if (textureList.find(file) != textureList.end())
	{
	  	return textureList[file];
	}
	else
	{
		if (file == "") {hge->System_Log("# Error # : can't load texture : missing file name");}
		else
		{
			textureList[file] = hge->Texture_Load(file.c_str(), 0, mipmaps);
			return textureList[file];
		}
	}
}

void SceneManager::freeTextures()
{
	map<string, HTEXTURE>::iterator iterTex;
	for (iterTex = this->textureList.begin(); iterTex != this->textureList.end(); iterTex++)
	{
		hge->Texture_Free(iterTex->second);
	}
}

hgeSprite* SceneManager::createSprite( HTEXTURE tex, float x, float y, float w, float h, bool GUI )
{
	hgeSprite* spr = new hgeSprite(tex, x, y, w, h);
	if (GUI)
		GUIspriteList.push_back(spr);
	else
		spriteList.push_back(spr);
	return spr;
}

hgeSprite* SceneManager::createSprite( hgeSprite* base, bool GUI )
{
	hgeSprite* spr = new hgeSprite(*base);
	if (GUI)
		GUIspriteList.push_back(spr);
	else
		spriteList.push_back(spr);
	return spr;
}

void SceneManager::deleteSprites()
{
	vector<hgeSprite*>::iterator iter;
	while (!spriteList.empty())
	{
		iter = spriteList.begin();
		delete *iter;
		spriteList.erase(iter);
	}
}

hgeAnimation* SceneManager::createAnimation( HTEXTURE tex, int frames, float fps, float x, float y, float w, float h )
{
	hgeAnimation* anim = new hgeAnimation(tex, frames, fps, x, y, w, h);
	animList.push_back(anim);
	return anim;
}

void SceneManager::deleteAnimations()
{
	vector<hgeAnimation*>::iterator iter;
	while (!animList.empty())
	{
		iter = animList.begin();
		delete *iter;
		animList.erase(iter);
	}
}

hgeRect* SceneManager::createRect( float x1, float y1, float x2, float y2 )
{
	hgeRect* rect = new hgeRect(x1, y1, x2, y2);
	rectList.push_back(rect);
	return rect;
}

void SceneManager::deleteRects()
{
	vector<hgeRect*>::iterator iter;
	while (!rectList.empty())
	{
		iter = rectList.begin();
		delete *iter;
		rectList.erase(iter);
	}
}

hgeParticleSystem* SceneManager::createPSys( string file, hgeSprite* spr )
{
	hgeParticleSystem* psys = new hgeParticleSystem(file.c_str(), spr);
	psysList.push_back(psys);
	return psys;
}

void SceneManager::deletePSys()
{
	vector<hgeParticleSystem*>::iterator iter;
	while (!psysList.empty())
	{
		iter = psysList.begin();
		delete *iter;
		psysList.erase(iter);
	}
}

void SceneManager::deleteDoodads()
{
	map<string, Doodad>::iterator iterDoodad;
	for (iterDoodad = this->actualZone.doodadList.begin(); iterDoodad != this->actualZone.doodadList.end(); iterDoodad++)
	{
		iterDoodad->second.deleteSelf();
	}
	this->actualZone.doodadList.clear();
}

void SceneManager::deleteUnits()
{
	map<string, Unit>::iterator iterUnit;
	for (iterUnit = this->unitList.begin(); iterUnit != this->unitList.end(); iterUnit++)
	{
		iterUnit->second.deleteSelf();
	}
	this->unitList.clear();
}

Unit* SceneManager::createUnit( string name, float x, float y, int lvl, Class* c, float speed )
{
	if (unitList.find(name) != unitList.end())
	{
		hge->System_Log("# Warning # : A unit with the name %s already exists, returning pointer.", name.c_str());
	}
	else
	{
		unitList[name] = Unit(name, x, y, lvl, c, speed);
		unitList[name].setAnimation();
		unitList[name].setBox();
		unitList[name].setStandBox();
		unitList[name].initAB();
	}
	return &unitList[name];
}

Unit* SceneManager::getUnitByName( string name )
{
	if (unitList.find(name) != unitList.end())
	{
		Unit *u = &unitList[name];
		return u;
	}
	else
	{
		return NULL;
	}
}

void SceneManager::deselectAll()
{
	map<string, Unit>::iterator iter;
	for (iter=unitList.begin(); iter !=unitList.end(); iter++)
	{
		iter->second.setSelected(false);
	}
}

Class* SceneManager::getClass( string name )
{
	if (classList.find(name) != classList.end())
	{
		Class *c = &classList[name];
		return c;
	}
	else
	{
		hge->System_Log("# ERROR # : No class found with the name %s", name.c_str());
	}
}

void SceneManager::createProjectile( Spell* spell, Unit* target, Unit* origin )
{
	string oname = origin->getName();
	if (projectileList.find(oname) == projectileList.end())
	{
		projectileList[oname] = Projectile(spell, target, origin);
	}
	string fxname = spell->attack_effect;
	projectileList[oname].getPSys()->MoveTo(origin->getX()+FXList[fxname].offset_x, origin->getY()+FXList[fxname].offset_y);
	projectileList[oname].getPSys()->Stop(true);
	projectileList[oname].getPSys()->Fire();
}

void SceneManager::createStatusBar( Unit* parent )
{
	StatusBar tmpSB;
	tmpSB.parent = parent;
	statusBarList[parent->getName()] = tmpSB;
}

void SceneManager::addScrollingText( Unit* parent, int type, string value )
{
	ScrollingText st;
	st.parent = parent;
	st.type = type;
	st.value = value;
	hgeRect* tmpRect = parent->getBox();
	st.x = (tmpRect->x1+tmpRect->x2)/2-gx;
	st.y = tmpRect->y1-40*parent->getScale()-gy;
	st.lifeTime = 0.0f;
	if (type == GUI_SCRTXT_TYPE_PHYSICAL)
		st.color = ARGB(255, 255, 0, 0);
	else if (type == GUI_SCRTXT_TYPE_HEAL)
		st.color = ARGB(255, 0, 255, 0);
	else if (type == GUI_SCRTXT_TYPE_SPELL)
		st.color = ARGB(255, 255, 205, 0);

	scrollingTextList[parent->getName() + "_" + toString(parent->getTextNbr())] = st;
}

void SceneManager::updateScrollingTexts()
{
	if (!scrollingTextList.empty())
	{
		map<string, ScrollingText>::iterator iterText, lastParsed;
		lastParsed = NULL;
		for (iterText=scrollingTextList.begin(); iterText!=scrollingTextList.end(); iterText++)
		{
			ScrollingText* st = &iterText->second;
			if (st->lifeTime >= scrollingTextMaxLife)
			{
				scrollingTextList.erase(iterText);
				if (scrollingTextList.empty())
				{
					break;
				}
				else
				{
					if (lastParsed == NULL)
					{
						iterText = scrollingTextList.begin();
						continue;
					}
					else
					{
						iterText = lastParsed;
					}
				}
			}
			else
			{
				st->lifeTime += dt;
				st->y -= scrollingTextSpeed*dt;
				if (scrollingTextFade)
				{
					//float alpha = GETA(st->color)-255/scrollingTextMaxLife*dt;
					float alpha = 255*(1-(st->lifeTime/scrollingTextMaxLife));
					st->color = ARGB(alpha, GETR(st->color), GETG(st->color), GETB(st->color));
				}
			}
			lastParsed = iterText;
		}
	}
}

void SceneManager::renderScrollingTexts()
{
	if (!scrollingTextList.empty())
	{
		map<string, ScrollingText>::iterator iterText;
		for (iterText=scrollingTextList.begin(); iterText!=scrollingTextList.end(); iterText++)
		{
			ScrollingText* st = &iterText->second;
			scrollingTextFont->SetColor(st->color);
			scrollingTextFont->printf(st->x+gx, st->y+gy, HGETEXT_CENTER, "%s", st->value.c_str());
		}
	}
}

Cursor* SceneManager::switchCursor( string nCurName )
{
	Cursor* cur;
	if (cursorList.find(nCurName) != cursorList.end())
	{
		cur = &cursorList[nCurName];
		if ( (cur->animated) && !(cur->anim->IsPlaying()) )
			cur->anim->Play();

		return cur;
	}
	else
		hge->System_Log("# ERROR # : No cursor found with the name %s", nCurName.c_str());
}

int SceneManager::getBaseHealth( int lvl, Class* c )
{
	string s = c->name + "_" + toString(lvl);
	return toInt(lvl_healthTable->GetString(s.c_str()));
}

int SceneManager::getBaseMana( int lvl, Class* c )
{
	string s = c->name + "_" + toString(lvl);
	return toInt(lvl_manaTable->GetString(s.c_str()));
}

int SceneManager::getXPNeeded( int lvl )
{
	string s = "xp_" + toString(lvl);
	return toInt(lvl_healthTable->GetString(s.c_str()));
}

void SceneManager::requestWPPath( Unit* u )
{
	if (u->destPoint == Point(u->getGX(), u->getGY()))
	{
		u->waypointIndice == -1;
		u->orderGiven = true;
		u->following = true;
		vector<Point> path;
		path.push_back(u->destPoint);
		u->path = path;
		if (u->order != "leashing")
			u->order = "move";
	}
	float index = hge->Timer_GetTime();
	while (this->requestWPList.find(index) != this->requestWPList.end())
	{
		index += 0.001;
	}
	this->requestWPList[index] = u;
	u->placeInWPQueue = index;
}

void SceneManager::buildWPPaths()
{
	if (!this->requestWPList.empty())
	{
		int pathBuilded = 0;
		map<float, Unit*>::iterator iter = this->requestWPList.begin();
		while (pathBuilded < maxComputedPaths)
		{
			Unit* u = iter->second;
			if (u->placeInWPQueue == iter->first)
			{
				u->wPath = getWaypoints
				(
					toInt(u->getGX()),
					toInt(u->getGY()),
					toInt(u->destPoint.x),
					toInt(u->destPoint.y)
				);
				u->orderGiven = true;

				pathBuilded++;

				this->requestWPList.erase(iter);
				iter = this->requestWPList.begin();
			}
			if (iter == this->requestWPList.end())
				break;
		}
	}
}

void SceneManager::requestPath( Unit* u )
{
	float index = hge->Timer_GetTime();
	while (this->requestList.find(index) != this->requestList.end())
	{
		index += 0.001;
	}
	this->requestList[index] = u;
	u->placeInQueue = index;
	u->pathRequested = true;
	u->pathObtained = false;
}

void SceneManager::buildPaths()
{
	if (!this->requestList.empty())
	{
		int pathBuilded = 0;
		map<float, Unit*>::iterator iter = this->requestList.begin();
		while (pathBuilded < maxComputedPaths)
		{
			Unit* u = iter->second;
			if (u->placeInQueue == iter->first)
			{
				vector<Point>::iterator iter2 = u->wPath.begin();
				for (int i=0; i < u->waypointIndice; i++)
				{
					iter2++;
				}
				if (iter2->size != 0.0f)
				{
					float ySize = iter2->size/1.6f;
					float randomY = hge->Random_Float(-ySize, ySize);
					float randomX = hge->Random_Float(-iter2->size, iter2->size)*sin(randomY/ySize);
					u->path = getShortestPath
					(
						toInt(u->getGX()),
						toInt(u->getGY()),
						toInt(iter2->x+randomX),
						toInt(iter2->y+randomY)
					);
				}
				else
				{
					u->path = getShortestPath
					(
						toInt(u->getGX()),
						toInt(u->getGY()),
						toInt(iter2->x),
						toInt(iter2->y)
					);
				}

				u->pathRequested = false;
				u->pathObtained = true;
				this->requestList.erase(iter);
				iter = this->requestList.begin();
				pathBuilded++;
			}
			if (iter == this->requestList.end())
				break;
		}
	}
}

void SceneManager::requestDirectPath( Unit* u )
{
	float index = hge->Timer_GetTime();
	while (this->requestDList.find(index) != this->requestDList.end())
	{
		index += 0.001;
	}
	this->requestDList[index] = u;
	u->placeInDQueue = index;
	u->pathRequested = true;
	u->pathObtained = false;
}

void SceneManager::buildDirectPaths()
{
	if (!this->requestDList.empty())
	{
		int pathBuilded = 0;
		map<float, Unit*>::iterator iter = this->requestDList.begin();
		while (pathBuilded < maxComputedPaths)
		{
			Unit* u = iter->second;
			if (u->placeInDQueue == iter->first)
			{
				u->path = getShortestPath
				(
					toInt(u->getGX()),
					toInt(u->getGY()),
					toInt(u->destPoint.x),
					toInt(u->destPoint.y)
				);
				u->pathRequested = false;
				u->pathObtained = true;
				this->requestDList.erase(iter);
				iter = this->requestDList.begin();
				pathBuilded++;
			}
			if (iter == this->requestDList.end())
				break;
		}
	}
}

void SceneManager::addErrorMessage( string caption )
{
	ErrorText eT;
	eT.caption = caption;
	eT.lifeTime = errorTextsDuration;
	eT.alpha = 255.0f;

	errorTextList.insert(errorTextList.begin(), eT);
	if (errorTextList.size() == 6)
		errorTextList.pop_back();
}

void SceneManager::updateErrorTexts()
{
	if (!errorTextList.empty())
	{
		vector<ErrorText>::iterator iter;
		iter = errorTextList.end();
		while (iter != errorTextList.begin())
		{
			iter--;
			iter->lifeTime -= dt;
			if (iter->lifeTime <= 0.0f)
			{
				errorTextList.pop_back();
				iter = errorTextList.end();
			}
			else if (iter->lifeTime <= errorTextsFadeDelay)
			{
				iter->alpha = iter->lifeTime*51;
			}
		}
	}
}

/*Inventory SceneManager::createInventory( Unit* parent )
{
	Inventory inv;
	inv.parent = parent;
	inv.size = 28;

	inv.background = mToolTip.background;
	inv.cornerTop = mToolTip.cornerTop;
	inv.cornerBottom = mToolTip.cornerBottom;
	inv.borderVertical = mToolTip.borderVertical;
	inv.borderHorizontalTop = mToolTip.borderHorizontalTop;
	inv.borderHorizontalBottom = mToolTip.borderHorizontalBottom;
	inv.emptySlot = inv_emptySlot;
	inv.closeButton = inv_closeButton;

	inv.title = strReplace(strTable->GetString("inv_inv"), "[unit]", parent->getName());
	//inv.font = getHGEFont(13, getBFont("calibri"));
	//inv.font->SetColor(ARGB(255, 255, 220, 0));

	return inv;
}*/

void SceneManager::loadUI()
{
	bool debugThis = false;
	mxml_initUI();

	if (debugThis) hge->System_Log("1");

	for (char* c = hge->Resource_EnumFolders("Interface/BaseUI/*"); c != 0; c = hge->Resource_EnumFolders())
	{
		loadAddOn(c, "Interface/BaseUI/");
	}
	for (char* c = hge->Resource_EnumFolders("Interface/AddOns/*"); c != 0; c = hge->Resource_EnumFolders())
	{
		loadAddOn(c, "Interface/AddOns/");
	}

	if (debugThis) hge->System_Log("2");

	map<string, GUIElement>::iterator iterElem;
	for (iterElem = guiList.begin(); iterElem != guiList.end(); iterElem++)
	{
		GUIElement* g = &iterElem->second;
		if (!g->child)
		{
			g->_init();

			map<string, GUIArt>::iterator iter;
			for (iter = g->arts.begin(); iter != g->arts.end(); iter++)
			{
				GUIArt* a = &iter->second;
				a->_init();
			}
		}
	}

	if (debugThis) hge->System_Log("3");

	for (iterElem = guiList.begin(); iterElem != guiList.end(); iterElem++)
	{
		if (debugThis) hge->System_Log("3.1 %s", iterElem->second.name.c_str());
		if (!iterElem->second.child)
			iterElem->second.OnLoad();
	}

	if (debugThis) hge->System_Log("4");

	// Load saved variables
	char* saved = hge->Resource_EnumFiles("Saves/AddOns/*");
	while (saved != 0)
	{
		string s = "Saves/AddOns/";
		string f = saved;
		if (f.find(".lua") != f.npos)
		{
			s += f;
			int error = luaL_dofile(luaVM, s.c_str());
			if (error) l_logPrint(luaVM);
		}

		saved = hge->Resource_EnumFiles();
	}

	if (debugThis) hge->System_Log("5");

	mSceneMgr->rebuildGUIList = true;
}

void SceneManager::closeUI()
{
	// Delete GUI elements
	map<string, GUIElement>::iterator iterElem;
	for (iterElem = guiList.begin(); iterElem != guiList.end(); iterElem++)
	{
		iterElem->second.deleteMe();
	}

	lua_register(mSceneMgr->luaVM, "sendString", l_sendString);
	lua_register(mSceneMgr->luaVM, "concTable", l_concTable);

	// Write saved variables
	map<string, AddOn>::iterator iterAddOn;
	for (iterAddOn = this->addOnList.begin(); iterAddOn != this->addOnList.end(); iterAddOn++)
	{
		AddOn* a = &iterAddOn->second;
		if (a->enabled)
		{
			if (!a->saved.empty())
			{
				string sfile = "Saves/AddOns/" + a->name + ".lua";
				fstream file(sfile.c_str(), ios::out);
				file << "\n";
				vector<string>::iterator iterVar;
				for (iterVar = a->saved.begin(); iterVar != a->saved.end(); iterVar++)
				{
					string var = *iterVar;
					lua_getglobal(luaVM, var.c_str());
					if (!lua_isnil(luaVM, -1))
					{
						int type = lua_type(luaVM, -1);
						if (type == LUA_TNUMBER)
						{
							file << var + " = " + toString(lua_tonumber(luaVM, -1)) + ";\n";
						}
						else if (type == LUA_TBOOLEAN)
						{
							file << var + " = " + BtoString(lua_toboolean(luaVM, -1)) + ";\n";
						}
						else if (type == LUA_TSTRING)
						{
							file << var + " = \"" + lua_tostring(luaVM, -1) + "\";\n";
						}
						else if (type == LUA_TTABLE)
						{
							tmpString = "";
							string exec = "str = \"\";\nstr = concTable(str, \"" + var + "\");\n";
							luaL_dostring(luaVM, exec.c_str());

							string s = tmpString;
							string tab = "	";
							file << var + " = {\n";
							int tableIndent = 1;
							bool tableEnded = false;
							int lineNbr = 0;
							while (!tableEnded)
							{
								if (lineNbr > 1000)
									break;

								if (tableIndent == -1)
								{
									tableEnded = true;
								}
								else
								{
									int i = s.find(" ");
									string k = s.substr(0, i);
									s.erase(0, i+1);
									if (k == "'end'")
									{
										tableIndent--;
										tab = tab.substr(0, tab.size()-4);
										if (tableIndent == -1)
											file << tab + "}\n";
										else
											file << tab + "},\n";
									}
									else
									{
										k = "[" + k + "]";

										i = s.find(" ");
										string v = s.substr(0, i);
										s.erase(0, i+1);

										int type;
										if (v == "'table'")
											type = LUA_TTABLE;
										else
										{
											type = LUA_TNUMBER;
											int j = v.find("\"");
											if (j != v.npos)
												type = LUA_TSTRING;
											j = v.find("'");
											if (j != v.npos)
											{
												type = LUA_TBOOLEAN;
												strRemoveSurChar(&v, '\'');
											}
										}

										if (type == LUA_TNUMBER)
										{
											file << tab + k + " = " + v + ";\n";
										}
										else if (type == LUA_TBOOLEAN)
										{
											file << tab + k + " = " + v + ";\n";
										}
										else if (type == LUA_TSTRING)
										{
											file << tab + k + " = " + v + ";\n";
										}
										else if (type == LUA_TTABLE)
										{
											file << tab + k + " = {\n";
											tab += "	";
										}
									}
								}
							}
						}
					}
				}
				file.close();
			}
		}
	}

	// Write addons activation
	fstream file("Interface/AddOns.txt", ios::out);
	for (iterAddOn = this->addOnList.begin(); iterAddOn != this->addOnList.end(); iterAddOn++)
	{
		string s = iterAddOn->second.name;
		if (s != "")
		{
			s += ": ";
			if (iterAddOn->second.enabled)
				s += "1\n";
			else
				s += "0\n";

			file << s;
		}
	}
	file.close();

	// Delete UI sprites
	vector<hgeSprite*>::iterator iter;
	while (!GUIspriteList.empty())
	{
		iter = GUIspriteList.begin();
		delete *iter;
		GUIspriteList.erase(iter);
	}
}

void SceneManager::reLoadUI()
{
	hge->System_Log("Reloading UI...");

	// Delete the UI
	closeUI();

	// Clear lists
	guiList.clear();
	addOnList.clear();
	parentList.clear();
	templateList.clear();

	// Clear LUA
	lua_close(luaVM);
	luaVM = lua_open();
	if (luaVM == NULL)
	{
		hge->System_Log("# Error initializing lua.");
		return;
	}
	luaL_openlibs(luaVM);
	mlua_registerAll();

	// Reload important LUA data
	functionNbr = 1;
	int error = luaL_dofile(luaVM, "Scripts/config.lua");
	if (error) l_logPrint(luaVM);

	error = luaL_dofile(mSceneMgr->luaVM, "Tables/buff_table.lua");
	if (error) l_logPrint(mSceneMgr->luaVM);

	error = luaL_dofile(mSceneMgr->luaVM, "Tables/spell_scripts_table.lua");
	if (error) l_logPrint(mSceneMgr->luaVM);

	error = luaL_dofile(mSceneMgr->luaVM, "Tables/spell_table.lua");
	if (error) l_logPrint(mSceneMgr->luaVM);

	map<string, Spell>::iterator iterSpell;
	for (iterSpell = spellList.begin(); iterSpell != spellList.end(); iterSpell++)
	{
		parseSpell(iterSpell->second.name, true);
	}

	error = luaL_dofile(mSceneMgr->luaVM, "Tables/item_table.lua");
	if (error) l_logPrint(mSceneMgr->luaVM);

	locale = mlua_getGlobalString("Game_locale");
	string strTableFile = "Tables/locale_" + locale + ".str";
	delete strTable;
	strTable = new hgeStringTable(strTableFile.c_str());

	// Load the new UI
	loadUI();

	hge->System_Log("Reloading UI : done.");
}

void SceneManager::loadAddOn( string name, string folder )
{
	bool debugThis = false;

	if (debugThis) hge->System_Log("1");

	if (this->addOnList[name].enabled)
	{
		if (debugThis) hge->System_Log("2");
		AddOn a;
		AddOn* pa;
		a.enabled = true;
		a.folder = folder + name;
		string tocFile = a.folder + "/" + name + ".toc";
		if (this->debugParser) {hge->System_Log(" Loading AddOn %s", name.c_str());}
		fstream file(tocFile.c_str(), ios::in);

		if (file.is_open())
		{
			if (debugThis) hge->System_Log("3");
			char line[256];
			while (!file.eof())
			{
				if (debugThis) hge->System_Log("3.1");
				file.getline(line, 256);
				if ( (line[0] == '#') && (line[1] == '#') )
				{
					if (debugThis) hge->System_Log("3.1.1");
					string temp = line;
					temp = temp.substr(3);
					int i = temp.find(":");
					if (i != temp.npos)
					{
						if (debugThis) hge->System_Log("3.1.2");
						string field = temp.substr(0, i);
						strRemoveSurChar(&field, ' ');
						string value = temp.substr(i+1);
						strRemoveSurChar(&value, ' ');
						if (field == "Interface")
						{
							value = value.substr(0, 4);
							value.insert(1, ".");
							a.UIVersion = atof(value.c_str());

							if (a.UIVersion >= gameVersion)
								a.enabled = true;
							else
								a.enabled = false;
						}
						else if (field == "Title")
						{
							a.name = value;
						}
						else if (field == "Version")
						{
							a.version = value;
						}
						else if (field == "Author")
						{
							a.author = value;
						}
						else if (field == "SavedVariables")
						{
							while (value != "")
							{
								int j = value.find(",");
								string variable;
								if (j == value.npos)
								{
									variable = value;
									a.saved.push_back(variable);
									value = "";
								}
								else
								{
									variable = value.substr(0, j);
									a.saved.push_back(variable);
									value.erase(0, j+1);
									strRemoveSurChar(&value, ' ');
								}
							}
						}
					}
				}
				else
				{
					if (debugThis) hge->System_Log("3.1.2");
					string temp = line;
					strRemoveSurChar(&temp, ' ');
					int i = temp.find(".lua");
					int j = temp.find(".xml");
					if ( (i != temp.npos) || (j != temp.npos) )
					{
						a.files.push_back(a.folder + "/" + temp);
					}
					if (debugThis) hge->System_Log("3.1.3");
				}
			}

			if (debugThis) hge->System_Log("4");

			file.close();

			if (a.name == "")
				hge->System_Log("# Error # : missing AddOn name in %s", tocFile.c_str());
			else if (this->addOnList[a.name].loaded)
				hge->System_Log("# Error # : duplicated AddOn name : %s", a.name.c_str());
			else
			{
				if (debugThis) hge->System_Log("5");
				this->addOnList[a.name] = a;
				pa = &this->addOnList[a.name];

				fstream file2("Interface/AddOns.txt", ios::in);
				if (file2.is_open())
				{
					if (debugThis) hge->System_Log("6");
					char line[256];
					while (!file2.eof())
					{
						if (debugThis) hge->System_Log("7");
						file2.getline(line, 256);
						string temp = line;
						int i = temp.find(":");
						if (i != temp.npos)
						{
							if (debugThis) hge->System_Log("8");
							string field = temp.substr(0, i);
							strRemoveSurChar(&field, ' ');
							string value = temp.substr(i+1);
							strRemoveSurChar(&value, ' ');
							if (field == pa->name)
							{
								if (debugThis) hge->System_Log("9");
								if (value != string("1"))
								{
									pa->enabled = false;
								}
								break;
							}
						}
					}
					file2.close();
				}

				if (debugThis) hge->System_Log("6");

				if (pa->enabled)
				{
					vector<string>::iterator iterFile;
					for (iterFile = pa->files.begin(); iterFile != pa->files.end(); iterFile++)
					{
						if (debugThis) hge->System_Log("6.1 %s", iterFile->c_str());
						int i = iterFile->find(".lua");
						int j = iterFile->find(".xml");
						if (i != iterFile->npos)
						{
							int error = luaL_dofile(luaVM, iterFile->c_str());
							if (error) l_logPrint(luaVM);
						}
						else if (j != iterFile->npos)
						{
							TiXmlDocument doc(iterFile->c_str());
							if (!doc.LoadFile())
								hge->System_Log("# XML : %s: %s", iterFile->c_str(), doc.ErrorDesc());
							else
							{
								mxml_parseUIFile(pa, doc);
							}
						}
					}
				}

				if (debugThis) hge->System_Log("7");

				pa->loaded = true;
			}
		}
	}
	else
	{
		AddOn a;
		a.enabled = false;
		this->addOnList[name] = a;
	}
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               Lua source               */
/*                                        */
/*  ## : This file contains two things :  */
/*    - a lua interface for frequently    */
/*      used function combination.        */
/*    - the lua glues, to call the progs' */
/*      functions inside lua scripts.     */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_lua.h"
#include "wowrl_scenemanager.h"
#include "wowrl_gui.h"
#include "wowrl_unit.h"

#include <sstream>

using namespace std;

extern SceneManager* mSceneMgr;
extern HGE* hge;

void mlua_registerAll()
{
	// [#] This function registers all the LUA methods and LUNAR classes.
	lua_register(mSceneMgr->luaVM, "LogPrint", l_logPrint);
	lua_register(mSceneMgr->luaVM, "RandomInt", l_randomInt);
	lua_register(mSceneMgr->luaVM, "RandomFloat", l_randomFloat);
	lua_register(mSceneMgr->luaVM, "StrReplace", l_strReplace);
	lua_register(mSceneMgr->luaVM, "StrCapitalStart", l_strCapitalStart);
	lua_register(mSceneMgr->luaVM, "GetDelta", l_getDelta);
	lua_register(mSceneMgr->luaVM, "GetLeadingUnit", l_getLeadingUnit);
	lua_register(mSceneMgr->luaVM, "GetLocale", l_getLocale);
	lua_register(mSceneMgr->luaVM, "GetLocalizedString", l_getLocalizedString);
	lua_register(mSceneMgr->luaVM, "GetTime", l_getTime);
	lua_register(mSceneMgr->luaVM, "GetGlobal", l_getGlobal);
	lua_register(mSceneMgr->luaVM, "GetMousePos", l_getMousePos);

	lua_register(mSceneMgr->luaVM, "Gfx_createSprite", l_Gfx_createSprite);
	lua_register(mSceneMgr->luaVM, "Gfx_renderSprite", l_Gfx_renderSprite);
 	lua_register(mSceneMgr->luaVM, "Gfx_createAnimation", l_Gfx_createAnimation);
 	lua_register(mSceneMgr->luaVM, "Gfx_updateAnimation", l_Gfx_updateAnimation);
 	lua_register(mSceneMgr->luaVM, "Gfx_renderAnimation", l_Gfx_renderAnimation);
 	lua_register(mSceneMgr->luaVM, "Gfx_createPSys", l_Gfx_createPSys);
 	lua_register(mSceneMgr->luaVM, "Gfx_updatePSys", l_Gfx_updatePSys);
 	lua_register(mSceneMgr->luaVM, "Gfx_renderPSys", l_Gfx_renderPSys);

 	lua_register(mSceneMgr->luaVM, "GUI_createElement", l_GUI_createElement);

 	lua_register(mSceneMgr->luaVM, "UnitSpawn", l_Unit_spawn);
 	lua_register(mSceneMgr->luaVM, "UnitAddEffect", l_Unit_addEffect);
 	lua_register(mSceneMgr->luaVM, "UnitSetHostile", l_Unit_setHostile);
 	lua_register(mSceneMgr->luaVM, "UnitSetMaxHP", l_Unit_setMaxHP);
 	lua_register(mSceneMgr->luaVM, "UnitSetAggroRange", l_Unit_setAggroRange);
 	lua_register(mSceneMgr->luaVM, "UnitSetTarget", l_Unit_setTarget);
	lua_register(mSceneMgr->luaVM, "UnitSetX", l_Unit_setX);
	lua_register(mSceneMgr->luaVM, "UnitSetY", l_Unit_setY);
	lua_register(mSceneMgr->luaVM, "UnitIsHostile", l_Unit_isHostile);
	lua_register(mSceneMgr->luaVM, "UnitIsDead", l_Unit_isDead);
	lua_register(mSceneMgr->luaVM, "UnitIsTargetInRange", l_Unit_isTargetInRange);
	lua_register(mSceneMgr->luaVM, "UnitTarget", l_Unit_getTarget);
	lua_register(mSceneMgr->luaVM, "UnitX", l_Unit_getX);
	lua_register(mSceneMgr->luaVM, "UnitY", l_Unit_getY);
	lua_register(mSceneMgr->luaVM, "UnitLevel", l_Unit_getLevel);
	lua_register(mSceneMgr->luaVM, "UnitHealth", l_Unit_getHealth);
	lua_register(mSceneMgr->luaVM, "UnitMana", l_Unit_getMana);
	lua_register(mSceneMgr->luaVM, "UnitHealthMax", l_Unit_getMaxHealth);
	lua_register(mSceneMgr->luaVM, "UnitManaMax", l_Unit_getMaxMana);
	lua_register(mSceneMgr->luaVM, "UnitPowerType", l_Unit_getPowerType);
	lua_register(mSceneMgr->luaVM, "UnitAddItem", l_Unit_addItem);
	lua_register(mSceneMgr->luaVM, "UnitGetActionTexture", l_Unit_getActionTexture);
	lua_register(mSceneMgr->luaVM, "UnitGetActionInfo", l_Unit_getActionInfo);
	lua_register(mSceneMgr->luaVM, "UnitCastSpell", l_Unit_castSpell);
	lua_register(mSceneMgr->luaVM, "UnitCastSpellIndirect", l_Unit_castSpellIndirect);
	lua_register(mSceneMgr->luaVM, "UnitIsCasting", l_Unit_isCasting);
	lua_register(mSceneMgr->luaVM, "UnitCastingInfo", l_Unit_castingInfo);
	lua_register(mSceneMgr->luaVM, "UnitSpellInfo", l_Unit_getSpellInfo);
	lua_register(mSceneMgr->luaVM, "UnitSetAttacking", l_Unit_setAttacking);
	lua_register(mSceneMgr->luaVM, "UnitSetHealing", l_Unit_setHealing);
	lua_register(mSceneMgr->luaVM, "UnitSetResurrecting", l_Unit_setResurrecting);
	lua_register(mSceneMgr->luaVM, "UnitDamage", l_Unit_damage);
	lua_register(mSceneMgr->luaVM, "UnitHeal", l_Unit_heal);
	lua_register(mSceneMgr->luaVM, "UnitRes", l_Unit_res);
	lua_register(mSceneMgr->luaVM, "UnitAddBuff", l_Unit_addBuff);
	lua_register(mSceneMgr->luaVM, "UnitGetBuffs", l_Unit_getBuffs);

	Lunar<l_UIObject>::Register(mSceneMgr->luaVM);
	Lunar<l_Region>::Register(mSceneMgr->luaVM);
	Lunar<l_Frame>::Register(mSceneMgr->luaVM);
	Lunar<l_StatusBar>::Register(mSceneMgr->luaVM);
	Lunar<l_LayeredRegion>::Register(mSceneMgr->luaVM);
	Lunar<l_Texture>::Register(mSceneMgr->luaVM);
	Lunar<l_FontString>::Register(mSceneMgr->luaVM);
}

string mlua_concTable(lua_State* luaVM, string table )
{
	/* [#] This function converts a LUA table into a formated string. It is used
	/* to save the content of the table in the SavedVariables.
	*/
	string s = "";
	s += "tbl = \"" + table + "\";\n";
	s += "temp = \"\";\n";
	s += "for k, v in pairs (" + table + ") do\n";
	s += "local s, t;\n";
	s += "if (type(k) == \"number\") then\ns = k;\nend\n";
	s += "if (type(k) == \"string\") then\ns = \"\\\"\"..k..\"\\\"\";\nend\n";

	s += "if (type(v) == \"number\") then\nt = v;\nend\n";
	s += "if (type(v) == \"string\") then\nt = \"\\\"\"..v..\"\\\"\";\nend\n";
	s += "if (type(v) == \"boolean\") then\nif v then\nt = \"'true'\";\nelse\nt = \"'false'\";\nend\nend\n";
	s += "if (type(v) == \"table\") then\n";
	s += "t = \"'table'\";\nsendString(s..\" \"..t..\" \");\nconcTable(temp, tbl..\"[\"..s..\"]\");\n";
	s += "else\n";
	s += "sendString(s..\" \"..t..\" \");\n";
	s += "end\n";
	s += "end\n";
	s += "sendString(\"'end' \");\n";

	luaL_dostring(luaVM, s.c_str());

	return mSceneMgr->tmpString;
}

void mlua_printError( string error )
{
	lua_Debug d;
	lua_getstack(mSceneMgr->luaVM, 1, &d);
	lua_getinfo(mSceneMgr->luaVM, "Sl" , &d);
	string debugStr = string(d.short_src) + ", line " + toString(d.currentline)
				+ string(" : ") + error;
	lua_pushstring(mSceneMgr->luaVM, debugStr.c_str());
	l_logPrint(mSceneMgr->luaVM);
}

void mlua_print( string str )
{
	lua_pushstring(mSceneMgr->luaVM, str.c_str());
	l_logPrint(mSceneMgr->luaVM);
}

/* [#] The following functions are shortcuts to the LUA C API. They are very
/* usefull when dealing with tables, and allow default values.
*/
int mlua_getGlobalInt( string name, bool critical, int defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isnumber(mSceneMgr->luaVM, -1))
	{
		hge->System_Log("4 : %d", lua_gettop(mSceneMgr->luaVM));
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		int i = (int)lua_tonumber(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return i;
	}
}

float mlua_getGlobalFloat( string name, bool critical, float defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isnumber(mSceneMgr->luaVM, -1))
	{
		mlua_print("Field is expected to be a number");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		float f = lua_tonumber(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return f;
	}
}

string mlua_getGlobalString( string name, bool critical, string defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isstring(mSceneMgr->luaVM, -1))
	{
		mlua_print("Field is expected to be a string");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		string s = lua_tostring(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return s;
	}
}

bool mlua_getGlobalBool( string name, bool critical, bool defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isboolean(mSceneMgr->luaVM, -1))
	{
		mlua_print("Field is expected to be a bool");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		bool b = lua_toboolean(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return b;
	}
}

int mlua_getFieldInt( string name, bool critical, int defaultValue, bool setValue, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_getfield(luaVM, -1, name.c_str());
	if (lua_isnil(luaVM, -1))
	{
		lua_pop(luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else if (setValue)
		{
			mlua_setFieldInt(name, defaultValue, luaVM);
			return defaultValue;
		}
		else
			return defaultValue;
	}
	else if (!lua_isnumber(luaVM, -1))
	{
		mlua_print("Field is expected to be a number");
		lua_pop(luaVM, 1);
	}
	else
	{
		int i = (int)lua_tonumber(luaVM, -1);
		lua_pop(luaVM, 1);
		return i;
	}
}

float mlua_getFieldFloat( string name, bool critical, float defaultValue, bool setValue, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_getfield(luaVM, -1, name.c_str());
	if (lua_isnil(luaVM, -1))
	{
		lua_pop(luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else if (setValue)
		{
			mlua_setFieldFloat(name, defaultValue, luaVM);
			return defaultValue;
		}
		else
			return defaultValue;
	}
	else if (!lua_isnumber(luaVM, -1))
	{
		mlua_print("Field is expected to be a number");
		lua_pop(luaVM, 1);
	}
	else
	{
		float f = lua_tonumber(luaVM, -1);
		lua_pop(luaVM, 1);
		return f;
	}
}

string mlua_getFieldString( string name, bool critical, string defaultValue, bool setValue, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_getfield(luaVM, -1, name.c_str());
	if (lua_isnil(luaVM, -1))
	{
		lua_pop(luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else if (setValue)
		{
			mlua_setFieldString(name, defaultValue, luaVM);
			return defaultValue;
		}
		else
			return defaultValue;
	}
	else if (!lua_isstring(luaVM, -1))
	{
		mlua_print("Field is expected to be a string");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		string str = lua_tostring(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return str;
	}
}

bool mlua_getFieldBool( string name, bool critical, bool defaultValue, bool setValue, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_getfield(luaVM, -1, name.c_str());
	if (lua_isnil(luaVM, -1))
	{
		lua_pop(luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else if (setValue)
		{
			mlua_setFieldBool(name, defaultValue, luaVM);
			return defaultValue;
		}
		else
			return defaultValue;
	}
	else if (!lua_isboolean(luaVM, -1))
	{
		mlua_print("Field is expected to be a bool");
		lua_pop(luaVM, 1);
	}
	else
	{
		bool b = lua_toboolean(luaVM, -1);
		lua_pop(luaVM, 1);
		return b;
	}
}

void mlua_setFieldInt( string name, int value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushstring(luaVM, name.c_str());
	lua_pushnumber(luaVM, value);
	lua_settable(luaVM, -3);
}

void mlua_setFieldFloat( string name, float value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushstring(luaVM, name.c_str());
	lua_pushnumber(luaVM, value);
	lua_settable(luaVM, -3);
}

void mlua_setFieldString( string name, string value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushstring(luaVM, name.c_str());
	lua_pushstring(luaVM, value.c_str());
	lua_settable(luaVM, -3);
}

void mlua_setFieldBool( string name, bool value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushstring(luaVM, name.c_str());
	lua_pushboolean(luaVM, value);
	lua_settable(luaVM, -3);
}

void mlua_setIFieldInt( int id, int value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushnumber(luaVM, id);
	lua_pushnumber(luaVM, value);
	lua_settable(luaVM, -3);
}

void mlua_setIFieldFloat( int id, float value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushnumber(luaVM, id);
	lua_pushnumber(luaVM, value);
	lua_settable(luaVM, -3);
}

void mlua_setIFieldString( int id, string value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushnumber(luaVM, id);
	lua_pushstring(luaVM, value.c_str());
	lua_settable(luaVM, -3);
}

void mlua_setIFieldBool( int id, bool value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushnumber(luaVM, id);
	lua_pushboolean(luaVM, value);
	lua_settable(luaVM, -3);
}

/* [#] The following functions are called "glues". They aren't used in C++ but
/* in the LUA environnement. To get a description of what they do, you can refer
/* to :
/*              http://www.wowwiki.com/World_of_Warcraft_API
/*
/* They aren't all described there, but the most complexe ones are. Their use is,
/* in many case, obvious. So I won't make a description for each : it would be
/* redundant.
*/

int l_sendString( lua_State* luaVM )
{
	mSceneMgr->tmpString += lua_tostring(luaVM, 1);

	return 0;
}

int l_concTable( lua_State* luaVM )
{
	string t = lua_tostring(luaVM, 1);
	string s = mlua_concTable(luaVM, lua_tostring(luaVM, 2));
	s = t+s;
	lua_pushstring(luaVM, s.c_str());

	return 1;
}

int l_logPrint( lua_State* luaVM )
{
	if (!lua_isstring(luaVM, -1))
		mlua_printError("Argument of LogPrint must be a string (caption)");
	else
		hge->System_Log("# LUA : %s", lua_tostring(luaVM, -1));

	return 0;
}

int l_randomInt( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"randomInt\" (2 expected : low, high)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of RandomInt must be a number (low)");
		error++;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 2 of RandomInt must be a number (high)");
		error++;
	}

	if (error == 0)
	{
		int low = toInt(lua_tonumber(luaVM, 1));
		int high = toInt(lua_tonumber(luaVM, 2));
		int rand = hge->Random_Int(low, high);
		lua_pushnumber(luaVM, rand);
	}

	return 1;
}

int l_randomFloat( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"RandomFloat\" (2 expected : low, high)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of RandomFloat must be a number (low)");
		error++;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 2 of RandomFloat must be a number (high)");
		error++;
	}

	if (error == 0)
	{
		float low = lua_tonumber(luaVM, 1);
		float high = lua_tonumber(luaVM, 2);
		float rand = hge->Random_Float(low, high);
		lua_pushnumber(luaVM, rand);
	}

	return 1;
}

int l_strReplace( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		mlua_printError("Too few arguments in \"StrReplace\" (3 expected : base string, pattern, replacement)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of StrReplace must be a string (base string)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of StrReplace must be a string (pattern)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		mlua_printError("Argument 3 of StrReplace must be a string (replacement)");
		error++;
	}

	if (error == 0)
	{
		string base = lua_tostring(luaVM, 1);
		int i = strReplace(&base, lua_tostring(luaVM, 2), lua_tostring(luaVM, 3));
		lua_pushstring(luaVM, base.c_str());
		lua_pushnumber(luaVM, i);
	}

	return 2;
}

int l_strCapitalStart( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"StrCapitalStart\" (one expected : base string)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of StrCapitalStart must be a string (base string)");
		error++;
	}

	if (error == 0)
	{
		lua_pushstring(luaVM, strCapitalStart(lua_tostring(luaVM, 1), true).c_str());
	}

	return 1;
}

int l_getDelta( lua_State* luaVM )
{
	lua_pushnumber(luaVM, mSceneMgr->dt);

	return 1;
}

int l_getLeadingUnit( lua_State* luaVM )
{
	if (mSceneMgr->leadingUnit != NULL)
		lua_pushstring(luaVM, mSceneMgr->leadingUnit->getName().c_str());
	else
		lua_pushnil(luaVM);

	return 1;
}

int l_getLocale( lua_State* luaVM )
{
	lua_pushstring(luaVM, mSceneMgr->locale.c_str());

	return 1;
}

int l_getLocalizedString( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"GetLocalizedString\" (one expected : string id)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of GetLocalizedString must be a string (string id)");
		error++;
	}

	if (error == 0)
	{
		lua_pushstring(luaVM, mSceneMgr->strTable->GetString(lua_tostring(luaVM, 1)));
	}

	return 1;
}

int l_getTime( lua_State* luaVM )
{
	lua_pushnumber(luaVM, getTime());

	return 1;
}

int l_getGlobal( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"GetGlobal\" (one expected : variable name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of GetGlobal must be a string (variable name)");
		error++;
	}

	if (error == 0)
	{
		lua_getglobal(luaVM, lua_tostring(luaVM, 1));
	}
	return 1;
}

int l_getMousePos( lua_State* luaVM )
{
	float mx, my;
	hge->Input_GetMousePos(&mx,&my);
	lua_pushnumber(luaVM, mx);
	lua_pushnumber(luaVM, my);
	return 2;
}

int l_Gfx_updateAnimation( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"Gfx_updateAnimation\" (one expected : anim name)");
	}
	if (!lua_isstring(luaVM, 1))
		mlua_printError("Argument of Gfx_updateAnimation must be a string (anim name)");
	mSceneMgr->mlua_animList[lua_tostring(luaVM, 1)]->Update(mSceneMgr->dt);

	return 0;
}

int l_Gfx_renderAnimation( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 6)
	{
		mlua_printError("Too few arguments in \"Gfx_renderAnimation\" (6 expected : anim name, x, y, angle, horizontal scale, vertical scale)");
	}
	if (!lua_isstring(luaVM, 1))
		mlua_printError("Argument 1 of Gfx_renderAnimation must be a string (anim name)");
	if (!lua_isnumber(luaVM, 2))
		mlua_printError("Argument 2 of Gfx_renderAnimation must be a number (x)");
	if (!lua_isnumber(luaVM, 3))
		mlua_printError("Argument 3 of Gfx_renderAnimation must be a number (y)");
	if (!lua_isnumber(luaVM, 4))
		mlua_printError("Argument 4 of Gfx_renderAnimation must be a number (angle)");
	if (!lua_isnumber(luaVM, 5))
		mlua_printError("Argument 5 of Gfx_renderAnimation must be a number (horizontal scale)");
	if (!lua_isnumber(luaVM, 6))
		mlua_printError("Argument 6 of Gfx_renderAnimation must be a number (vertical scale)");
	hgeAnimation* a = mSceneMgr->mlua_animList[lua_tostring(luaVM, 1)];
	a->RenderEx
	(
		lua_tonumber(luaVM, 2),
		lua_tonumber(luaVM, 3),
		lua_tonumber(luaVM, 4),
		lua_tonumber(luaVM, 5),
		lua_tonumber(luaVM, 6)
	);

	return 0;
}

int l_Gfx_createPSys( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		mlua_printError("Too few arguments in \"Gfx_createPSys\" (3 expected : psys name, file, sprite)");
	}
	if (!lua_isstring(luaVM, 1))
		mlua_printError("Argument 1 of Gfx_createPSys must be a string (psys name)");
	if (!lua_isstring(luaVM, 2))
		mlua_printError("Argument 2 of Gfx_createPSys must be a string (file)");
	if (!lua_isstring(luaVM, 3))
		mlua_printError("Argument 3 of Gfx_createPSys must be a string (sprite)");

	hgeSprite* spr = mSceneMgr->mlua_spriteList[lua_tostring(luaVM, 3)];
	mSceneMgr->mlua_psysList[lua_tostring(luaVM, 1)] = mSceneMgr->createPSys(lua_tostring(luaVM, 2), spr);

	lua_pushstring(luaVM, lua_tostring(luaVM, 1));
	return 1;
}

int l_Gfx_updatePSys( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"Gfx_updatePSys\" (one expected : psys name)");
	}
	if (!lua_isstring(luaVM, 1))
		mlua_printError("Argument of Gfx_updatePSys must be a string (psys name)");

	mSceneMgr->mlua_psysList[lua_tostring(luaVM, 1)]->Update(mSceneMgr->dt);

	return 0;
}

int l_Gfx_renderPSys( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		mlua_printError("Too few arguments in \"Gfx_renderPSys\" (3 expected : psys name, x, y)");
	}
	if (!lua_isstring(luaVM, 1))
		mlua_printError("Argument 1 of Gfx_renderPSys must be a string (psys name)");
	if (!lua_isnumber(luaVM, 2))
		mlua_printError("Argument 2 of Gfx_renderPSys must be a number (x)");
	if (!lua_isnumber(luaVM, 3))
		mlua_printError("Argument 3 of Gfx_renderPSys must be a number (y)");

	hgeParticleSystem* psys = mSceneMgr->mlua_psysList[lua_tostring(luaVM, 1)];
	psys->MoveTo(lua_tonumber(luaVM, 2)-mSceneMgr->gx, lua_tonumber(luaVM, 3)-mSceneMgr->gy);
	psys->Transpose(mSceneMgr->gx, mSceneMgr->gy);
	psys->Render();

	return 0;
}

int l_Gfx_renderSprite( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 6)
	{
		mlua_printError("Too few arguments in \"Gfx_renderSprite\" (6 expected : sprite name, x, y, angle, horizontal scale, vertical scale)");
	}
	if (!lua_isstring(luaVM, 1))
		mlua_printError("Argument 1 of Gfx_renderSprite must be a string (sprite name)");
	if (!lua_isnumber(luaVM, 2))
		mlua_printError("Argument 2 of Gfx_renderSprite must be a number (x)");
	if (!lua_isnumber(luaVM, 3))
		mlua_printError("Argument 3 of Gfx_renderSprite must be a number (y)");
	if (!lua_isnumber(luaVM, 4))
		mlua_printError("Argument 4 of Gfx_renderSprite must be a number (angle)");
	if (!lua_isnumber(luaVM, 5))
		mlua_printError("Argument 5 of Gfx_renderSprite must be a number (horizontal scale)");
	if (!lua_isnumber(luaVM, 6))
		mlua_printError("Argument 6 of Gfx_renderSprite must be a number (vertical scale)");

	hgeSprite* spr = mSceneMgr->mlua_spriteList[lua_tostring(luaVM, 1)];
	spr->RenderEx
	(
		lua_tonumber(luaVM, 2),
		lua_tonumber(luaVM, 3),
		lua_tonumber(luaVM, 4),
		lua_tonumber(luaVM, 5),
		lua_tonumber(luaVM, 6)
	);

	return 0;
}

int l_Gfx_createSprite( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 9)
	{
		mlua_printError("Too few arguments in \"Gfx_createSprite\" (9 expected : sprite name, texture file, generate mipmaps, x offset, y offset, width, height, x hot spot, y hot spot)");
		return 0;
	}
	else
	{
		if (!lua_isstring(luaVM, 1))
			mlua_printError("Argument 1 of Gfx_createSprite must be a string (sprite name)");

		string sName = lua_tostring(luaVM, 1);
		if (mSceneMgr->mlua_spriteList.find(sName) != mSceneMgr->mlua_spriteList.end())
		{
    		mlua_printError("A sprite with the name " + sName + " already exists");
    		lua_pushstring(luaVM, sName.c_str());
    		return 1;
		}

		if (!lua_isstring(luaVM, 2))
			mlua_printError("Argument 2 of Gfx_createSprite must be a string (texture file)");
		if (!lua_isboolean(luaVM, 3))
			mlua_printError("Argument 3 of Gfx_createSprite must be a bool (generate mipmaps)");
		if (!lua_isnumber(luaVM, 4))
			mlua_printError("Argument 4 of Gfx_createSprite must be a number (x offset)");
		if (!lua_isnumber(luaVM, 5))
			mlua_printError("Argument 5 of Gfx_createSprite must be a number (y offset)");
		if (!lua_isnumber(luaVM, 8))
			mlua_printError("Argument 6 of Gfx_createSprite must be a number (x hot spot)");
		if (!lua_isnumber(luaVM, 9))
			mlua_printError("Argument 7 of Gfx_createSprite must be a number (y hot spot)");

		float w, h;
		HTEXTURE tex = mSceneMgr->loadTexture
		(
			lua_tostring(luaVM, 2),
			lua_toboolean(luaVM, 3)
		);
		if (lua_isnumber(luaVM, 6))
			w = lua_tonumber(luaVM, 6);
		else if (lua_isstring(luaVM, 6))
		{
			if (string(lua_tostring(luaVM, 6)) == "texw")
				w = hge->Texture_GetWidth(tex, true);
			else
				w = 0.0f;
		}
		else
			mlua_printError("Argument 6 of Gfx_createSprite must be a number or a string (width)");

		if (lua_isnumber(luaVM, 7))
			h = lua_tonumber(luaVM, 7);
		else if (lua_isstring(luaVM, 7))
		{
			if (string(lua_tostring(luaVM, 7)) == "texh")
				h = hge->Texture_GetHeight(tex, true);
			else
				h = 0.0f;
		}
		else
			mlua_printError("Argument 7 of Gfx_createSprite must be a number or a string (height)");

		mSceneMgr->mlua_spriteList[sName] = mSceneMgr->createSprite
		(
			tex,
			lua_tonumber(luaVM, 4),
			lua_tonumber(luaVM, 5),
			w,
			h
		);

		mSceneMgr->mlua_spriteList[sName]->SetHotSpot(lua_tonumber(luaVM, 8), lua_tonumber(luaVM, 9));

		lua_pushstring(luaVM, sName.c_str());
	}

	return 1;
}

int l_Gfx_createAnimation( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 11)
	{
		mlua_printError("Too few arguments in \"Gfx_createAnimation\" (11 expected : anim name, texture file, generate mipmaps, frame number, frame per second, x offset, y offset, width, height, x hot spot, y hot spot)");
		return 0;
	}
	else
	{
		if (!lua_isstring(luaVM, 1))
			mlua_printError("Argument 1 of Gfx_createAnimation must be a string (anim name)");
		string aName = lua_tostring(luaVM, 1);
		if (mSceneMgr->mlua_animList.find(aName) != mSceneMgr->mlua_animList.end())
		{
    		mlua_printError("An animation with the name " + aName + " already exists");
    		lua_pushstring(luaVM, aName.c_str());
    		return 1;
		}

		if (!lua_isstring(luaVM, 2))
			mlua_printError("Argument 2 of Gfx_createAnimation must be a string (texture file)");
		if (!lua_isboolean(luaVM, 3))
			mlua_printError("Argument 3 of Gfx_createAnimation must be a bool (generate mipmaps)");
		if (!lua_isnumber(luaVM, 4))
			mlua_printError("Argument 4 of Gfx_createAnimation must be a number (frame number)");
		if (!lua_isnumber(luaVM, 5))
			mlua_printError("Argument 5 of Gfx_createAnimation must be a number (frame per second)");
		if (!lua_isnumber(luaVM, 6))
			mlua_printError("Argument 6 of Gfx_createAnimation must be a number (x offset)");
		if (!lua_isnumber(luaVM, 7))
			mlua_printError("Argument 7 of Gfx_createAnimation must be a number (y offset)");
		if (!lua_isnumber(luaVM, 8))
			mlua_printError("Argument 8 of Gfx_createAnimation must be a number (width)");
		if (!lua_isnumber(luaVM, 9))
			mlua_printError("Argument 9 of Gfx_createAnimation must be a number (height)");
		if (!lua_isnumber(luaVM, 10))
			mlua_printError("Argument 10 of Gfx_createAnimation must be a number (x hot spot)");
		if (!lua_isnumber(luaVM, 11))
			mlua_printError("Argument 11 of Gfx_createAnimation must be a number (y hot spot)");

		HTEXTURE tex = mSceneMgr->loadTexture
		(
			lua_tostring(luaVM, 2),
			lua_toboolean(luaVM, 3)
		);
		/*hge->System_Log
		(
			"%s, %d, %.0f, %.0f, %.0f, %.0f, %.0f",
			aName.c_str(),
			(int)lua_tonumber(luaVM, 4),
			lua_tonumber(luaVM, 5),
			lua_tonumber(luaVM, 6),
			lua_tonumber(luaVM, 7),
			lua_tonumber(luaVM, 8),
			lua_tonumber(luaVM, 9)

		);*/
		mSceneMgr->mlua_animList[aName] = mSceneMgr->createAnimation
		(
			tex,
			(int)lua_tonumber(luaVM, 4),
			lua_tonumber(luaVM, 5),
			lua_tonumber(luaVM, 6),
			lua_tonumber(luaVM, 7),
			lua_tonumber(luaVM, 8),
			lua_tonumber(luaVM, 9)
		);

		mSceneMgr->mlua_animList[aName]->SetHotSpot(lua_tonumber(luaVM, 10), lua_tonumber(luaVM, 11));
		lua_pushstring(luaVM, aName.c_str());
	}

	return 1;
}

int l_Unit_spawn( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 6)
	{
		mlua_printError("Too few arguments in \"UnitSpawn\" (6 expected : unit name, x, y, level, class, speed)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSpawn must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSpawn must be a number (x)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitSpawn must be a number (y)");
		error++;
	}
	if (!lua_isnumber(luaVM, 4))
	{
		mlua_printError("Argument 4 of UnitSpawn must be a number (level)");
		error++;
	}
	if (!lua_isstring(luaVM, 5))
	{
		mlua_printError("Argument 5 of UnitSpawn must be a string (class)");
		error++;
	}
	if (!lua_isnumber(luaVM, 6))
	{
		mlua_printError("Argument 6 of UnitSpawn must be a number (speed)");
		error++;
	}

	if (error == 0)
	{
		mSceneMgr->createUnit
		(
			lua_tostring(luaVM, 1),
			lua_tonumber(luaVM, 2),
			lua_tonumber(luaVM, 3),
			(int)lua_tonumber(luaVM, 4),
			mSceneMgr->getClass(lua_tostring(luaVM, 5)),
			lua_tonumber(luaVM, 6)
		);
		mSceneMgr->forceUpdate();
	}
	return 0;
}

int l_Unit_addEffect( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitAddEffect\" (2 expected : unit name, effect name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitAddEffect must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitAddEffect must be a string (effect name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				string fx = lua_tostring(luaVM, 2);
				if (mSceneMgr->FXList.find(fx) == mSceneMgr->FXList.end())
					hge->System_Log("# ERROR # : Unknown effect \"%s\"", fx.c_str());
				else
					u->addEffect(fx);
			}
		}
	}
	return 0;
}

int l_Unit_setHostile( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitSetHostile\" (2 expected : unit name, hostile)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSetHostile must be a string (unit name)");
		error++;
	}
	if (!lua_isboolean(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSetHostile must be a bool (hostile)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
				u->setHostile(lua_toboolean(luaVM, 2));
		}
	}
	return 0;
}

int l_Unit_setMaxHP( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		mlua_printError("Too few arguments in \"UnitSetMaxHP\" (3 expected : unit name, hp, fill to max)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSetMaxHP must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSetMaxHP must be a number (hp)");
		error++;
	}
	if (!lua_isboolean(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitSetMaxHP must be a bool (fill to max)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
				u->setMaxHealth(lua_tonumber(luaVM, 2), lua_toboolean(luaVM, 3));
		}
	}
	return 0;
}

int l_Unit_setAggroRange( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitSetAggroRange\" (2 expected : unit name, aggro range)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSetAggroRange must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSetAggroRange must be a number (aggro range)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
				u->setAggroRange(lua_tonumber(luaVM, 2));
		}
	}
	return 0;
}

int l_Unit_getMaxMana( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitMaxMana\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitMaxMana must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				float mmana = u->getMaxMana();
				lua_pushnumber(luaVM, mmana);
			}
			else
				lua_pushnumber(luaVM, 1);
		}
		else
			lua_pushnumber(luaVM, 1);
	}
	return 1;
}

int l_Unit_getMaxHealth( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitMaxHealth\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitMaxHealth must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				float mhealth = u->getMaxHealth();
				lua_pushnumber(luaVM, mhealth);
			}
			else
				lua_pushnumber(luaVM, 1);
		}
		else
			lua_pushnumber(luaVM, 1);
	}
	return 1;
}

int l_Unit_getMana( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitMana\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitMana must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				float mana = u->getMana();
				lua_pushnumber(luaVM, mana);
			}
			else
				lua_pushnumber(luaVM, 0);
		}
		else
			lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_getLevel( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitLevel\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitLevel must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				int lvl = u->getLvl();
				lua_pushnumber(luaVM, lvl);
			}
			else
				lua_pushnumber(luaVM, 0);
		}
		else
			lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_getHealth( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitHealth\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitHealth must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				float health = u->getHealth();
				lua_pushnumber(luaVM, health);
			}
			else
				lua_pushnumber(luaVM, 0);
		}
		else
			lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_getPowerType( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitPowerType\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitPowerType must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				int p = u->getPowerType();
				lua_pushnumber(luaVM, p);
			}
		}
	}
	return 1;
}

int l_Unit_getY( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitY\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitY must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				float y = u->getGY();
				lua_pushnumber(luaVM, y);
			}
			else
				lua_pushnumber(luaVM, 0);
		}
		else
			lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_getX( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitX\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitX must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				float x = u->getGX();
				lua_pushnumber(luaVM, x);
			}
			else
				lua_pushnumber(luaVM, 0);
		}
		else
			lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_getTarget( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitTarget\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitTarget must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				Unit* t = u->getTarget();
				if (t != NULL)
				{
					string str = t->getName().c_str();
					lua_pushstring(luaVM, str.c_str());
				}
				else
					lua_pushnil(luaVM);
			}
			else
				lua_pushnil(luaVM);
		}
		else
			lua_pushnil(luaVM);
	}
	return 1;
}

int l_Unit_isTargetInRange( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitIsTargetInRange\" (2 expected : unit name, spell name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitIsTargetInRange must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitIsTargetInRange must be a string (spell name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		string sname = lua_tostring(luaVM, 2);
		if ( (uname != "") && (sname != "") )
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				Spell* s = &mSceneMgr->spellList[sname];
				if (s->name != "")
				{
					bool r = u->isTargetInRange(s);
					lua_pushboolean(luaVM, r);
				}
				else
					lua_pushboolean(luaVM, false);
			}
			else
				lua_pushboolean(luaVM, false);
		}
		else
			lua_pushboolean(luaVM, false);
	}
	return 1;
}

int l_Unit_isDead( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitIsDead\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitIsDead must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				bool d = u->isDead();
				lua_pushboolean(luaVM, d);
			}
			else
				lua_pushboolean(luaVM, false);
		}
		else
			lua_pushboolean(luaVM, false);
	}
	return 1;
}

int l_Unit_isHostile( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitIsHostile\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitIsHostile must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				bool h = u->isHostile();
				lua_pushboolean(luaVM, h);
			}
			else
				lua_pushboolean(luaVM, false);
		}
		else
			lua_pushboolean(luaVM, false);
	}
	return 1;
}

int l_Unit_setTarget( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitSetTarget\" (2 expected : unit name, target name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSetTarget must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSetTarget must be a string (target name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		string tname = lua_tostring(luaVM, 2);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
				u->target(mSceneMgr->getUnitByName(tname));
		}
	}

	return 0;
}

int l_Unit_setX( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitSetX\" (2 expected : unit name, x)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSetX must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSetX must be a string (x)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
				u->setX(lua_tonumber(luaVM, 2));
		}
	}

	return 0;
}

int l_Unit_setY( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitSetY\" (2 expected : unit name, y)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSetY must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSetY must be a number (y)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
				u->setY(lua_tonumber(luaVM, 2));
		}
	}

	return 0;
}

int l_Unit_addItem( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitAddItem\" (2 expected : unit name, item id)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitAddItem must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitAddItem must be a number (item id)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
				u->getInventory()->addItem(mSceneMgr->parseItem(toInt(lua_tonumber(luaVM, 2))));
		}
	}
	return 0;
}

int l_Unit_getActionTexture( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitGetActionTexture\" (2 expected : unit name, action id)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitGetActionTexture must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitGetActionTexture must be a number (action id)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				int i = toInt(lua_tonumber(luaVM, 2));
				if ( (i <= 120) && (i >= 0) )
				{
					ActionButton ab = u->getABList()[i];
					if (ab.spell != NULL)
					{
						if (ab.type == GUI_CASTBUTTON_SPELL)
						{
							lua_pushstring(luaVM, ab.spell->iconPath.c_str());
						}
						else if (ab.type == GUI_CASTBUTTON_STOP)
							lua_pushstring(luaVM, "Icons/stop.png");
						else
							lua_pushstring(luaVM, "");
					}
					else
						lua_pushstring(luaVM, "");

				}
				else
					lua_pushstring(luaVM, "");
			}
			else
				lua_pushstring(luaVM, "");
		}
		else
			lua_pushstring(luaVM, "");
	}
	else
		lua_pushstring(luaVM, "");

	return 1;
}

int l_Unit_getActionInfo( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitGetActionInfo\" (2 expected : unit name, action id)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitGetActionInfo must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitGetActionInfo must be a number (action id)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mSceneMgr->getUnitByName(uname);
			if (u != NULL)
			{
				int i = toInt(lua_tonumber(luaVM, 2));
				if ( (i <= 120) && (i >= 0) )
				{
					ActionButton ab = u->getABList()[i];
					if (ab.spell != NULL)
					{
						if (ab.type == GUI_CASTBUTTON_SPELL)
						{
							lua_pushstring(luaVM, "spell");
						}
						else if (ab.type == GUI_CASTBUTTON_STOP)
							lua_pushstring(luaVM, "stop");
						else
							lua_pushstring(luaVM, "");
					}
					else
						lua_pushstring(luaVM, "");

				}
				else
					lua_pushstring(luaVM, "");
			}
			else
				lua_pushstring(luaVM, "");
		}
		else
			lua_pushstring(luaVM, "");
	}
	else
		lua_pushstring(luaVM, "");

	return 1;
}

int l_Unit_castSpell( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitCastSpell\" (3 expected : unit name, spell id, spell book)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitCastSpell must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitCastSpell must be a number (spell id)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitCastSpell must be a string (spell book)");
		error++;
	}

	if (error == 0)
	{
		int spellID = toInt(lua_tonumber(luaVM, 2));
		if ( (spellID >= 0) && (spellID <= 120) )
		{
			Unit* u = &mSceneMgr->unitList[lua_tostring(luaVM, 1)];
			if (u != NULL)
			{
				ActionButton* ab = &u->getABList()[spellID];
				Spell* s = ab->spell;
				if (s != NULL)
				{
					Unit* t = u->getTarget();
					if (t != NULL)
					{
						if (ab->type == GUI_CASTBUTTON_SPELL)
						{
							string reason;
							if (u->isCastable(s, &reason))
							{
								u->stop();
								if (s->self_only)
									u->incant(s, u);
								else
									u->incant(s, t);
							}
							else
								mSceneMgr->addErrorMessage(u->getName() + " : " + mSceneMgr->strTable->GetString(reason.c_str()));
						}
						else if (ab->type == GUI_CASTBUTTON_STOP)
						{
							u->stop();
						}
					}
					else
					{
						if (ab->type == GUI_CASTBUTTON_SPELL)
						{
							string reason;
							if (u->isCastable(s, &reason, true, true))
							{
								mSceneMgr->castedButton = ab;
								mSceneMgr->casterUnit = u;

								if (!s->self_only)
									mSceneMgr->castingSpell = true;

								if (s->self_only)
								{
									u->stop();
									u->incant(s, u);
								}
								else
									mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action_imp");
							}
							else
								mSceneMgr->addErrorMessage(u->getName() + " : " + mSceneMgr->strTable->GetString(reason.c_str()));
						}
						else if (ab->type == GUI_CASTBUTTON_STOP)
						{
							u->stop();
						}
					}
				}
			}
		}
	}

	return 0;
}

int l_Unit_castSpellIndirect( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitCastSpellIndirect\" (3 expected : unit name, spell id, spell book)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitCastSpellIndirect must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitCastSpellIndirect must be a number (spell id)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitCastSpellIndirect must be a string (spell book)");
		error++;
	}

	if (error == 0)
	{
		int spellID = toInt(lua_tonumber(luaVM, 2));
		if ( (spellID >= 0) && (spellID <= 120) )
		{
			Unit* u = &mSceneMgr->unitList[lua_tostring(luaVM, 1)];
			if (u != NULL)
			{
				ActionButton* ab = &u->getABList()[spellID];
				Spell* s = ab->spell;
				if (s != NULL)
				{
					if (ab->type == GUI_CASTBUTTON_SPELL)
					{
						string reason;
						if (u->isCastable(s, &reason, true, true))
						{
							mSceneMgr->castedButton = ab;
							mSceneMgr->casterUnit = u;

							if (!s->self_only)
								mSceneMgr->castingSpell = true;

							if (s->self_only)
							{
								u->stop();
								u->incant(s, u);
							}
							else
								mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action_imp");
						}
						else
							mSceneMgr->addErrorMessage(u->getName() + " : " + mSceneMgr->strTable->GetString(reason.c_str()));
					}
					else if (ab->type == GUI_CASTBUTTON_STOP)
					{
						u->stop();
					}
				}
			}
		}
	}

	return 0;
}

int l_Unit_isCasting( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitIsCasting\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitIsCasting must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (mSceneMgr->unitList.find(uname) != mSceneMgr->unitList.end())
		{
			Unit* u = &mSceneMgr->unitList[uname];
			if(u->isCasting())
			{
				if (!u->getSpell()->channeled)
				{
					lua_pushstring(luaVM, "SPELL");
				}
				else
				{
					lua_pushstring(luaVM, "CHANNELED");
				}
			}
			else
				lua_pushstring(luaVM, "");
		}
		else
			lua_pushstring(luaVM, "");
	}
	else
		lua_pushstring(luaVM, "");

	return 1;
}

int l_Unit_castingInfo( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitCastingInfo\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitCastingInfo must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (mSceneMgr->unitList.find(uname) != mSceneMgr->unitList.end())
		{
			Unit* u = &mSceneMgr->unitList[uname];
			if (u->isCasting())
			{
				Spell* s = u->getSpell();
				lua_pushstring(luaVM, s->name.c_str());
				if (s->rank != -1)
					lua_pushstring(luaVM, string(string(mSceneMgr->strTable->GetString("gui_cb_rank")) + string(" ") + toString(s->rank)).c_str());
				else
					lua_pushstring(luaVM, "");
				lua_pushstring(luaVM, mSceneMgr->strTable->GetString(s->display_name.c_str()));
				lua_pushstring(luaVM, s->iconPath.c_str());
				lua_pushnumber(luaVM, (getTime()-u->getActionState()*s->cast_time)*1000);
				lua_pushnumber(luaVM, (getTime()+(1-u->getActionState())*s->cast_time)*1000);
			}
			else
			{
				for (int i = 0; i < 6; i++)
					lua_pushnil(luaVM);
			}
		}
		else
		{
			for (int i = 0; i < 6; i++)
				lua_pushnil(luaVM);
		}
	}
	else
	{
		for (int i = 0; i < 6; i++)
			lua_pushnil(luaVM);
	}

	return 6;
}

int l_Unit_getSpellInfo( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitSpellInfo\" (2 expected : unit name, spell id)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSpellInfo must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSpellInfo must be a number (spell id)");
		error++;
	}

	if (error == 0)
	{
		int spellID = toInt(lua_tonumber(luaVM, 2));
		if ( (spellID >= 0) && (spellID <= 120) )
		{
			Unit* u = &mSceneMgr->unitList[lua_tostring(luaVM, 1)];
			if (u != NULL)
			{
				ActionButton* ab = &u->getABList()[spellID];
				if (ab != NULL)
				{
					Spell* s = ab->spell;
					if (s != NULL)
					{
						lua_getglobal(luaVM, "Spells");
						lua_getfield(luaVM, -1, s->name.c_str());
					}
					else
						lua_pushnil(luaVM);
				}
				else
					lua_pushnil(luaVM);
			}
			else
				lua_pushnil(luaVM);
		}
		else
			lua_pushnil(luaVM);
	}
	else
		lua_pushnil(luaVM);

	return 1;
}

int l_Unit_setAttacking( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitSetAttacking\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitSetAttacking must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (mSceneMgr->unitList.find(uname) != mSceneMgr->unitList.end())
		{
			Unit* u = &mSceneMgr->unitList[uname];
			u->attacking = true;
			mSceneMgr->attackerList[u->getName()] = u;
			mSceneMgr->actingList[u->getName()] = u;
		}
	}

	return 0;
}

int l_Unit_setHealing( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitSetHealing\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitSetHealing must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (mSceneMgr->unitList.find(uname) != mSceneMgr->unitList.end())
		{
			Unit* u = &mSceneMgr->unitList[uname];
			u->healing = true;
			mSceneMgr->healerList[u->getName()] = u;
			mSceneMgr->actingList[u->getName()] = u;
		}
	}

	return 0;
}

int l_Unit_setResurrecting( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitSetResurrecting\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitSetResurrecting must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (mSceneMgr->unitList.find(uname) != mSceneMgr->unitList.end())
		{
			Unit* u = &mSceneMgr->unitList[uname];
			u->resurrecting = true;
			mSceneMgr->reserList[u->getName()] = u;
			mSceneMgr->actingList[u->getName()] = u;
		}
	}

	return 0;
}

int l_Unit_damage( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 6)
	{
		mlua_printError("Too few arguments in \"UnitDamage\" (6 expected : unit name, caster name, damages, school, generate aggro, scrolling text)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitDamage must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitDamage must be a string (caster name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitDamage must be a number (dammages)");
		error++;
	}
	if (!lua_isnumber(luaVM, 4))
	{
		mlua_printError("Argument 4 of UnitDamage must be a number (school)");
		error++;
	}
	if (!lua_isboolean(luaVM, 5))
	{
		mlua_printError("Argument 5 of UnitDamage must be a bool (generate aggro)");
		error++;
	}
	if (!lua_isboolean(luaVM, 6))
	{
		mlua_printError("Argument 6 of UnitDamage must be a bool (scrolling text)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		string cname = lua_tostring(luaVM, 2);
		if (mSceneMgr->unitList.find(uname) != mSceneMgr->unitList.end())
		{
			if (mSceneMgr->unitList.find(cname) != mSceneMgr->unitList.end())
			{
				Unit* u = &mSceneMgr->unitList[uname];
				Unit* c = &mSceneMgr->unitList[cname];
				int value = toInt(lua_tonumber(luaVM, 3));
				int school = toInt(lua_tonumber(luaVM, 4));
				u->damage(c, value, school, lua_toboolean(luaVM, 5));

				int type;
				if (school == SPELL_SCHOOL_NONE)
					type = GUI_SCRTXT_TYPE_PHYSICAL;
				else
					type = GUI_SCRTXT_TYPE_SPELL;

				if (lua_toboolean(luaVM, 6))
					mSceneMgr->addScrollingText(u, type, toString(value));
			}
		}
	}

	return 0;
}

int l_Unit_heal( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 5)
	{
		mlua_printError("Too few arguments in \"UnitHeal\" (5 expected : unit name, caster name, healings, generate aggro, scrolling text)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitHeal must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitHeal must be a string (caster name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitHeal must be a number (healings)");
		error++;
	}
	if (!lua_isboolean(luaVM, 4))
	{
		mlua_printError("Argument 4 of UnitHeal must be a bool (generate aggro)");
		error++;
	}
	if (!lua_isboolean(luaVM, 5))
	{
		mlua_printError("Argument 5 of UnitHeal must be a bool (scrolling text)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		string cname = lua_tostring(luaVM, 2);
		if (mSceneMgr->unitList.find(uname) != mSceneMgr->unitList.end())
		{
			if (mSceneMgr->unitList.find(cname) != mSceneMgr->unitList.end())
			{
				Unit* u = &mSceneMgr->unitList[uname];
				Unit* c = &mSceneMgr->unitList[cname];
				int value = toInt(lua_tonumber(luaVM, 3));
				u->heal(c, value, lua_toboolean(luaVM, 4));
				if (lua_toboolean(luaVM, 5))
					mSceneMgr->addScrollingText(u, GUI_SCRTXT_TYPE_HEAL, toString(value));
			}
		}
	}

	return 0;
}

int l_Unit_res( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 4)
	{
		mlua_printError("Too few arguments in \"UnitRes\" (4 expected : unit name, caster name, health gained, mana gained)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitRes must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitRes must be a string (caster name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitRes must be a number (health gained)");
		error++;
	}
	if (!lua_isnumber(luaVM, 4))
	{
		mlua_printError("Argument 4 of UnitRes must be a number (mana gained)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		string cname = lua_tostring(luaVM, 2);
		if (mSceneMgr->unitList.find(uname) != mSceneMgr->unitList.end())
		{
			if (mSceneMgr->unitList.find(cname) != mSceneMgr->unitList.end())
			{
				Unit* u = &mSceneMgr->unitList[uname];
				Unit* c = &mSceneMgr->unitList[cname];
				int health = toInt(lua_tonumber(luaVM, 3));
				int mana = toInt(lua_tonumber(luaVM, 4));
				u->res(health, mana, c);
			}
		}
	}

	return 0;
}

int l_Unit_addBuff( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		mlua_printError("Too few arguments in \"UnitAddBuff\" (3 expected : unit name, caster name, buff)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitAddBuff must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitAddBuff must be a string (caster name)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitAddBuff must be a string (buff)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		string cname = lua_tostring(luaVM, 2);
		if (mSceneMgr->unitList.find(uname) != mSceneMgr->unitList.end())
		{
			if (mSceneMgr->unitList.find(cname) != mSceneMgr->unitList.end())
			{
				Unit* u = &mSceneMgr->unitList[uname];
				Unit* c = &mSceneMgr->unitList[cname];

				u->addBuff(lua_tostring(luaVM, 3));
			}
		}
	}

	return 0;
}

int l_Unit_getBuffs( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitGetBuffs\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitGetBuff must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (mSceneMgr->unitList.find(uname) != mSceneMgr->unitList.end())
		{
			Unit* u = &mSceneMgr->unitList[uname];
			multimap<float, Buff*> buffList = u->getBuffList();
			lua_pushnumber(luaVM, buffList.size());

			lua_newtable(luaVM);
			multimap<float, Buff*>::iterator iterBuff;
			int i = 1;
			for (iterBuff = buffList.begin(); iterBuff != buffList.end(); iterBuff++)
			{
				Buff* b = iterBuff->second;
				lua_createtable(luaVM, 0, 2);
				mlua_setFieldFloat("time_remaining", b->buff->duration-b->life, luaVM);
				mlua_setFieldInt("count", b->count, luaVM);
				mlua_setFieldString("icon", b->buff->icon_file, luaVM);
				lua_rawseti(luaVM, -2, i);
			}
		}
	}

	return 2;
}

int l_GUI_createElement( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"GUI_createElement\" (one expected : element name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of GUI_createElement must be a string (element name)");
		error++;
	}

	if (error == 0)
	{
		if (mSceneMgr->guiList.find(lua_tostring(luaVM, 1)) == mSceneMgr->guiList.end())
		{
			string name = lua_tostring(luaVM, 1);
			if (name != "")
			{
				GUIElement g;
				mSceneMgr->guiList[name] = g;
			}
		}

		lua_pushstring(luaVM, lua_tostring(luaVM, 1));
		return 1;
	}
	else
		return 0;
}

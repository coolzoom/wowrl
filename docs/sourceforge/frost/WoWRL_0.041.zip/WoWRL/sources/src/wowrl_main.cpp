/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               Main source              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_scenemanager.h"
#include "wowrl_fontmanager.h"
#include "wowrl_unit.h"
#include "wowrl_projectile.h"
#include "wowrl_point.h"
#include "wowrl_global.h"
#include "wowrl_pathfinding.h"
#include "wowrl_collision.h"
#include "wowrl_distortion.h"
#include "wowrl_doodad.h"
#include "wowrl_statusbar.h"
#include "wowrl_structs.h"
#include "wowrl_tooltip.h"
#include "wowrl_lua.h"
#include "wowrl_effect.h"
#include "wowrl_gui.h"

#include <math.h>
#include <string>

using namespace std;

// Global variables
HGE *hge = 0;
SceneManager* mSceneMgr;
FontManager* mFontMgr;
KeyHandler myKeyHandler;
float dt;
float dx=0.0f, dy=0.0f; // Global variations
const float speed=400; // Speed factor
float pSpeed=150.0f; // Player speed
float timerAlpha;
float timerUpdtateRender=0.0f;
float timerPSys=0.0f;
float timerRender=0.0f;
float button_scale=0.625f;
bool ctrlPressed=false;
bool shiftPressed=false;
bool altPressed=false;
bool castingSpell=false;
Unit* targetUnit=NULL;
bool castable=false;
bool panning=false;
int loaderState=0;
bool jumpToNextState=false;

// Debug bools
bool debugZ=false;
bool spawned=false;
int uNbr=0;

// Temp

// System
//Cursor*				cursor;
hgeSprite*   		pixel; // Pixel sprite
hgeSprite*   		particle;
hgeFont*            systemFont;

// Bouding boxes and stuff to prevent the background to fly out of the screen
hgeRect*            bgRect = new hgeRect(); // Background Rect
hgeRect*            screenLRect; // Top Left BB
hgeRect*            screenTRect; // Top Right BB
hgeRect*            screenRRect; // Bottom Right BB
hgeRect*            screenBRect; // Bottom Left BB
bool screenLInt; // Checks intersection between BG's BB and Left BB
bool screenTInt; // Checks intersection between BG's BB and Top BB
bool screenRInt; // Checks intersection between BG's BB and Right BB
bool screenBInt; // Checks intersection between BG's BB and Bottom BB

// Bounding boxes and stuff for clicking
hgeRect*            mouseRect = new hgeRect(); // Mouse BB for click detection
hgeRect*            selectSquareRect = new hgeRect(); // Selection square's BB
bool selected=false;
bool squareSelection=false;
bool RenderSquare=false;
float squarex, squarey, squareXScale, squareYScale;
hgeVector mouseVec;

// Stuff for orders
bool orderGiven=false;

// Stuff for collision
bool destCollides=true;

// Background variables
float bgx=0, bgy=0; // BG initial pos and scale

// Bools and stuff for mouse input
int mRState;
int mLState;
float mSpeed=500.0f;
float mx=0, my=0; //mz=0; // Mouse pos and wheel state
float gmx=0,  gmy=0; // Global mouse pos (= mouse pos - global pos)
float dmx=0.0f, dmy=0.0f; //dmz=0.0f; // Mouse pos and wheel variation
float mx_old=0, my_old=0; // Old mouse pos, used to calculate the variation
float curx=0, cury=0; // Cursor pos

// Function called by HGE once per frame.
bool FrameFunc()
{
	if (myKeyHandler.keyIsPressed(HGEK_ESCAPE))
		return true;

	switch (mSceneMgr->gameState)
	{
/********************************/
		case GAME:
/********************************/
		{
			/* --------------------------------------------- */
			/* Get inputs and store them in global variables */
			/* --------------------------------------------- */

			dt = hge->Timer_GetDelta();
			mSceneMgr->dt = dt;

			// Get wheel state, not used atm
			//mz = hge->Input_GetMouseWheel();

			// Get mouse pos
			hge->Input_GetMousePos(&mx,&my);
			dmx = mx_old-mx;
			dmy = my_old-my;
			mx_old = mx;
			my_old = my;

			// Cursor pos
			curx=mx;
			cury=my;

			if (myKeyHandler.keyIsDown(HGEK_CTRL))
			{
				ctrlPressed = true;
			}
			else
				ctrlPressed = false;

			if (myKeyHandler.keyIsDown(HGEK_SHIFT))
			{
				shiftPressed = true;
			}
			else
				shiftPressed = false;

			if (myKeyHandler.keyIsDown(HGEK_ALT))
			{
				altPressed = true;
			}
			else
				altPressed = false;

			// Handle left mouse button
			if (myKeyHandler.keyIsDown(HGEK_LBUTTON))
			{
				if (myKeyHandler.keyIsPressed(HGEK_LBUTTON))
					mLState = 2; // single pressed
				else if(myKeyHandler.keyIsDoubleClicked(HGEK_LBUTTON))
					mLState = 4; // double clicked
				else
					mLState = 1; // dragged

				mSceneMgr->mouseButton = "LeftButton";
			}
			else if (myKeyHandler.keyIsReleased(HGEK_LBUTTON))
			{
				mLState = 3; // released
				mSceneMgr->mouseButton = "LeftButton";
			}
			else
			{
				mLState = 0; // no input
				if (mRState == 0)
					mSceneMgr->mouseButton = "";
			}

			// Handle right mouse button
			if (myKeyHandler.keyIsDown(HGEK_RBUTTON))
			{
				if (myKeyHandler.keyIsPressed(HGEK_RBUTTON))
					mRState = 2;
				else if (myKeyHandler.keyIsDoubleClicked(HGEK_RBUTTON))
					mRState = 4;
				else
					mRState = 1;

				if (mSceneMgr->mouseButton == "LeftButton")
					mSceneMgr->mouseButton = "BothButtons";
				else
					mSceneMgr->mouseButton = "RightButton";
			}
			else if (myKeyHandler.keyIsReleased(HGEK_RBUTTON))
			{
				mRState = 3;
				if (mSceneMgr->mouseButton == "LeftButton")
					mSceneMgr->mouseButton = "BothButtons";
				else
					mSceneMgr->mouseButton = "RightButton";
			}
			else
			{
				mRState = 0;
				if (mLState == 0)
					mSceneMgr->mouseButton = "";
			}

			if (myKeyHandler.keyIsPressed(HGEK_DELETE))
			{
				// Kill selected
				if (selected)
				{
					map<string, Unit*>::iterator iter;
					while (mSceneMgr->selectedList.empty() == false)
					{
						iter = mSceneMgr->selectedList.begin();
						iter->second->die();
					}
					selected = false;
				}
			}

			if (myKeyHandler.keyIsPressed(HGEK_NUMPAD1))
			{
				// Spawn a mage
				if (!spawned)
				{
					uNbr++;
					Unit* u = mSceneMgr->createUnit("Player"+toString(uNbr), gmx, gmy, hge->Random_Int(1,70), mSceneMgr->getClass("mage"), pSpeed);
					mSceneMgr->forceUpdate();
					spawned = true;
				}
			}
			else
				spawned = false;

			if (myKeyHandler.keyIsPressed(HGEK_NUMPAD2))
			{
				// Spawn a hunter
				if (!spawned)
				{
					uNbr++;
					Unit* u = mSceneMgr->createUnit("Player"+toString(uNbr), gmx, gmy, hge->Random_Int(1,70), mSceneMgr->getClass("hunter"), pSpeed);
					mSceneMgr->forceUpdate();
					spawned = true;
				}
			}
			else
				spawned = false;

			if (myKeyHandler.keyIsPressed(HGEK_NUMPAD3))
			{
				// Spawn a priest
				if (!spawned)
				{
					uNbr++;
					Unit* u = mSceneMgr->createUnit("Player"+toString(uNbr), gmx, gmy, hge->Random_Int(1,70), mSceneMgr->getClass("priest"), pSpeed);
					mSceneMgr->forceUpdate();
					spawned = true;
				}
			}
			else
				spawned = false;

			if (myKeyHandler.keyIsPressed(HGEK_C))
			{
				if (selected)
				{
					map<string, Unit*>::iterator iter;
					for (iter = mSceneMgr->selectedList.begin(); iter != mSceneMgr->selectedList.end(); iter++)
					{
						if (!iter->second->isDead())
							iter->second->setInCombat();
					}
				}
			}

			if (myKeyHandler.keyIsPressed(HGEK_T))
			{
				int error = luaL_dofile(mSceneMgr->luaVM, "Scripts/test.lua");
				if (error) l_logPrint(mSceneMgr->luaVM);
			}

			if (myKeyHandler.keyIsPressed(HGEK_PAUSE))
			{
				mSceneMgr->gamePaused = !mSceneMgr->gamePaused;
			}

			if (myKeyHandler.keyIsPressed(HGEK_H))
			{
				if (selected)
				{
					map<string, Unit*>::iterator iter;
					while (mSceneMgr->selectedList.empty() == false)
					{
						iter = mSceneMgr->selectedList.begin();
						if (!iter->second->isDead())
						{
							iter->second->setHostile(true);
						}
						else
						{
							iter->second->setSelected(false);
						}
					}
					selected = false;
				}
			}

			if (myKeyHandler.keyIsPressed(HGEK_S) && shiftPressed)
			{
				mSceneMgr->showEnemiesStatusBars = !mSceneMgr->showEnemiesStatusBars;
			}
			else if (myKeyHandler.keyIsPressed(HGEK_S))
			{
				mSceneMgr->showStatusBars = !mSceneMgr->showStatusBars;
			}

			if (myKeyHandler.keyIsPressed(HGEK_G))
			{
				map<float, Object>::iterator iter;
				for (iter = mSceneMgr->zSortedList.begin(); iter != mSceneMgr->zSortedList.end(); iter++)
				{
					if (iter->second.type == UNIT)
					{
						Unit *u = static_cast<Unit*>(iter->second.ptr);
						if (u->isSelected())
							hge->System_Log("[%f] %s (S)", iter->first, u->getName().c_str());
						else
							hge->System_Log("[%f] %s", iter->first, u->getName().c_str());
					}
					else if (iter->second.type == DOODAD)
					{
						Doodad *d = static_cast<Doodad*>((*iter).second.ptr);
						hge->System_Log("[%f] %s", iter->first, d->name.c_str());
					}
				}
				debugZ = true;
			}

			if (myKeyHandler.keyIsPressed(HGEK_U))
			{
				hge->System_Log("# GUI # :");
				hge->System_Log(" - AddOns list :");
				map<string, AddOn>::iterator iter1;
				for (iter1 = mSceneMgr->addOnList.begin(); iter1 != mSceneMgr->addOnList.end(); iter1++)
				{
					hge->System_Log("	 - %s (%d)", iter1->second.name.c_str(), iter1->second.enabled);
				}

				hge->System_Log("\n - GUIElement list :");

				map<string, GUIElement>::iterator iter2;
				for (iter2 = mSceneMgr->guiList.begin(); iter2 != mSceneMgr->guiList.end(); iter2++)
				{
					if (!iter2->second.child)
						iter2->second._print(1);
				}

				/*hge->System_Log("\n - Template list :");
				for (iter2 = mSceneMgr->templateList.begin(); iter2 != mSceneMgr->templateList.end(); iter2++)
				{
					iter2->second._print(1);
				}
				hge->System_Log(" ");*/
			}

			if (myKeyHandler.keyIsPressed(HGEK_R))
			{
				mSceneMgr->reLoadUI();
			}

			if (myKeyHandler.keyIsPressed(HGEK_B))
			{
				if (mSceneMgr->leadingUnit != NULL)
					mSceneMgr->mInventory = mSceneMgr->leadingUnit->getInventory();
			}

			// If the mouse enters a 4 pixel zone around the screen, pan the view in the direction
			// given by the mouse pointer
			mouseRect->Set(curx-2,cury-2,curx+2,cury+2); // Set the mouse BB properties

			bool mouseLInt = mouseRect->Intersect(screenLRect);
			bool mouseTInt = mouseRect->Intersect(screenTRect);
			bool mouseRInt = mouseRect->Intersect(screenRRect);
			bool mouseBInt = mouseRect->Intersect(screenBRect);

			if (mouseLInt || mouseTInt || mouseRInt || mouseBInt)
			{
				mSceneMgr->cursor = mSceneMgr->switchCursor("pan");
				mSceneMgr->cursor->rot = -1.0f;
				if (mouseLInt && !(mouseTInt && mouseRInt && mouseBInt))
				{
					mSceneMgr->cursor->rot = M_PI;
				  	dx = mSpeed*dt;
				}
				if (mouseTInt && !(mouseLInt && mouseRInt && mouseBInt))
				{
					if (mSceneMgr->cursor->rot == -1.0f)
						mSceneMgr->cursor->rot = 3*M_PI_2;
					else
						mSceneMgr->cursor->rot = (mSceneMgr->cursor->rot+3*M_PI_2)/2.0f;
				 	dy = mSpeed*dt;
				}
				if (mouseRInt && !(mouseLInt && mouseTInt && mouseBInt))
				{
					if (mSceneMgr->cursor->rot == -1.0f)
						mSceneMgr->cursor->rot = 0.0f;
					else
						mSceneMgr->cursor->rot = -M_PI_2/2.0f;
				 	dx = -mSpeed*dt;
				}
				if (mouseBInt && !(mouseLInt && mouseTInt && mouseRInt))
				{
					if (mSceneMgr->cursor->rot == -1.0f)
						mSceneMgr->cursor->rot = M_PI_2;
					else
						mSceneMgr->cursor->rot = (mSceneMgr->cursor->rot+M_PI_2)/2.0f;
				 	dy = -mSpeed*dt;
				}
				panning = true;
			}
			else
			{
				if (panning)
				{
					mSceneMgr->cursor = mSceneMgr->switchCursor("normal");
					panning = false;
				}
			}

		/* ------------------------------------------------------- */
		/* Apply the "movement" to the global values and collision */
		/* detectors.											  */
		/* ------------------------------------------------------- */

			// ## Global values
			mSceneMgr->gx += dx;
			mSceneMgr->gy += dy;
			mSceneMgr->dgx = dx;
			mSceneMgr->dgy = dy;
			gmx = mx-mSceneMgr->gx;
			gmy = my-mSceneMgr->gy;

			/*if (my > mSceneMgr->sHeight-114.0f)
			{
				mouseOverPlayField = false;
			}
			else
			{
				mouseOverPlayField = true;
			}*/

			// Detect loss of intersections between screen BBs and the background
			bgRect->x1 = mSceneMgr->gx;
			bgRect->y1 = mSceneMgr->gy;
			bgRect->x2 = mSceneMgr->gx+mSceneMgr->actualZone.w;
			bgRect->y2 = mSceneMgr->gy+mSceneMgr->actualZone.h;
			screenLInt = bgRect->Intersect(screenLRect);
			screenTInt = bgRect->Intersect(screenTRect);
			screenRInt = bgRect->Intersect(screenRRect);
			screenBInt = bgRect->Intersect(screenBRect);

			// If the background goes away from a screen bounding boxes, discard the previous changes
			if (!screenLInt)
			{
				mSceneMgr->gx -= dx;
				dx = 0;
			}
			if (!screenTInt)
			{
				mSceneMgr->gy -= dy;
				dy = 0;
			}
			if (!screenRInt)
			{
				mSceneMgr->gx -= dx;
				dx = 0;
			}
			if (!screenBInt)
			{
				mSceneMgr->gy -= dy;
				dy = 0;
			}

		/* ---------------------------------------------------- */
		/* Handle clicking : movements                          */
		/* ---------------------------------------------------- */

			// Define whether the mouse was on an obstruded zone or not
			destCollides = CheckPointCollision(toInt(gmx), toInt(gmy));

			// Parse all hostile units to define wether the mouse is hovering one
			if (mSceneMgr->mouseOverPlayField)
			{
				bool attack=false;
				Unit* target = NULL;
				mSceneMgr->newOvering = NULL;

				map<float, Unit*>::iterator iterUnit;
				for (iterUnit = mSceneMgr->zSortedUnitList.begin(); iterUnit != mSceneMgr->zSortedUnitList.end(); iterUnit++)
				{
					Unit* u = iterUnit->second;
					attack = mouseRect->Intersect(u->getBox());

					if (attack)
					{
						mSceneMgr->newOvering = u;
					}

					if (!u->isDead() && u->isHostile() && selected)
					{
						if (attack)
						{
							target = u;
							if (!panning)
								mSceneMgr->cursor = mSceneMgr->switchCursor("attack");
							break;
						}
						else
						{
							if (!panning)
								mSceneMgr->cursor = mSceneMgr->switchCursor("normal");
						}
					}
					else
						attack = false;
				}

				if ( (mSceneMgr->newOvering != mSceneMgr->lastOvering) &&
					 (!mSceneMgr->squareSelection) &&
					 (dmx != 0.0f) && (dmy != 0.0f) )
				{
					int asking = mlua_getGlobalInt("AskingForTooltip", false);
					lua_pushboolean(mSceneMgr->luaVM, true);
					lua_setglobal(mSceneMgr->luaVM, "ChangeToolTipContent");
					if (mSceneMgr->newOvering != NULL)
					{
						lua_newtable(mSceneMgr->luaVM);
						lua_setglobal(mSceneMgr->luaVM, "NewContent");
						lua_getglobal(mSceneMgr->luaVM, "NewContent");
						mlua_setFieldString("type", "unit");
						mlua_setFieldString("id", mSceneMgr->newOvering->getName());
						lua_pop(mSceneMgr->luaVM, 1);

						if (mSceneMgr->lastOvering == NULL)
						{
							asking++;
							lua_pushnumber(mSceneMgr->luaVM, asking);
							lua_setglobal(mSceneMgr->luaVM, "AskingForTooltip");
						}
					}
					else
					{
						asking--;
						lua_pushnumber(mSceneMgr->luaVM, asking);
						lua_setglobal(mSceneMgr->luaVM, "AskingForTooltip");
					}
					mSceneMgr->lastOvering = mSceneMgr->newOvering;
				}

				if ( (mRState==2) && (selected) && (!mSceneMgr->squareSelection) && (!mSceneMgr->castingSpell) )
				{
					if (altPressed) // It's a target order
					{
						if (mSceneMgr->newOvering != NULL)
						{
							map<string, Unit*>::iterator iterSelected;
							for (iterSelected = mSceneMgr->selectedList.begin(); iterSelected != mSceneMgr->selectedList.end(); iterSelected++)
							{
// TODO (Corentin#1#): Keep track of spell target => Unit manager.
								iterSelected->second->target(mSceneMgr->newOvering);
							}
						}
					}
					else
					{
						if (attack) // It's, obviously, an attack order
						{
							map<string, Unit*>::iterator iter;
							for (iter = mSceneMgr->selectedList.begin(); iter != mSceneMgr->selectedList.end(); iter++)
							{
								Unit* u = iter->second;
								if (!u->isDead())
								{
									string reason;
									if (u->isCastable(u->getDefaultSpell(), &reason, true))
									{
										if (u->isInSpellRange(target->getX(), target->getY()))
											u->incant(u->getDefaultSpell(), target);
										else
										{
											u->target(target);
											u->moveInRange(target);
											if (mSceneMgr->orderList.find(u->getName()) == mSceneMgr->orderList.end())
											{
												mSceneMgr->orderList[u->getName()] = u;
											}
										}
									}
									else
										mSceneMgr->addErrorMessage(u->getName() + " : " + mSceneMgr->strTable->GetString(reason.c_str()));
								}
							}
						}
						else // It's a movement order
						{
							if (!destCollides) // If the destination is not obstruded, set it to the mouse position
							{
								mSceneMgr->leadingUnit->destPoint.set(toInt(gmx), toInt(gmy));
							}
							else // Else define whitch is the nearest free point to go
							{
								mSceneMgr->leadingUnit->destPoint = getNearestFreePoint(mSceneMgr->leadingUnit->getGX(), mSceneMgr->leadingUnit->getGY(), toInt(gmx), toInt(gmy));
							}

							vector<Point> destPoint;
							// If Ctrl is not pressed, make several destinations
							if (!ctrlPressed)
							{
								// Get the size of the unit
								hgeRect* tmpRect = mSceneMgr->leadingUnit->getBox();
								float space = tmpRect->x2-tmpRect->x1;
								// And call the function
								destPoint = getDestPoints(mSceneMgr->leadingUnit, mSceneMgr->selectedList.size(), space);
							}
							// Else, make only one
							vector<Point>::iterator iterPoint = destPoint.begin();

							// Then parse all selected units to give them orders
							map<string, Unit*>::iterator iter;
							for (iter = mSceneMgr->selectedList.begin(); iter != mSceneMgr->selectedList.end(); iter++)
							{
								Unit *u = iter->second;
								if (!u->isDead())
								{
									u->stop();

									// If ctrl is not pressed, give this unit a unique destination
									if (!ctrlPressed)
									{
										u->destPoint = *iterPoint;
										iterPoint++;
									}
									else // Else, all units are going to the same point
									{
										u->destPoint = mSceneMgr->leadingUnit->destPoint;
									}

									// Get the path
									mSceneMgr->requestWPPath(u);
									u->pathRequested = false;
									u->pathObtained = false;
									u->following = false;
									u->followingWp = false;
									u->order = "move";

									// Add the unit to the order list
									if (mSceneMgr->orderList.find(u->getName()) == mSceneMgr->orderList.end())
									{
										mSceneMgr->orderList[u->getName()] = u;
									}

									orderGiven = true;
								}
							}
						}
					}
				}
				else if ( (mRState==2) && (mSceneMgr->castingSpell) )
				{
					mSceneMgr->castingSpell = false;
					mSceneMgr->castedButton = NULL;
				}
			}

		/* ---------------------------------------------------- */
		/* Handle clicking : selections and actions			 */
		/* ---------------------------------------------------- */

			if (mSceneMgr->castingSpell)
			{
				if (mSceneMgr->castedButton->spell->target == SPELL_TARGET_HOSTILES)
				{
					bool attack=false;
					map<string, Unit*>::iterator iterHostile;
					for (iterHostile = mSceneMgr->hostileList.begin(); iterHostile != mSceneMgr->hostileList.end(); iterHostile++)
					{
						attack = mouseRect->Intersect(iterHostile->second->getBox());
						if (attack)
						{
							targetUnit = iterHostile->second;
							mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action");
							castable = true;
							break;
						}
						else
						{
							mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action_imp");
							castable = false;
						}
					}
				}
				if (mSceneMgr->castedButton->spell->target == SPELL_TARGET_FRIENDS)
				{
					bool attack=false;
					map<string, Unit>::iterator iterUnit;
					for (iterUnit = mSceneMgr->unitList.begin(); iterUnit != mSceneMgr->unitList.end(); iterUnit++)
					{
						Unit *u = &iterUnit->second;
						if (!u->isHostile())
						{
							attack = mouseRect->Intersect(u->getBox());
							if (attack)
							{
								targetUnit = u;
								if (!panning)
									mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action");
								castable = true;
								break;
							}
							else
							{
								if (!panning)
									mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action_imp");
								castable = false;
							}
						}
					}
				}
				else if (mSceneMgr->castedButton->spell->target == SPELL_TARGET_ALL)
				{
					bool attack=false;
					map<string, Unit>::iterator iterUnit;
					for (iterUnit = mSceneMgr->unitList.begin(); iterUnit != mSceneMgr->unitList.end(); iterUnit++)
					{
						Unit *u = &iterUnit->second;
						attack = mouseRect->Intersect(u->getBox());
						if (attack)
						{
							targetUnit = u;
							if (!panning)
								mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action");
							castable = true;
							break;
						}
						else
						{
							if (!panning)
								mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action_imp");
							castable = false;
						}
					}
				}
				else if (mSceneMgr->castedButton->spell->target == SPELL_TARGET_DEADS)
				{
					bool attack=false;
					map<string, Unit*>::iterator iterDeath;
					for (iterDeath = mSceneMgr->deadList.begin(); iterDeath != mSceneMgr->deadList.end(); iterDeath++)
					{
						Unit *u = iterDeath->second;
						attack = mouseRect->Intersect(u->getBox());
						if (attack)
						{
							targetUnit = u;
							if (!panning)
								mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action");
							castable = true;
							break;
						}
						else
						{
							if (!panning)
								mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action_imp");
							castable = false;
						}
					}
				}
				else if (mSceneMgr->castedButton->spell->target == SPELL_TARGET_DEAD_FRIENDS)
				{
					bool attack=false;
					map<string, Unit*>::iterator iterDeath;
					for (iterDeath = mSceneMgr->deadList.begin(); iterDeath != mSceneMgr->deadList.end(); iterDeath++)
					{
						Unit *u = iterDeath->second;
						if (!u->isHostile())
						{
							attack = mouseRect->Intersect(u->getBox());
							if (attack)
							{
								targetUnit = u;
								if (!panning)
									mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action");
								castable = true;
								break;
							}
							else
							{
								if (!panning)
									mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action_imp");
								castable = false;
							}
						}
					}
				}
				else if (mSceneMgr->castedButton->spell->target == SPELL_TARGET_DEAD_HOSTILES)
				{
					bool attack=false;
					map<string, Unit*>::iterator iterDeath;
					for (iterDeath = mSceneMgr->deadList.begin(); iterDeath != mSceneMgr->deadList.end(); iterDeath++)
					{
						Unit *u = iterDeath->second;
						if (u->isHostile())
						{
							attack = mouseRect->Intersect(u->getBox());
							if (attack)
							{
								targetUnit = u;
								if (!panning)
									mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action");
								castable = true;
								break;
							}
							else
							{
								if (!panning)
									mSceneMgr->cursor = mSceneMgr->switchCursor("normal_action_imp");
								castable = false;
							}
						}
					}
				}
			}

			// Simple selection : only one unit is selected
			if ( (mLState == 2) && (mSceneMgr->mouseOverPlayField) )
			{
				if (!mSceneMgr->castingSpell)
				{
					if (!shiftPressed)
					{
						mSceneMgr->deselectAll();
					}
					if (ctrlPressed)
					{
						Class* c;
						map<string, Unit>::iterator iter;
						for (iter = mSceneMgr->unitList.begin(); iter != mSceneMgr->unitList.end(); iter++)
						{
							Unit *u = &(*iter).second;
							if (!u->isHostile())
							{
								if (u->getBox()->TestPoint(mx, my))
								{
									u->setSelected(true);
									c = u->getClass();
									break;
								}
							}
						}
						for (iter = mSceneMgr->unitList.begin(); iter != mSceneMgr->unitList.end(); iter++)
						{
							Unit *u = &(*iter).second;
							if (!u->isHostile())
							{
								if (u->getClass() == c)
								{
									u->setSelected(true);
								}
							}
						}
					}
					else
					{
						map<string, Unit>::iterator iter;
						for (iter = mSceneMgr->unitList.begin(); iter != mSceneMgr->unitList.end(); iter++)
						{
							Unit *u = &(*iter).second;
							if (!u->isHostile())
							{
								if (u->getBox()->TestPoint(mx, my))
								{
									if (u->isSelected())
										u->setSelected(false);
									else
										u->setSelected(true);
									break;
								}
							}
						}
					}
					if (!mSceneMgr->selectedList.empty())
						selected = true;
					else
						selected = false;
				}
				else
				{
					if (castable)
					{
						Unit* u = mSceneMgr->casterUnit;
						Unit* t = targetUnit;
						u->stop();
						u->target(t);
						string reason;
						if (u->isCastable(mSceneMgr->castedButton->spell, &reason, true))
						{
							string reason;
							if (u->isTargetInRange(mSceneMgr->castedButton->spell))
								u->incant(mSceneMgr->castedButton->spell, t);
							else
							{
								u->target(t);
								u->moveInRange(t);
								if (mSceneMgr->orderList.find(u->getName()) == mSceneMgr->orderList.end())
								{
									mSceneMgr->orderList[u->getName()] = u;
								}
							}
						}
						else
							mSceneMgr->addErrorMessage(mSceneMgr->casterUnit->getName() + " : " + mSceneMgr->strTable->GetString(reason.c_str()));

						mSceneMgr->castingSpell = false;
						castable = false;
						mSceneMgr->castedButton = NULL;
						if (!panning)
							mSceneMgr->cursor = mSceneMgr->switchCursor("normal");
					}
				}
			}

			// Update the GUI...
			mSceneMgr->lScriptsStr = "";
			mSceneMgr->mouseOverPlayField = true;
			map<string, GUIElement>::iterator iterGUI;
			for (iterGUI = mSceneMgr->guiList.begin(); iterGUI != mSceneMgr->guiList.end(); iterGUI++)
			{
				GUIElement* g = &iterGUI->second;
				if (g->IsVisible())
				{
					g->CheckInput(mx, my, mLState, mRState);
					g->OnUpdate();
				}
			}
			int error = luaL_dostring(mSceneMgr->luaVM, mSceneMgr->lScriptsStr.c_str());
			if (error) l_logPrint(mSceneMgr->luaVM);

			if (mSceneMgr->rebuildGUIList)
			{
				mSceneMgr->sortedGUIList.clear();
				for (iterGUI = mSceneMgr->guiList.begin(); iterGUI != mSceneMgr->guiList.end(); iterGUI++)
				{
					GUIElement* g = &iterGUI->second;
					if (g->IsVisible())
					{
						if (!g->child)
						{
							mSceneMgr->sortedGUIList.insert(make_pair(g->frameStrata, g));
						}
					}
				}
				mSceneMgr->rebuildGUIList = false;
			}

			// ... and the cache
			multimap<int, GUIElement*>::iterator iterGUI2;
			for (iterGUI2 = mSceneMgr->sortedGUIList.begin(); iterGUI2 != mSceneMgr->sortedGUIList.end(); iterGUI2++)
			{
				GUIElement* g = iterGUI2->second;
				g->Render(true);
			}

			// Selection square
			if ( (mLState == 1) && (!mSceneMgr->castingSpell) && (!mSceneMgr->lastDragged) &&(mSceneMgr->mouseOverPlayField) )
			{
				if (!mSceneMgr->squareSelection)
				{
					squarex = gmx;
					squarey = gmy;
					mSceneMgr->squareSelection = true;
					mSceneMgr->tempSelectedList.empty();
					mSceneMgr->tempSelectedList = map<string, Unit*>(mSceneMgr->selectedList);
				}

				if (mSceneMgr->squareSelection)
				{
					squareXScale = (gmx-squarex)/28;
					squareYScale = (gmy-squarey)/28;

					if (squareYScale == 0.0f)
						RenderSquare = false; // Because HGE interprets Yscale = 0 as Yscale = 1
					else
						RenderSquare = true;

					if ( (squarex-gmx != 0.0f) && (squarey-gmy != 0.0f) )
					{
						mSceneMgr->selectionSquare->GetBoundingBoxEx(squarex+mSceneMgr->gx, squarey+mSceneMgr->gy, 0.0f, squareXScale, squareYScale, selectSquareRect);
						map<string, Unit>::iterator iter;
						for (iter = mSceneMgr->unitList.begin(); iter != mSceneMgr->unitList.end(); iter++)
						{
							Unit *u = &iter->second;
							if (!u->isHostile())
							{
								if (selectSquareRect->Intersect(u->getBox()))
								{
									if (!u->isSelected())
									{
										u->setSelected(true);
									}
								}
								else
								{
									if (u->isSelected())
									{
										if (shiftPressed)
										{
											if (mSceneMgr->tempSelectedList.find(u->getName()) == mSceneMgr->tempSelectedList.end())
											{
												u->setSelected(false);
											}
										}
										else
											u->setSelected(false);
									}
								}
							}
						}
					}
					if (!mSceneMgr->selectedList.empty())
						selected = true;
					else
						selected = false;
				}
			}
			else if (mLState == 0)
				mSceneMgr->squareSelection = false;

		/* ---------------------------------------------------- */
		/* End loop maths									   */
		/* ---------------------------------------------------- */

			// Global alpha glow
			timerAlpha += dt;
			if (timerAlpha > M_PI_2)
				timerAlpha = 0;

			// Reset variation
			dx = 0;
			dy = 0;

		/* ---------------------------------------------------- */
		/* Updates											  */
		/* ---------------------------------------------------- */

			// Update leading unit
			if (selected)
			{
				if (mSceneMgr->selectedList.empty())
				{
					mSceneMgr->leadingUnit = NULL;
					selected = false;
				}
				else
				{
					mSceneMgr->leadingUnit = NULL;
					map<string, Unit*>::iterator iter;
					for (iter = mSceneMgr->selectedList.begin(); iter != mSceneMgr->selectedList.end(); iter++)
					{
						if (!iter->second->isDead())
						{
							mSceneMgr->leadingUnit = iter->second;
							break;
						}
					}
					if (mSceneMgr->leadingUnit == NULL)
					{
						mSceneMgr->leadingUnit = mSceneMgr->selectedList.begin()->second;
					}
				}
			}
			else
			{
				mSceneMgr->leadingUnit = NULL;
			}

			// Update keyhandler
			myKeyHandler.updateKeys(dt);

			if (!mSceneMgr->gamePaused)
			{
				// Update scrolling combat texts
				mSceneMgr->updateScrollingTexts();

				// Update error texts
				mSceneMgr->updateErrorTexts();

				// Build a certain amount of the requested paths
				mSceneMgr->buildWPPaths();

				// Build some other paths
				mSceneMgr->buildPaths();
				mSceneMgr->buildDirectPaths();

				// Update all projectiles and their particle system
				map<string, Projectile>::iterator iterProj, lastProj;
				lastProj = NULL;
				for (iterProj = mSceneMgr->projectileList.begin(); iterProj != mSceneMgr->projectileList.end(); iterProj++)
				{
					Projectile *p = &iterProj->second;
					if (!p->updatePos())
					{
						p->getPSys()->Stop();
						mSceneMgr->projectileList.erase(iterProj);
						if (mSceneMgr->projectileList.empty())
						{
							break;
						}
						if (lastProj == NULL)
						{
							iterProj = mSceneMgr->projectileList.begin();
							continue;
						}
						else
							iterProj = lastProj;
					}
					else
					{
						p->getPSys()->MoveTo(p->x, p->y);
						p->getPSys()->Transpose(mSceneMgr->gx, mSceneMgr->gy);
						p->getPSys()->Update(dt);
					}
					lastProj = iterProj;
				}
			}
			else
			{
				map<string, Projectile>::iterator iterProj, lastProj;
				lastProj = NULL;
				for (iterProj = mSceneMgr->projectileList.begin(); iterProj != mSceneMgr->projectileList.end(); iterProj++)
				{
					Projectile *p = &iterProj->second;
					p->getPSys()->MoveTo(p->x, p->y);
					p->getPSys()->Transpose(mSceneMgr->gx, mSceneMgr->gy);
				}
			}

			// Update render order every 0.1 sec
			timerUpdtateRender += dt;
			bool rebuild;
			if (timerUpdtateRender >= 0.33f)
			{
				rebuild = true;
				timerUpdtateRender = 0.0f;
			}
			else
				rebuild = false;
			mSceneMgr->buildRenderList(rebuild, debugZ);

			if (orderGiven)
			{
				setGlowing(mSceneMgr->orderCircle, timerAlpha);
				if (mSceneMgr->orderList.empty())
					orderGiven = false;
			}

			// Update the cursor animation if it has one
			if (mSceneMgr->cursor->animated)
				mSceneMgr->cursor->anim->Update(dt);

			// Update target links color
			if (selected)
			{
				mSceneMgr->targetLinkTimer += dt/2;
				if (mSceneMgr->targetLinkTimer > 1.0f)
					mSceneMgr->targetLinkTimer = 0.0f;

				mSceneMgr->targetLinkColorF1 = ARGB(255, 0, 127.5f*sin((mSceneMgr->targetLinkTimer+0.25f)*2*M_PI)+127.5f, 0);
				mSceneMgr->targetLinkColorF2 = ARGB(255, 0, 127.5f*sin(mSceneMgr->targetLinkTimer*2*M_PI)+127.5f, 0);
				mSceneMgr->targetLinkColorF3 = ARGB(255, 0, 127.5f*sin((mSceneMgr->targetLinkTimer-0.25f)*2*M_PI)+127.5f, 0);

				mSceneMgr->targetLinkColorE1 = ARGB(255, 127.5f*sin((mSceneMgr->targetLinkTimer+0.25f)*2*M_PI)+127.5f, 0, 0);
				mSceneMgr->targetLinkColorE2 = ARGB(255, 127.5f*sin(mSceneMgr->targetLinkTimer*2*M_PI)+127.5f, 0, 0);
				mSceneMgr->targetLinkColorE3 = ARGB(255, 127.5f*sin((mSceneMgr->targetLinkTimer-0.25f)*2*M_PI)+127.5f, 0, 0);
			}

			break;
		}

/********************************/
		case LOADING:
/********************************/
		{
			static string classes_file;
			static string effects_file;
			static string cursors_file;
			static string fonts_file;
			static int state1 = 1;
			static int state2 = 1;

			if (loaderState == 0)
			{
				mSceneMgr->mDxDevice = hge->Gfx_GetDevice();
				mSceneMgr->initValues();

				int error = luaL_dofile(mSceneMgr->luaVM, "Tables/def_table.lua");
				if (error) l_logPrint(mSceneMgr->luaVM);

				hge->System_Log("Parsing Scripts/config.lua...");
				mSceneMgr->actualZone.name = mlua_getGlobalString("Files_starting_zone");

				mSceneMgr->aspectRatio = 1.0f/mlua_getGlobalFloat("Game_aspect_ratio");
				mSceneMgr->inCombatTimer = mlua_getGlobalFloat("Game_out_of_combat_timer");
				mSceneMgr->regenTimer = mlua_getGlobalFloat("Game_regen_tick");
				mSceneMgr->maxComputedPaths = mlua_getGlobalInt("Game_max_computed_path");

				mSceneMgr->showStatusBars = mlua_getGlobalBool("UI_show_status_bars");
				mSceneMgr->showEnemiesStatusBars = mlua_getGlobalBool("UI_show_enemies_status_bars");
				mSceneMgr->scrollingTextMaxLife = mlua_getGlobalFloat("UI_scrolling_texts_duration");
				mSceneMgr->scrollingTextSpeed = mlua_getGlobalFloat("UI_scrolling_texts_speed");
				mSceneMgr->scrollingTextFade = mlua_getGlobalBool("UI_scrolling_texts_fade");
				mSceneMgr->errorTextsDuration = mlua_getGlobalFloat("UI_error_texts_duration");
				mSceneMgr->errorTextsFadeDelay = mlua_getGlobalFloat("UI_error_texts_fade_delay");

				hge->System_Log("Parsing Scripts/config.lua : done.\n");

				//mSceneMgr->parseFonts();
				string fnt = mlua_getGlobalString("Fonts_default_font");
				mSceneMgr->defaultFont = mFontMgr->getFont(true, fnt, 15, false, false);
				if (mSceneMgr->defaultFont == NULL) {hge->System_Log("# Error # : missing default font...");}
				mSceneMgr->scrollingTextFont = mFontMgr->getFont(true, fnt, 16, true, false); // outlined
				mSceneMgr->errorFont = mFontMgr->getFont(true, fnt, 18, true, false); // outlined
				systemFont = mSceneMgr->scrollingTextFont;

				mSceneMgr->mLoadingBar.initialize();

				jumpToNextState = true;
				mSceneMgr->mLoadingBar.filling += 0.05f;
				mSceneMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading_zone");
			}
			else if (loaderState == 1)
			{
				bool finished, state;
				state = mSceneMgr->parseZoneDyn(state1, state2, &finished, 0.35f);
				if (finished)
				{
					jumpToNextState = true;
					mSceneMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading_cursors");
					state1 = 1;
					state2 = 1;
				}
				else
				{
					if (state)
					{
						state1++;
						state2 = 1;
					}
					else
						state2++;
				}
			}
			else if (loaderState == 2)
			{
				mSceneMgr->parseCursors();
				jumpToNextState = true;
				mSceneMgr->mLoadingBar.filling += 0.05f;
				mSceneMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading_classes");
			}
			else if (loaderState == 3)
			{
				bool finished, state;
				state = mSceneMgr->parseClassesDyn(state1, &finished, 0.05f);
				if (finished)
				{
					jumpToNextState = true;
					mSceneMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading_animations");
					state1 = 1;
					state2 = 0;
				}
				else
				{
					if (state)
						state1++;
				}
			}
			else if (loaderState == 4)
			{
				bool finished, state;
				state = mSceneMgr->parseAnimationsDyn(state1, state2, &finished, 0.3f);
				if (finished)
				{
					jumpToNextState = true;
					mSceneMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading_effects");
					state1 = 1;
					state2 = 1;
				}
				else
				{
					if (state)
					{
						state1++;
						state2 = 0;
					}
					else
						state2++;
				}
			}
			else if (loaderState == 5)
			{
				mSceneMgr->parseEffects();
				jumpToNextState = true;
				mSceneMgr->mLoadingBar.filling += 0.15f;
				mSceneMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading_ui");
			}
			else if (loaderState == 6)
			{
				// Create sprites
				hge->System_Log("Creating system data...");
				HTEXTURE px_tex = mSceneMgr->loadTexture("pixel.png");
				pixel = mSceneMgr->createSprite(px_tex,0,0,1,1);

				// Create the screen BBs
				screenLRect = mSceneMgr->createRect(0, 0, 4, mSceneMgr->sHeight);
				screenTRect = mSceneMgr->createRect(0, 0, mSceneMgr->sWidth, 4);
				screenRRect = mSceneMgr->createRect(mSceneMgr->sWidth-4, 0, mSceneMgr->sWidth, mSceneMgr->sHeight);
				screenBRect = mSceneMgr->createRect(0, mSceneMgr->sHeight-4, mSceneMgr->sWidth, mSceneMgr->sHeight);
				mSceneMgr->scrRect = mSceneMgr->createRect(0, 0, mSceneMgr->sWidth, mSceneMgr->sHeight);

				// Choose the cursor
				mSceneMgr->cursor = mSceneMgr->switchCursor("normal");

				hge->System_Log("Creating system data : done.");

				// Reading tables
				hge->System_Log("Reading tables...");
				mSceneMgr->lvl_healthTable = new hgeStringTable("Tables/lvl_health.tbl");
				mSceneMgr->lvl_manaTable = new hgeStringTable("Tables/lvl_mana.tbl");
				mSceneMgr->lvl_xp_neededTable = new hgeStringTable("Tables/lvl_xp_needed.tbl");
				hge->System_Log("Reading tables : done.");

				hge->System_Log("Creating units...");

				// Run the initialization script
				int error = luaL_dofile(mSceneMgr->luaVM, "Scripts/init.lua");
				if (error) l_logPrint(mSceneMgr->luaVM);

				hge->System_Log("Creating units : done.");

				// Load the UI
				hge->System_Log("Loading UI...");
				mSceneMgr->loadUI();
				hge->System_Log("Loading UI : done.");

				jumpToNextState = true;
				mSceneMgr->mLoadingBar.filling += 0.05f;
			}
			else if (loaderState == 7)
			{
				hge->System_Log("Now playing !\n");
				mSceneMgr->gameState = GAME;
			}

			if (jumpToNextState)
			{
				jumpToNextState = false;
				loaderState++;
			}

			break;
		}
	}

	return false;
}


bool RenderFunc()
{
	switch (mSceneMgr->gameState)
	{
/********************************/
		case GAME:
/********************************/
		{
			// Begin rendering.
			hge->Gfx_BeginScene();

			// Clear screen with black color
			hge->Gfx_Clear(0);

			// Render the background first
			hge->System_SetState(HGE_TEXTUREFILTER, false);
			std::map<float, BGPart>::iterator iterParts;
			for (iterParts = mSceneMgr->actualZone.parts.begin(); iterParts != mSceneMgr->actualZone.parts.end(); iterParts++)
			{
				BGPart* tmpPart = &iterParts->second;
				tmpPart->bg->Render(tmpPart->x+mSceneMgr->gx, tmpPart->y+mSceneMgr->gy);
			}
			hge->System_SetState(HGE_TEXTUREFILTER, true);

			// Render order circles
			if (orderGiven)
			{
				map<string, Unit*>::iterator iter = mSceneMgr->orderList.begin();
				Unit *u = iter->second;
				float mdist = getPointDistortion(toInt(u->destPoint.x), toInt(u->destPoint.y));
				float scale = mSceneMgr->actualZone.distortion_scale_min-mdist*(mSceneMgr->actualZone.distortion_scale_min-mSceneMgr->actualZone.distortion_scale_max);
				for (iter = mSceneMgr->orderList.begin(); iter != mSceneMgr->orderList.end(); iter++)
				{
					u = iter->second;
					if (u->isSelected())
					{
						float s_scale = u->getClass()->shadow_scale;
						float vscale = mSceneMgr->actualZone.distortion_vscale_min-mdist*(mSceneMgr->actualZone.distortion_vscale_min-mSceneMgr->actualZone.distortion_vscale_max);
						mSceneMgr->orderCircle->RenderEx(u->destPoint.x+mSceneMgr->gx, u->destPoint.y+mSceneMgr->gy, 0.0f, 2.0f*scale*s_scale, 1.4f*scale*s_scale*vscale);
					}
				}
			}

			// Render selection, death and hostile circles and shadows
			map<float, Unit*>::iterator iterUnit;
			for (iterUnit = mSceneMgr->zSortedUnitList.begin(); iterUnit != mSceneMgr->zSortedUnitList.end(); iterUnit++)
			{
				Unit *u = iterUnit->second;
				float ux = u->getX();
				float uy = u->getY();
				float scale = u->getScale()*(u->getClass()->scale);
				float s_scale = u->getClass()->shadow_scale;
				mSceneMgr->p_shadow->RenderEx(ux, uy, 0.0f, scale*s_scale, scale*s_scale);
				if (u->isDead() && u->isSelected())
					mSceneMgr->deathCircle->RenderEx(ux, uy, 0.0f, 2.0f*scale*s_scale, 1.2f*scale*s_scale);
				else
				{
					if (u->isSelected())
						mSceneMgr->selectionCircle->RenderEx(ux, uy, 0.0f, 2.0f*scale*s_scale, 1.2f*scale*s_scale);
					if (u->isHostile() && !u->isDead())
						mSceneMgr->hostileCircle->RenderEx(ux, uy, 0.0f, 2.0f*scale*s_scale, 1.2f*scale*s_scale);
				}
			}

			// Render target links
			map<string, Unit*>::iterator iterUnit2;
			for (iterUnit2 = mSceneMgr->selectedList.begin(); iterUnit2 != mSceneMgr->selectedList.end(); iterUnit2++)
			{
				Unit* u = iterUnit2->second;
				Unit* t = u->getTarget();
				if (t != NULL)
				{
					DWORD col1, col2, col3;
					if (t->isHostile())
					{
						col1 = mSceneMgr->targetLinkColorE1;
						col2 = mSceneMgr->targetLinkColorE2;
						col3 = mSceneMgr->targetLinkColorE3;
					}
					else
					{
						col1 = mSceneMgr->targetLinkColorF1;
						col2 = mSceneMgr->targetLinkColorF2;
						col3 = mSceneMgr->targetLinkColorF3;
					}

					hgeVector vec = hgeVector(u->getX()-t->getX(), u->getY()-t->getY());
					hgeVector vecO = vec;
					vecO.Normalize(); vecO.Rotate(M_PI_2);

					mSceneMgr->targetLink1.v[0].col = col1;
					mSceneMgr->targetLink1.v[0].x = u->getX()-vecO.x;
					mSceneMgr->targetLink1.v[0].y = u->getY()-vecO.y;
					mSceneMgr->targetLink1.v[1].col = col1;
					mSceneMgr->targetLink1.v[1].x = u->getX()+vecO.x;
					mSceneMgr->targetLink1.v[1].y = u->getY()+vecO.y;
					mSceneMgr->targetLink1.v[2].col = col2;
					mSceneMgr->targetLink1.v[2].x = u->getX()-vec.x/2+vecO.x;
					mSceneMgr->targetLink1.v[2].y = u->getY()-vec.y/2+vecO.y;
					mSceneMgr->targetLink1.v[3].col = col2;
					mSceneMgr->targetLink1.v[3].x = u->getX()-vec.x/2-vecO.x;
					mSceneMgr->targetLink1.v[3].y = u->getY()-vec.y/2-vecO.y;

					mSceneMgr->targetLink2.v[0].col = col2;
					mSceneMgr->targetLink2.v[0].x = u->getX()-vec.x/2-vecO.x;
					mSceneMgr->targetLink2.v[0].y = u->getY()-vec.y/2-vecO.y;
					mSceneMgr->targetLink2.v[1].col = col2;
					mSceneMgr->targetLink2.v[1].x = u->getX()-vec.x/2+vecO.x;
					mSceneMgr->targetLink2.v[1].y = u->getY()-vec.y/2+vecO.y;
					mSceneMgr->targetLink2.v[2].col = col3;
					mSceneMgr->targetLink2.v[2].x = t->getX()+vecO.x;
					mSceneMgr->targetLink2.v[2].y = t->getY()+vecO.y;
					mSceneMgr->targetLink2.v[3].col = col3;
					mSceneMgr->targetLink2.v[3].x = t->getX()-vecO.x;
					mSceneMgr->targetLink2.v[3].y = t->getY()-vecO.y;

					hge->Gfx_RenderQuad(&mSceneMgr->targetLink1);
					hge->Gfx_RenderQuad(&mSceneMgr->targetLink2);
				}
			}

			// Render units and doodads
			map<float, Object>::iterator iterObj;
			for (iterObj = mSceneMgr->zSortedList.begin(); iterObj != mSceneMgr->zSortedList.end(); iterObj++)
			{
				if (iterObj->second.type == UNIT)
				{
					Unit *u = static_cast<Unit*>(iterObj->second.ptr);
					float ux = u->getX();
					float uy = u->getY();
					float scale = u->getScale();
					float shadow = u->getShadow();
					RGB color = u->getColor();

					if (mSceneMgr->newOvering == u)
					{
						if (u->isHostile())
							u->getAnimation()->SetColor(ARGB(100, 255, 0, 0));
						else
							u->getAnimation()->SetColor(ARGB(100, 0, 255, 0));
						u->getAnimation()->SetBlendMode(BLEND_COLORADD | BLEND_ALPHAADD | BLEND_NOZWRITE);
						for (float f = 0.0f; f < 1.0f; f += 0.1f)
						{
							u->getAnimation()->RenderEx(ux+3*cos(f*2*M_PI), uy+3*sin(f*2*M_PI), 0.0f, scale, scale);
						}
						u->getAnimation()->SetBlendMode(BLEND_DEFAULT);
					}

					u->getAnimation()->SetColor(ARGB(255, shadow+color.R, shadow+color.G, shadow+color.B));
					u->getAnimation()->RenderEx(ux, uy, 0.0f, scale, scale);
					// Render effects
					if (u->FXPlaying)
					{
						map<string, Effect> fxList = u->getEffectList();
						map<string, Effect>::iterator iterFX;
						for (iterFX = fxList.begin(); iterFX != fxList.end(); iterFX++)
						{
							iterFX->second.RenderEx(ux, uy, 0.0f, scale);
						}
					}
				}
				else if (iterObj->second.type == DOODAD)
				{
					Doodad* d = static_cast<Doodad*>(iterObj->second.ptr);
					d->sprite->Render(floor(d->getX()),floor(d->getY()));
				}
			}

			// Render projectiles
			map<string, Projectile>::iterator iterProj;
			for (iterProj = mSceneMgr->projectileList.begin(); iterProj != mSceneMgr->projectileList.end(); iterProj++)
			{
				iterProj->second.getPSys()->Render();
			}

			// Render always in top doodads
			map<float, Doodad*>::iterator iterDoodad;
			for (iterDoodad = mSceneMgr->renderInTopList.begin(); iterDoodad != mSceneMgr->renderInTopList.end(); iterDoodad++)
			{
				Doodad* d = iterDoodad->second;
				d->sprite->Render(toInt(d->getX()), toInt(d->getY()));
			}

			// Render status bars
			if (mSceneMgr->showStatusBars)
			{
				for (iterUnit = mSceneMgr->zSortedUnitList.begin(); iterUnit != mSceneMgr->zSortedUnitList.end(); iterUnit++)
				{
					if (!(iterUnit->second->isHostile() && mSceneMgr->showEnemiesStatusBars))
					{
						StatusBar* sb = iterUnit->second->getStatusBar();
						sb->Render();
					}
				}
			}

			mSceneMgr->renderScrollingTexts();

			// Render the selection square
			if (mSceneMgr->squareSelection)
			{
				if (RenderSquare)
				{
					mSceneMgr->selectionSquare->RenderEx(squarex+mSceneMgr->gx, squarey+mSceneMgr->gy, 0.0f, squareXScale, squareYScale);
					mSceneMgr->selectionSquareLeftBorder->RenderEx(squarex+mSceneMgr->gx, squarey+mSceneMgr->gy, 0.0f, 1.0f, squareYScale);
					mSceneMgr->selectionSquareRightBorder->RenderEx(squarex+mSceneMgr->gx+squareXScale*28, squarey+mSceneMgr->gy, 0.0f, 1.0f, squareYScale);
				}
				mSceneMgr->selectionSquareTopBorder->RenderEx(squarex+mSceneMgr->gx, squarey+mSceneMgr->gy, 0.0f, squareXScale, 1.0f);
				mSceneMgr->selectionSquareBottomBorder->RenderEx(squarex+mSceneMgr->gx, squarey+mSceneMgr->gy+squareYScale*28, 0.0f, squareXScale, 1.0f);
			}

		/* --------------------------------- */
		/*  RENDER UI						*/
		/* --------------------------------- */

			// Pause text
			if (mSceneMgr->gamePaused)
			{
				mSceneMgr->errorFont->SetColor(ARGB(255, 255, 60, 60));
				mSceneMgr->errorFont->printf
				(
					mSceneMgr->sWidth/2.0f, mSceneMgr->sHeight-195, HGETEXT_CENTER,
					mSceneMgr->strTable->GetString("game_paused")
				);
			}

			// LUA UI
			multimap<int, GUIElement*>::iterator iterGUI2;
			for (iterGUI2 = mSceneMgr->sortedGUIList.begin(); iterGUI2 != mSceneMgr->sortedGUIList.end(); iterGUI2++)
			{
				GUIElement* g = iterGUI2->second;
				g->Render(false);
			}

			// Error texts
			vector<ErrorText>::iterator iter;
			float errorY = 115.0f;
			for (iter = mSceneMgr->errorTextList.begin(); iter != mSceneMgr->errorTextList.end(); iter++)
			{
				mSceneMgr->errorFont->SetColor(ARGB(toInt(iter->alpha), 255, 60, 60));
				mSceneMgr->errorFont->printf
				(
					mSceneMgr->sWidth/2.0f, errorY, HGETEXT_CENTER,
					iter->caption.c_str()
				);
				errorY += 25.0f;
			}

			// FPS counter
			systemFont->SetColor(ARGB(255, 255, 255, 255));
			systemFont->printf
			(
				mSceneMgr->sWidth-10, mSceneMgr->sHeight-20, HGETEXT_RIGHT,
				"FPS : %d",
				hge->Timer_GetFPS()
			);

			// Render the cursor above all
			if (mSceneMgr->cursor->animated)
			{
				mSceneMgr->cursor->anim->RenderEx(curx, cury, mSceneMgr->cursor->rot, 1.0f);
			}
			else
			{
				mSceneMgr->cursor->sprite->RenderEx(curx, cury, mSceneMgr->cursor->rot, 1.0f);
			}

			// End rendering, update the screen
			hge->Gfx_EndScene();

			/*static int frameCount = 1;
			hge->System_Log("[%d]", frameCount);
			frameCount++;*/

			break;
		}

/********************************/
		case LOADING:
/********************************/
		{
			// Begin rendering.
			hge->Gfx_BeginScene();

			mSceneMgr->loadingBackground->RenderStretch(0,0,mSceneMgr->sWidth,mSceneMgr->sHeight);
			mSceneMgr->mLoadingBar.Render();

			hge->Gfx_EndScene();
			break;
		}
	}

	return false;
}


bool RestoreFunc()
{
	map<string, GUIElement>::iterator iterGUI;
	for (iterGUI = mSceneMgr->guiList.begin(); iterGUI != mSceneMgr->guiList.end(); iterGUI++)
	{
		GUIElement* g = &iterGUI->second;
		if (g->target && g->spr)
			g->spr->SetTexture(hge->Target_GetTexture(g->target));
	}

	return false;
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	srand((unsigned)time(0));

	// Initialize HGE
	hge = hgeCreate(HGE_VERSION);
	hge->Random_Seed(0);

	hge->System_SetState(HGE_LOGFILE, "WoWRL.log"); // Initialize the Log file
	hge->System_SetState(HGE_TITLE, "WoW Raid Leader"); // Set the frame title
	hge->System_SetState(HGE_FRAMEFUNC, FrameFunc);
	hge->System_SetState(HGE_RENDERFUNC, RenderFunc);
	hge->System_SetState(HGE_GFXRESTOREFUNC, RestoreFunc);

	// Create scene and font managers
	mSceneMgr = SceneManager::getSingleton();
	mFontMgr = FontManager::getSingleton();

	mSceneMgr->gameVersion = GAMEVERSION;
	hge->System_Log("##########################");
	hge->System_Log("# Starting WoWRL v.%.3f #", mSceneMgr->gameVersion);
	hge->System_Log("##########################\n");

	// Initialize LUA
	mSceneMgr->luaVM = lua_open();
	if (mSceneMgr->luaVM == NULL)
	{
		hge->System_Log("# Error initializing lua.");
		return 0;
	}
	luaL_openlibs(mSceneMgr->luaVM);
	mlua_registerAll();

	hge->System_Log("Parsing display config...");

	int error = luaL_dofile(mSceneMgr->luaVM, "Scripts/config.lua");
	if (error) l_logPrint(mSceneMgr->luaVM);

	mSceneMgr->sWidth = mlua_getGlobalInt("Display_screen_width");
	mSceneMgr->sHeight = mlua_getGlobalInt("Display_screen_height");
	int sDepth = mlua_getGlobalInt("Display_screen_depth");
	int sMaxFPS = mlua_getGlobalInt("Display_max_fps");
	bool windowed = !mlua_getGlobalBool("Display_fullscreen");
	mSceneMgr->locale = mlua_getGlobalString("Game_locale");
	string strTableFile = "Tables/locale_" + mSceneMgr->locale + ".str";

	hge->System_Log("Parsing display config : done.\n");

	mSceneMgr->strTable = new hgeStringTable(strTableFile.c_str());

	hge->System_SetState(HGE_FPS, sMaxFPS);
	hge->System_SetState(HGE_WINDOWED, windowed);
	hge->System_SetState(HGE_SCREENWIDTH, mSceneMgr->sWidth);
	hge->System_SetState(HGE_SCREENHEIGHT, mSceneMgr->sHeight);
	hge->System_SetState(HGE_SCREENBPP, sDepth);

	hge->System_SetState(HGE_ICON, MAKEINTRESOURCE (1));

	hge->System_SetState(HGE_USESOUND, false); // Disactivate sound

	if(hge->System_Initiate())
	{
		// Create loading bar
		string loadingBar = "UI/ui_default_loading_bar.png";
		mSceneMgr->loadTexture(loadingBar);
		mSceneMgr->mLoadingBar.border = mSceneMgr->createSprite(mSceneMgr->textureList[loadingBar],1,57,250,30);
		mSceneMgr->mLoadingBar.border->SetHotSpot(125, 0);
		mSceneMgr->mLoadingBar.spark = mSceneMgr->createSprite(mSceneMgr->textureList[loadingBar],84,30,7,24);
		mSceneMgr->mLoadingBar.spark->SetHotSpot(5, 0);
		mSceneMgr->mLoadingBar.spark->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHABLEND | BLEND_NOZWRITE);
		mSceneMgr->mLoadingBar.gauge_active = mSceneMgr->createSprite(mSceneMgr->textureList[loadingBar],1,29,26,26);
		mSceneMgr->mLoadingBar.gauge_error = mSceneMgr->createSprite(mSceneMgr->textureList[loadingBar],29,29,26,26);
		mSceneMgr->mLoadingBar.gauge_finish = mSceneMgr->createSprite(mSceneMgr->textureList[loadingBar],57,29,26,26);
		mSceneMgr->mLoadingBar.background = mSceneMgr->createSprite(mSceneMgr->textureList[loadingBar],1,1,246,26);
		mSceneMgr->mLoadingBar.background->SetHotSpot(123, 0);
		mSceneMgr->mLoadingBar.filling = 0.0f;

		//int fileNbr = hge->Random_Int(1,2);
		int fileNbr = 1;

		// Load the loading background
		if (mSceneMgr->sWidth == 1024)
		{
			mSceneMgr->loadTexture("Zones/LoadingScreen/loading_screen_" + toString(fileNbr)+ "_1024.jpg");
			mSceneMgr->loadingBackground = mSceneMgr->createSprite(mSceneMgr->textureList["Zones/LoadingScreen/loading_screen_" + toString(fileNbr)+ "_1024.jpg"],0,0,1024,768);
		}
		else
		{
			mSceneMgr->loadTexture("Zones/LoadingScreen/loading_screen_" + toString(fileNbr)+ "_1280.jpg");
			mSceneMgr->loadingBackground = mSceneMgr->createSprite(mSceneMgr->textureList["Zones/LoadingScreen/loading_screen_" + toString(fileNbr)+ "_1280.jpg"],0,0,1280,1024);
		}
		mSceneMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading");

		// Load ressources and start
		mSceneMgr->gameState = LOADING;

		hge->System_Start();
	}
	else
	{
		MessageBox(NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_APPLMODAL);
	}

	hge->System_Log("Game ended.\n");

	// End, delete/free everything
	hge->System_Log("Freeing resources :");
	hge->System_Log("   Closing UI...");
// TODO (Corentin#2#): Create a GUI manager class
	mSceneMgr->closeUI();
	hge->System_Log("   Freeing textures...");
	mSceneMgr->freeTextures();
	hge->System_Log("   Deleting sprites...");
	mSceneMgr->deleteSprites();
	hge->System_Log("   Deleting animations...");
	mSceneMgr->deleteAnimations();
	hge->System_Log("   Deleting rects...");
	mSceneMgr->deleteRects();
	hge->System_Log("   Deleting doodads...");
// TODO (Corentin#2#): Create a Zone manager class
	mSceneMgr->deleteDoodads();
	hge->System_Log("   Deleting units...");
// TODO (Corentin#2#): Create a Unit manager class
	mSceneMgr->deleteUnits();
	hge->System_Log("   Deleting fonts...");
	mFontMgr->deleteFonts();

	lua_close(mSceneMgr->luaVM);

// FIXME (Corentin#1#): Crash ?
	//delete mSceneMgr;
	//delete mFontMgr;

	hge->System_Log("Done.");

	hge->System_Shutdown();
	hge->Release();

	return 0;
}

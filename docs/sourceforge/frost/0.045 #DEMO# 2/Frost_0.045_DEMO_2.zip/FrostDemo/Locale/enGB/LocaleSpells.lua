-- This file contains localized string for the English language.

-- Spells :
SPELL_FROSTBOLT_NAME = "Frostbolt";
SPELL_FROSTBOLT_DESC = "Launches a bolt of frost at the enemy, causing [damage_min] to [damage_max] [school] damage and slowing movement speed by [slowdown_percent]% for [duration] sec.";
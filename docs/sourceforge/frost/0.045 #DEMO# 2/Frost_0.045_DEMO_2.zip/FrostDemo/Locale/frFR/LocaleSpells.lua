-- Ce fichier contient les textes traduits en Fran�ais.

-- Sorts :
SPELL_FROSTBOLT_NAME = "Eclair de givre";
SPELL_FROSTBOLT_DESC = "Lance un �clair de givre sur l'ennemi, inflige [damage_min] � [damage_max] points de d�g�ts de [school] et r�duit sa vitesse de d�placement de [slowdown_percent]% pendant [duration] sec.";


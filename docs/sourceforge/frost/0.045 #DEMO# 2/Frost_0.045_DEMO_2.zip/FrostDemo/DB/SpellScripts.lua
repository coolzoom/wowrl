-- Here are stored all spell scripts and other enums.
-- This file is meant to reduce the size of the spell database file
-- and ease spell manipulation.

-- Spell family enum :
FAMILY_FROSTBOLT = 1;
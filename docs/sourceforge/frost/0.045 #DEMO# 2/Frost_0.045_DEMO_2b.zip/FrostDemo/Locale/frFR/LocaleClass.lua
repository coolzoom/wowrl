-- Ce fichier contient les textes traduits en Fran�ais.

-- Classes :
CLASS_MAGE = "Mage";
CLASS_PRIEST = "Pr�tre";
CLASS_DRUID = "Druide";
CLASS_DEMONIST = "Demoniste";
CLASS_HUNTER = "Chasseur";
CLASS_PALADIN = "Paladin";
CLASS_SHAMAN = "Chaman";
CLASS_WARRIOR = "Guerrier"
CLASS_ROGUE = "Voleur";
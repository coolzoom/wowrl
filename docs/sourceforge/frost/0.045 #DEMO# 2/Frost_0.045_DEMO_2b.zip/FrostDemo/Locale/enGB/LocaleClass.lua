-- This file contains localized string for the English language.

-- Classes :
CLASS_MAGE = "Mage";
CLASS_PRIEST = "Priest";
CLASS_DRUID = "Druid";
CLASS_DEMONIST = "Demonist";
CLASS_HUNTER = "Hunter";
CLASS_PALADIN = "Paladin";
CLASS_SHAMAN = "Shaman";
CLASS_WARRIOR = "Warrior";
CLASS_ROGUE = "Rogue";
-- Test script : executed everytime the [T] key is pressed

--Unit_addEffect("Kalette", "mage_chilling_armor");
--Unit_addEffect("Kaloth", "generic_poison");
--Unit_addItem(GetLeadingUnit(), 8952); -- add one [Roasted Quail] to the selected unit's inventory
ChatEditBox:SetFocus();


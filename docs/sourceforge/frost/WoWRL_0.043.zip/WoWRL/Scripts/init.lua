-- Initialization script : executed once, just after zone loading

local pSpeed = 300;

if (Files_starting_zone == "Zones/ZG/ZG_001.lua") then
	UnitSpawn("Kalette", 2300, 1050, 70, "scourge", GENDER_FEMALE, "mage", pSpeed);
	UnitSpawn("Kaloth", 2390, 1130, 65, "tauren", GENDER_MALE, "hunter", pSpeed);
	UnitSpawn("Mercy", 2500, 1200, 45, "troll", GENDER_FEMALE, "priest", pSpeed);
	local u = UnitSpawn("Insanity", 1738, 1600, 70, "troll", GENDER_MALE, "hunter", pSpeed);
	UnitSetHostile(u, true);
	--UnitSetMaxHP(u, 50000, true);
	UnitSetAggroRange(u, 40);
else
	UnitSpawn("Kalith", 300, 750, 70, "scourge", GENDER_MALE, "mage", pSpeed);
end

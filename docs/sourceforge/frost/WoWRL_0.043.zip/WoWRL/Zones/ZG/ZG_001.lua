
Zone = {
    ["width"] = 3387;
    ["height"] = 2293;
    ["start_x"] = 1763;
    ["start_y"] = 749;
    ["respawn_time"] = 210; -- WIP
    ["scale"] = 0.50;
    ["vscale"] = 0.75;
    ["Background"] = {
        [1] = {
            ["background"] = "Zones/ZG/ZG_001/ZG_001_01.jpg";
            ["distortion"] = "Zones/ZG/ZG_001/ZG_001_01_d.png";
        },
        [2] = {
            ["background"] = "Zones/ZG/ZG_001/ZG_001_02.jpg";
        },
        [3] = {
            ["background"] = "Zones/ZG/ZG_001/ZG_001_03.jpg";
            ["distortion"] = "Zones/ZG/ZG_001/ZG_001_03_d.png";
        },
        [4] = {
            ["background"] = "Zones/ZG/ZG_001/ZG_001_04.jpg";
        },
        [5] = {
            ["background"] = "Zones/ZG/ZG_001/ZG_001_05.jpg";
            ["distortion"] = "Zones/ZG/ZG_001/ZG_001_05_d.png";
        },
        [6] = {
            ["background"] = "Zones/ZG/ZG_001/ZG_001_06.jpg";
            ["distortion"] = "Zones/ZG/ZG_001/ZG_001_06_d.png";
        },
        [7] = {
            ["background"] = "Zones/ZG/ZG_001/ZG_001_07.jpg";
            ["distortion"] = "Zones/ZG/ZG_001/ZG_001_07_d.png";
        },
        [8] = {
            ["background"] = "Zones/ZG/ZG_001/ZG_001_08.jpg";
        },
        [9] = {
            ["background"] = "Zones/ZG/ZG_001/ZG_001_09.jpg";
            ["distortion"] = "Zones/ZG/ZG_001/ZG_001_09_d.png";
        },
        [10] = {
            ["background"] = "Zones/ZG/ZG_001/ZG_001_10.jpg";
            ["distortion"] = "Zones/ZG/ZG_001/ZG_001_10_d.png";
        },
        [11] = {
            ["background"] = "Zones/ZG/ZG_001/ZG_001_11.jpg";
        },
        [12] = {
            ["background"] = "Zones/ZG/ZG_001/ZG_001_12.jpg";
        },
    },
    ["Links"] = nil, -- WIP
    ["Doodads"] = {
        [1] = {
            ["name"] = "bamboo01up";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_bamboo01up",
								"Zones/ZG/ZG_001/ZG_001_bamboo01up.png",
								false, 0, 0, 512, 512, 240, 412
                         );
            ["x"] = 2698;
            ["y"] = 1050;
            ["always_in_top"] = true;
        },
        [2] = {
            ["name"] = "bamboo02";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_bamboo02",
								"Zones/ZG/ZG_001/ZG_001_bamboo02.png",
								false, 0, 0, 128, 128, 64, 64
                         );
            ["x"] = 2535;
            ["y"] = 957;
            ["always_in_top"] = true;
        },
        [3] = {
            ["name"] = "bamboo03up";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_bamboo03up",
								"Zones/ZG/ZG_001/ZG_001_bamboo03up.png",
								false, 0, 0, 128, 128, 80, 102
                         );
            ["x"] = 2643;
            ["y"] = 1067;
            ["always_in_top"] = true;
        },
        [4] = {
            ["name"] = "bloc01";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_bloc01",
								"Zones/ZG/ZG_001/ZG_001_bloc01.png",
								false, 0, 0, 32, 32, 16, 21
                         );
            ["x"] = 1738;
            ["y"] = 1496;
            ["orientation"] = 11.0;
        },
        [5] = {
            ["name"] = "bridgefixation01";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_bridgefixation01",
								"Zones/ZG/ZG_001/ZG_001_bridgefixation01.png",
								false, 0, 0, 128, 128, 64, 64
                         );
            ["x"] = 1466;
            ["y"] = 1633;
            ["always_in_top"] = true;
        },
        [6] = {
            ["name"] = "column01";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_column01",
								"Zones/ZG/ZG_001/ZG_001_column01.png",
								false, 0, 0, 64, 128, 38, 93
                         );
            ["x"] = 1652;
            ["y"] = 1576;
            ["always_in_top"] = true;
        },
        [7] = {
            ["name"] = "column02";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_column02",
								"Zones/ZG/ZG_001/ZG_001_column02.png",
								false, 0, 0, 64, 128, 36, 91
                         );
            ["x"] = 1661;
            ["y"] = 1499;
            ["orientation"] = 5.0;
        },
        [8] = {
            ["name"] = "column03";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_column03",
								"Zones/ZG/ZG_001/ZG_001_column03.png",
								false, 0, 0, 128, 128, 67, 102
                         );
            ["x"] = 2458;
            ["y"] = 958;
            ["orientation"] = 6.0;
        },
        [9] = {
            ["name"] = "column04";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_column04",
								"Zones/ZG/ZG_001/ZG_001_column04.png",
								false, 0, 0, 128, 128, 64, 104
                         );
            ["x"] = 2388;
            ["y"] = 921;
            ["orientation"] = 4.0;
        },
        [10] = {
            ["name"] = "fern01";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_fern01",
								"Zones/ZG/ZG_001/ZG_001_fern01.png",
								false, 0, 0, 64, 64, 26, 41
                         );
            ["x"] = 2421;
            ["y"] = 1243;
            ["orientation"] = 0.0;
        },
        [11] = {
            ["name"] = "fern02";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_fern02",
								"Zones/ZG/ZG_001/ZG_001_fern02.png",
								false, 0, 0, 64, 64, 37, 36
                         );
            ["x"] = 2372;
            ["y"] = 1083;
            ["orientation"] = -23.0;
        },
        [12] = {
            ["name"] = "fern03";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_fern03",
								"Zones/ZG/ZG_001/ZG_001_fern03.png",
								false, 0, 0, 32, 32, 11, 15
                         );
            ["x"] = 2182;
            ["y"] = 1240;
            ["orientation"] = -15.0;
        },
        [13] = {
            ["name"] = "fern04";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_fern04",
								"Zones/ZG/ZG_001/ZG_001_fern04.png",
								false, 0, 0, 32, 32, 12, 25
                         );
            ["x"] = 2108;
            ["y"] = 1252;
            ["orientation"] = 36.0;
        },
        [14] = {
            ["name"] = "fern05";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_fern05",
								"Zones/ZG/ZG_001/ZG_001_fern05.png",
								false, 0, 0, 64, 64, 19, 49
                         );
            ["x"] = 1891;
            ["y"] = 1295;
            ["orientation"] = 14.0;
        },
        [15] = {
            ["name"] = "fern06";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_fern06",
								"Zones/ZG/ZG_001/ZG_001_fern06.png",
								false, 0, 0, 64, 32, 33, 25
                         );
            ["x"] = 2226;
            ["y"] = 1005;
            ["orientation"] = 0.0;
        },
        [16] = {
            ["name"] = "fern07";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_fern07",
								"Zones/ZG/ZG_001/ZG_001_fern07.png",
								false, 0, 0, 32, 16, 15, 11
                         );
            ["x"] = 2212;
            ["y"] = 1049;
            ["orientation"] = 30.0;
        },
        [17] = {
            ["name"] = "fern08";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_fern08",
								"Zones/ZG/ZG_001/ZG_001_fern08.png",
								false, 0, 0, 64, 64, 34, 38
                         );
            ["x"] = 2200;
            ["y"] = 1150;
            ["orientation"] = -24.5;
        },
        [18] = {
            ["name"] = "fern09";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_fern09",
								"Zones/ZG/ZG_001/ZG_001_fern09.png",
								false, 0, 0, 32, 32, 15, 19
                         );
            ["x"] = 1970;
            ["y"] = 1380;
            ["orientation"] = -26.0;
        },
        [19] = {
            ["name"] = "fern10";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_fern10",
								"Zones/ZG/ZG_001/ZG_001_fern10.png",
								false, 0, 0, 64, 64, 36, 44
                         );
            ["x"] = 1755;
            ["y"] = 1429;
            ["orientation"] = -24.0;
        },
        [20] = {
            ["name"] = "fern11";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_fern11",
								"Zones/ZG/ZG_001/ZG_001_fern11.png",
								false, 0, 0, 128, 128, 45, 88
                         );
            ["x"] = 1858;
            ["y"] = 1412;
            ["orientation"] = -49.0;
        },
        [21] = {
            ["name"] = "gong01";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_gong01",
								"Zones/ZG/ZG_001/ZG_001_gong01.png",
								false, 0, 0, 128, 128, 70, 84
                         );
            ["x"] = 2408;
            ["y"] = 1183;
            ["orientation"] = 20.0;
        },
        [22] = {
            ["name"] = "gong02";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_gong02",
								"Zones/ZG/ZG_001/ZG_001_gong02.png",
								false, 0, 0, 32, 128, 13, 78
                         );
            ["x"] = 2217;
            ["y"] = 1112;
            ["orientation"] = -62.0;
        },
        [23] = {
            ["name"] = "snake01";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_snake01",
								"Zones/ZG/ZG_001/ZG_001_snake01.png",
								false, 0, 0, 64, 128, 38, 108
                         );
            ["x"] = 2265;
            ["y"] = 1290;
            ["orientation"] = 11.0;
        },
        [24] = {
            ["name"] = "snake02";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_snake02",
								"Zones/ZG/ZG_001/ZG_001_snake02.png",
								false, 0, 0, 64, 128, 39, 106
                         );
            ["x"] = 2162;
            ["y"] = 1237;
            ["orientation"] = -16.0;
        },
        [25] = {
            ["name"] = "snakebody01";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_snakebody01",
								"Zones/ZG/ZG_001/ZG_001_snakebody01.png",
								false, 0, 0, 128, 128, 69, 77
                         );
            ["x"] = 2169;
            ["y"] = 1361;
            ["orientation"] = 30.0;
        },
        [26] = {
            ["name"] = "snakebody02";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_snakebody02",
								"Zones/ZG/ZG_001/ZG_001_snakebody02.png",
								false, 0, 0, 128, 128, 69, 68
                         );
            ["x"] = 2065;
            ["y"] = 1300;
            ["orientation"] = 27.0;
        },
        [27] = {
            ["name"] = "snaketail01";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_snaketail01",
								"Zones/ZG/ZG_001/ZG_001_snaketail01.png",
								false, 0, 0, 32, 64, 15, 45
                         );
            ["x"] = 2052;
            ["y"] = 1429;
            ["orientation"] = -4.0;
        },
        [28] = {
            ["name"] = "snaketail02";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_snaketail02",
								"Zones/ZG/ZG_001/ZG_001_snaketail02.png",
								false, 0, 0, 32, 64, 16, 44
                         );
            ["x"] = 1949;
            ["y"] = 1376;
            ["orientation"] = -4.0;
        },
        [29] = {
            ["name"] = "torch01";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_torch01",
								"Zones/ZG/ZG_001/ZG_001_torch01.png",
								false, 0, 0, 8, 32, 3, 23
                         );
            ["x"] = 2237;
            ["y"] = 1170;
            ["orientation"] = 0.0;
        },
        [30] = {
            ["name"] = "tree01";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_tree01",
								"Zones/ZG/ZG_001/ZG_001_tree01.png",
								false, 0, 0, 512, 256, 223, 196
                         );
            ["x"] = 2155;
            ["y"] = 1047;
            ["orientation"] = -9.0;
        },
        [31] = {
            ["name"] = "tree01up";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_tree01up",
								"Zones/ZG/ZG_001/ZG_001_tree01up.png",
								false, 0, 0, 512, 512, 265, 511
                         );
            ["x"] = 2155;
            ["y"] = 867;
            ["always_in_top"] = true;
        },
        [32] = {
            ["name"] = "tree02";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_tree02",
								"Zones/ZG/ZG_001/ZG_001_tree02.png",
								false, 0, 0, 256, 256, 157, 116
                         );
            ["x"] = 1825;
            ["y"] = 1373;
            ["orientation"] = 6.0;
        },
        [33] = {
            ["name"] = "tree02up";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_tree02up",
								"Zones/ZG/ZG_001/ZG_001_tree02up.png",
								false, 0, 0, 1024, 512, 565, 506
                         );
            ["x"] = 1825;
            ["y"] = 1293;
            ["always_in_top"] = true;
        },
        [34] = {
            ["name"] = "trollhut01";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_trollhut01",
								"Zones/ZG/ZG_001/ZG_001_trollhut01.png",
								false, 0, 0, 256, 128, 164, 106
                         );
            ["x"] = 2638;
            ["y"] = 1435;
            ["orientation"] = 36.0;
        },
        [35] = {
            ["name"] = "trollhut02a";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_trollhut02a",
								"Zones/ZG/ZG_001/ZG_001_trollhut02a.png",
								false, 0, 0, 64, 128, 32, 64
                         );
            ["x"] = 1874;
            ["y"] = 1577;
            ["always_in_top"] = true;
        },
        [36] = {
            ["name"] = "trollhut02b";
            ["sprite"] = Gfx_createSprite(
								"ZG_001_trollhut02b",
								"Zones/ZG/ZG_001/ZG_001_trollhut02b.png",
								false, 0, 0, 32, 128, 17, 105
                         );
            ["x"] = 1915;
            ["y"] = 1627;
            ["orientation"] = -40.0;
        },
    },
    ["Waypoints"] = {
        [1] = {
            ["name"] = "wp_1";
            ["x"] = 2291;
            ["y"] = 1052;
            ["size"] = 36;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_2";
	                ["distance"] = 351.171875;
	            },
	            [2] = {
	                ["name"] = "wp_32";
	                ["distance"] = 373.760620;
	            },
	            [3] = {
	                ["name"] = "wp_33";
	                ["distance"] = 380.073517;
	            },
	            [4] = {
	                ["name"] = "wp_27";
	                ["distance"] = 450.240051;
	            },
            },
        },
        [2] = {
            ["name"] = "wp_10";
            ["x"] = 1015;
            ["y"] = 1768;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_11";
	                ["distance"] = 65.653961;
	            },
	            [2] = {
	                ["name"] = "wp_9";
	                ["distance"] = 83.254776;
	            },
            },
        },
        [3] = {
            ["name"] = "wp_11";
            ["x"] = 956;
            ["y"] = 1750;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_10";
	                ["distance"] = 65.653961;
	            },
	            [2] = {
	                ["name"] = "wp_12";
	                ["distance"] = 98.578758;
	            },
            },
        },
        [4] = {
            ["name"] = "wp_12";
            ["x"] = 876;
            ["y"] = 1786;
            ["size"] = 25;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_11";
	                ["distance"] = 98.578758;
	            },
	            [2] = {
	                ["name"] = "wp_30";
	                ["distance"] = 191.824997;
	            },
	            [3] = {
	                ["name"] = "wp_13";
	                ["distance"] = 221.554626;
	            },
	            [4] = {
	                ["name"] = "wp_29";
	                ["distance"] = 331.386475;
	            },
            },
        },
        [5] = {
            ["name"] = "wp_13";
            ["x"] = 683;
            ["y"] = 1854;
            ["size"] = 21;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_14";
	                ["distance"] = 44.944408;
	            },
	            [2] = {
	                ["name"] = "wp_12";
	                ["distance"] = 221.554626;
	            },
	            [3] = {
	                ["name"] = "wp_30";
	                ["distance"] = 265.397827;
	            },
	            [4] = {
	                ["name"] = "wp_29";
	                ["distance"] = 389.881805;
	            },
            },
        },
        [6] = {
            ["name"] = "wp_14";
            ["x"] = 645;
            ["y"] = 1869;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_13";
	                ["distance"] = 44.944408;
	            },
	            [2] = {
	                ["name"] = "wp_15";
	                ["distance"] = 115.421974;
	            },
            },
        },
        [7] = {
            ["name"] = "wp_15";
            ["x"] = 565;
            ["y"] = 1921;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_16";
	                ["distance"] = 89.444672;
	            },
	            [2] = {
	                ["name"] = "wp_14";
	                ["distance"] = 115.421974;
	            },
            },
        },
        [8] = {
            ["name"] = "wp_16";
            ["x"] = 494;
            ["y"] = 1955;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_17";
	                ["distance"] = 83.541870;
	            },
	            [2] = {
	                ["name"] = "wp_15";
	                ["distance"] = 89.444672;
	            },
            },
        },
        [9] = {
            ["name"] = "wp_17";
            ["x"] = 419;
            ["y"] = 1978;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_18";
	                ["distance"] = 54.921371;
	            },
	            [2] = {
	                ["name"] = "wp_16";
	                ["distance"] = 83.541870;
	            },
            },
        },
        [10] = {
            ["name"] = "wp_18";
            ["x"] = 366;
            ["y"] = 1987;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_19";
	                ["distance"] = 43.118904;
	            },
	            [2] = {
	                ["name"] = "wp_17";
	                ["distance"] = 54.921371;
	            },
            },
        },
        [11] = {
            ["name"] = "wp_19";
            ["x"] = 323;
            ["y"] = 1985;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_18";
	                ["distance"] = 43.118904;
	            },
	            [2] = {
	                ["name"] = "wp_20";
	                ["distance"] = 174.542252;
	            },
            },
        },
        [12] = {
            ["name"] = "wp_2";
            ["x"] = 2213;
            ["y"] = 1266;
            ["size"] = 45;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_1";
	                ["distance"] = 351.171875;
	            },
	            [2] = {
	                ["name"] = "wp_27";
	                ["distance"] = 443.878357;
	            },
	            [3] = {
	                ["name"] = "wp_3";
	                ["distance"] = 529.906006;
	            },
            },
        },
        [13] = {
            ["name"] = "wp_20";
            ["x"] = 164;
            ["y"] = 2030;
            ["size"] = 33;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_19";
	                ["distance"] = 174.542252;
	            },
            },
        },
        [14] = {
            ["name"] = "wp_21";
            ["x"] = 536;
            ["y"] = 1225;
            ["size"] = 69;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_22";
	                ["distance"] = 261.210205;
	            },
	            [2] = {
	                ["name"] = "wp_31";
	                ["distance"] = 441.185730;
	            },
	            [3] = {
	                ["name"] = "wp_30";
	                ["distance"] = 781.146179;
	            },
            },
        },
        [15] = {
            ["name"] = "wp_22";
            ["x"] = 673;
            ["y"] = 1086;
            ["size"] = 28;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_21";
	                ["distance"] = 261.210205;
	            },
	            [2] = {
	                ["name"] = "wp_31";
	                ["distance"] = 384.363220;
	            },
	            [3] = {
	                ["name"] = "wp_23";
	                ["distance"] = 754.713196;
	            },
            },
        },
        [16] = {
            ["name"] = "wp_23";
            ["x"] = 432;
            ["y"] = 639;
            ["size"] = 21;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_24";
	                ["distance"] = 121.952316;
	            },
	            [2] = {
	                ["name"] = "wp_22";
	                ["distance"] = 754.713196;
	            },
            },
        },
        [17] = {
            ["name"] = "wp_24";
            ["x"] = 371;
            ["y"] = 573;
            ["size"] = 31;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_23";
	                ["distance"] = 121.952316;
	            },
	            [2] = {
	                ["name"] = "wp_26";
	                ["distance"] = 214.848785;
	            },
	            [3] = {
	                ["name"] = "wp_25";
	                ["distance"] = 521.873718;
	            },
            },
        },
        [18] = {
            ["name"] = "wp_25";
            ["x"] = 145;
            ["y"] = 279;
            ["size"] = 81;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_24";
	                ["distance"] = 521.873718;
	            },
            },
        },
        [19] = {
            ["name"] = "wp_26";
            ["x"] = 559;
            ["y"] = 508;
            ["size"] = 70;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_24";
	                ["distance"] = 214.848785;
	            },
            },
        },
        [20] = {
            ["name"] = "wp_27";
            ["x"] = 2651;
            ["y"] = 1221;
            ["size"] = 33;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_28";
	                ["distance"] = 384.375305;
	            },
	            [2] = {
	                ["name"] = "wp_2";
	                ["distance"] = 443.878357;
	            },
	            [3] = {
	                ["name"] = "wp_1";
	                ["distance"] = 450.240051;
	            },
            },
        },
        [21] = {
            ["name"] = "wp_28";
            ["x"] = 2738;
            ["y"] = 1455;
            ["size"] = 44;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_27";
	                ["distance"] = 384.375305;
	            },
            },
        },
        [22] = {
            ["name"] = "wp_29";
            ["x"] = 1025;
            ["y"] = 1971;
            ["size"] = 28;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_12";
	                ["distance"] = 331.386475;
	            },
	            [2] = {
	                ["name"] = "wp_13";
	                ["distance"] = 389.881805;
	            },
	            [3] = {
	                ["name"] = "wp_30";
	                ["distance"] = 520.009766;
	            },
            },
        },
        [23] = {
            ["name"] = "wp_3";
            ["x"] = 1838;
            ["y"] = 1500;
            ["size"] = 67;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_4";
	                ["distance"] = 373.541718;
	            },
	            [2] = {
	                ["name"] = "wp_2";
	                ["distance"] = 529.906006;
	            },
            },
        },
        [24] = {
            ["name"] = "wp_30";
            ["x"] = 753;
            ["y"] = 1694;
            ["size"] = 89;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_12";
	                ["distance"] = 191.824997;
	            },
	            [2] = {
	                ["name"] = "wp_13";
	                ["distance"] = 265.397827;
	            },
	            [3] = {
	                ["name"] = "wp_29";
	                ["distance"] = 520.009766;
	            },
	            [4] = {
	                ["name"] = "wp_21";
	                ["distance"] = 781.146179;
	            },
            },
        },
        [25] = {
            ["name"] = "wp_31";
            ["x"] = 977;
            ["y"] = 1233;
            ["size"] = 77;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_22";
	                ["distance"] = 384.363220;
	            },
	            [2] = {
	                ["name"] = "wp_21";
	                ["distance"] = 441.185730;
	            },
            },
        },
        [26] = {
            ["name"] = "wp_32";
            ["x"] = 2650;
            ["y"] = 987;
            ["size"] = 43;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_1";
	                ["distance"] = 373.760620;
	            },
	            [2] = {
	                ["name"] = "wp_33";
	                ["distance"] = 391.763275;
	            },
            },
        },
        [27] = {
            ["name"] = "wp_33";
            ["x"] = 2365;
            ["y"] = 819;
            ["size"] = 30;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_1";
	                ["distance"] = 380.073517;
	            },
	            [2] = {
	                ["name"] = "wp_32";
	                ["distance"] = 391.763275;
	            },
            },
        },
        [28] = {
            ["name"] = "wp_4";
            ["x"] = 1506;
            ["y"] = 1607;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_5";
	                ["distance"] = 45.403130;
	            },
	            [2] = {
	                ["name"] = "wp_3";
	                ["distance"] = 373.541718;
	            },
            },
        },
        [29] = {
            ["name"] = "wp_5";
            ["x"] = 1462;
            ["y"] = 1614;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_4";
	                ["distance"] = 45.403130;
	            },
	            [2] = {
	                ["name"] = "wp_6";
	                ["distance"] = 152.481216;
	            },
            },
        },
        [30] = {
            ["name"] = "wp_6";
            ["x"] = 1370;
            ["y"] = 1690;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_7";
	                ["distance"] = 105.515152;
	            },
	            [2] = {
	                ["name"] = "wp_5";
	                ["distance"] = 152.481216;
	            },
            },
        },
        [31] = {
            ["name"] = "wp_7";
            ["x"] = 1290;
            ["y"] = 1733;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_6";
	                ["distance"] = 105.515152;
	            },
	            [2] = {
	                ["name"] = "wp_8";
	                ["distance"] = 106.437775;
	            },
            },
        },
        [32] = {
            ["name"] = "wp_8";
            ["x"] = 1195;
            ["y"] = 1763;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_9";
	                ["distance"] = 100.527390;
	            },
	            [2] = {
	                ["name"] = "wp_7";
	                ["distance"] = 106.437775;
	            },
            },
        },
        [33] = {
            ["name"] = "wp_9";
            ["x"] = 1097;
            ["y"] = 1777;
            ["size"] = 0;
            ["childs"] = {
	            [1] = {
	                ["name"] = "wp_10";
	                ["distance"] = 83.254776;
	            },
	            [2] = {
	                ["name"] = "wp_8";
	                ["distance"] = 100.527390;
	            },
            },
        },
    },
}

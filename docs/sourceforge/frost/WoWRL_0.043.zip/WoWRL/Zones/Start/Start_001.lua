
Zone = {
    ["width"] = 1024;
    ["height"] = 1024;
    ["start_x"] = 0;
    ["start_y"] = 256;
    ["respawn_time"] = 210; -- WIP
    ["scale"] = 1;
    ["vscale"] = 0.75;
    ["Background"] = {
        [1] = {
            ["background"] = "Zones/Start/Start_001/Start_001_01.jpg";
            ["distortion"] = "Zones/Start/Start_001/Start_001_01_d.png";
        },
    },
    ["Links"] = nil; -- WIP
    ["Doodads"] = nil;
    ["Waypoints"] = nil;
}
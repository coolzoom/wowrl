-- Item database

function GSC(g, s, c)
	-- Converts (Gold, Silver, Copper) to Copper
	return (g*100+s)*100+c;
end

Items = {
	[8952] = { -- Roasted Quail
		["display_name"] = "item_8952_name";
		["description"] = "item_8952_desc";
		["icon"] = "Icons/INV_Misc_Food_15.png";
		["type"] = ITEM_TYPE_CONSUMABLE;
		["quality"] = ITEM_QUALITY_COMMON;
		["binds"] = ITEM_BINDS_NEVER;
		["requieres_lvl"] = 45;
		["unique"] = 0;
		["stacks"] = 20;
		["charges"] = 1;
		["sellable"] = true;
		["sell_value"] = GSC(0, 2, 0);
		["buy_value"] = GSC(0, 8, 0);
	},
	[19362] = { -- Doom's Edge
		["display_name"] = "item_19362_name";
		["description"] = "item_19362_desc";
		["icon"] = "Icons/INV_Axe_15.png";
		["model"] = "DoomsEdge";
		["type"] = ITEM_TYPE_WEAPON;
		["quality"] = ITEM_QUALITY_EPIC;
		["binds"] = ITEM_BINDS_PICKUP;
		["requieres_lvl"] = 60;
		["unique"] = 1;
		["sellable"] = true;
		["sell_value"] = GSC(7, 42, 38);
	},
}
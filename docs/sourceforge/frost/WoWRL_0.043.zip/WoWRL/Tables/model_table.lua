-- Model database

Models = {
	-- Characters
    --[[["bloodelf_male"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/BloodElfMale.m2";
		["skin"] = "Textures/Character/BloodElf/Male/BloodElfMaleSkin.png";
        ["preload"] = true;
    },
    ["bloodelf_female"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/BloodElfFemale.m2";
		["skin"] = "Textures/Character/BloodElf/Female/BloodElfFemaleSkin.png";
        ["preload"] = true;
    },
    ["draenei_male"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/DraeneiMale.m2";
		["skin"] = "Textures/Character/Draenei/Male/DraeneiMaleSkin.png";
        ["preload"] = true;
    },
    ["draenei_female"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/DraeneiFemale.m2";
		["skin"] = "Textures/Character/Draenei/Female/DraeneiFemaleSkin.png";
        ["preload"] = true;
    },
    ["dwarf_male"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/DwarfMale.m2";
		["skin"] = "Textures/Character/Dwarf/Male/DwarfMaleSkin.png";
        ["preload"] = true;
    },
    ["dwarf_female"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/DwarfFemale.m2";
		["skin"] = "Textures/Character/Dwarf/Female/DwarfFemaleSkin.png";
        ["preload"] = true;
    },
    ["gnome_male"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/GnomeMale.m2";
		["skin"] = "Textures/Character/Gnome/Male/GnomeMaleSkin.png";
        ["preload"] = true;
    },
    ["gnome_female"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/GnomeFemale.m2";
		["skin"] = "Textures/Character/Gnome/Female/GnomeFemaleSkin.png";
        ["preload"] = true;
    },
    ["human_male"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/HumanMale.m2";
		["skin"] = "Textures/Character/Human/Male/HumanMaleSkin.png";
        ["preload"] = true;
    },
    ["human_female"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/HumanFemale.m2";
		["skin"] = "Textures/Character/Human/Female/HumanFemaleSkin.png";
        ["preload"] = true;
    },
    ["nightelf_male"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/NightElfMale.m2";
		["skin"] = "Textures/Character/NightElf/Male/NightElfMaleSkin.png";
        ["preload"] = true;
    },
    ["nightelf_female"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/NightElfFemale.m2";
		["skin"] = "Textures/Character/NightElf/Female/NightElfFemaleSkin.png";
        ["preload"] = true;
    },
    ["orc_male"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/OrcMale.m2";
		["skin"] = "Textures/Character/Orc/Male/OrcMaleSkin.png";
        ["preload"] = true;
    },
    ["orc_female"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/OrcFemale.m2";
		["skin"] = "Textures/Character/Orc/Female/OrcFemaleSkin.png";
        ["preload"] = true;
    },]]--
    ["scourge_male"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/ScourgeMale.m2";
		["skin"] = "Textures/Character/Scourge/Male/ScourgeMaleSkin.png";
        ["preload"] = true;
    },
    ["scourge_female"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/ScourgeFemale.m2";
		["skin"] = "Textures/Character/Scourge/Female/ScourgeFemaleSkin.png";
        ["preload"] = true;
    },
    ["tauren_male"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/TaurenMale.m2";
		["skin"] = "Textures/Character/Tauren/Male/TaurenMaleSkin.png";
        ["preload"] = true;
    },
    ["tauren_female"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/TaurenFemale.m2";
		["skin"] = "Textures/Character/Tauren/Female/TaurenFemaleSkin.png";
        ["preload"] = true;
    },
    ["troll_male"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/TrollMale.m2";
		["skin"] = "Textures/Character/Troll/Male/TrollMaleSkin.png";
        ["preload"] = true;
    },
    ["troll_female"] = {
		["type"] = MODEL_TYPE_CHARACTER;
        ["file"] = "Models/Character/TrollFemale.m2";
		["skin"] = "Textures/Character/Troll/Female/TrollFemaleSkin.png";
        ["preload"] = true;
    },
	
	-- Weapons
	["DoomsEdge"] = {
		["type"] = MODEL_TYPE_ITEM;
		["file"] = "Models/Item/ObjectComponents/Weapon/Axe_1H_Blackwing_A_01.m2";
		["skin"] = "Textures/Item/ObjectComponents/Weapon/Axe_1H_Blackwing_A_01.png";
	},
}
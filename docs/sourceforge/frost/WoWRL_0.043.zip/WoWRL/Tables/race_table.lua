-- Race database

Races = {
	--[[["bloodelf"] = {
		["display_name"] = "race_bloodelf";
		["model_male"] = "bloodelf_male";
        ["model_female"] = "bloodelf_female";
	},
	["draenei"] = {
		["display_name"] = "race_draenei";
		["model_male"] = "draenei_male";
        ["model_female"] = "draenei_female";
	},
	["dwarf"] = {
		["display_name"] = "race_dwarf";
		["model_male"] = "dwarf_male";
        ["model_female"] = "dwarf_female";
	},
	["gnome"] = {
		["display_name"] = "race_gnome";
		["model_male"] = "gnome_male";
        ["model_female"] = "gnome_female";
	},
	["human"] = {
		["display_name"] = "race_human";
		["model_male"] = "human_male";
        ["model_female"] = "human_female";
	},
	["nightelf"] = {
		["display_name"] = "race_nightelf";
		["model_male"] = "nightelf_male";
        ["model_female"] = "nightelf_female";
	},
	["orc"] = {
		["display_name"] = "race_orc";
		["model_male"] = "orc_male";
        ["model_female"] = "orc_female";
	},]]--
	["scourge"] = {
		["display_name"] = "race_scourge";
		["model_male"] = "scourge_male";
        ["model_female"] = "scourge_female";
        ["shadow_scale"] = 0.7;
        ["status_bar_size"] = 45;
		["status_bar_offset_y"] = 62;
	},
	["tauren"] = {
		["display_name"] = "race_tauren";
		["model_male"] = "tauren_male";
        ["model_female"] = "tauren_female";
        ["shadow_scale"] = 0.8;
		["status_bar_size"] = 60;
		["status_bar_offset_y"] = 65;
	},
	["troll"] = {
		["display_name"] = "race_troll";
		["model_male"] = "troll_male";
        ["model_female"] = "troll_female";
        ["shadow_scale"] = 0.8;
		["status_bar_size"] = 45;
		["status_bar_offset_y"] = 80;
	},
}
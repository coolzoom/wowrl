-- Class database

Classes = {
	[1] = {
		["name"] = "mage";
		["display_name"] = "class_mage";
		["id"] = 1;
		--["animset"] = "mage";
		["health_gained_per_spirit"] = 0.10;
		["health_gained_per_tick"] = 6;
		["mana_gained_per_spirit"] = 0.25;
		["mana_gained_per_tick"] = 12.5;
		["power_type"] = 0;
		["regen_health_in_combat"] = 0.00;
		["regen_mana_in_combat"] = 0.30;
		["icon"] = "Icons/Class_Mage.png";
		["spells"] = {
			[1] = {
				["name"] = "frostbolt_rk11";
				["available_at_lvl"] = 58;
				["cost"] = 15000;
			},
			[2] = {
				["name"] = "chilling_armor_rk1";
			},
		},
		["talent_trees"] = {
			[1] = {
				["name"] = "mage_arcane";
				["display_name"] = "class_mage_tree_arcane";
				["role"] = "offensive";
				["default_spell"] = "frostbolt_rk11";
			},
			[2] = {
				["name"] = "mage_fire";
				["display_name"] = "class_mage_tree_fire";
				["role"] = "offensive";
				["default_spell"] = "frostbolt_rk11";
			},
			[3] = {
				["name"] = "mage_frost";
				["display_name"] = "class_mage_tree_frost";
				["role"] = "offensive";
				["default_spell"] = "frostbolt_rk11";
			},
		},
		["default_spec"] = "mage_frost";
	},
	[2] = {
		["name"] = "hunter";
		["display_name"] = "class_hunter";
		["id"] = 2;
		--["animset"] = "hunter";
		["health_gained_per_spirit"] = 0.25;
		["health_gained_per_tick"] = 6;
		["mana_gained_per_spirit"] = 0.2;
		["mana_gained_per_tick"] = 15;
		["power_type"] = 2;
		["regen_health_in_combat"] = 0.00;
		["regen_mana_in_combat"] = 0.00;
		["icon"] = "Icons/Class_Hunter.png";
		["spells"] = {
			[1] = {
				["name"] = "auto_shoot";
				["available_at_lvl"] = 1;
				["cost"] = 0;
			},
		},
		["talent_trees"] = {
			[1] = {
				["name"] = "hunter_beast_mastery";
				["display_name"] = "class_hunter_tree_beast_mastery";
				["role"] = "offensive";
				["default_spell"] = "auto_shoot";
			},
			[2] = {
				["name"] = "hunter_marksman_ship";
				["display_name"] = "class_hunter_tree_marksman_ship";
				["role"] = "offensive";
				["default_spell"] = "auto_shoot";
			},
			[3] = {
				["name"] = "hunter_survival";
				["display_name"] = "class_hunter_tree_survival";
				["role"] = "offensive";
				["default_spell"] = "auto_shoot";
			},
		},
		["default_spec"] = "hunter_marksman_ship";
	},
	[3] = {
		["name"] = "priest";
		["display_name"] = "class_priest";
		["id"] = 3;
		--["animset"] = "mage";
		["health_gained_per_spirit"] = 0.10;
		["health_gained_per_tick"] = 6;
		["mana_gained_per_spirit"] = 0.25;
		["mana_gained_per_tick"] = 12.5;
		["power_type"] = 1;
		["regen_health_in_combat"] = 0.00;
		["regen_mana_in_combat"] = 0.15;
		["icon"] = "Icons/Class_Priest.png";
		["spells"] = {
			[1] = {
				["name"] = "greater_heal_rk5";
				["available_at_lvl"] = 58;
				["cost"] = 15000;
			},
			[2] = {
				["name"] = "resurrection_rk5";
				["available_at_lvl"] = 58;
				["cost"] = 15000;
			},
		},
		["talent_trees"] = {
			[1] = {
				["name"] = "priest_discipline";
				["display_name"] = "class_priest_tree_discipline";
				["role"] = "heal";
				["default_spell"] = "greater_heal_rk5";
			},
			[2] = {
				["name"] = "priest_holy";
				["display_name"] = "class_priest_tree_holy";
				["role"] = "heal";
				["default_spell"] = "greater_heal_rk5";
			},
			[3] = {
				["name"] = "priest_shadow";
				["display_name"] = "class_priest_tree_shadow";
				["role"] = "offensive";
				["default_spell"] = "greater_heal_rk5";
			},
		},
		["default_spec"] = "priest_holy";
	},
}
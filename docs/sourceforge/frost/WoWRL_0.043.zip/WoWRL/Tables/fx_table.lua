-- Special effects database

Effects = {
	[1] = {
	    ["name"] = "mage_frostbolt";
	    ["type"] = "psys";
	    ["life_duration"] = 0.0;
	    ["file"] = "FX/spells/mage/mage_frostbolt.psi";
	    ["sprite"] = Gfx_createSprite(
					 	"psys_particle",
						"FX/generic/particles.png",
						false, 96, 32, 32, 32, 0, 0
					 );
		["blend_mode"] = "add";
		["fire_delay"] = 0.20;
		["offset_x"] = 0.0;
		["offset_y"] = -40.0;
	},
	[2] = {
	    ["name"] = "mage_casting_frost";
	    ["type"] = "multi_angle_anim";
	    ["life_duration"] = 0.0;
		["fade_in"] = 0.5;
		["fade_out"] = 0.5;
		["blend_mode"] = "add";
		["sub_animations"] = {
		    [0] = Gfx_createAnimation(
	                    "mage_casting_frost_0",
	                    "FX/spells/mage/mage_casting_frost_1.png",
	                    false, 16, 13, 0, 0, 77, 73, 38, 54
				  );
			[1] = Gfx_createAnimation(
	                    "mage_casting_frost_1",
	                    "FX/spells/mage/mage_casting_frost_1.png",
	                    false, 16, 13, 231, 73, 77, 73, 40, 48
				  );
			[2] = Gfx_createAnimation(
	                    "mage_casting_frost_2",
	                    "FX/spells/mage/mage_casting_frost_1.png",
	                    false, 16, 13, 462, 146, 77, 73, 38, 47
				  );
			[3] = Gfx_createAnimation(
	                    "mage_casting_frost_3",
	                    "FX/spells/mage/mage_casting_frost_1.png",
	                    false, 16, 13, 693, 219, 77, 73, 43, 48
				  );
			[4] = Gfx_createAnimation(
	                    "mage_casting_frost_4",
	                    "FX/spells/mage/mage_casting_frost_2.png",
	                    false, 16, 13, 0, 0, 71, 78, 35, 54
				  );
			[5] = Gfx_createAnimation(
	                    "mage_casting_frost_5",
	                    "FX/spells/mage/mage_casting_frost_2.png",
	                    false, 16, 13, 142, 76, 71, 78, 36, 54
				  );
			[6] = Gfx_createAnimation(
	                    "mage_casting_frost_6",
	                    "FX/spells/mage/mage_casting_frost_2.png",
	                    false, 16, 13, 284, 152, 71, 78, 36, 51
				  );
			[7] = Gfx_createAnimation(
	                    "mage_casting_frost_7",
	                    "FX/spells/mage/mage_casting_frost_2.png",
	                    false, 16, 13, 426, 228, 71, 78, 34, 55
				  );
		},
	},
	[3] = {
	    ["name"] = "mage_chilling_armor";
	    ["type"] = "single_angle_anim";
	    ["life_duration"] = 2.0;
		["fade_in"] = 0.0;
		["fade_out"] = 0.5;
		["scale"] = 0.65;
		["loop"] = false;
		["offset_x"] = 0.0;
		["offset_y"] = -80.0;
		["animation"] = Gfx_createAnimation(
	                    	"mage_chilling_armor",
	                    	"FX/spells/mage/mage_ice_armor.png",
	                    	false, 20, 40, 0, 0, 45, 64, 22, 32
				  		);
	},
	[4] = {
	    ["name"] = "generic_poison";
	    ["type"] = "psys";
	    ["life_duration"] = 0.0;
	    ["file"] = "FX/spells/generic/generic_poison.psi";
	    ["sprite"] = "psys_particle";
		["blend_mode"] = "add";
		["fire_delay"] = 0.00;
		["offset_x"] = -20.0;
		["offset_y"] = -50.0;
	},
}
-- Buffs database

Buffs = {
	-- # Default values :
	-- display_name : ""
	-- description : ""
	-- icon : "Icons/INV_Misc_QuestionMark.png"
	-- duration : 0 (infinite)
	-- max_count : 1
	
-- MAGE
	["chilling_armor_rk1"] = {
		["display_name"] = "buff_chilling_armor_name";
		["description"] = "buff_chilling_armor_desc";
		["duration"] = 1800;
		["icon"] = "Icons/Spell_Frost_ChillingArmor.png"
	},
}
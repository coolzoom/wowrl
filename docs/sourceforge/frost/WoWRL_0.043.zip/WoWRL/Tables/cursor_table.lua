-- Cursors database

Cursors = {
	[1] = {
	    ["name"] = "normal";
		["sprite"] = Gfx_createSprite(
					 	"cursor_normal",
						"Cursors/cur_normal.png",
						false, 0, 0, "texw", "texh", 0, 0
					 );
	},
	[2] = {
	    ["name"] = "normal_imp";
		["sprite"] = Gfx_createSprite(
					 	"cursor_normal_imp",
						"Cursors/cur_normal_imp.png",
						false, 0, 0, "texw", "texh", 0, 0
					 );
	},
	[3] = {
	    ["name"] = "normal_action";
		["sprite"] = Gfx_createSprite(
						"cursor_normal_action",
						"Cursors/cur_normal_action.png",
						false, 0, 0, "texw", "texh", 16, 16
					 );
	},
	[4] = {
	    ["name"] = "normal_action_imp";
		["sprite"] = Gfx_createSprite(
						"cursor_normal_action_imp",
						"Cursors/cur_normal_action_imp.png",
						false, 0, 0, "texw", "texh", 16, 16
					 );
	},
	[5] = {
	    ["name"] = "attack";
		["sprite"] = Gfx_createSprite(
						"cursor_attack",
						"Cursors/cur_attack.png",
						false, 0, 0, "texw", "texh", 0, 0
					 );
	},
	[6] = {
	    ["name"] = "attack_action";
		["sprite"] = Gfx_createSprite(
						"cursor_attack_action",
						"Cursors/cur_attack_action.png",
						false, 0, 0, "texw", "texh", 16, 16
					 );
	},
	[7] = {
	    ["name"] = "attack_action_imp";
		["sprite"] = Gfx_createSprite(
						"cursor_attack_action_imp",
						"Cursors/cur_attack_action_imp.png",
						false, 0, 0, "texw", "texh", 16, 16
					 );
	},
    [8] = {
	    ["name"] = "taxi";
		["sprite"] = Gfx_createSprite(
						"cursor_taxi",
						"Cursors/cur_taxi.png",
						false, 0, 0, "texw", "texh", 0, 0
					 );
	},
	[9] = {
	    ["name"] = "pan";
		["animated"] = true;
		["anim"] = Gfx_createAnimation(
						"cursor_pan",
						"Cursors/cur_pan.png",
						false, 3, 9.0, 0, 0, 32, 32, 29, 16
				   );		
	},
}
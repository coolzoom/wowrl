/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           ModelManager header          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#ifndef WOWRL_MODELMANAGER_H
#define WOWRL_MODELMANAGER_H

#include "wowrl.h"

#include "wowrl_model.h"

class ModelManager
{
public :

    ~ModelManager();
    static ModelManager* GetSingleton();

    Model* CopyModel( Model* m );
    Model* LoadModel( std::string file );
    Model* LoadModelTable( lua_State* luaVM, std::string name );
    bool ParseModelsDyn( lua_State* luaVM, int state1, int state2, bool* finished, float filling );
    void RemoveModel( Model* m );

    void UpdateVertexList(bool rebuild = false);

    Vertex* lVertexList;
    int     iVertexNbr;

    int iMeshNbr;

protected :

    ModelManager();

private :

    static ModelManager* mModelMgr;

    std::map<std::string, Model*> lBaseModelList;
    std::map<int, Model*> lModelList;
    int iModelNbr;
    bool bRebuildVB;
};

#endif

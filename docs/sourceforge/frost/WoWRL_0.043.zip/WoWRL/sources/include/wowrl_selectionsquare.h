/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*        SelectionSquare header          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_SELECTIONSQUARE_H
#define WOWRL_SELECTIONSQUARE_H

#include "wowrl.h"


/// Displays a selection square.
/** A selection square is a semi transparent square that
*   selects all friendly units that intersects with it.
*/
class SelectionSquare
{
public :
    SelectionSquare();

/** \return A boolean stating if this selection square is active, that means that the user is using it
*/
    bool IsActive();

/** Update this selection square. Must be called every frame.
*/
    void Update();

/** Renders this selection square.
*/
    void Render();

private :
    bool     bActive;
    hgeRect* mRect;
    bool     bRenderBg;
    float    fX, fY;
    float    fW, fH;

    hgeQuad mBg;
    hgeQuad mBorder;
};



#endif

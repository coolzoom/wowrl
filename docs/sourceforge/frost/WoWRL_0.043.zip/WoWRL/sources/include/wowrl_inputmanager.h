/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          InputManager header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_INPUTMANAGER_H
#define WOWRL_INPUTMANAGER_H

#include "hge/hge.h"
//#include "hge/hgerect.h"
#include <string>

class InputManager
{
public:

    ~InputManager();
    static InputManager* GetSingleton();

    // Variables
    float       fMX, fMY;
    float       fGMX, fGMY;
    float       fDMX, fDMY;
    int         iMLState, iMRState;
    std::string sMouseButton;
    bool        bLastDragged;
    bool        bCtrlPressed;
    bool        bShiftPressed;
    bool        bAltPressed;

    // Basic input
    void  GetMousePos();
    char  GetChar(bool, bool force = false);
    bool  GetKey(bool force = false);
    bool  KeyIsDown(int, bool force = false);
    bool  KeyIsDownLong(int, bool force = false);
    bool  KeyIsPressed(int, bool force = false);
    bool  KeyIsReleased(int, bool force = false);
    bool  KeyIsDoubleClicked(int, bool force = false);
    void  Update();

    // Parameters
    void SetDoubleclickTime(float);
    void SetGlobalDisplacement(float, float);
    void SetFocus(bool);

protected:

    InputManager();

private:

    static InputManager *mInputMgr;

    float fDoubleclickTime;
    float lDoubleclickDelay[3];
    float lKeyDelay[256];
    bool  lKeyLong[256];
    bool  lKeyBuf[256];
    bool  lKeyBufOld[256];

    float fOldMX, fOldMY;
    float fGX, fGY;

    bool bFocus;
    bool bKey;
};

#endif

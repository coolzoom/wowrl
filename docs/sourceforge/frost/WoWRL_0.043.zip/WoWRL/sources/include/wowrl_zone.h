/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Zone header               */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_ZONE_H
#define WOWRL_ZONE_H

#include "wowrl.h"
#include "wowrl_structs.h"
#include "wowrl_zone.h"
#include "wowrl_doodad.h"

/// Stores informations about background and doodads.
/** This class is used to manage all the static elements of a zone,
*	such as doodads (see Doodad class), background parts (see
*	BGPart struct) or waypoints (see Waypoint struct). It is just
*	a storage class.
*/
class Zone
{
public :

/** Takes care of pointers deletion.
*/
    void DeleteThis();

/** Returns the background's tile located at the given coordinates
*	\param x The searched tile's horizontal coordinate
*	\param y The searched tile's vertical coordinate
*	\return The tile you asked
*/
    BGPart* GetBGPart(float x, float y);

/// Zone's name
    std::string sName;
/// Deprecated
    float fDistScaleMax;
/// Deprecated
    float fDistScaleMin;
/// Deprecated
    float fDistVScaleMax;
/// Deprecated
    float fDistVScaleMin;
/// Deprecated
    float fDistAngleMax;
/// Deprecated
    float fDistAngleMin;
/// Doodad container
    std::map<std::string, Doodad*> lDoodadList;
/// Waypoint container
    std::map<std::string, Waypoint> lWPntList;
/// Zone's width
    int iW;
/// Zone's height
    int iH;
/// Tile's width
    int iTW;
/// Tile's height
    int iTH;
/// WIP
    float fRespawnTime;
/// WIP
    std::map<std::string, float> lRespawn;
/// BGPart (tiles) container
    std::map<float, BGPart*> lPartList;
/// Tile size
    int iPartSize;
/// Does this Zone contains waypoints ?
    bool bWaypoints;
};

#endif

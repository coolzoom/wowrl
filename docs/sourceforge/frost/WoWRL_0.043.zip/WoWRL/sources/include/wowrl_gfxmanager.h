/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            GFXManager header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_GFXMANAGER_H
#define WOWRL_GFXMANAGER_H

#include "wowrl.h"

class GFXManager
{
public :

    ~GFXManager();
    static GFXManager* GetSingleton();

    hgeRect*          mScrRect;
    int				  iSWidth, iSHeight;
    int               iMaxFPS;
    IDirect3DDevice9* mDxDevice;
    HTARGET           mMainTarget;
    hgeSprite*        mMainSprite;

    // Textures
    HTEXTURE LoadTexture( std::string, bool mipmaps = false );
    void     FreeTextures();

    // Sprites
    hgeSprite* CreateSprite( HTEXTURE tex, float x, float y, float w, float h, bool GUI = false );
    hgeSprite* CreateSprite( hgeSprite*, bool GUI = false );
    void       DeleteSprites();

    // Animations
    hgeAnimation* CreateAnimation( HTEXTURE tex, int frames, float fps, float x, float y, float w, float h );
    void          DeleteAnimations();
    //bool          ParseAnimationsDyn( lua_State*, int, int, bool*, float );

    // PSys
    hgeParticleSystem* CreatePSys( std::string file,  hgeSprite* spr );
    void               DeletePSys();

    // Rects
    hgeRect* CreateRect( float x1, float y2, float x2, float y2 );
    void     DeleteRects();

    // Effects
    void ParseEffects( lua_State* );

    // System
    hgeSprite* pixel;

    // 3D
    //int  AddTriangle( Triangle t );
    void CreatePixelShader();
    void CreateVertexShader();
    //Triangle* GetTriangle( int i );
    void Prepare3D();
    void Prepare2D();
    void UpdatePixelShader();
    void UpdateVertexBuffer();
    void UpdateVertexShader( Model* m, int group = -1 );
    void SetProjectionMatrix( D3DXMATRIX mat );
    void SetSceneMatrices();
    void SetTexture( LPDIRECT3DTEXTURE9 tex );
    void SetViewMatrix( D3DXMATRIX mat );
    void SetWorldMatrix( D3DXMATRIX mat );

    //std::vector<Triangle> lGlobalTriangleList;

    LPDIRECT3DVERTEXBUFFER9      mVertexBuffer;
    LPDIRECT3DVERTEXSHADER9      mVertexShader;
    LPDIRECT3DVERTEXDECLARATION9 mVertexDecl;
    LPD3DXCONSTANTTABLE          mVSConstantTable;

    LPDIRECT3DPIXELSHADER9       mPixelShader;
    LPD3DXCONSTANTTABLE          mPSConstantTable;

    D3DXMATRIX mProjectionMat;
    D3DXMATRIX mViewMat;
    D3DXMATRIX mWorldMat;
    D3DXMATRIX mViewProjMat;
    D3DXMATRIX mViewport;

    D3DXHANDLE mVSCWorldViewProj;
    D3DXHANDLE mVSCWorld;
    D3DXHANDLE mVSCBoneMat;
    D3DXHANDLE mVSCMeshID;

    D3DXHANDLE mPSCLighting;
    D3DXHANDLE mPSCLightAmbient;
    D3DXHANDLE mPSCLightType;
    D3DXHANDLE mPSCLightColor;
    D3DXHANDLE mPSCLightPos;
    D3DXHANDLE mPSCLightAttenFactors;

    // Z sorted object list for rendering
    void                     BuildRenderList();
    void                     ForceUpdate();
    std::map<float, Object>  lZSortedList;
    std::map<float, Unit*>   lZSortedUnitList;
    std::map<float, Doodad*> lRenderInTopList;

    // Lists
    std::map<std::string, HTEXTURE> 	 lTextureList;
    std::map<std::string, PAnim> 		 lPAnimList;
    std::map<std::string, SEffect>       lFXList;
    std::vector<hgeSprite*>				 lSpriteList;
    std::vector<hgeAnimation*>			 lAnimList;
    std::vector<hgeParticleSystem*>      lPSysList;
    std::vector<hgeRect*>				 lRectList;

    std::map<std::string, hgeSprite*>	      lLuaSpriteList;
    std::map<std::string, hgeAnimation*>      lLuaAnimList;
    std::map<std::string, hgeParticleSystem*> lLuaPSysList;
    std::map<std::string, hgeRect*>		      lLuaRectList;

protected :

    GFXManager();

private:

    static GFXManager* mGFXMgr;

    bool bDebugParser;
    bool bDebugRenderList;
    bool bForceUpdate;

    LPDIRECT3DTEXTURE9 mCurrentTexture;

};

#endif

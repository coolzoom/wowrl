#ifndef WOWRL_ITEM_H
#define WOWRL_ITEM_H

#include "wowrl.h"
#include "wowrl_structs.h"

#define ITEM_MODEL_TYPE_NONE     0
#define ITEM_MODEL_TYPE_TEXTURE  1
#define ITEM_MODEL_TYPE_EMBEDDED 2
#define ITEM_MODEL_TYPE_EXTERN   3

struct ItemModel
{
    int iType;

    // Textured model

    // Embedded model
    int iSubMeshID;
    HTEXTURE mTex;

    // Extern model
    Model* mModel;
};

class Item
{
public :
    int         iID;
    int         iType;
    int         iQuality;
    int         iBinds;
    int         iStacks;
    int         iReqLevel;
    int         iReqClass;
    std::string sReqSkill;
    int         sReqSkillLevel;
    float       fCooldown;
    int 		iUnique;
    bool        bSoulbound;
    bool        bSellable;
    int         iSellPrice;
    int         iBuyPrice;

    // Scripts
    Spell* mOnEquip;
    Spell* mOnUse;
    Spell* mOnHit;
};

class Equipment : public Item
{
public :
    int iSlot;
    bool bEquiped;
};

class Gear : public Equipment
{
public :
    int iDurabilityMax;
    int iDurabilityCur;

    void UpdateDurability(bool death = false);

    Stats mBonus;

    // Sets
    std::map<std::string, Item*> lSetItemList;
    std::string                  sSetName;
    std::vector<Stats>           lSetBonusList;

    ItemModel mModel;
};

class Weapon : public Gear
{
public :
    int Damage();
};

class Shield : public Gear
{
public :
    bool Dodge();
};

class Armor : public Gear
{
public :
    int Hit();
};

class Bag : public Equipment
{
public :
    int iSize;

    void AddItem();
    void RemoveItem(int id);

    std::map<int, Item> lItemList;
};

class Consumable : public Item
{
public :
    int iCharges;

    bool Use();
};

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           AnimManager header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#ifndef WOWRL_ANIMMANAGER_H
#define WOWRL_ANIMMANAGER_H

#include "wowrl.h"

#include "wowrl_model.h"

struct AnimationBlock;

struct AnimData
{
    Vector4    mQuat;
    Vector3    mVec;
};

struct SequenceInfo
{
    int iLowestTime;
    int iHighestTime;
    int iStartTime;
    int iEndTime;
    D3DXMATRIX mEndMat;
    int iStartID;
};

struct Anim
{
    Anim();
    Anim(const Anim &a);
    ~Anim();

    int  iInterpolation;
    bool bUsed;
    bool bIsCopy;
    int  iType;
    int  iActualUpID;
    int  iFirstTime;
    AnimData* mFirstData;
    int  iSecondTime;
    AnimData* mSecondData;

    int  iTimeNbr;
    int* lTimes;
    AnimData* lData;
    int  iSequenceNbr;
    SequenceInfo* lInfo;

    // Transition
    AnimData mLastData;
    AnimData mTFirstData;
    AnimData* mTSecondData;
    bool bTDataBuilt;
    int  iOldTSequence;

    bool GetMatrix(D3DXMATRIX* m, int iTime, int iSequence);
    bool GetMatrixT(D3DXMATRIX* m,  float fCoef, int iSequence);
    void Load(int type, char* buffer, AnimationBlock* anim, AnimSequence* lAnimList, int sequenceNbr);
};

class Bone
{
public :

    Bone();
    Bone(const Bone &b);
    ~Bone();

    int   iID;
    int   iSequence;
    int   iParent;
    bool  bAnimated;
    bool  bRoot;
    bool  bUpperBody;
    bool  bUnknown;
    float fX, fY, fZ;
    Anim* mTranslate;
    Anim* mRotate;
    Anim* mScale;
    int*  lChildList;
    int   iChildNbr;

    int iLastUpdated;
    int iLastTime;
    float fLastCoef;

    bool Update(Model* m, int iTime, int iSequence, bool forceAll = false);
    bool UpdateT(Model* m, float fCoef, int iSequence);
    D3DXMATRIX* GetMatrix() { return &mMat; }

private :
    D3DXMATRIX mMat;
};

struct AnimSequence
{
    int iRID;
    int iID;
    int iLoop;
    int iStart, iEnd;
    int iNextAnim;
    int iNextNbr;
    Vector3 vBBoxMin, vBBoxMax;
};

class AnimManager
{
public :

    AnimManager(Model* parent, AnimSequence* asList, int animNbr);
    AnimManager(const AnimManager &mgr);
    ~AnimManager();

    bool IsAnimated() { return (mActualAnim != NULL); }
    AnimSequence* GetAnim(AnimID ID = ANIM_NONE);
    int  GetAnimID() { if (mActualAnim != NULL) return mActualAnim->iID; else return -1; }
    void SetParent(Model* parent);
    void SetAnim(AnimID a, bool pauseAfter = false);
    void Play();
    void Pause();
    void PrepareMatrixList();
    void Update(float dt);
    D3DXMATRIX** GetMeshMatrices(Mesh* m, int* bNbr);

    int iLastUpdatedBones;
    int iBoneToUpdate;
    bool bNewFrame;

protected :

    AnimManager();

private :

    void RandomAnim();

    AnimSequence* lAnimList;
    int iAnimNbr;
    AnimSequence* mActualAnim;
    AnimSequence* mRefAnim;
    bool bPaused;
    bool bPauseAfter;
    bool bTransition;
    AnimSequence* mOldAnim;
    int  iTime;
    int  iTrueTime;
    Model* mParent;

    int iUpdatedBones;
    int iLastBaseBone;
    int iLastBoneChild;

};

#endif

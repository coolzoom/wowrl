/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Status bar header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_STATUSBAR_H
#define WOWRL_STATUSBAR_H

#include "wowrl.h"

/// Displays units' health state.
/** This class is used to display a small status bar
*   above every unit's head indicating its health state.
*/
class StatusBar
{
public :

    StatusBar();
    ~StatusBar();

/** Renders this status bar. No position is provided : it's locked to its parent unit.
*/
    void Render();

/// Background's left part
    hgeSprite* mBgLeft;
/// Background's middle part
    hgeSprite* mBgMiddle;
/// Background's right part
    hgeSprite* mBgRight;
/// Gauge
    hgeSprite* mGauge;
/// Parent unit
    Unit*      mParent;
/// Status bar width
    float      fSize;
/// Status bar filling
    float      fState;
/// Status bar color
    RGB        cColor;
};

#endif

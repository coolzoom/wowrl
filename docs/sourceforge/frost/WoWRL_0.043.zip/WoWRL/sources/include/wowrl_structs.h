/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Structures header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_STRUCTS_H
#define WOWRL_STRUCTS_H

#include "wowrl.h"
#include "wowrl_stats.h"

struct RGB
{
    float fR;
    float fG;
    float fB;
};

struct FormatedString
{
    float       fX, fY;
    DWORD       dwColor;
    std::string sStr;

    FormatedString()
    {
        dwColor = ARGB(255, 255, 255, 255);
        fX = 0;
        fY = 0;
    }
};

struct FormatedText
{
    std::list<FormatedString> lFStr;
    hgeFont*    mFnt;
    int         iFntSize;
    DWORD       dwColor;
    int         iAlign;
    float       fTracking;
    bool        bBox;
    float       fW, fH;
    std::string sStr;
    std::string sBaseStr;
    bool        bShadow;
    int         iOutline;
    float       fSOffX, fSOffY;
    DWORD       dwSColor;

    FormatedText()
    {
        dwColor = ARGB(255, 255, 255, 255);
        dwSColor = ARGB(255, 0, 0, 0);
        mFnt = NULL;
    }
};

struct SBuff
{
    std::string sName;
    float       fDuration;
    int         iMaxCount;

    SBuff()
    {
        sName = "";
    }
};

struct Buff
{
    std::string sName;
    SBuff*      mBuff;
    int         iCount;
    float       fLife;
};

struct Spell
{
    std::string sName;
    bool		bLoaded;
    float       fCastTime;
    float       fCost;
    float       fCostP;
    float       fRange;
    bool        bSelfOnly;
    bool        bGCD;
    float       fCrits;
    bool        bUsableInCombat;
    bool		bPutsInCombat;
    bool        bLoop;
    int         iSchool;
    bool        bHasCastEffect;
    std::string sCastEffect;
    bool        bHasAttackEffect;
    std::string sAttackEffect;
    bool		bHasProj;
    float		fProjSpeed;
    bool		bChanneled;
    int			iTargetType;
    bool        bMelee;

    AnimID mCastAnim;
    AnimID mIncantAnim;

    std::string sOnCastBegin;
    std::string sOnCasted;
    std::string sOnImpact;
    std::string sOnUpdate;

    Spell()
    {
        sName = "";
        bLoaded = false;
    }

};

struct SpellData
{
    Spell* mSpell;
    int    iCost;
    int    iLevelRequiered;
};

struct Specialisation
{
    std::string sName;
    std::string sDisplayName;
    std::string sRole;
    Spell*      mDefaultSpell;
};

struct Cursor
{
    std::string   sName;
    bool          bAnimated;
    float         fRot;
    hgeSprite*    mSprite;
    hgeAnimation* mAnim;
};

struct Class
{
    std::string     sName;
    std::string     sDisplayName;
    int             iID;
    float           fScale;
    hgeSprite*      mIcon;
    Specialisation* mDefaultSpec;
    float           fHealthGainedPerSpirit;
    float           fHealthGainedPerTick;
    float           fManaGainedPerSpirit;
    float           fManaGainedPerTick;
    float           fGCD;
    int             iPowerType;
    float           fRegenHealthInCombat;
    float           fRegenManaInCombat;

    std::map<std::string, SpellData>      lSpellList;
    std::map<std::string, Specialisation> lSpecList;
};

struct Race
{
    std::string sName;
    std::string sDisplayName;
    Model*      mMaleModel;
    Model*      mFemaleModel;
    float       fShadowScale;
    float       fStatusBarSize;
    float       fStatusBarYOffset;
};

struct Animation
{
    hgeAnimation* lStateList[8];
};

struct AnimatedEffect
{
    float         fFadeIn;
    float         fFadeOut;
    int           iType;
    float         fScale;
    hgeAnimation* lStateList[8];
    hgeAnimation* mAnim;
};

struct ParticleEffect
{
    hgeParticleSystem* mPSys;
    float              fDelay;
};

struct SEffect
{
    std::string    sName;
    int            iType;
    float          fLife;
    float          fOffX;
    float          fOffY;
    AnimatedEffect mAFX;
    ParticleEffect mPFX;
};

struct PAnim
{
    std::string sName;
    std::map<std::string, Animation> lAnimationList;
};

struct ActionButton
{
    bool        bClickable;
    std::string sReason;
    int         iType;
    Spell*      mSpell;
    Item*       mItem;
};

struct Object
{
    int   iType;
    void* mPtr;
};

struct ScrollingText
{
    Unit*       mParent;
    float       fX, fY;
    int         iType;
    std::string sValue;
    float       fLifeTime;
    DWORD		dwColor;
};

struct ErrorText
{
    std::string sCaption;
    float       fAlpha;
    float       fLifeTime;
};

struct BGPart
{
    int        iID;
    float      fX, fY;
    float      fW, fH;
    hgeSprite* mBg;
    bool       bDistData;
    DWORD*     mDist;
    DWORD      dwGlobalDist;
};

struct Waypoint
{
    float       fX, fY;
    float       fSize;
    std::string sName;
    std::multimap<float, Waypoint*> lChildList;

    // Temporary attributes used for pathfinding
    bool      bUseless;
    bool      bOpened;
    bool      bClosed;
    float     fG;
    Waypoint* mParent;
};

struct AddOn
{
    std::string sName;
    std::string sVersion;
    float fUIVersion;
    std::string sAuthor;

    bool bEnabled;
    bool bLoaded;

    std::string sFolder;

    std::vector<std::string> lFileList;
    std::vector<std::string> lSavedVariableList;

    AddOn()
    {
        bEnabled = true;
        bLoaded = false;
    }
};

#endif

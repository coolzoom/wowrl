/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Lua header                */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_LUA_H
#define WOWRL_LUA_H

#include "wowrl.h"
#include <string>

#define LUA_MSTRLIBNAME	"string"

class LUA
{
public :

    static std::string ConcTable( std::string table );

    static int  LogL( lua_State* luaVM );
    static void Print( std::string str );
    static void PrintError( std::string error );

    static int         GetGlobalInt( std::string name, bool critical = true, int defaultValue = 0 );
    static float       GetGlobalFloat( std::string name, bool critical = true, float defaultValue = 0.0f );
    static std::string GetGlobalString( std::string name, bool critical = true, std::string defaultValue = "" );
    static bool        GetGlobalBool( std::string name, bool critical = true, bool defaultValue = false );

    static int         GetFieldInt( std::string name, bool critical = true, int defaultValue = 0, bool setValue = false, lua_State* luaVM = NULL );
    static float       GetFieldFloat( std::string name, bool critical = true, float defaultValue = 0.0f, bool setValue = false, lua_State* luaVM = NULL );
    static std::string GetFieldString( std::string name, bool critical = true, std::string defaultValue = "", bool setValue = false, lua_State* luaVM = NULL );
    static bool        GetFieldBool( std::string name, bool critical = true, bool defaultValue = false, bool setValue = false, lua_State* luaVM = NULL );

    static void SetFieldInt( std::string name, int value, lua_State* luaVM = NULL );
    static void SetFieldFloat( std::string name, float value, lua_State* luaVM = NULL );
    static void SetFieldString( std::string name, std::string value, lua_State* luaVM = NULL );
    static void SetFieldBool( std::string name, bool value, lua_State* luaVM = NULL );

    static void SetIFieldInt( int id, int value, lua_State* luaVM = NULL );
    static void SetIFieldFloat( int id, float value, lua_State* luaVM = NULL );
    static void SetIFieldString( int id, std::string value, lua_State* luaVM = NULL );
    static void SetIFieldBool( int id, bool value, lua_State* luaVM = NULL );

    static void RegisterAll( lua_State* luaVM );

    // Edited string lib

    static int  OpenString( lua_State* luaVM );
    static void OpenLibs( lua_State* luaVM );
};

// Glue, but also used direcly in C++
int l_SendString( lua_State* luaVM );
int l_ConcTable( lua_State* luaVM );


#endif

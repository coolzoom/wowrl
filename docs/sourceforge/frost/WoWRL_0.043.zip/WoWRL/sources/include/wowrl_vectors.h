/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*       Vector3 and Vector4 header       */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#ifndef WOWRL_VECTORS_H
#define WOWRL_VECTORS_H

#include "wowrl.h"

inline float SaturateFloat(float f)
{
    if (f < 0.0f)
        f = 0.0f;
    else if (f > 1.0f)
        f = 1.0f;

    return f;
}

struct Vector3
{
	float x, y, z;

	Vector3(float xi=0.0f, float yi=0.0f, float zi=0.0f) : x(xi), y(yi), z(zi) {}

	Vector3(float xi, float yi, float zi, D3DXMATRIX mat)
	{
		x = xi; y = yi; z = zi;
		this->operator*=(mat);
	}

	void Normalize()
	{
		float lenght = sqrt(x*x + y*y + z*z);
		x = x/lenght; y = y/lenght;	z = z/lenght;
	}

	void Saturate()
	{
	    SaturateFloat(x);
        SaturateFloat(y);
        SaturateFloat(z);
	}

	float GetLength()
	{
		return sqrt(x*x + y*y + z*z);
	}

	Vector3 operator* (float a)
	{
		Vector3 v(x*a, y*a, z*a);
		return v;
	}

	void operator*= (float a)
	{
		x *= a;	y *= a;	z *= a;
	}

	void operator*= (D3DXMATRIX mat)
	{
		x = (x*mat._11)+(y*mat._21)+(z*mat._31)+(1*mat._41);
		y = (x*mat._12)+(y*mat._22)+(z*mat._32)+(1*mat._42);
		z = (x*mat._13)+(y*mat._23)+(z*mat._33)+(1*mat._43);
	}

	Vector3 operator+ (Vector3 v2)
	{
		Vector3 v;
		v.x = this->x + v2.x;
		v.y = this->y + v2.y;
		v.z = this->z + v2.z;
		return v;
	}

	void operator+= (Vector3 v2)
	{
		x += v2.x; y += v2.y; z += v2.z;
	}

	Vector3 operator- (Vector3 v2)
	{
		Vector3 v;
		v.x = this->x - v2.x;
		v.y = this->y - v2.y;
		v.z = this->z - v2.z;
		return v;
	}

	void operator-= (Vector3 v2)
	{
		x -= v2.x; y -= v2.y; z -= v2.z;
	}

	Vector3 Interpolate(float r, Vector3 v2);

	D3DXVECTOR3 GetDXVector()
	{
	    return D3DXVECTOR3(x, y, z);
	}

	static float DotProduct(Vector3* v1, Vector3* v2)
    {
        return v1->x*v2->x + v1->y*v2->y + v1->z*v2->z;
    }

    static Vector3 Min(Vector3* v1, Vector3* v2)
    {
        return Vector3(std::min(v1->x,v2->x), std::min(v1->y, v2->y), std::min(v1->z, v2->z));
    }

    static Vector3 Max(Vector3* v1, Vector3* v2)
    {
        return Vector3(std::max(v1->x,v2->x), std::max(v1->y, v2->y), std::max(v1->z, v2->z));
    }
};

struct Vector4
{
    float x, y, z, w;

    Vector4(float xi=0.0f, float yi=0.0f, float zi=0.0f, float wi=0.0f) : x(xi), y(yi), z(zi), w(wi) {}

    void Normalize()
	{
		float length = sqrt(x*x + y*y + z*z + w*w);
		x = x/length; y = y/length;	z = z/length; w = w/length;
	}

    float operator* (Vector4 v)
	{
		return x*v.x + y*v.y + z*v.z + w*v.w;
	}

    Vector4 operator* (float a)
	{
		Vector4 v(x*a, y*a, z*a, w*a);
		return v;
	}

    void operator*= (float a)
	{
		x *= a;	y *= a;	z *= a; w *= a;
	}

	Vector4 operator+ (Vector4 v)
	{
		return Vector4(x+v.x, y+v.y, z+v.z, w+v.w);
	}

	void operator+= (Vector4 v)
	{
		x+=v.x; y+=v.y; z+=v.z; w+=v.w;
	}

	Vector4 operator- (Vector4 v)
	{
		return Vector4(x-v.x, y-v.y, z-v.z, w-v.w);
	}

	void operator-= (Vector4 v)
	{
		x-=v.x; y-=v.y; z-=v.z; w-=v.w;
	}

	D3DXQUATERNION GetDXQuaternion()
	{
	    return D3DXQUATERNION(x,y,z,w);
	}

	// Linear interpolation
	Vector4 InterpolateL(float r, Vector4 v2);
	// A other lerp, more accurate than the above, but less performant
	Vector4 InterpolateL2(float r, Vector4 v2);

	// Spherical interpolation
	Vector4 InterpolateS(float r, Vector4 v2);
};

inline D3DXVECTOR4 SaturateDXVec(D3DXVECTOR4 v)
{
    v.x = SaturateFloat(v.x);
    v.y = SaturateFloat(v.y);
    v.z = SaturateFloat(v.z);
    v.w = SaturateFloat(v.w);

    return v;
}

inline float Dist(Vector3 v1, Vector3 v2)
{
    Vector3 v = v1 - v2;
    return v.GetLength();
}

inline void D3DXMatrixScaling(D3DXMATRIX* mat, Vector3* vec)
{
    D3DXMatrixScaling(mat, vec->x, vec->y, vec->z);
}

inline void D3DXMatrixTranslation(D3DXMATRIX* mat, Vector3* vec)
{
    D3DXMatrixTranslation(mat, vec->x, vec->y, vec->z);
}

inline void D3DXMatrixRotationQuaternion(D3DXMATRIX* mat, Vector4* vec)
{
    D3DXQUATERNION quat = vec->GetDXQuaternion();
    D3DXMatrixRotationQuaternion(mat, &quat);
}

void D3DXMatrixViewport(D3DXMATRIX* mat);

void D3DXMatrixInterpolateL(D3DXMATRIX* mat, D3DXMATRIX* m1, D3DXMATRIX* m2, float fCoef);

#endif

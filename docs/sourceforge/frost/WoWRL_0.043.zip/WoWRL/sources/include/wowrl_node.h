/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Node header               */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_NODE_H
#define WOWRL_NODE_H

#include "wowrl.h"

/// Pathfinding node.
/** This class is used by the pathfinding
*   algorithm. It's basically a point with
*   some weight values, a few special flags
*   and a hierarchy.
*/
class Node
{
public :

    Node();
    ~Node();

/** Set all this node's parameters.
*   \param x      The new horizontal coordinate
*   \param y      The new vertical coordinate
*   \param parent The new parent node
*   \param f      The new weight value
*   \param g      The new step number
*/
    void Set( float x, float y, Node* parent, float f, float g );

/** \return A Point which only contains fX and fY.
*/
    Point GetPoint();

/// The horizontal coordinate
    float fX;
/// The vertical coordinate
    float fY;
/// The weight
    float fF;
/// The step number
    float fG;
/// The parent node
    Node* mParent;
/// This node is closed (already entered)
    bool  bClosed;
/// This node is opened (alreay visited but not entered)
    bool  bOpened;
/// This node is walkable
    bool  bWalkable;
/// This node is useless (all its childs are either closed or not walkable)
    bool  bUseless;
};

#endif

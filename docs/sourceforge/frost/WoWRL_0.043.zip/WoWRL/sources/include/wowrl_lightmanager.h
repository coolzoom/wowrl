/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           LightManager header          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#ifndef LIGHTMANAGER_H_INCLUDED
#define LIGHTMANAGER_H_INCLUDED

#include "dx9/d3dx9.h"

#include "windows.h"
#include <vector>

#include "wowrl_vectors.h"

class LightManager
{
public :

    ~LightManager();
    static LightManager* GetSingleton();

    int AddPointLight(float x, float y, float z, float range, DWORD color);
    Vector3 GetAmbient();
    std::vector<D3DLIGHT9> GetLights(Vector3 pos);
    void SetAmbient(Vector3 nAmb);

    Vector3 PointDiffuse(Vector3 VertPos, Vector3 VertNorm, Vector3 LightPos,
                 Vector3 LightColor, Vector3 LightAttenuation, float LightRange);

protected :

    LightManager();

private :

    static LightManager* mLightMgr;
    int iLightNbr;
    Vector3 vAmb;

    std::vector<D3DLIGHT9> lLightList;

};

#endif // LIGHTMANAGER_H_INCLUDED

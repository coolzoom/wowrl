/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             Profiler header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_PROFILER_H
#define WOWRL_PROFILER_H

#include <map>
#include <string>
#include <vector>
#include <windows.h>

/// The profiling class
/** A profiler should be assigned to a single
*   function or portion of code. It will accumulate
*   timings from every Chrono created from it.
*/
class Profiler
{
public:

/** The default constructor.
*   \param group The group to which it belongs (used to group prints later)
*   \param name  The name of this Profiler (usualy the name of the function
*                it profiles)
*   \param keeps Store all timings in a list to print them later
*/
    Profiler(int group, std::string name, bool keeps);

/** Adds a timing.
*   \param t The timing
*/
    void AddTiming(double t);

/** Prints timing infos.
*   \param total The total profiling time, used to calculate percentages.
*/
    void PrintProfile(double total);

/** Switches the timing saving.
*/
    void SetKeepRecords(bool keep);

/** \return This Profiler's group
*/
    int  GetGroup()
    {
        return iGroup;
    }

private:
    std::string sName;
    int         iGroup;
    double      dStartTime;
    double      dTotalTime;
    double      dHighestTime;
    double      dLowestTime;
    int         iCallNbr;
    int         iZeroTimings;
    bool        bKeepRecords;

    std::vector<double> lRecordList;
};

/// An automatic timer
/** This timer starts when you create it and ends
*   at destruction or when you call Stop().
*   So, to use it, the simplest way is to call :
*       Chrono c = Chrono(mTimeMgr->GetProfiler(...));
*   And when c will be destroyed, it will add a timing
*   to the profiler you gave in the constructor.<br>
*   Note : This class should only be used for profiling
*   purposes.
*/
class Chrono
{
public:
    Chrono(Profiler*, bool start=true);
    ~Chrono();

/** \return Elapsed time since its creation
*/
    double GetTime();

/** Restarts a timer after it has been stopped.
*/
    void   Start();

/** Stops this timer and add its timing to the
*   profiler.
*   \param send If set to false, the timer will only be
*   paused and won't send data to the profiler.
*/
    void   Stop(bool send=true);

private:
    Profiler* mParent;
    double    dStart;
    double    dCumul;
    bool      bStopped;
};

/// A periodic timer...
/** This timer is meant to tick periodicaly,
*   so you can use it for any periodic event
*   such as key repetition or a count down.
*/
#define TIMER_START_NO    0 // The timer will start if you call Start()
#define TIMER_START_NOW   1 // The timer starts immediatly after it is created
#define TIMER_START_FIRST 2 // The timer will start when you first call Ticks()

class PeriodicTimer
{
public:

/** The default constructor
*   \param period The time interval between each tick
*   \param start  See
*   \param ticks  The timer ticks immediately
*/
    PeriodicTimer(double period, int start, bool ticks);

/** \return The time elapsed since last tick
*/
    double GetElapsed();

/** \return 'true' if the period is reached
*/
    bool   Ticks();

/** Pauses the timer and resets it.
*/
    void   Stop();

/** Starts the timer but doesn't reset it.
*/
    void   Start();

/** Pauses the timer.
*/
    void   Pause();

/** Resets the timer but doesn't pause it.
*/
    void   Zero();

private:

    double dElapsed;
    double dStart;
    double dPeriod;
    bool   bPaused;
    int    iStart;
};

/// Keeper of time
/** This class manages everything that is related
*   to time : FPS, delta and profiling.
*/
class TimeManager
{
public:

    ~TimeManager();
/// Returns a unique instance
    static TimeManager* GetSingleton();

/** Updates delta time and FPS.
*/
    void Update();

/** \return Elapsed time since last frame
*/
    double GetDelta();

/** \return Average frame per second over a second
*/
    int    GetFPS();

/** \return Average frame per second since game launch
*/
    int    GetAverageFPS();

/** \return Current time (origin unknown, only used to get a
*   time difference)
*/
    double GetTime();

/** \return The actual year
*/
    int    GetYear();

/** \return The actual month
*/
    int    GetMonth();

/** \return The actual day name code
*/
    int    GetDayName();

/** \return The actual day number
*/
    int    GetDay();

/** \return The actual hour
*/
    int    GetHour();

/** \return The actual minutes
*/
    int    GetMinutes();

/** \return The elapsed time since the game has started,
/*  formated : "[h.:m.:s.:ms.]"
*/
    std::string GetPlayTime();

/** \return The actual seconds
*/
    int    GetSeconds();

/** \param prof Starts profiling
*/
    void      SetProfiling(bool prof);

/** \return 'true' if it is profiling
*/
    bool      IsProfiling()
    {
        return bProfiling;
    }

/** Creates a profiler with the given parameters or
*   return the already existing one if any.
*   \param group The group to which it belongs (used to group prints later)
*   \param name  The name of this Profiler (usualy the name of the function
*                it profiles)
*   \param keeps Store all timings in a list to print them later
*/
    Profiler* GetProfiler(int group, std::string name, bool keeps);

/** Prints in the log all timing infos.
*   \param group Filter output by group number
*/
    void      Print(int group = -1);

protected:
    TimeManager();

private:
    static TimeManager* mTimeMgr;

    bool bProfiled;
    bool bProfiling;

    int    iFPS;
    double fDelta;

    double dFrameNbr;
    int    iAvgFPS;

    double dStart;

    LARGE_INTEGER liFreq, liTs, liOs;
    double dLast;
    double dProfileTime;
    std::map<std::string, Profiler> lProfilerList;
};

/****** PROFILING GROUPS ******/
/* [1] : pathfinding          */
/* [2] : unit                 */
/* [3] : GUI parsing          */
/* [4] : GUI drawing          */
/* [5] : data parsing         */
/* [6] : render order         */
/* [7] : scene manager        */
/* [8] : frame func           */
/* [0] : other                */
/******************************/

#endif

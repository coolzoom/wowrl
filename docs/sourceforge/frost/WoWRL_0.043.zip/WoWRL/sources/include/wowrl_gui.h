/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               GUI header               */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_GUI_H
#define WOWRL_GUI_H

#include "wowrl.h"
#include "wowrl_guimanager.h"
#include "wowrl_structs.h"
#include "wowrl_lua.h"

struct Anchor
{
    int         iAnchorPt;
    int         iRelativePt;
    GUIBase*    mParent;
    std::string sParentName;
    float       fX, fY;

    Anchor()
    {
        fX = 0.0f;
        fY = 0.0f;
        mParent = NULL;
        sParentName = "";
        iAnchorPt = GUI_ANCHOR_TOPLEFT;
        iRelativePt = GUI_ANCHOR_TOPLEFT;
    }
};

struct Backdrop
{
    bool  bTile;
    float fEdgeSize;
    float fTileSize;
    float fInsL;
    float fInsR;
    float fInsT;
    float fInsB;

    float fBgW;
    float fBgH;
    float fEdgeOriginalSize;

    std::string sBgFile;
    std::string sEdgeFile;

    DWORD dwEdgeColor;
    DWORD dwBgColor;

    bool       bEdgeReady;
    hgeSprite* mEdgeL;
    hgeSprite* mEdgeR;
    hgeSprite* mEdgeT;
    hgeSprite* mEdgeB;
    hgeSprite* mCornerTL;
    hgeSprite* mCornerTR;
    hgeSprite* mCornerBL;
    hgeSprite* mCornerBR;
    bool       bBgReady;
    hgeSprite* mBackground;
    bool       bBgReadyC;

    // Cache
    HTARGET    mTarget;
    hgeSprite* mSpr;
};

struct OnFunc
{
    int         iType;
    bool        bFuncDefined;
    int         iFuncId;
};

class GUIBase
{
public :

    float GetX( bool relative = false );
    float GetY( bool relative = false );
    bool  IsVisible();

    void Init();
    GUIBase* GetHighestVirtParent();

    std::string sName;
    std::string sBName;
    std::string sVName;
    int         iType;
    bool        bVirt;
    bool        bReady;
    float       fX, fY;
    float       fW, fH;
    float       fAlpha;
    bool        bHidden;

    std::map<int, Anchor> lAnchorList;
    Anchor* mAnchor;
    std::map<std::string, GUIBase*> lParentList;

    GUIElement* mParent;
    std::string sParentName;
};

class GUIArt : public GUIBase
{
public :

    GUIArt(const GUIArt &a);

    void Render();

    int iID;

    hgeSprite*    mSprite;
    hgeAnimation* mAnim;
    FormatedText  mText;

    int   iLayer;
    float fScale;
    float fVScale;
    float fAngle;
    bool  bUseBox;
    DWORD dwColor;
    int   iBlend;

    float fAX, fAY;

    std::string sFile;

    GUIArt() : GUIBase()
    {
        mSprite = NULL;
        mAnim = NULL;
        mParent = NULL;
        sParentName = "";
        sName = "";
        sVName = "";
        bHidden = false;
        bUseBox = false;
        bReady = false;
        dwColor = ARGB(255, 255, 255, 255);
        fX = 0.0f;
        fY = 0.0f;
        iLayer = 0;
        fAngle = 0.0f;
        fScale = 1.0f;
        fVScale = 1.0f;
        mAnchor = NULL;
    }
};

class GUIElement : public GUIBase
{
public :

    GUIElement();
    GUIElement(const GUIElement &g);
    ~GUIElement();

    void AdjustCache( bool adjustParent = true );
    void CheckInput(float, float, int, int);
    void CopyVirt(GUIElement*);
    void DeleteThis();
    int  GetChildLevel();
    void Init();
    void On(int, Event* event = NULL);
    void Print(int);
    void SetOnFunction(int, int);
    void RebuildCache( bool child = false );
    void Render(bool);
    void UpdateCarret();

    std::map<std::string, GUIElement*> lChildList;
    std::map<std::string, GUIElement*> lVChildList;
    bool 							   bChild;

    std::map<std::string, GUIArt*> lArtList;

    // Parameters
    float fGX, fGY;
    bool  bLastOn;
    bool  bRegisteredForDrag;
    bool  bEnableMouse;
    bool  bMovable;
    bool  bDragged;
    bool  bBaseUI;
    int   iFrameStrata;
    bool  bRebuildList;

    int iHitInsL;
    int iHitInsR;
    int iHitInsT;
    int iHitInsB;

    std::map<int, OnFunc> lFuncList;
    std::map<int, bool>   lRegEventList;

    // Cache
    HTARGET    mTarget;
    hgeSprite* mSpr;
    bool       bRebuildCache;
    bool       bRebuildBackdrop;
    bool       bRecreateCache;
    float      fLD, fRD;
    float      fTD, fBD;


    // Backdrop
    Backdrop mBackdrop;
    bool     bUseBackdrop;

    // Status bar specific variables
    float       fValue;
    float       fMinValue;
    float       fMaxValue;
    float       fBaseWidth;
    GUIArt*     mBarTexture;
    std::string sBarTextureName;

    // Edit box specific variables
    std::string sEBText;
    int         iLetters;
    int         iHistoryLines;
    int         iEBInsL, iEBInsR, iEBInsT, iEBInsB;
    float       fBlinkSpeed;
    float       fCarretTimer;
    int         iCarretPos;
    int         iSubStrStart;
    int         iSubStrLength;
    float       fCarretX, fCarretY, fCarretScale;
    bool        bShowCarret;
    bool        bNumeric;
    bool        bPassword;
    bool        bMultiLine;
    bool        bIgnoreArrows;
    bool        bAutoFocus;
    GUIArt*     mCaptionFont;
    std::string sCaptionFontName;

    // Scrolling message frame specific variables
    int   iMaxLines;
    int   iActualLine;
    int   iBottomLine;
    int   iOldBottomLine;
    float fFadeDuration;
    float fDisplayDuration;
    bool  bFade;
    int   iSMFInsL, iSMFInsR, iSMFInsT, iSMFInsB;
    bool  bAtTop;
    bool  bAtBottom;

    // Button specific variables
    GUIArt*     mTexNormal;
    GUIArt*     mTexPushed;
    GUIArt*     mTexDisabled;
    GUIArt*     mTexHighlight;
    GUIArt*     mFontNormal;
    GUIArt*     mFontHighlight;
    GUIArt*     mFontDisabled;
    int         iPushTxtOffX;
    int         iPushTxtOffY;
    bool        bMouseDown;
    bool        bButtonDisabled;
    bool        bButtonFontReady;
    bool        bButtonTextureReady;
    std::string sButtonText;
    int         iButtonState;

private :

    std::multimap<int, GUIElement*> lSortedGUIList;
};

class GUI
{
public :

    class UIObject
    {
    public :

        static const char className[];
        static Lunar<UIObject>::RegType methods[];

        /**/ int GetAlpha(lua_State*) {}
        /**/ int GetObjectType(lua_State*) {}
        /**/ int IsObjectType(lua_State*) {}
        /**/ int SetAlpha(lua_State*) {}

        int GetDataTable(lua_State *L)
        {
            lua_getref(L, iRef);
            return 1;
        }

        UIObject(lua_State* luaVM)
        {
            lua_newtable(luaVM);
            iRef = luaL_ref(luaVM, LUA_REGISTRYINDEX);
            l = luaVM;
        }

        ~UIObject()
        {
            luaL_unref(l, LUA_REGISTRYINDEX, iRef);
        }

    protected :

        std::string sName;
        lua_State*  l;
        int         iRef;
    };

	class Region : public UIObject
    {
    public :

        static const char className[];
        static Lunar<Region>::RegType methods[];

        int GetName(lua_State*);

        int GetBottom(lua_State*);
        int GetCenter(lua_State*);
        int GetHeight(lua_State*);
        int GetLeft(lua_State*);
        /**/ int GetNumPoint(lua_State*) {}
        int GetParent(lua_State*);
        int GetPoint(lua_State*);
        int GetRight(lua_State*);
        int GetTop(lua_State*);
        int GetWidth(lua_State*);
        int Hide(lua_State*);
        int IsShown(lua_State*);
        int IsVisible(lua_State*);
        int RebuildCache(lua_State*);
        /**/ int SetAllPoints(lua_State*) {}
        int SetHeight(lua_State*);
        /**/ int SetParent(lua_State*) {}
        int SetPoint(lua_State*);
        int SetWidth(lua_State*);
        int Show(lua_State*);

        Region(lua_State* luaVM) : GUI::UIObject(luaVM)
        {
            mEBase=NULL;
            mRBase=NULL;
            mABase=NULL;
        }

    protected :

        GUIBase*    mRBase;
        GUIElement* mEBase;
        GUIArt*     mABase;
    };

	class Frame : public Region
    {
    public :

        static const char className[];
        static Lunar<Frame>::RegType methods[];

        /**/ int CreateFontString(lua_State*) {}
        /**/ int CreateTexture(lua_State*) {}
        /**/ int CreateTitleRegion(lua_State*) {}
        /**/ int DisableDrawLayer(lua_State*) {}
        /**/ int EnableDrawLayer(lua_State*) {}
        /**/ int EnableKeyboard(lua_State*) {}
        /**/ int EnableMouse(lua_State*) {}
        /**/ int EnableMouseWheel(lua_State*) {}
        int GetBackdrop(lua_State*);
        /**/ int GetBackdropBorderColor(lua_State*) {}
        /**/ int GetBackdropColor(lua_State*) {}
        /**/ int GetChildren(lua_State*) {}
        /**/ int GetEffectiveAlpha(lua_State*) {}
        /**/ int GetEffectiveScale(lua_State*) {}
        /**/ int GetFrameLevel(lua_State*) {}
        /**/ int GetFrameStrata(lua_State*) {}
        /**/ int GetFrameType(lua_State*) {}
        /**/ int GetHitRectInsets(lua_State*) {}
        /**/ int GetID(lua_State*) {}
        /**/ int GetMaxResize(lua_State*) {}
        /**/ int GetMinResize(lua_State*) {}
        /**/ int GetNumChildren(lua_State*) {}
        /**/ int GetNumRegions(lua_State*) {}
        /**/ int GetScale(lua_State*) {}
        /**/ int GetScript(lua_State*) {}
        /**/ int GetTitleRegion(lua_State*) {}
        /**/ int HasScript(lua_State*) {}
        /**/ int HookScript(lua_State*) {}
        /**/ int IsClampedtoScreen(lua_State*) {}
        /**/ int IsFrameType(lua_State*) {}
        /**/ int IsKeyboardEnabled(lua_State*) {}
        /**/ int IsMouseEnabled(lua_State*) {}
        /**/ int IsMouseWheelEnabled(lua_State*) {}
        /**/ int IsMovable(lua_State*) {}
        /**/ int IsResizable(lua_State*) {}
        /**/ int IsTopLevel(lua_State*) {}
        /**/ int IsUserPlaced(lua_State*) {}
        /**/ int Lower(lua_State*) {}
        /**/ int Raise(lua_State*) {}
        /**/ int RegisterAllEvents(lua_State*) {}
        int RegisterEvent(lua_State*);
        /**/ int RegisterForDrag(lua_State*) {}
        int SetBackdrop(lua_State*);
        /**/ int SetBackdropBorderColor(lua_State*) {}
        int SetBackdropColor(lua_State*);
        /**/ int SetClampedToScreen(lua_State*) {}
        /**/ int SetFrameLevel(lua_State*) {}
        /**/ int SetFrameStrata(lua_State*) {}
        /**/ int SetHitRectInsets(lua_State*) {}
        /**/ int SetID(lua_State*) {}
        /**/ int SetMaxResize(lua_State*) {}
        /**/ int SetMinResize(lua_State*) {}
        /**/ int SetMovable(lua_State*) {}
        /**/ int SetResizable(lua_State*) {}
        /**/ int SetScale(lua_State*) {}
        /**/ int SetScript(lua_State*) {}
        /**/ int SetTopLevel(lua_State*) {}
        /**/ int SetUserPlaced(lua_State*) {}
        /**/ int StartMoving(lua_State*) {}
        /**/ int StartSizing(lua_State*) {}
        /**/ int StopMovingOrSizing(lua_State*) {}
        int UnregisterAllEvents(lua_State*);
        int UnregisterEvent(lua_State*);

        int _init(lua_State*);

        Frame(lua_State*);

    protected :

        GUIElement* mBase;
    };

class StatusBar : public Frame
    {
    public :

        static const char className[];
        static Lunar<StatusBar>::RegType methods[];

        /**/ int GetMinMaxValues(lua_State*) {}
        /**/ int GetOrientation(lua_State*) {}
        /**/ int GetStatusBarColor(lua_State*) {}
        /**/ int GetStatusBarTexture(lua_State*) {}
        /**/ int GetValue(lua_State*) {}
        int SetMinMaxValues(lua_State*);
        /**/ int SetOrientation(lua_State*) {}
        int SetStatusBarColor(lua_State*);
        /**/ int SetStatusBarTexture(lua_State*) {}
        int SetValue(lua_State*);

        StatusBar(lua_State*);
    };

class EditBox : public Frame
    {
    public :

        static const char className[];
        static Lunar<EditBox>::RegType methods[];

        /**/ int AddHistoryLine(lua_State*) {}
        int ClearFocus(lua_State*);
        /**/ int GetAltArrowKeyMode(lua_State*) {}
        /**/ int GetBlinkSpeed(lua_State*) {}
        /**/ int GetHistoryLines(lua_State*) {}
        /**/ int GetInputLanguage(lua_State*) {}
        /**/ int GetMaxBytes(lua_State*) {}
        /**/ int GetMaxLetters(lua_State*) {}
        /**/ int GetNumLetters(lua_State*) {}
        /**/ int GetNumber(lua_State*) {}
        int GetText(lua_State*);
        /**/ int GetTextInsets(lua_State*) {}
        /**/ int HighlithtText(lua_State*) {}
        /**/ int Insert(lua_State*) {}
        /**/ int IsAutoFocus(lua_State*) {}
        /**/ int IsMultiLine(lua_State*) {}
        /**/ int IsNumeric(lua_State*) {}
        /**/ int IsPassword(lua_State*) {}
        /**/ int SetAltArrowKeyMode(lua_State*) {}
        /**/ int SetAutoFocus(lua_State*) {}
        /**/ int SetBlinkSpeed(lua_State*) {}
        int SetFocus(lua_State*);
        /**/ int SetHistoryLines(lua_State*) {}
        /**/ int SetMaxBytes(lua_State*) {}
        /**/ int SetMaxLetters(lua_State*) {}
        /**/ int SetMultiLine(lua_State*) {}
        /**/ int SetNumber(lua_State*) {}
        /**/ int SetNumeric(lua_State*) {}
        /**/ int SetPassword(lua_State*) {}
        int SetText(lua_State*);
        /**/ int SetTextInsets(lua_State*) {}
        /**/ int ToggleInputLanguage(lua_State*) {}


        EditBox(lua_State*);
    };

class ScrollingMessageFrame : public Frame
    {
    public :

        static const char className[];
        static Lunar<ScrollingMessageFrame>::RegType methods[];

        int AddMessage(lua_State*);
        int AtBottom(lua_State*);
        int AtTop(lua_State*);
        /**/ int Clear(lua_State*) {}
        /**/ int GetCurrentLine(lua_State*) {}
        /**/ int GetCurrentScroll(lua_State*) {}
        /**/ int GetFadeDuration(lua_State*) {}
        /**/ int GetFading(lua_State*) {}
        /**/ int GetMaxLines(lua_State*) {}
        /**/ int GetNumLinesDisplayed(lua_State*) {}
        /**/ int GetNumMessages(lua_State*) {}
        /**/ int GetTimeVisible(lua_State*) {}
        /**/ int PageDown(lua_State*) {}
        /**/ int PageUp(lua_State*) {}
        int ScrollDown(lua_State*);
        int ScrollToBottom(lua_State*);
        int ScrollToTop(lua_State*);
        int ScrollUp(lua_State*);
        /**/ int SetFadeDuration(lua_State*) {}
        /**/ int SetFading(lua_State*) {}
        /**/ int SetMaxLines(lua_State*) {}
        /**/ int SetScrollFromBottom(lua_State*) {}
        /**/ int SetTimeVisible(lua_State*) {}
        /**/ int UpdateColorByID(lua_State*) {}

        ScrollingMessageFrame(lua_State*);
    };

class Button : public Frame
    {
    public :

        static const char className[];
        static Lunar<Button>::RegType methods[];

        /**/ int Click(lua_State*) {}
        int Disable(lua_State*);
        int Enable(lua_State*);
        int GetButtonState(lua_State*);
        /**/ int GetDisabledFontObject(lua_State*) {}
        /**/ int GetDisabledTextColor(lua_State*) {}
        /**/ int GetDisabledTexture(lua_State*) {}
        /**/ int GetFont(lua_State*) {}
        /**/ int GetFontString(lua_State*) {}
        /**/ int GetHighlightFontObject(lua_State*) {}
        /**/ int GetHighlightTextColor(lua_State*) {}
        /**/ int GetHighlightTexture(lua_State*) {}
        /**/ int GetNormalTexture(lua_State*) {}
        /**/ int GetPushedTextOffset(lua_State*) {}
        /**/ int GetPushedTexture(lua_State*) {}
        /**/ int GetText(lua_State*) {}
        /**/ int GetTextColor(lua_State*) {}
        /**/ int GetTextFontObject(lua_State*) {}
        /**/ int GetTextHeight(lua_State*) {}
        /**/ int GetTextWidth(lua_State*) {}
        int IsEnabled(lua_State*);
        /**/ int LockHighlight(lua_State*) {}
        /**/ int RegisterForClicks(lua_State*) {}
        /**/ int SetButtonState(lua_State*) {}
        /**/ int SetDisabledFontObject(lua_State*) {}
        /**/ int SetDisabledTextColor(lua_State*) {}
        /**/ int SetDisabledTexture(lua_State*) {}
        /**/ int SetFont(lua_State*) {}
        /**/ int SetFontString(lua_State*) {}
        /**/ int SetHighlightFontObject(lua_State*) {}
        /**/ int SetHighlightTextColor(lua_State*) {}
        /**/ int SetHighlightTexture(lua_State*) {}
        /**/ int SetNormalTexture(lua_State*) {}
        /**/ int SetPushedTextOffset(lua_State*) {}
        /**/ int SetPushedTexture(lua_State*) {}
        /**/ int SetText(lua_State*) {}
        /**/ int SetTextColor(lua_State*) {}
        /**/ int SetTextFontObject(lua_State*) {}
        /**/ int UnlockHighlight(lua_State*) {}

        Button(lua_State*);
    };

class LayeredRegion : public Region
    {
    public :

        static const char className[];
        static Lunar<LayeredRegion>::RegType methods[];

        /**/ int GetDrawLayer(lua_State*) {}
        /**/ int SetDrawLayer(lua_State*) {}

        int _init(lua_State*);

        LayeredRegion(lua_State* luaVM) : Region(luaVM)
        {
            mBase=NULL;
        }

    protected :

        std::string sPName;
        GUIArt* mBase;
    };

class Texture : public LayeredRegion
    {
    public :

        static const char className[];
        static Lunar<Texture>::RegType methods[];

        /**/ int GetBlendMode(lua_State*) {}
        /**/ int GetTexCoord(lua_State*) {}
        /**/ int GetTexCoordModifiesRect(lua_State*) {}
        /**/ int GetTexture(lua_State*) {}
        /**/ int GetVertexColor(lua_State*) {}
        /**/ int GetDesaturated(lua_State*) {}
        /**/ int SetBlendMode(lua_State*) {}
        /**/ int SetDesaturated(lua_State*) {}
        /**/ int SetGradient(lua_State*) {}
        /**/ int SetGradientAlpha(lua_State*) {}
        int SetTexCoord(lua_State*);
        /**/ int SetTexCoordModifiesRect(lua_State*) {}
        int SetTexture(lua_State*);
        int SetVertexColor(lua_State*);

        Texture(lua_State*);

    protected :
    };

class FontString : public LayeredRegion
    {
    public :

        static const char className[];
        static Lunar<FontString>::RegType methods[];

        // Inherits from FontInstance
        /**/ int GetFont(lua_State*) {}
        /**/ int GetFontObject(lua_State*) {}
        /**/ int GetJustifyH(lua_State*) {}
        /**/ int GetJustifyV(lua_State*) {}
        /**/ int GetShadowColor(lua_State*) {}
        /**/ int GetShadowOffset(lua_State*) {}
        /**/ int GetSpacing(lua_State*) {}
        /**/ int GetTextColor(lua_State*) {}
        int SetFont(lua_State*);
        /**/ int SetFontObject(lua_State*) {}
        /**/ int SetJustifyH(lua_State*) {}
        /**/ int SetJustifyV(lua_State*) {}
        /**/ int SetShadowColor(lua_State*) {}
        /**/ int SetShadowOffset(lua_State*) {}
        /**/ int SetSpacing(lua_State*) {}
        int SetTextColor(lua_State*);

        /**/ int CanNonSpaceWrap(lua_State*) {}
        int GetStringWidth(lua_State*);
        /**/ int GetText(lua_State*) {}
        /**/ int SetAlphaGradient(lua_State*) {}
        /**/ int SetNonSpaceWrap(lua_State*) {}
        int SetText(lua_State*);
        /**/ int SetTextHeight(lua_State*) {}

        FontString(lua_State*);

    protected :
    };
};

#endif

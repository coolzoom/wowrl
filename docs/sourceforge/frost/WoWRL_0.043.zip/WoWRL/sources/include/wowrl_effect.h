/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Effect header             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_EFFECT_H
#define WOWRL_EFFECT_H

#include "wowrl.h"

class Effect
{
public :

    Effect()
    {
        mAnim = NULL;
        mPSys = NULL;
    }

    void Render(float x, float y);
    void RenderEx(float x, float y, float angle, float v_scale, float h_scale = 0.0f);
    void SetColor(DWORD col);
    void Play();
    void Stop();
    void Update(float dt);

    std::string        sName;
    int                iType;
    bool               bEnded;
    float              fLife;
    float              fLifeTimer;
    hgeAnimation*      mAnim;
    int                iRot;
    float              fFadeIn;
    float              fFadeOut;
    bool               bFade;
    bool               bFadedIn;
    bool               bFadedOut;
    float              fFadeTimer;
    float              fScale;
    hgeParticleSystem* mPSys;
    float              fOffX;
    float              fOffY;
    float              fDelay;

private :

};

#endif

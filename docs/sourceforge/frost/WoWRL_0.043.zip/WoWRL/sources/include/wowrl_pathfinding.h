/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Pathfinding header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_PATHFINDING_H
#define WOWRL_PATHFINDING_H

#include "wowrl.h"

std::vector<Point> GetDestPoints(Unit* leader, int pointNumber, float space);
Point              GetNearestInRangePoint(float xi, float yi, float destx, float desty, float range);
Waypoint*          FindNearestWaypoint(float x, float y);
std::vector<Point> GetWaypoints(float xi, float yi, float destx, float desty);
std::vector<Point> GetShortestPath(float xi, float yi, float destx, float desty, float range = 0.0f);
std::vector<Point> SimplifyPath(std::vector<Point> path);

#endif

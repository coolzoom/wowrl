/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Model header              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#ifndef WOWRL_MODEL_H
#define WOWRL_MODEL_H

#include "wowrl.h"

#include "wowrl_vectors.h"
#include "wowrl_animmanager.h"

#define MODEL_SUBMCAT_BODY     -1
#define MODEL_SUBMCAT_HAIRS     0
#define MODEL_SUBMCAT_BEARD01   1
#define MODEL_SUBMCAT_BEARD02   2
#define MODEL_SUBMCAT_FACE_ARTS 3
#define MODEL_SUBMCAT_GLOVES    4
#define MODEL_SUBMCAT_LEGS_LOW  5
#define MODEL_SUBMCAT_UNK01     6  // ?
#define MODEL_SUBMCAT_EARS      7
#define MODEL_SUBMCAT_EAR_RINGS 8
#define MODEL_SUBMCAT_BOOT_UP   9  // ?
#define MODEL_SUBMCAT_BELT01    10 // ?
#define MODEL_SUBMCAT_BELT02    11 // ?
#define MODEL_SUBMCAT_TABARD    12
#define MODEL_SUBMCAT_LEGS_UP   13
#define MODEL_SUBMCAT_UNK02     14 // ?
#define MODEL_SUBMCAT_CAPES     15

#define MODEL_UPDATE_TIME 0.017f // ~60 updates per second

struct Vertex
{
    float fX, fY, fZ;
    float fWeight[4];
    float fBone[4];
    //float fNX, fNY, fNZ;
    float fU, fV;
    //float fMesh;
    //DWORD dwColor;
};

struct Mesh
{
    Mesh();
    Mesh(const Mesh &m);
    ~Mesh();
    int  iID;
    int  iGID;
    bool bShown;
    Vertex* lVertexList;
    int  iVertexNbr;
    int  iVertexOff;
    std::map<int, int> lBoneIDToRIDMap;
    int* lBoneList;
    int  iBoneNbr;
    bool bIsCopy;
    bool bIsBody;

    LPDIRECT3DTEXTURE9 mTex;
};

class AnimManager;

struct Segment
{
    Segment() {}
    Segment(Point p1, Point p2) : mP1(p1), mP2(p2) {}
    Point mP1;
    Point mP2;
};

struct Parallelogram
{
    Point mP[4];
};

class Model
{
public :

    Model(std::string sFile);
    Model(const Model &m);
    ~Model();

    void ApplySkin(std::string sFile);

    Vector3 GetColor();
    Vector3 GetOrientation();
    Unit*   GetParent() { return mParent; }
    Vector3 GetPosition();
    HTARGET GetRTarget();
    int     GetRTargetSize() { return iRTSize; }
    Vector3 GetScale();
    int     GetSubMeshID(int category, int variation);
    hgeSprite* GetSprite();
    void Hide(int iSubMeshID = -1);
    bool Hidden();
    bool Intersect(hgeRect* rect);
    void Render();
    void RenderBones();

    void SetOrientation(Vector3 nOrient);
    void SetParent(Unit* p) { if (mParent == NULL) mParent = p; }
    void SetPosition(Vector3 nPos);
    void SetScale(Vector3 nScale);

    void SetSubMeshTexture(int iSubMeshID, std::string sFile);
    void SetSubMeshTexture(int iSubMeshID, HTEXTURE tex);
    void Show(int iSubMeshID = -1);

    bool TestPoint(float x, float y);

    void UpdateBBox();

    int iID;

    AnimManager* mAnimMgr;

    Mesh**  lMeshList;
    int     iMeshNbr;
    Bone**  lBoneList;
    int     iBoneNbr;
    int*    lBaseBoneList;
    int     iBaseBoneNbr;

    Vector3 vBBoxMin;
    Vector3 vBBoxMax;

    HTEXTURE mBodyTex;

protected :

    Model();

private :

    Vector3 vPos;
    Vector3 vOrient;
    Vector3 vScale;
    Vector3 vColor;

    bool bShown;
    bool bIsCopy;
    bool bAnimated;
    bool bUpdateWMat;
    PeriodicTimer* mUpdateTimer;

    HTARGET mRTarget;
    hgeSprite* mSprite;
    int iRTSize;

    Unit* mParent;

    D3DXMATRIX mPos;
    D3DXMATRIX mRot;
    D3DXMATRIX mScale;
    D3DXMATRIX mWorld;
    D3DXMATRIX mProj;

    Parallelogram lBBoxeList[6];
    bool bUpdateBBoxes;
};

#endif

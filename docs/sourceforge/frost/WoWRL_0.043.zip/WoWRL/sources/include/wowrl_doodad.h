/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Doodad header             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_DOODAD_H
#define WOWRL_DOODAD_H

#include "wowrl.h"

class Doodad
{
public :

    Doodad();
    ~Doodad();

    void     SetX(float);
    void     SetY(float);
    float    GetX();
    float    GetY();
    Point    GetPoint();
    float    GetZ();
    void     SetBox();
    hgeRect* GetBox();
    float    GetRelativeDepth(Point);
    void     DeleteThis();
    bool     Intersects(Object);

    std::string sName;
    hgeSprite* mSprite;
    float fZ;
    float fOrientation;
    bool bLocked;
    bool bInTop;

private :

    Doodad(const Doodad &d);

    float    fX;
    float    fY;
    float    fOldX;
    float    fOldY;
    hgeRect* mBox;

};

#endif

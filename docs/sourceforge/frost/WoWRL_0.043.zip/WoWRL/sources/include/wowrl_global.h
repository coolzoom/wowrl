/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             Global header              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_GLOBAL_H
#define WOWRL_GLOBAL_H

#ifndef NULL
#define NULL 0
#endif

#include "wowrl.h"
//#include "wowrl_structs.h"
#include "wowrl_point.h"

std::string   ToString( int i, int charNbr );
std::string   ToString( float f );
std::string   BToString( bool b );
int           StrReplace( std::string* baseStr, std::string pattern, std::string replacement );
std::string   StrReplace( std::string baseStr, std::string pattern, std::string replacement );
int           StrCountOccurence( std::string baseStr, std::string pattern );
std::string   StrPrintIn( std::string baseStr, ... );
std::string   StrCapitalStart( std::string baseStr, bool capital );
void          StrRemoveSurChar( std::string* baseStr, char );
bool          FileExists( std::string fileName, bool bPrint = true );
int           ToInt( float f );
int           ToInt( const char* s );
int           ToInt( std::string s );
int           HexToInt( const char* c );
unsigned long HexToULong( const char* c );
std::string   IntToHex( int i );
int           SignOf( float f );
bool          ToBool( char* c );
float         Rac2( float f );
float         Dist( Point p1, Point p2 );
float         Dist( float x1, float y1, float x2, float y2 );
void          SetGlowing( hgeSprite* Sprite, float timerAlpha, float speed = 2.0f );
float         RadToDeg( float r, bool negativeDeg = true );
float         DegToRad( float d );
int           NearestPow2Up( float f );
void          Log( std::string, ... );
bool          FixTextureName( std::string* );

#endif

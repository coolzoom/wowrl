/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Point header              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_POINT_H
#define WOWRL_POINT_H

#include "wowrl.h"

/// A simple 2d coordinate storage.
/** This class is used to store a two dimensions
*   set of coordinates (x, y). It provides a few
*   basic operations (+, -, (in)equality).
*/
class Point
{
public :

    Point();

/** \param x The horizontal coordinate
*   \param y The vertical coordinate
*/
    Point(float x, float y);

/** Copy constructor
*/
    Point(Point*);
    ~Point();

/** Set a point's coordinates.
*   \param x The new horizontal coordinate
*   \param y The new vertical coordinate
*/
    void Set(float x, float y);

    Point operator+ (Point p2);
    Point operator- (Point p2);
    void operator+= (Point);
    void operator-= (Point);
    bool operator== (Point);
    bool operator!= (Point);

/// The horizontal coordinate
    float fX;
/// The vertical coordinate
    float fY;

/// The point's size, used to generate randomnes
    float fSize;

private :

};

#endif

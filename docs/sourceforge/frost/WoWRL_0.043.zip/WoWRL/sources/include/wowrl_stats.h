/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Stats header              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_STATS_H
#define WOWRL_STATS_H

#include "wowrl.h"

/// Stores unit's stats
/** This class is used to simplify the stats operations.
*   If you equip an item (which has its own Stats) on a
*   unit (which has its Stats too), then the result is the
*   sum of the two Stats elements. Making the sum of each
*   stat one by one would be a real pain.
*   It's not documented : everything is self explanatory.
*/
class Stats
{
public :

    void Clear();

    Stats operator+ (Stats);
    Stats operator- (Stats);

    int iArmor;
    int iHealth;
    int iMana;
    int iPowerType;
    int iStamina;
    int iIntellect;
    int iAgility;
    int iSpirit;
    int iStrengh;
    int iBlock;

    int iResistAll;
    int iResistFrost;
    int iResistFire;
    int iResistNature;
    int iResistShadow;
    int iResistArcane;

    int	iSpellPower;
    int	iAttackPower;
    int	iRegen5sHealth;
    int	iRegen5sMana;
    int iCrit;
    int iCritSpell;
    int iHit;
    int	iPenetration;

private :

};

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Model structures            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#ifndef WOWRL_MODELSTRUCTS_H
#define WOWRL_MODELSTRUCTS_H

/** \cond NOT_REMOVE_FROM_DOC
*/
typedef unsigned char uint8;
typedef char int8;
typedef unsigned __int16 uint16;
typedef __int16 int16;
typedef unsigned __int32 uint32;
typedef __int32 int32;

struct ModelHeader
{
    char id[4];
    uint8 version[4];
    uint32 nameLength;
    uint32 nameOfs;
    uint32 type;

    uint32 nGlobalSequences;
    uint32 ofsGlobalSequences;
    uint32 nAnimations;
    uint32 ofsAnimations;
    uint32 nC;
    uint32 ofsC;
    uint32 nD;
    uint32 ofsD;
    uint32 nBones;
    uint32 ofsBones;
    uint32 nF;
    uint32 ofsF;

    uint32 nVertices;
    uint32 ofsVertices;
    uint32 nViews;
    uint32 ofsViews;

    uint32 nColors;
    uint32 ofsColors;

    uint32 nTextures;
    uint32 ofsTextures;

    uint32 nTransparency; // H
    uint32 ofsTransparency;
    uint32 nI;   // always unused ?
    uint32 ofsI;
    uint32 nTexAnims;	// J
    uint32 ofsTexAnims;
    uint32 nTexReplace;
    uint32 ofsTexReplace;

    uint32 nTexFlags;
    uint32 ofsTexFlags;
    uint32 nY;
    uint32 ofsY;

    uint32 nTexLookup;
    uint32 ofsTexLookup;

    uint32 nTexUnitLookup;		// L
    uint32 ofsTexUnitLookup;
    uint32 nTransparencyLookup; // M
    uint32 ofsTransparencyLookup;
    uint32 nTexAnimLookup;
    uint32 ofsTexAnimLookup;

    float floats[14];

    uint32 nBoundingTriangles;
    uint32 ofsBoundingTriangles;
    uint32 nBoundingVertices;
    uint32 ofsBoundingVertices;
    uint32 nBoundingNormals;
    uint32 ofsBoundingNormals;

    uint32 nAttachments; // O
    uint32 ofsAttachments;
    uint32 nAttachLookup; // P
    uint32 ofsAttachLookup;
    uint32 nQ; // Q
    uint32 ofsQ;
    uint32 nLights; // R
    uint32 ofsLights;
    uint32 nCameras; // S
    uint32 ofsCameras;
    uint32 nT;
    uint32 ofsT;
    uint32 nRibbonEmitters; // U
    uint32 ofsRibbonEmitters;
    uint32 nParticleEmitters; // V
    uint32 ofsParticleEmitters;

};

struct ModelVertex
{
    float pos[3];
    uint8 weights[4];
    uint8 bones[4];
    float normal[3];
    float texcoords[2];
    float unk1, unk2; // always 0,0 so this is probably unused
};

struct ModelView
{
    uint32 nIndex, ofsIndex; // Vertices in this model (index into vertices[])
    uint32 nTris, ofsTris;	 // indices
    uint32 nProps, ofsProps; // additional vertex properties
    uint32 nSub, ofsSub;	 // materials/renderops/submeshes
    uint32 nTex, ofsTex;	 // material properties/textures
    int32 lod;				 // LOD bias?
};

struct ModelSubMesh
{
    uint32 id;
    uint16 ofsVertex;
    uint16 nVertex;
    uint16 ofsTris;
    uint16 nTris;
    uint16 unk1, unk2, unk3, unk4;
    float unk5[3];
    float unk6[4];
};

struct ModelTexUnit
{
    uint16 flags;		// Flags
    int16 order;		// ?
    uint16 op;			// Material this texture is part of (index into mat)
    uint16 op2;			// Always same as above?
    int16 colorIndex;	// color or -1
    uint16 flagsIndex;	// more flags...
    uint16 texunit;		// Texture unit (0 or 1)
    uint16 d4;			// ? (seems to be always 1)
    uint16 textureid;	// Texture id (index into global texture list)
    uint16 texunit2;	// copy of texture unit value?
    uint16 transid;		// transparency id (index into transparency list)
    uint16 texanimid;	// texture animation id
};

struct ModelTextureDef
{
    uint32 type;
    uint32 flags;
    uint32 nameLen;
    uint32 nameOfs;
};

struct ModelAnimation
{
    uint32 animID;
    uint32 timeStart;
    uint32 timeEnd;

    float moveSpeed;

    uint32 loopType;
    uint32 flags;
    uint32 d1;
    uint32 d2;
    uint32 playSpeed;  // note: this can't be play speed because it's 0 for some models

    float boxA[3], boxB[3];
    float rad;

    int16 next;

    int16 s;
};

struct AnimationBlock
{
    int16 type;		// interpolation type (0=none, 1=linear, 2=hermite)
    int16 seq;		// global sequence id or -1
    uint32 nRanges;
    uint32 ofsRanges;
    uint32 nTimes;
    uint32 ofsTimes;
    uint32 nKeys;
    uint32 ofsKeys;
};

struct ModelBoneDef
{
    int32 animid;
    int32 flags;
    int16 parent; // parent bone index
    int16 geoid;
    // new int added to the bone definitions.  Added in WoW 2.0
    int32 unknown;
    AnimationBlock translation;
    AnimationBlock rotation;
    AnimationBlock scaling;
    float pivot[3];
};

struct ModelColorDef
{
    AnimationBlock color;
    AnimationBlock opacity;
};

struct ModelTransDef
{
    AnimationBlock trans;
};

/** \endcond
*/

#endif

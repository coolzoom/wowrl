/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Projectile header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_PROJECTILE_H
#define WOWRL_PROJECTILE_H

#include "wowrl.h"

class Unit;

class Projectile
{
public :

    Projectile();
    Projectile(Spell*, Unit*, Unit*);
    ~Projectile();

    Unit*              GetDestination();
    Unit*              GetParent();
    hgeParticleSystem* GetPSys();
    Spell*             GetSpell();
    float              GetZ();
    void               SetDestination(Unit*);
    void               Stop();
    bool               UpdatePos();

    float fX;
    float fY;
    float fSpeed;
    bool  bArrived;

private :

    Unit*              mDestination;
    Unit*              mOrigin;
    Spell*             mSpell;
    hgeParticleSystem* mPSys;
    std::string        sPSysName;
    std::string        sOldPSysName;
};

#endif

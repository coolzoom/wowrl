/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Distortion header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_DISTORTION_H
#define WOWRL_DISTORTION_H

#include "wowrl.h"

float GetPointDistortion(int x, int y);
float GetPointShadow(int x, int y);

#endif

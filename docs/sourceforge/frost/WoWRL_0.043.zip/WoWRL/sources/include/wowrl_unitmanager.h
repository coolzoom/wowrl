/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           UnitManager header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_UNITMANAGER_H
#define WOWRL_UNITMANAGER_H

#include "wowrl.h"
#include "wowrl_unit.h"

/// Manages units' actions and properties.
/** This class is used to create units and store them.
*   It also takes care of projectiles, spells, buffs and
*   classes.
*/
class UnitManager
{
public :

    ~UnitManager();
/// Returns a unique instance
    static UnitManager* GetSingleton();

/** Creates a Projectile and adds it to the projectile list.
*   \param s      The spell which created the projectile
*   \param target The unit which is aimed
*	\param origin The unit which emited the projectile
*/
    void   CreateProjectile( Spell* s, Unit* target, Unit* origin );

/** Creates a Unit and adds it to the unit list.
*   \param name   The name of the new unit
*   \param x      Its horizontal position
*	\param y      Its vertical position
*   \param level  Its level
*   \param r      Its race
*   \param gender Its gender (male/female)
*   \param c      Its class
*   \param speed  Its speed
*	\return A pointer to the new unit
*/
    Unit*  CreateUnit( std::string name, float x, float y, int level, Race* r, int gender, Class* c, float speed );

/** Takes care of Units deletion.
*/
    void   DeleteUnits();

/** Clears the selection list.
*/
    void   DeselectAll();

/** Searchs in the 'level to base health' table.
*   \param level The level of the unit
*   \param c     Its class
*	\return The base (without any modifier nor equipment) max health value of the unit
*/
    int    GetBaseHealth( int level, Class* c );

/** Searchs in the 'level to base mana' table.
*   \param level The level of the unit
*   \param c     Its class
*	\return The base (without any modifier nor equipment) max mana value of the unit
*/
    int    GetBaseMana( int level, Class* c );

/** A shortcut to the Class list.
*   \param name The name of the Class you want to get
*	\return The Class you asked
*/
    Class* GetClass( std::string name );

/** A shortcut to the Race list.
*   \param name The name of the Race you want to get
*	\return The Race you asked
*/
    Race* GetRace( std::string name );

/** A shortcut to the Unit list.
*   \param name The Unit's name
*	\return The Unit you asked, NULL if not found.
*/
    Unit*  GetUnitByName( std::string name );

/** A shortcut to the Unit list.
*   \param id The Unit's ID
*	\return The Unit you asked, NULL if not found.
*/
    Unit*  GetUnitByID( int id );

/** Searchs in the 'level to xp needed' table.
*   \param level The level of the unit
*	\return The total amount of XP needed to level up
*/
    int    GetXPNeeded( int level );

/** Parses a Buff in the LUA tables.
*   \param luaVM A pointer to the lua state.
*   \param name  The Buff's name
*	\return A pointer to the new Buff (or to the one with the same name if any)
*/
    SBuff* ParseBuff( lua_State* luaVM, std::string name );

/** Parses the Class file and creates AnimSets.
*	\param      luaVM    A pointer to the lua state.
*	\param      state1   The loading state
*	\param[out] finished A boolean telling if the loader should stop calling this function
*	\param      filling  The total loading bar's filling to be used
*	\return A boolean telling if the loader should jump to the next state
*/
    bool   ParseClassesDyn( lua_State* luaVM, int state1, bool* finished, float filling );

/** Parses a Race in the LUA tables.
*   \param luaVM  A pointer to the lua state.
*   \param name   The Race's name
*	\return A pointer to the new Race (or to the one with the same name if any)
*/
    Race* ParseRace( lua_State* luaVM, std::string name );

/** Parses a Spell in the LUA tables.
*   \param luaVM  A pointer to the lua state.
*   \param name   The Spell's name
*   \param regLUA A boolean that states if the Spell must be checked again (if the the LUA environnement has been cleared)
*	\return A pointer to the new Spell (or to the one with the same name if any)
*/
    Spell* ParseSpell( lua_State* luaVM, std::string name, bool regLUA );

/// The abstract action button on which the player has clicked
    ActionButton* mCastedButton;
/// States if the player is casting a spell (= he is choosing a target)
    bool          bCastingSpell;
/// The unit which would cast the spell
    Unit*         mCasterUnit;
/// The unit that's been chosen to cast the spell on
    Unit*         mTargetUnit;
/// States if there is at least one unit selected
    bool          bSelected;
/// States if there is at least one order being executed (movement...)
    bool          bOrderGiven;
/// States if the actual spell is castable
    bool          bCastable;

/// A table linking level to base health
    hgeStringTable*	tLevelToHealth;
/// A table linking level to base mana
    hgeStringTable*	tLevelToMana;
/// A table linking level to XP needed to level up
    hgeStringTable* tLevelToXPNeeded;

/// If more than one unit is selected, this one is the leader
    Unit* mLeadingUnit;
/// The last unit that's been under the mouse
    Unit* mLastOvering;
/// The unit under the mouse
    Unit* mNewOvering;
/// Units default movement speed
    float fPSpeed;

/// The unit list
    std::map<int, Unit*> lUnitList;
/// The Name to ID map
    std::map<std::string, int> lNameToIDMap;
/// The order list
    std::map<int, Unit*> lOrderList;
/// The hostile unit list
    std::map<int, Unit*> lHostileList;
/// The selected unit list
    std::map<int, Unit*> lSelectedList;
/// The temporary selected unit list (selection square)
    std::map<int, Unit*> lTempSelectedList;
/// The acting unit list
    std::map<int, Unit*> lActingList;
/// The attacking unit list
    std::map<int, Unit*> lAttackerList;
/// The healing unit list
    std::map<int, Unit*> lHealerList;
/// The resurrecting unit list
    std::map<int, Unit*> lReserList;
/// The dead unit list
    std::map<int, Unit*> lDeadList;

/// The spell list
    std::map<std::string, Spell>      lSpellList;
/// The buff list
    std::map<std::string, SBuff>      lBuffList;
/// The class list
    std::map<std::string, Class>      lClasseList;
/// The race list
    std::map<std::string, Race>       lRaceList;
/// The projectile list
    std::map<std::string, Projectile> lProjectileList;

protected :

    UnitManager();

private:

    static UnitManager* mUnitMgr;
    bool bDebugParser;
    int iUnitNbr;

};

#endif

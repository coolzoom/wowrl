/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Collision header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_COLLISION_H
#define WOWRL_COLLISION_H

#include "wowrl.h"

bool  CheckPointCollision(int x, int y);
DWORD GetColor(int x, int y);
Point GetNearestAlignedFreePoint(float objx, float objy, float destx, float desty);
Point GetNearestFreePoint(float xi, float yi, float destx, float desty, int precision = 10, int range = 2048);

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Font manager header          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_FONTMANAGER_H
#define WOWRL_FONTMANAGER_H

#include "hge/hgefont.h"

#include <map>
#include <string>
#include <vector>

class FontManager
{
public :

    ~FontManager();
    static FontManager* GetSingleton();

    hgeFont* GetFont(bool file, std::string szFontName, int nSize, bool bBold, bool bItalic);
    void     DeleteFonts();

    hgeFont* mSystemFont;

protected :

    FontManager();

private:

    static FontManager* mFontMgr;
    std::map<std::string, hgeFont*> lFntList;
    std::map<std::string, std::string> lFntPathList;
    std::vector<std::string> lTTFList;
};

#endif

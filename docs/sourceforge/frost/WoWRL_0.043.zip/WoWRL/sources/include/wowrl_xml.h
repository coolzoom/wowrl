/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               XML source               */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_XML_H
#define WOWRL_XML_H

#include "wowrl.h"
#include "wowrl_structs.h"

#include <string>

/// Namespace.
/** This class contains all XML related functions.
*   Note : What I call an 'element' is a UI component that can contain another.
*   An 'art' can't contain anything, it is used to draw things on the screen (text, pictures...)
*   Everything else is an 'attribute'.
*/
class XML
{
public :

/** Initializes the XML interface.
*/
    static void InitUI();

/** Parses a XML UI file.
*   \param a   The AddOn to which this file belongs
*	\param doc The file handler provided by TinyXML
*/
    static void ParseUIFile( AddOn* a, TiXmlDocument doc );

/** Parses a Frame (or one of its derivations).
*   \param node   The XML node at which this element starts
*	\param parent The other element to which this element belongs
*	\param type   The type of this frame, see GUI_OBJECT_TYPE_... (wowrl.h)
*/
    static void ParseFrame( TiXmlNode* node, GUIElement* parent, int type );

/** Parses a Texture (or one of its derivations).
*   \param node   The XML node at which this art starts
*	\param parent The other element to which this art belongs
*	\param layer  The drawing layer of this art
*	\param type   The type of this frame, see GUI_OBJECT_TYPE_... (wowrl.h)
*/
    static void ParseTexture( TiXmlNode* node, GUIElement* parent, int layer, int type = GUI_OBJECT_TYPE_TEXTURE );

/** Parses a FontString (or one of its derivations).
*   \param node   The XML node at which this art starts
*	\param parent The other element to which this art belongs
*	\param layer  The drawing layer of this art
*	\param type   The type of this frame, see GUI_OBJECT_TYPE_... (wowrl.h)
*/
    static void ParseString( TiXmlNode* node, GUIElement* parent, int layer, int type = GUI_OBJECT_TYPE_FONTSTRING );

/** Parses an Anchor attribute.
*   \param node   The XML node at which this attribute starts
*	\param parent The other element to which this attribute belongs
*/
    static void ParseAnchor( TiXmlNode* node, GUIBase* parent );

/** Parses a Backdrop art.
*   \param node   The XML node at which this art starts
*	\param parent The other element to which this art belongs
*/
    static void ParseBackdrop( TiXmlNode* node, GUIElement* parent );
};

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             CastBar header             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_LOADINGBAR_H
#define WOWRL_LOADINGBAR_H

#include "wowrl.h"

class LoadingBar
{
public :

    LoadingBar()
    {
        mCaptionFnt = NULL;
    }

    void Init();
    void Render();

    float fFilling;
    std::string sState;
    std::string sCaption;
    hgeSprite*  mBorder;
    hgeSprite*  mSpark;
    hgeSprite*  mGauge;
    hgeSprite*  mBackground;

private :

    hgeFont* mCaptionFnt;
};

#endif

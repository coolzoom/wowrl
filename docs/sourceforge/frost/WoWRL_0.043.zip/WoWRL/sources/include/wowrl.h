
#define GAME_VERSION 0.043

/***************/
/* GAME STATES */
/***************/
#define GAME_STATE_GAME    0
#define GAME_STATE_LOADING 1

// Un-comment this line and press [P] ingame to start profiling
//#define PROFILE

/****************/
/* OBJECT TYPES */
/****************/
#define OBJ_TYPE_UNIT   0
#define OBJ_TYPE_DOODAD 1

/***********/
/* EFFECTS */
/***********/
// Fx types
#define FX_ANIMATED_EFFECT 0
#define FX_PARTICLE_SYSTEM 1

// Animated fx types
#define FX_MULTI_ANGLE_ANIM  0
#define FX_SINGLE_ANGLE_ANIM 1

/*******/
/* GUI */
/*******/
#define GUI_ART_TYPE_SPRITE    0
#define GUI_ART_TYPE_ANIMATION 1
#define GUI_ART_TYPE_TEXT      2

#define GUI_OBJECT_TYPE_FRAME      0
#define GUI_OBJECT_TYPE_TEXTURE    1
#define GUI_OBJECT_TYPE_FONTSTRING 2
#define GUI_OBJECT_TYPE_STATUSBAR  3
#define GUI_OBJECT_TYPE_TSTATUSBAR 4  // Status bar texture
#define GUI_OBJECT_TYPE_EDITBOX    5
#define GUI_OBJECT_TYPE_FEDITBOX   6  // Edit box font
#define GUI_OBJECT_TYPE_SMSGFRAME  7
#define GUI_OBJECT_TYPE_FSMSGFRAME 8  // Scrolling message frame font
#define GUI_OBJECT_TYPE_BUTTON     9
#define GUI_OBJECT_TYPE_FNBUTTON   10 // Button normal font
#define GUI_OBJECT_TYPE_FHBUTTON   11 // Button highlight font
#define GUI_OBJECT_TYPE_FDBUTTON   12 // Button disabled font
#define GUI_OBJECT_TYPE_TNBUTTON   13 // Button normal texture
#define GUI_OBJECT_TYPE_THBUTTON   14 // Button highlight texture
#define GUI_OBJECT_TYPE_TDBUTTON   15 // Button disabled texture
#define GUI_OBJECT_TYPE_TPBUTTON   16 // Button pushed texture

#define GUI_ANCHOR_TOPLEFT     0
#define GUI_ANCHOR_TOP         1
#define GUI_ANCHOR_TOPRIGHT    2
#define GUI_ANCHOR_RIGHT       3
#define GUI_ANCHOR_BOTTOMRIGHT 4
#define GUI_ANCHOR_BOTTOM      5
#define GUI_ANCHOR_BOTTOMLEFT  6
#define GUI_ANCHOR_LEFT        7
#define GUI_ANCHOR_CENTER      8

#define GUI_LAYER_BACKGROUND  0
#define GUI_LAYER_BORDER      1
#define GUI_LAYER_ARTWORK     2
#define GUI_LAYER_OVERLAY     3
#define GUI_LAYER_HIGHLIGHT   4
#define GUI_LAYER_SPECIALHIGH 5

#define GUI_STRATA_TOOLTIP           7
#define GUI_STRATA_FULLSCREEN_DIALOG 6
#define GUI_STRATA_FULLSCREEN        5
#define GUI_STRATA_DIALOG            4
#define GUI_STRATA_HIGH              3
#define GUI_STRATA_MEDIUM            2
#define GUI_STRATA_LOW               1
#define GUI_STRATA_BACKGROUND        0

#define GUI_CASTBUTTON_EMPTY -1
#define GUI_CASTBUTTON_SPELL 0
#define GUI_CASTBUTTON_STOP  1

#define GUI_SCRTXT_TYPE_PHYSICAL 0
#define GUI_SCRTXT_TYPE_HEAL     1
#define GUI_SCRTXT_TYPE_SPELL    2

#define GUI_BUTTON_STATE_NORMAL 0
#define GUI_BUTTON_STATE_PUSHED 1

// Frame handlers
#define GUI_FUNC_UPDATE          0
#define GUI_FUNC_LOAD            1
#define GUI_FUNC_ENTER           2
#define GUI_FUNC_LEAVE           3
#define GUI_FUNC_HIDE            4
#define GUI_FUNC_SHOW            5
#define GUI_FUNC_KEYUP           6
#define GUI_FUNC_KEYDOWN         7
#define GUI_FUNC_MOUSEUP         8
#define GUI_FUNC_MOUSEDOWN       9
#define GUI_FUNC_DRAGSTART       10
#define GUI_FUNC_RECEIVEDRAG     11
#define GUI_FUNC_EVENT           12
// EditBox handlers
#define GUI_FUNC_CHAR            13
#define GUI_FUNC_ENTERPRESSED    14
#define GUI_FUNC_SPACEPRESSED    15
#define GUI_FUNC_TABPRESSED      16
#define GUI_FUNC_ESCAPEPRESSED   17
#define GUI_FUNC_EDITFOCUSGAINED 18
#define GUI_FUNC_EDITFOCUSLOST   19
// Button handler
#define GUI_FUNC_CLICK           20

/**********/
/* EVENTS */
/**********/
#define EVENT_CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS   1
#define EVENT_CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMMAGE 2
#define EVENT_CHAT_MSG_COMBAT_PARTY_HITS               3
#define EVENT_CHAT_MSG_SPELL_PARTY_DAMAGE              4
#define EVENT_CHAT_MSG_COMBAT_FRIENDLY_DEATH           5
#define EVENT_CHAT_MSG_COMBAT_HOSTILE_DEATH            6

/**********/
/* SPELLS */
/**********/
// Spell types
#define SPELL_TARGET_ALL           0
#define SPELL_TARGET_HOSTILES      1
#define SPELL_TARGET_FRIENDS       2
#define SPELL_TARGET_DEADS         3
#define SPELL_TARGET_DEAD_FRIENDS  4
#define SPELL_TARGET_DEAD_HOSTILES 5

// Spell school
#define SPELL_SCHOOL_NONE   -1
#define SPELL_SCHOOL_HOLY   0
#define SPELL_SCHOOL_FROST  1
#define SPELL_SCHOOL_FIRE   2
#define SPELL_SCHOOL_NATURE 3
#define SPELL_SCHOOL_SHADOW 4
#define SPELL_SCHOOL_ARCANE 5

/*********/
/* ITEMS */
/*********/
// Item binding
#define ITEM_BINDS_NEVER  0
#define ITEM_BINDS_PICKUP 1
#define ITEM_BINDS_EQUIP  2
#define ITEM_BINDS_USE    3
// Item type
#define ITEM_TYPE_ARMOR   0
#define ITEM_TYPE_WEAPON  1
#define ITEM_TYPE_JEWELRY 2
#define ITEM_TYPE_SHIELD  3
#define ITEM_TYPE_TABARD  4
#define ITEM_TYPE_OFFHAND 5
#define ITEM_TYPE_BAG     6
#define ITEM_TYPE_CONS    7
// Item slot
#define ITEM_SLOT_SHIRT    0
#define ITEM_SLOT_CHEST    1
#define ITEM_SLOT_BACK     2
#define ITEM_SLOT_FEET     3
#define ITEM_SLOT_HANDS    4
#define ITEM_SLOT_LEGS     5
#define ITEM_SLOT_SHOULDER 6
#define ITEM_SLOT_WAIST    7
#define ITEM_SLOT_WRIST    8
#define ITEM_SLOT_1H       9
#define ITEM_SLOT_2H       10
#define ITEM_SLOT_MAIN     11
#define ITEM_SLOT_OFF      12
#define ITEM_SLOT_RANGED   13
#define ITEM_SLOT_RING     14
#define ITEM_SLOT_NECKLACE 15
#define ITEM_SLOT_TRINKET  16
// Item quality
#define ITEM_QUALITY_POOR      0
#define ITEM_QUALITY_COMMON    1
#define ITEM_QUALITY_UNCOMMON  2
#define ITEM_QUALITY_RARE      3
#define ITEM_QUALITY_EPIC      4
#define ITEM_QUALITY_LEGENDARY 5
#define ITEM_QUALITY_ARTIFACT  6

/*********/
/* UNITS */
/*********/
// Gender
#define GENDER_MALE   0
#define GENDER_FEMALE 1

// Power type
#define POWER_TYPE_NONE      -1
#define POWER_TYPE_MANA      0
#define POWER_TYPE_RAGE      1
#define POWER_TYPE_FOCUS     2
#define POWER_TYPE_ENERGY    3
#define POWER_TYPE_HAPPINESS 4

// Movement type
#define MOVEMENT_MOVE           0
#define MOVEMENT_APPROACH       1
#define MOVEMENT_APPROACH_AGGRO 2
#define MOVEMENT_LEASHING       3

/**********/
/* MODELS */
/**********/
// Flexible Vertex Format
#define VERTEX_FVF (D3DFVF_XYZ | D3DFVF_TEXCOORDSIZE4(1) |  D3DFVF_TEXCOORDSIZE4(0) | D3DFVF_TEX1)

// Model type
#define MODEL_TYPE_CHARACTER 0
#define MODEL_TYPE_CREATURE  1
#define MODEL_TYPE_DOODAD    2
#define MODEL_TYPE_SPELL     3

// Animations type
#define ANIM_TYPE_SCALE     0
#define ANIM_TYPE_ROTATE    1
#define ANIM_TYPE_TRANSLATE 2

// Bone lookup
#define BONE_LARM      0  // Left upper arm
#define BONE_RARM      1  // Right upper arm
#define BONE_LSHOULDER 2  // Left Shoulder / deltoid area
#define BONE_RSHOULDER 3  // Right Shoulder / deltoid area
#define BONE_STOMACH   4  // Abdomen (upper?)
#define BONE_WAIST     5  // Waist (lower abdomen?)
#define BONE_HEAD      6  // Head
#define BONE_JAW       7  // Jaw/mouth
#define BONE_RFINGER1  8  // (Trolls have 3 "fingers", this points to the 2nd one.
#define BONE_RFINGER2  9  // Center right finger - only used by dwarfs.. don't know why
#define BONE_RFINGER3  10 // (Trolls have 3 "fingers", this points to the 3rd one.
#define BONE_RFINGERS  11 // Right fingers -- this is -1 for trolls, they have no fingers, only the 3 thumb like thingys
#define BONE_RTHUMB    12 // Right Thumb
#define BONE_LFINGER1  13 // (Trolls have 3 "fingers", this points to the 2nd one.
#define BONE_LFINGER2  14 // Center left finger - only used by dwarfs.
#define BONE_LFINGER3  15 // (Trolls have 3 "fingers", this points to the 3rd one.
#define BONE_LFINGERS  16 // Left fingers
#define BONE_LTHUMB    17 // Left Thumb
#define BONE_UnK18     18 // ?
#define BONE_UnK19     19 // ?
#define BONE_UnK20     20 // ?
#define BONE_UnK21     21 // ?
#define BONE_UnK22     22 // ?
#define BONE_UnK23     23 // ?
#define BONE_UnK24     24 // ?
#define BONE_UnK25     25 // ?
#define BONE_ROOT      26 // The "Root" bone,  this controls rotations, transformations, etc of the whole model and all subsequent bones.

#include "dx9/d3dx9.h"

#include <math.h>
#include <string>
#include <map>
#include <ext/hash_map>
#include <vector>
#include <list>
#include <sstream>
#include <fstream>
#include <ios>

#include "hge/hge.h"
#include "hge/hgesprite.h"
#include "hge/hgefont.h"
#include "hge/hgerect.h"
#include "hge/hgevector.h"
#include "hge/hgeanim.h"
#include "hge/hgeparticle.h"
#include "hge/hgestrings.h"

extern "C"
{
	#include "lua/lualib.h"
	#include "lua/lauxlib.h"
	#include "lua/lua.h"
}

#include "lua/lunar.h"

#include "xml/tinyxml.h"

#include "wowrl_timemanager.h"
#include "wowrl_global.h"
#include "wowrl_enums.h"

class Unit;
class Doodad;
class StatusBar;
class Projectile;
class Point;
class Node;
class SceneManager;
class InputManager;
class GFXManager;
class GUIManager;
class UnitManager;
class AnimManager;
class ModelManager;
class Model;
class Bone;
class Zone;
class LoadingBar;
class Effect;
class Stats;
class GUIBase;
class GUIElement;
class GUIArt;

// Namespaces
class XML;
class LUA;
class GUI;

// lua classes
class GUI::UIObject;
class GUI::Region;
class GUI::Frame;
class GUI::StatusBar;
class GUI::EditBox;
class GUI::ScrollingMessageFrame;
class GUI::Button;
class GUI::LayeredRegion;
class GUI::Texture;
class GUI::FontString;

struct RGB;
struct FormatedString;
struct FormatedText;
struct SBuff;
struct Buff;
struct SpellData;
struct Spell;
struct Specialisation;
struct Cursor;
struct Class;
struct Animation;
struct AnimatedEffect;
struct ParticleEffect;
struct SEffect;
struct PAnim;
struct ActionButton;
struct Object;
struct ScrollingText;
struct ErrorText;
struct BGPart;
struct Waypoint;
struct Item;
struct Vector3;
struct Vector4;
struct Vertex;
struct Mesh;
struct AnimData;
struct Anim;
struct AnimSequence;
struct Race;

// Frame funcs
bool GameFrame();
bool LoadFrame();

// Render funcs
bool GameRender();
bool LoadRender();

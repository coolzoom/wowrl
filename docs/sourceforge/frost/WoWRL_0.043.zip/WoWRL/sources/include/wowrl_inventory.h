/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Inventory header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_INVENTORY_H
#define WOWRL_INVENTORY_H

#include "wowrl.h"
#include "wowrl_structs.h"
#include "wowrl_stats.h"

class Inventory
{
public :

    Inventory();
    void Render(float x, float y);
    bool addItem(Item);

    std::map<int, Item> items;
    int size;
    Unit* parent;

    std::string title;
    hgeFont* font;

    float w, h;

    hgeSprite* background;
    hgeSprite* cornerTop;
    hgeSprite* cornerBottom;
    hgeSprite* borderVertical;
    hgeSprite* borderHorizontalTop;
    hgeSprite* borderHorizontalBottom;
    hgeSprite* emptySlot;
    hgeSprite* closeButton;

private :

};

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Unit header               */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_UNIT_H
#define WOWRL_UNIT_H

#include "wowrl.h"
#include "wowrl_point.h"
#include "wowrl_structs.h"
#include "wowrl_effect.h"
#include "wowrl_animmanager.h"

/// An object that can move, attack, ...
/** A Unit is an active object. It is the base of
*   the gameplay. The player controls a few of them
*   and fights against other Units.
*/
class Unit
{
public :

    Unit();
/** \param name   The name of this unit
*   \param x      Its horizontal position
*	\param y      Its vertical position
*   \param level  Its level
*   \param r      Its race
*   \param gender Its gender (male/female)
*   \param c      Its class
*   \param speed  Its speed
*/
    Unit(std::string name, float x, float y, int level, Race* r, int gender, Class* c, float speed);

    ~Unit();

/** Adds aggro points to the provided Unit toward this one.
*   \param u     The Unit which will receive aggro
*   \param aggro The aggro to add
*/
    void                          AddAggroTo(Unit* u, float aggro);

/** Adds a Buff to this unit.<br>
*   Note : if the unit already have this buff and if it
*   is stackable, the buff will be counted one time more.
*   If the buff is not stackable, it just resets its timer.
*   \param name The name of the Buff you want to add
*/
    void                          AddBuff(std::string name);

/** Adds an Effect to this unit.
*   \param name The name of the Effect you want to add
*/
    void                          AddEffect(std::string name);

/** Adds a Unit to this Unit's aggro list with an aggro of 0
*   and add this Unit to the other one's aggroed list.
*   \param u The unit you want to add in the aggro list
*/
    void                          AddUnitToAggroList(Unit* u);

/** Updates this Unit's aggroed list only if RebuildAggroedList()
*   has been called.
*/
    void                          BuildAggroedList();

/** Updates this Unit's aggroed list only if RebuildAggroList()
*   has been called or if 'force' is true.
*   \param force Forces the update
*/
    void                          BuildAggroList(bool force);

/** If it has enough mana/rage/energy and if its target is in range,
*   substracts the Spell's cost and calls the Spell's OnCasted script.
*   Also sets this Unit and its target in combat if necessary.
*   \param s The Spell to cast
*   \return 'true' is the Spell has been casted
*/
    bool                          Cast(Spell* s);

/** Substracts health points to this Unit and calls Die() if it
*   doesn't have any health points. Also generates aggro.
*   \param spell  The Spell from which those damages are coming from
*   \param caster The Unit which inflicts those damages
*   \param value  The health points to substract
*   \param aggro  Generates aggro
*/
    void                          Damage(Spell* spell, Unit* caster, int value, bool aggro);

/** Deletes all pointers (animation, bounding box and effects)
*/
    void                          DeleteThis();

/** Kills this Unit, sets its health and engery to 0 and starts
*   the "dying" animation.
*/
    void                          Die();

/** Updates this Unit's movement on its Point path.
*   \return 'true' if the Unit has arrived to the end of the path
*/
    bool                          FollowPath();

/** Updates this Unit's movement on its Waypoint path.
*   \return 'true' if the Unit has arrived to the end of the path
*/
    bool                          FollowWaypointPath();

/** Starts casting the provided spell to the provided target.
*   \param spell  The Spell to incant
*   \param target The aimed Unit
*/
    void                          Incant(Spell* spell, Unit* target);

/** Sets all Unit's parameters to their default value. Used in both constructors.
*/
    void                          Init();

/** Prepares this Unit's action buttons.
*/
    void                          InitAB();

/** \param o The Object to test
*   \return 'true' if the provided Object's bouding box intersects with this Unit's one
*/
    bool                          Intersects(Object o);

/** \param rect The hgeRect to test
*   \return 'true' if the provided rect intersects with this Unit's Model's bounding box.
*/
    bool                          Intersects(const hgeRect* rect);

/** \param onlyActions Ignore any passive activity (dancing, ...)
*   \return 'true' if this Unit is doing something else than moving or standing
*/
    bool                          IsActing(bool onlyActions = false);

/** \return 'true' if this Unit is attacking something
*/
    bool                          IsAttacking();

/** Tests if the provided Spell can be casted by this Unit
*   under its actual conditions (and to its actual target).
*   \param      s                The Spell to test
*   \param[out] reason           A pointer to a string that'll contain the error code
*   \param      ignoreRange      Ignore range checking
*   \param      ignoreTargetType Ignore the target type checking
*   \return 'true' if the spell can be casted
*/
    bool                          IsCastable(Spell* s, std::string* reason = NULL, bool ignoreRange = false, bool ignoreTargetType = false);

/** \return 'true' if this Unit is casting a spell
*/
    bool                          IsCasting();

/** \return 'true' if this Unit is dead
*/
    bool                          IsDead();

/** \return 'true' if this Unit is healing another
*/
    bool                          IsHealing();

/** \param u Optional Unit to test
*   \return If 'u' isn't NULL, returns 'this unit is hostile toward u', else returns 'true' if this Unit is hostile
*/
    bool                          IsHostile(Unit* u = NULL);

/** \param u The Unit to test
*   \return 'true' if this Unit is in the aggro list of 'u'
*/
    bool                          IsInAggroListOf(Unit* u);

/** \return 'true' if this Unit is in combat
*/
    bool                          IsInCombat();

/** \param x The horizontal coordinate to test
*   \param y The vertical coordinate to test
*   \return 'true' if the provided point is in this Unit's actual Spell's range.
*/
    bool                          IsInSpellRange(float x,float y);

/** \return 'true' if this Unit is selected
*/
    bool                          IsSelected();

/** \param s Optional Spell to use
*   \return 'true' if this Unit's target is in its Spell's range, or, if any, in the provided Spell's range.
*/
    bool                          IsTargetInRange(Spell* s = NULL);

/** \return This Unit's ActionButton list (classic array)
*/
    ActionButton*                 GetABList();

/** \return The actual Spell's incantation percentage, 1.0f if no spell
*/
    float                         GetActionState();

/* \return The actual animation used
*/
    //hgeAnimation*                 GetAnimation();

/** \return The actual animation state ("walk", "stand", ...)
*/
    std::string                   GetAnimState();

/// Deprecated.
    float                         GetAngle();

/** \return This Unit's bounding box (doesn't update it)
*/
    hgeRect*                      GetBox();

/** \return The Buff list, sorted by time remaining
*/
    std::multimap<float, Buff*>   GetBuffList();

/** \return This Unit's Class
*/
    Class*                        GetClass();

/** \return This Unit's color modifier (shadow, effect, ...)
*/
    RGB                           GetColor();

/** \return This Unit's default Spell
*/
    Spell*                        GetDefaultSpell();

/** \return A copy of this Unit's Effect list
*/
    std::map<std::string, Effect> GetEffectList();

/** \return The time left on the global cooldown
*/
    float                         GetGCD();

/** \return This Unit's actual health
*/
    float                         GetHealth();

/** \return This Unit's ID
*/
    int                           GetID();

/** \return This Unit's actual mana
*/
    float                         GetMana();

/** \return This Unit's maximum health
*/
    float                         GetMaxHealth();

/** \return This Unit's maximum mana
*/
    float                         GetMaxMana();

/** \return This Unit's Model
*/
    Model*                        GetModel();

/** \return This Unit's display name
*/
    std::string                   GetName();

/** \return This Unit's on screen position
*/
    Point                         GetPoint();

/** \return This Unit's power type, see POWER_TYPE_... (wowrl.h)
*/
    int	                          GetPowerType();

/** \return This Unit's global position
*/
    Point                         GetGPoint();

/** \return This Unit's global horizontal position
*/
    float                         GetGX();

/** \return This Unit's global vertical position
*/
    float                         GetGY();

/** \return This Unit's level
*/
    int                           GetLevel();

/** \param p The point to test
*   \return This Unit's depth relative to the given point (it's just an Y difference)
*/
    float                         GetRelativeDepth(Point p);

/** \return This Unit's Race
*/
    Race*                         GetRace();

/** \return This Unit's orientation (where it looks at), ranging from 0 to 2*PI
*/
    float                         GetRot();

/// Deprecated, does the same as GetGY()
    float                         GetRZ();

/** \return This Unit's scale factor
*/
    float                         GetScale();

/** \return This Unit's shadow value, ranging from 0 to 255
*/
    float                         GetShadow();

/** \return This Unit's movement speed
*/
    float                         GetSpeed();

/** \return This Unit's actual Spell, NULL if none
*/
    Spell*                        GetSpell();

/** \return This Unit's bounding box when standing (doesn't update it)
*/
    hgeRect*                      GetStandBox();

/** \return This Unit's StatusBar, already formated
*/
    StatusBar*                    GetStatusBar();

/** \return This Unit's target, NULL if none
*/
    Unit*                         GetTarget();

/** \return This Unit's number of scrolling combat texts it has made since the begining
*/
    int                           GetTextNbr();

/// Deprecated
    float                         GetVScale();

/** \return This Unit's on screen horizontal position
*/
    float                         GetX();

/** \return This Unit's on screen vertical position
*/
    float                         GetY();

/// Deprecated, does the same as GetGY()
    float                         GetZ();

/** Tells this Unit to go back where it was before it
*   started to attack another Unit that has entered its
*   aggro range.
*/
    void                          GoBackToOldState();

/** Makes a Unit move to the provided point, must be called
*   on every frame.<br><b>Note</b> : this function doens't make any
*   colision test. It must use a path made by the pathfinder.
*   \param destPoint The destination
*   \return 'true' if the Unit has arrived to this point
*/
    bool                          GoTo(Point destPoint);

/** Adds some health points to this Unit.
*   \param caster The Unit which casted the spell
*   \param value  The total health points to add
*   \param aggro  Generates aggro
*/
    void                          Heal(Unit* caster, int value, bool aggro);

/** Set this Unit's model orientation so that it looks at
*   the given 2D point (in world coordinates).
*   \param p The point at which the Unit will look at
*/
    void                          LookAt(Point p);

/** Tells this Unit to approach the given target until
*   it enters its spell range (* 0.75, just to have the
*   time to cast at least a spell)
*   \param target The Unit to approach, if NULL, this Unit's actual target is used.
*/
    void                          MoveInRange(Unit* target = NULL);

/** Parses a string for special patterns ([spell], [school], ...)
*   and replaces them with the proper values.
*   \param str The base string with values to replace
*   \return The same string, with replaced values
*/
    std::string                   ParseString(std::string str);

/** Parses a string for special patterns ([spell], [school], ...)
*   and replaces them with the proper values, plus some external ones.
*   \param str The base string with values to replace
*   \param u   The caster Unit
*   \param s   The spell used
*   \param value The total ammount of damage given
*   \return The same string, with replaced values
*/
    std::string                   ParseStringAttack(std::string str, Unit* u, Spell* s, int value);

/** Tells this unit to rebuild its aggroed Unit list.
*/
    void                          RebuildAggroedList();

/** Tells this unit to rebuild its aggro list.
*/
    void                          RebuildAggroList();

/** Applies a Spell casted by another Unit to this one
*   \param s The casted Spell
*   \param u The caster
*/
    void                          Receive(Spell* s, Unit* u);

/** Renders this Unit's Model into a render target and update
*   its sprite
*/
    void                          RenderSprite();

/** Resurrects this Unit with a few health and mana points
*   \param health The health to add
*   \param mana   The mana to add
*   \param u      The caster. This Unit will be 'teleported' near 'u'
*/
    void                          Res(int health, int mana, Unit* u);

/** Call this function whenever the application losts focus
*/
    void                          RestoreGfx();

/** Sets this Unit's aggro range.
*   \param range The new range
*/
    void                          SetAggroRange(float range);

/* Sets this Unit's animation (not update automatically) and
*   optionally starts at a special frame, or with the same as before.
*   \param frame         The optional frame id to use
*   \param keepSameFrame Use the same frame number as the previous animation
*/
    //hgeAnimation*                 SetAnimation(int frame = -1, bool keepSameFrame = false);

/** Changes this Unit's animation.
*   \param state See "ANIM_..." (wowrl_animmanager.h)
*   \param pauseAfter If 'true', the Unit won't be animated after this animation has been played. Else, it will go back to "stand".
*/
    void                          SetAnimState(AnimID state, bool pauseAfter = false);

/** Updates this Unit's bounding box.
*/
    void                          SetBox();

/** Changes this Unit's Class.
*   \param c The new Class to use
*/
    void                          SetClass(Class* c);

/** Changes this Unit's color.
*   \param c The new color to use
*/
    void                          SetColor(RGB c);

/** Changes this Unit's color.
*   \param r The new red chanel value (0 -> 255)
*   \param g The new green chanel value (0 -> 255)
*   \param b The new blue chanel value (0 -> 255)
*/
    void                          SetColor(int r, int g, int b);

/** Changes this Unit's side.
*   \param h This Unit will be hostile
*/
    void                          SetHostile(bool h);

/** Set this Unit's ID. This function can only be called once :
*   later calls will have no effect.
*   \param id The new ID
*/
    void                          SetID(int id);

/** Puts this Unit in combat.
*/
    void                          SetInCombat();

/** Changes this Unit's maximum health.
*   \param value  The new maximum health
*   \param adjust Adjusts actual health to the new maximum
*/
    void                          SetMaxHealth(float value, bool adjust);

/** Changes this Unit's maximum mana.
*   \param value  The new maximum mana
*   \param adjust Adjusts actual mana to the new maximum
*/
    void                          SetMaxMana(float value, bool adjust);

    //void                          SetName(std::string);

/** Changes this Unit's Race.
*   \param r The new Race to use
*   \param gender The gender to use, see GENDER_... (wowrl.h)
*/
    void                          SetRace(Race* r, int gender);

/** Changes this Unit's orientation.
*   \param rot The new orientation (in radian : 0 is bottom)
*/
    void                          SetRot(float rot);

/* Changes this Unit's orientation using an angle.
*   \param a The angle from which to calculate the new orientation
*/
    //void                          SetRotFromAngle(float a);

/** Selects / deselects this Unit.
*   \param s Selects this Unit
*/
    void                          SetSelected(bool s);

/** Changes this Unit's scale.
*   \param s The new scale factor
*/
    void                          SetScale(float s);

/** Changes this Unit's movement speed.
*   \param s The new speed
*/
    void                          SetSpeed(float s);

/** Updates this Unit's standing bouding box.
*/
    void                          SetStandBox();

/** Changes this Unit's horizontal position.
*   \param x The new horizontal position
*/
    void                          SetX(float);

/** Changes this Unit's vertical position.
*   \param y The new vertical position
*/
    void                          SetY(float);

/** Cancels everything this Unit is doing, sets its animation state
*   to "stand" and remove it from any special Unit list it was in.
*   \param ignoreAnim If set to 'true', animation won't be changed
*/
    void                          Stop(bool ignoreAnim = false);

/** Changes this Unit's target.
*   \param t The new target (can be NULL)
*/
    void                          Target(Unit* t);

/** \param x The point's horizontal coordinate
*   \param y The point's vertical coordinate
*   \return 'true' if the provided point is in this Unit's Model's bouding box.
*/
    bool                          TestPoint(float x, float y);

/** Updates everything (calls all update functions)
*/
    void                          Update();

/** Updates this Unit's action (attack, heal, resurrection, ...)
*   Sets the proper animation states, calls Incant(), Cast() or Stop()
*   depending on the situation.
*/
    void                          UpdateAction();

/** Updates this Unit's aggressity, switching its target if
*   a Unit becomes more aggressive than the last most aggressive
*   one and engaging Units that enters its aggro zone.
*/
    void                          UpdateAggro();

/** Updates this Unit's buff, their timer and their effects.
*/
    void                          UpdateBuffs();

/** Updates this Unit's special effects.
*/
    void                          UpdateEffects();

/** Updates this Unit's movement, request paths to the pathfinder
*   and calls the proper functions to make this Unit follow them.
*/
    void                          UpdateMovement();

/** Updates this Unit's health and mana regeneration.
*/
    void                          UpdateRegen();

/** Updates this Unit's health and mana from its stuff.
*/
    void                          UpdateStats();

/// Is this Unit attacking another ?
    bool  bAttacking;
/// Is this Unit healing another ?
    bool  bHealing;
/// Is this Unit resurrecting another ?
    bool  bResurrecting;
/// Is this Unit playing an emote ?
    bool  bEmote;
/// Is this Unit hidden ?
    bool  bHidden;
/// Is this Unit dying ?
    bool  bDying;
/// Is this Unit moving ?
    bool  bMoving;
/// Has this Unit been given an order ?
    bool  bOrderGiven;
/// The order type, see MOVEMENT_... (wowrl.h)
    int   iOrder;
/// The path calculated by the pathfinder
    std::vector<Point> lPath;
/// The waypoint path
    std::vector<Point> lWPath;
/// The indice of the point this Unit is reaching
    int   iPointIndice;
/// The indice of the waypoint this Unit is reaching
    int   iWaypointIndice;
/// Is this Unit following a path ?
    bool  bFollowing;
/// Is this Unit following a waypoint path ?
    bool  bFollowingWp;
/// The final destination point
    Point pDestPoint;
/// Is there a special effect being played ?
    bool  bFXPlaying;
/// Deprecated
    float fRZ;
/// This Unit's place in the waypoint path quiery queue
    float fPlaceInWPQueue;
/// This Unit's place in the path quiery queue
    float fPlaceInQueue;
/// This Unit's place in the direct path quiery queue
    float fPlaceInDQueue;
/// Has this Unit requested a path ?
    bool  bPathRequested;
/// Has this Unit obtained its path ?
    bool  bPathObtained;

/// The list of Units which have drawn some aggro to this one
    std::multimap<float, Unit*> lAggroList;
/// The list of Units this Unit has drawn aggro to
    std::map<Unit*, float>      lAggroedList;

private :

    Unit(const Unit &u);

    int iID;

    // Rendering data
    float fX;
    float fY;
    float fOrientation;
    float fRot;
    int   iOldrot;
    float fScale;
    float fVScale;
    RGB   cColor;
    float fShadow;
    float fOldGX, fOldGY;
    int   iTextNbr;
    bool  bProjectile;

    // 3D and cache
    Model* mModel;

    // Animation
    std::string   sAnimState;
    std::string   sOldAnimState;
    //hgeAnimation* mAnimation;
    bool          bFinishAnim;

    // Effect
    std::string                   sEffectState;
    std::string                   sOldEffectState;
    std::map<std::string, Effect> lEffectList;

    // Gameplay data
    // # Infos
    std::string     sName;
    float           fSpeed;
    Race*           mRace;
    int             iGender;
    Class*          mClass;
    Spell*          mSpell;
    Specialisation* mSpec;
    Unit*           mTarget;
    int             iLevel;
    bool            bHostile;
    bool            bSelected;
    bool            bDead;
    bool 			bInCombat;
    int             iAttackState;
    float           fGlobalCoolDown;

    std::map<std::string, Buff> lBuffList;

    // # Stats
    float fHealth;
    float fMana;
    float fAggroRange;
    Stats mStats;

    // # Aggro
    bool			       bAggro;
    bool                   bRebuildAggroList;
    bool                   bRebuildAggroedList;
    Point                  pOldPos;
    Point                  pOldDestPoint;
    std::vector<Point>     lOldPath;
    std::vector<Point>     lOldWPath;
    int                    iOldPointIndice;
    int                    iOldWaypointIndice;
    bool                   bOldOrderGiven;
    int                    iOldOrder;
    bool                   bOldFollowing;
    bool                   bOldMoving;

    // Interaction
    hgeRect* mBox;
    hgeRect* mSBox;

    // GUI
    StatusBar*   mStatusBar;
    ActionButton lAButtonList[121];

    // Update
    float fActionTimer;
    float fRegenTimer;
    float fInCombatTimer;
    float fPathfindingTimer;
};

#endif

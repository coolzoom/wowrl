/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           ZoneManager header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_ZONEMANAGER_H
#define WOWRL_ZONEMANAGER_H

#include "wowrl.h"
#include "wowrl_zone.h"

/// Manages zone switching.
/** This class is used to manage all the zones of the game.
*	It takes care of zone switching and all zone's deletion.
*/
class ZoneManager
{
public :

    ~ZoneManager();
/// Returns a unique instance
    static ZoneManager* GetSingleton();

/** Parses the zone file and build collision and waypoints map.
*	\param      luaVM    A pointer to the lua state.
*	\param      state1   The main loading state
*	\param      state2   The secondary loading state
*	\param[out] finished A boolean telling if the loader should stop calling this function
*	\param      filling  The total loading bar's filling to be used
*	\return A boolean telling if the loader should jump to the next state
*/
    bool ParseZoneDyn( lua_State* luaVM, int state1, int state2, bool* finished, float filling );

/** Deletes doodads.
*/
    void DeleteDoodads();

/// Bakground's horizontal position
    float fBgX;
/// Bakground's vertical position
    float fBgY;
/// The zone you're playing in
    Zone mActualZone;

protected :

    ZoneManager();

private:

    static ZoneManager* mZoneMgr;

    bool bDebugParser;

};

#endif

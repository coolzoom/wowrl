/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           GUIManager header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_GUIMANAGER_H
#define WOWRL_GUIMANAGER_H

#include "wowrl.h"
#include "wowrl_structs.h"
#include "wowrl_loadingbar.h"
#include "wowrl_selectionsquare.h"

#define ARG_TYPE_INTEGER 0
#define ARG_TYPE_FLOAT   1
#define ARG_TYPE_STRING  2
#define ARG_TYPE_BOOL    3

struct Argument
{
    int iType;
    int vInt;
    float vFloat;
    bool vBool;
    std::string vString;

    Argument()
    {
        iType = -1;
    }

    Argument(int type, int value)
    {
        iType = type;
        vInt = value;
    }

    Argument(int type, float value)
    {
        iType = type;
        vFloat = value;
    }

    Argument(int type, bool value)
    {
        iType = type;
        vBool = value;
    }

    Argument(int type, std::string value)
    {
        iType = type;
        vString = value;
    }
};

struct Event
{
    int iID;
    bool bCumulable;
    std::string sName;
    int iArgNbr;
    Argument lArgList[9];
};

class GUIManager
{
public :

    ~GUIManager();
    static GUIManager* GetSingleton();
    void Init();

    // Fonts
    hgeFont* mDefaultFont;

    // Cursors
    void    ParseCursors(lua_State*);
    Cursor* SwitchCursor(std::string);
    Cursor* mCursor;

    // Scrolling combat text
    void       AddScrollingText( Unit*, int, std::string );
    void       UpdateScrollingTexts();
    void       RenderScrollingTexts();
    hgeFont*   mScrollingTextFont;
    // StatusBar
    void       CreateStatusBar( Unit* );
    hgeSprite* mStatusBBgLeft;
    hgeSprite* mStatusBBgMiddle;
    hgeSprite* mStatusBBgRight;
    hgeSprite* mStatusBDeadBgLeft;
    hgeSprite* mStatusBDeadBgMiddle;
    hgeSprite* mStatusBDeadBgRight;
    hgeSprite* mStatusBGauge;
    // TargetLinks
    hgeQuad    mTargetLink1;
    hgeQuad    mTargetLink2;
    float      fTargetLinkTimer;
    DWORD      dwTargetLinkColorF1;
    DWORD      dwTargetLinkColorF2;
    DWORD      dwTargetLinkColorF3;
    DWORD      dwTargetLinkColorE1;
    DWORD      dwTargetLinkColorE2;
    DWORD      dwTargetLinkColorE3;
    // SelectionSquare
    SelectionSquare mSelSquare;
    // Base UI
    hgeSprite* mSelectionCircle;
    hgeSprite* mDeathCircle;
    hgeSprite* mHostileCircle;
    hgeSprite* mPShadow;
    hgeSprite* mOrderCircle;
    hgeSprite* mLoadingBackground;
    hgeSprite* mCarret;
    LoadingBar mLoadingBar;

    // GUI management
    void        ParseUI( std::string );
    void        LoadAddOn( lua_State*, std::string, std::string );
    void        LoadUI( lua_State* );
    void        CloseUI( lua_State* );
    lua_State*  ReLoadUI( lua_State* );
    void        UpdateUI();
    void        RegisterFunc( GUIElement*, int, std::string );
    bool        bRebuildGUIList;
    int         iFuncCount;

    // Event list
    Event       mActualEvent;
    std::vector<Event> lEventList;
    void        FireEvent(Event);
    std::map<int, std::string> lEventNToSMap;
    std::map<std::string, int> lEventSToNMap;
    void        RegisterEvents();
    int         ToEventNbr( std::string );
    std::string ToEventName( int );

    // FormatedText
    FormatedText ParseFormatedText( FormatedText );

    // Error messages
    void     AddErrorMessage( std::string );
    void     UpdateErrorTexts();
    hgeFont* mErrorFont;

    // Edit box
    bool  HasFocus( GUIElement* );
    void  RequestFocus( GUIElement* );
    void  LooseFocus( GUIElement* );
    Point GetCarretPos( GUIElement*, bool );
    Point GetCarretPos( int, hgeFont*, float, float, std::string );
    void  PlaceCarret( GUIElement*, float, float );
    void  UpdateCarretPos( GUIElement* );
    void  UpdateEditBox();

    // Scrolling message frame
    void UpdateScrollingMsgFrame( GUIElement* );

    // GUI lists
    std::map<std::string, GUIElement*> lGuiList;
    std::multimap<int, GUIElement*>    lSortedGUIList;
    std::map<std::string, GUIElement*> lTemplateList;
    std::map<std::string, GUIBase*>    lParentList;
    std::map<std::string, AddOn>       lAddOnList;
    std::map<std::string, Cursor> 	   lCursorList;
    std::map<int, StatusBar>           lStatusBarList;
    std::multimap<int, GUIElement*>    lSortedEditBoxList;

    std::vector<ErrorText>               lErrorTextList;
    std::map<std::string, ScrollingText> lScrollingTextList;
    std::vector<hgeSprite*>              lGUIspriteList;

    // GUI constants
    float fLoadingBarX, fLoadingBarY;
    float fScrollingTextMaxLife;
    float fScrollingTextSpeed;
    bool  bScrollingTextFade;
    bool  bShowStatusBars;
    bool  bShowEnemiesStatusBars;
    float fErrorTextsDuration;
    float fErrorTextsFadeDelay;

protected :

    GUIManager();

private:

    static GUIManager* mGUIMgr;

    GUIElement* mFocus;
    bool        bNewFocus;

};


#endif

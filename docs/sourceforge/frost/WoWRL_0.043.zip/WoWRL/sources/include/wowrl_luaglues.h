#ifndef WOWRL_LUAGLUES_H
#define WOWRL_LUAGLUES_H

/*********/
/* Glues */
/*********/

// Global functions
int l_RandomInt( lua_State* luaVM );
int l_RandomFloat( lua_State* luaVM );
int l_StrReplace( lua_State* luaVM );
int l_StrCapitalStart( lua_State* luaVM );
int l_GetDelta( lua_State* luaVM );
int l_GetLeadingUnit( lua_State* luaVM );
int l_GetLocale( lua_State* luaVM );
int l_GetLocalizedString( lua_State* luaVM );
int l_GetTime( lua_State* luaVM );
int l_GetTimeOfTheDay( lua_State* luaVM );
int l_GetGlobal( lua_State* luaVM );
int l_GetMousePos( lua_State* luaVM );
int l_GetMouseGPos( lua_State* luaVM );
int l_DoString( lua_State* luaVM );

// Graphics functions
int l_Gfx_CreateSprite( lua_State* luaVM );
int l_Gfx_RenderSprite( lua_State* luaVM );
int l_Gfx_CreateAnimation( lua_State* luaVM );
int l_Gfx_UpdateAnimation( lua_State* luaVM );
int l_Gfx_RenderAnimation( lua_State* luaVM );
int l_Gfx_CreatePSys( lua_State* luaVM );
int l_Gfx_UpdatePSys( lua_State* luaVM );
int l_Gfx_RenderPSys( lua_State* luaVM );

// GUI functions
int l_GUI_CreateElement( lua_State* luaVM );

// Unit functions
int l_Unit_Name( lua_State* luaVM );
int l_Unit_Spawn( lua_State* luaVM );
int l_Unit_AddEffect( lua_State* luaVM );
int l_Unit_SetHostile( lua_State* luaVM );
int l_Unit_SetMaxHP( lua_State* luaVM );
int l_Unit_SetAggroRange( lua_State* luaVM );
int l_Unit_SetTarget( lua_State* luaVM );
int l_Unit_SetX( lua_State* luaVM );
int l_Unit_SetY( lua_State* luaVM );
int l_Unit_IsHostile( lua_State* luaVM );
int l_Unit_IsDead( lua_State* luaVM );
int l_Unit_IsTargetInRange( lua_State* luaVM );
int l_Unit_GetTarget( lua_State* luaVM );
int l_Unit_GetX( lua_State* luaVM );
int l_Unit_GetY( lua_State* luaVM );
int l_Unit_GetLevel( lua_State* luaVM );
int l_Unit_GetHealth( lua_State* luaVM );
int l_Unit_GetMana( lua_State* luaVM );
int l_Unit_GetMaxHealth( lua_State* luaVM );
int l_Unit_GetMaxMana( lua_State* luaVM );
int l_Unit_GetPowerType( lua_State* luaVM );
int l_Unit_AddItem( lua_State* luaVM );
int l_Unit_GetActionTexture( lua_State* luaVM );
int l_Unit_GetActionInfo( lua_State* luaVM );
int l_Unit_IsActionInRange( lua_State* luaVM );
int l_Unit_IsUsableAction( lua_State* luaVM );
int l_Unit_CastSpell( lua_State* luaVM );
int l_Unit_CastSpellIndirect( lua_State* luaVM );
int l_Unit_IsCasting( lua_State* luaVM );
int l_Unit_CastingInfo( lua_State* luaVM );
int l_Unit_GetSpellInfo( lua_State* luaVM );
int l_Unit_SetAttacking( lua_State* luaVM );
int l_Unit_SetHealing( lua_State* luaVM );
int l_Unit_SetResurrecting( lua_State* luaVM );
int l_Unit_Damage( lua_State* luaVM );
int l_Unit_Heal( lua_State* luaVM );
int l_Unit_Res( lua_State* luaVM );
int l_Unit_AddBuff( lua_State* luaVM );
int l_Unit_AddEffect( lua_State* luaVM );
int l_Unit_GetBuffs( lua_State* luaVM );
int l_Unit_ShowSubMesh( lua_State* luaVM );
int l_Unit_Emote( lua_State* luaVM );
int l_Unit_SetAnim( lua_State* luaVM );

#endif

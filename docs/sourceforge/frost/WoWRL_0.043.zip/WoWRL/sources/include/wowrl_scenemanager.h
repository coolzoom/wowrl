/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          Scene manager header          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_SCENEMANAGER_H
#define WOWRL_SCENEMANAGER_H

#include "wowrl.h"
#include "wowrl_structs.h"

class SceneManager
{
public :

    ~SceneManager();
    static SceneManager* GetSingleton();

    void  BuildDirectPaths();
    void  BuildPaths();
    void  BuildWPPaths();
    void  DeleteThis();
    void  LogString( std::string, ... );
    Item* ParseItem( int item_id );
    void  PrintLog();
    void  ReplaceSpellValues( std::string*, Spell* );
    void  RequestDirectPath( Unit* );
    void  RequestPath( Unit* );
    void  RequestWPPath( Unit* );
    void  Update();

    // Global variables
    float fGX, fGY;
    float fDX, fDY;
    float fDGX, fDGY;
    int   iGameState;
    bool  bGamePaused;
    float fGameVersion;
    int   iLoaderState;
    bool  bJumpToNextState;

    // Scene variables
    bool bPanning;
    bool bMouseOverPlayField;

    hgeRect* mScreenLRect;
    hgeRect* mScreenTRect;
    hgeRect* mScreenRRect;
    hgeRect* mScreenBRect;

    // Lua parser
    lua_State*  luaVM;
    // Used to communicate with LUA
    std::string sTmpString;

    // String manipulation

    hgeStringTable* tStrTable;

    // Tables
    std::string sLocale;

    // Items

    std::map<float, Unit*> lRequestWPList;
    std::map<float, Unit*> lRequestList;
    std::map<float, Unit*> lRequestDList;

    // Game constants
    float fAspectRatio;
    float fRegenTimer;
    float fInCombatTimer;
    int   iMaxComputedPaths;

    // Lists
    std::map<int, Item*> lItemList;

protected :

    SceneManager();

private:

    static SceneManager* mSceneMgr;
    bool bDebugParser;

    std::string sLog;
    std::fstream fsFile;

    hgeRect*    mBgRect;
    bool        bScreenLInt;
    bool        bScreenTInt;
    bool        bScreenRInt;
    bool        bScreenBInt;
    float       fPanSpeed;

};

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Point source              */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Point class.                   */
/*       A Point is a simple set of two   */
/*  float values. You can use it as a     */
/*  coordinate container.                 */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_point.h"

Point::Point() : fX(0.0f), fY(0.0f)
{
}

Point::Point(float nx, float ny) : fX(nx), fY(ny)
{
}

Point::Point(Point *p) : fX(p->fX), fY(p->fY)
{
}

Point::~Point()
{
    fX = 0.0f; fY = 0.0f;
}

void Point::Set( float nx, float ny )
{
	fX = nx;
	fY = ny;
}

Point Point::operator+ (Point p2)
{
    return Point(fX + p2.fX, fY + p2.fY);
}
void Point::operator+= ( Point p )
{
    fX += p.fX; fY += p.fY;
}

Point Point::operator- (Point p2)
{
    return Point(fX - p2.fX, fY - p2.fY);
}
void Point::operator-= ( Point p )
{
    fX -= p.fX; fY -= p.fY;
}
bool Point::operator== ( Point p )
{
    return ( (fX==p.fX) && (fY==p.fY) );
}
bool Point::operator!= ( Point p )
{
    return !( (fX==p.fX) && (fY==p.fY) );
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          InputManager source           */
/*                                        */
/*  ## : ...                              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_timemanager.h"
#include "wowrl_inputmanager.h"

#include "memory.h"

#define INPUT_LONGPRESS_DELAY 0.7f

extern TimeManager *mTimeMgr;
extern HGE *hge;

InputManager::InputManager()
{
	fGMX = 0.0f; fGMY = 0.0f;
	fDMX = 0.0f; fDMY = 0.0f;
	fOldMX = 0.0f; fOldMY = 0.0f;

	memset(lKeyDelay, 0, 256 * sizeof(float));
	memset(lKeyLong, 0, 256 * sizeof(bool));
	memset(lKeyBuf, 0, 256 * sizeof(bool));
	memset(lKeyBufOld, 0, 256 * sizeof(bool));
	lDoubleclickDelay[0] = 0;
	lDoubleclickDelay[1] = 0;
	lDoubleclickDelay[2] = 0;
	fDoubleclickTime = 0.25;

	bCtrlPressed = false;
	bShiftPressed = false;
	bAltPressed = false;

	bLastDragged = false;

	bFocus = false;
}

InputManager::~InputManager()
{
    mInputMgr = NULL;
}

InputManager* InputManager::mInputMgr = NULL;

InputManager* InputManager::GetSingleton()
{
	if (mInputMgr == NULL)
		mInputMgr = new InputManager;
	return mInputMgr;
}

char InputManager::GetChar( bool format, bool force )
{
	if (!force && bFocus)
		return 0;
	else if (format)
	{
		// Filter non printable characters and special keys
		char c = hge->Input_GetChar();
		if ((c == 8)  || // Backspace
			(c == 9)  || // Tab
			(c == 13) || // Enter
			(c == 27)    // Escape
			)
			c = 0;
		return c;
	}
	else
		return hge->Input_GetChar();
}

bool InputManager::GetKey( bool force )
{
	if (!force && bFocus)
		return false;
	else
		return bKey;
}

void InputManager::GetMousePos()
{
	hge->Input_GetMousePos(&fMX, &fMY);
}

bool InputManager::KeyIsDown( int index, bool force )
{
	if (!force && bFocus)
		return false;
	else
		return lKeyBuf[index];
}

bool InputManager::KeyIsDownLong( int index, bool force )
{
	if (!force && bFocus)
		return false;
	else
		return (lKeyBuf[index] && lKeyLong[index]);
}

bool InputManager::KeyIsPressed( int index, bool force )
{
	if (!force && bFocus)
		return false;
	else
		return (lKeyBuf[index] && !lKeyBufOld[index]);
}

bool InputManager::KeyIsReleased( int index, bool force )
{
	if (!force && bFocus)
		return false;
	else
		return (!lKeyBuf[index] && lKeyBufOld[index]);
}

bool InputManager::KeyIsDoubleClicked( int index, bool force )
{
	if (!force && bFocus)
		return false;
	else
	{
		switch (index)
		{
			case HGEK_LBUTTON: return (KeyIsPressed(HGEK_LBUTTON) && lDoubleclickDelay[0]>0); break;
			case HGEK_RBUTTON: return (KeyIsPressed(HGEK_RBUTTON) && lDoubleclickDelay[1]>0); break;
			case HGEK_MBUTTON: return (KeyIsPressed(HGEK_MBUTTON) && lDoubleclickDelay[2]>0); break;
		}
		return false;
	}
}

void InputManager::Update()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(0, "InputManager::Update", false);
		Chrono c(prof);
	#endif

	// Get delta time
	/*double time = GetTime();
	dt = time - lastTime;
	lastTime = time;*/

	// Update keys
	for (int i = 0; i < 256; i++)
		lKeyBufOld[i] = lKeyBuf[i];

	// Control extreme dTime after loading/at startup etc
	float delta = mTimeMgr->GetDelta();
	if (delta<0 || delta>1)
		delta = 0.05f;

	lDoubleclickDelay[0] -= delta;
	lDoubleclickDelay[1] -= delta;
	lDoubleclickDelay[2] -= delta;

	if(lKeyBuf[HGEK_LBUTTON])
		lDoubleclickDelay[0] = fDoubleclickTime;
	if(lKeyBuf[HGEK_RBUTTON])
		lDoubleclickDelay[1] = fDoubleclickTime;
	if(lKeyBuf[HGEK_MBUTTON])
		lDoubleclickDelay[2] = fDoubleclickTime;

	bKey = false;
	for (int i = 0; i < 256; i++)
	{
		lKeyBuf[i] = hge->Input_GetKeyState(i);
		// Get if any key has been pressed (exclude mouse buttons)
		if ( lKeyBuf[i] && (i!=1) && (i!=2) && (i!=4) ) bKey = true;
	}

	// Update delays
	for (int i = 0; i < 256; i++)
	{
		if (lKeyBuf[i])
		{
			lKeyDelay[i] += delta;
			if (lKeyDelay[i] >= INPUT_LONGPRESS_DELAY)
				lKeyLong[i] = true;
		}
		else
		{
			lKeyDelay[i] = 0.0f;
			lKeyLong[i] = false;
		}
	}

	// Update mouse
	GetMousePos();

	fDMX = fOldMX-fMX;
	fDMY = fOldMY-fMY;
	fOldMX = fMX;
	fOldMY = fMY;

	fGMX = fMX-fGX;
	fGMY = fMY-fGY;

	// Handle left mouse button
	if (KeyIsDown(HGEK_LBUTTON, true))
	{
		if (KeyIsPressed(HGEK_LBUTTON, true))
			iMLState = 2; // single pressed
		else if(KeyIsDoubleClicked(HGEK_LBUTTON, true))
			iMLState = 4; // double clicked
		else
			iMLState = 1; // dragged

		sMouseButton = "LeftButton";
	}
	else if (KeyIsReleased(HGEK_LBUTTON, true))
	{
		iMLState = 3; // released
		sMouseButton = "LeftButton";
	}
	else
	{
		iMLState = 0; // no input
		if (iMRState == 0)
			sMouseButton = "";
	}

	// Handle right mouse button
	if (KeyIsDown(HGEK_RBUTTON, true))
	{
		if (KeyIsPressed(HGEK_RBUTTON, true))
			iMRState = 2;
		else if (KeyIsDoubleClicked(HGEK_RBUTTON, true))
			iMRState = 4;
		else
			iMRState = 1;

		if (sMouseButton == "LeftButton")
			sMouseButton = "BothButtons";
		else
			sMouseButton = "RightButton";
	}
	else if (KeyIsReleased(HGEK_RBUTTON, true))
	{
		iMRState = 3;
		if (sMouseButton == "LeftButton")
			sMouseButton = "BothButtons";
		else
			sMouseButton = "RightButton";
	}
	else
	{
		iMRState = 0;
		if (iMLState == 0)
			sMouseButton = "";
	}

	if (KeyIsDown(HGEK_CTRL, true))
		bCtrlPressed = true;
	else
		bCtrlPressed = false;

	if (KeyIsDown(HGEK_SHIFT, true))
		bShiftPressed = true;
	else
		bShiftPressed = false;

	if (KeyIsDown(HGEK_ALT, true))
		bAltPressed = true;
	else
		bAltPressed = false;
}

void InputManager::SetDoubleclickTime( float setTime )
{
	fDoubleclickTime = setTime;
}

void InputManager::SetGlobalDisplacement( float ngx, float ngy )
{
	fGX = ngx; fGY = ngy;
	fGMX = fMX-fGX;
	fGMY = fMY-fGY;
}

void InputManager::SetFocus( bool f )
{
	bFocus = f;
}

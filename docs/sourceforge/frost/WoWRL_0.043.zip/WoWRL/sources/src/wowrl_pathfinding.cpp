/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Pathfinding source           */
/*                                        */
/*  ## : Contains the pathfinding         */
/*  function. It is yet to be perfected.  */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge/hge.h"
#include "hge/hgesprite.h"
#include "hge/hgevector.h"
#include <math.h>
#include <vector>
#include <ext/hash_map>

#include "wowrl_point.h"
#include "wowrl_node.h"
#include "wowrl_global.h"
#include "wowrl_collision.h"
#include "wowrl_scenemanager.h"
#include "wowrl_zonemanager.h"
#include "wowrl_unit.h"
#include "wowrl_structs.h"

#include "wowrl_pathfinding.h"

#define PRECISION 8
#define MAXNODE 50000

extern HGE *hge;
extern SceneManager *mSceneMgr;
extern ZoneManager *mZoneMgr;
extern TimeManager *mTimeMgr;

std::vector<Point> GetDestPoints( Unit* leader, int pointNumber, float space )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "getDestPoints", false);
		Chrono c(prof);
	#endif
	/* [#] This function returns a vector of destination points. All of these
	/* points are walkable and aligned with the others in a rectangular shape.
	/* [#] If you want to understand how it works, change "debug" to true, order
	/* a dozen units to move and look in the log file.
	*/
	bool debug = false;
	std::vector<Point> pDestPoints;

	float xi = ToInt(leader->pDestPoint.fX);
	float yi = ToInt(leader->pDestPoint.fY);

	pDestPoints.push_back(Point(xi,yi));

	int collumnNbr = ToInt(ceil(Rac2(pointNumber)));

	if (debug) Log(" # Asking for %d points around position (%.0f, %.0f)", pointNumber-1, xi, yi);

	hgeVector destVec;
	destVec.x = xi - leader->GetGX();
	destVec.y = yi - leader->GetGY();

	float angle = destVec.Angle();
	if (debug) Log(" # destVec.Angle() = %.0f (degree)", RadToDeg(angle));

	float x = xi;
	float y = yi;
	float vx = 0.0f;
	float vy = 0.0f;

	float offset = 0.0f;

	int pointToPlace = pointNumber-1;
	int pointPlacedOnRow = 1;
	int row = 0;
	while (pointToPlace != 0)
	{
		if (debug) Log(" pointToPlace = %d, row = %d, pointPlacedOnRow = %d", pointToPlace, row, pointPlacedOnRow);
		if (offset == 0.0f)
		{
			double fpart, ipart;
			fpart = modf(pointPlacedOnRow/2.0f, &ipart);
			if (fpart != 0.0f) // if pointPlacedOnRow is odd
			{
				vx = (ipart+1)*space;
			}
			else // else it's even
			{
				vx = -ipart*space;
			}
		}
		else
		{
			vx += space;
		}

		if (debug) Log(" virtual position (%.0f , %.0f)", vx, vy);

		hgeVector pVec;
		pVec.x = vx;
		pVec.y = vy;
		float pDist = pVec.Length();
		float pAngle = pVec.Angle();

		if (debug) Log(" virtual lenght = %.0f", pDist);
		if (debug) Log(" virtual angle = %.0f", RadToDeg(pAngle));

		float dx = ToInt(pDist*sin(angle - pAngle));
		float dy = - ToInt(pDist*cos(angle - pAngle)*mSceneMgr->fAspectRatio);

		if (debug) Log(" real position (%.0f, %.0f)", dx, dy);

		x = xi + dx;
		y = yi + dy;

		if (debug) Log(" -> (%.0f, %.0f)", x, y);

		if (CheckPointCollision(ToInt(x), ToInt(y)))
		{
			Point p = GetNearestFreePoint(x, y, xi, yi);
			x = p.fX;
			y = p.fY;
			if (debug) Log(" These coordinates aren't walkable : (%.0f, %.0f) are", x, y);
		}

		pDestPoints.push_back(Point(x, y));
		pointToPlace--;
		pointPlacedOnRow++;
		if (pointPlacedOnRow == collumnNbr)
		{
			pointPlacedOnRow = 0;
			vy += space;
			row++;
			if (pointToPlace < collumnNbr)
			{
				if (debug) Log(" Last raw has less units than the number of unit per row (%d < %d)", pointToPlace, collumnNbr);
				double fpart1, ipart1;
				fpart1 = modf(pointToPlace/2.0f, &ipart1);
				double fpart2, ipart2;
				fpart2 = modf(collumnNbr/2.0f, &ipart2);
				if ( (fpart1 == 0.0f) && (fpart2 != 0.0f) )
				{
					offset = ( ( 1-pointToPlace )/2.0f - 1)*space;
					vx = offset;
					if (debug) Log(" It's an even number contrary to the collumn number, so we add an offset : %f", offset);
				}
				else if ( (fpart1 != 0.0f) && (fpart2 == 0.0f) )
				{
					offset = ( ( 2-pointToPlace )/2.0f -1)*space;
					vx = offset;
					if (debug) Log(" It's an odd number contrary to the collumn number, so we add an offset : %f", offset);
				}
			}
		}
	}

	return pDestPoints;
}

Point GetNearestInRangePoint(float xi, float yi, float destx, float desty, float range)
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "getNearestInRangePoint", false);
		Chrono c(prof);
	#endif
	/* [#] This function looks very similar to getNearestAlignedFreePoint except
	/* that it stops when it finds a point in the provided range from the destination.
	*/
	hgeVector vec;
	vec.x = ToInt(destx)-ToInt(xi);
	vec.y = ToInt(desty)-ToInt(yi);
	float coefx = cos(vec.Angle());
	float coefy = sin(vec.Angle());
	vec.x = ToInt(xi);
	vec.y = ToInt(yi);

	float distance = Dist(xi, yi*mSceneMgr->fAspectRatio, destx, desty*mSceneMgr->fAspectRatio);
	if (range >= distance)
		return Point(xi, yi);
	if (range < 1)
		range = 1;

	bool collides = false;

	while (!collides)
	{
		vec.x += coefx;
		vec.y += coefy;
		collides = CheckPointCollision(ToInt(vec.x), ToInt(vec.y));
		if (collides)
			return Point(-1, -1);
		else
		{
			distance = Dist(destx, desty*mSceneMgr->fAspectRatio, vec.x, vec.y*mSceneMgr->fAspectRatio);
			if (distance <= range)
				return Point(vec.x, vec.y);
		}
	}
}

Waypoint* FindNearestWaypoint( float x, float y )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "findNearestWaypoint", false);
		Chrono c(prof);
	#endif
	/* [#] This function is very simple :
	/* It chooses the nearest waypoint in the zone's waypoint list from the two
	/* coordinates given, just by checking the distance for each and keeping the
	/* one with the shortest distance.
	/* [#] As in getDestPoints(), change "debug" to true if you want to understand
	/* how it works.
	*/
	bool debug = false;

	float bestDist = -1.0f;
	Waypoint* bestWp = NULL;
	std::map<std::string, Waypoint>::iterator iterWp;
	for (iterWp = mZoneMgr->mActualZone.lWPntList.begin(); iterWp != mZoneMgr->mActualZone.lWPntList.end(); iterWp++)
	{
		Waypoint* wp = &iterWp->second;
		float distance = Dist(wp->fX, wp->fY*mSceneMgr->fAspectRatio, x, y*mSceneMgr->fAspectRatio);
		if (debug) {Log("Analysing %s (%.0f,%.0f) : distance = %.0f", wp->sName.c_str(), wp->fX, wp->fY, distance);}
		if ((distance < bestDist) || (bestDist == -1.0f))
		{
			if (debug) {Log(" New best child !");}
			bestDist = distance;
			bestWp = wp;
		}
	}

	return bestWp;
}

std::vector<Point> GetWaypoints( float xi, float yi, float destx, float desty )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "getWaypoints", false);
		Chrono c(prof);
	#endif
	/* [#] In this function, we use an A* hybrid :
	/*  - Instead of the node system used in the getShortestPath() function, the
	/* search is based on user placed waypoints whose list is contained in the
	/* zone INI.
	/*  - Each of these waypoints has a child list which contains all the othe
	/* waypoints that are directly accessible from it.
	/*  - The algorithm reads the whole child list to get the best child, the
	/* one which is the closest from the destination waypoint.
	/* [#] The use of this waypoints system is mainly for performance. A unit
	/* following a waypoint path only calls getShortestPath() from its actual
	/* waypoint to the next one : the whole path is calculated in several times.
	/* [#] Another advantage of this system is that it allows "path forcing". A
	/* unit following a waypoint path will be obliged to go through every waypoint
	/* in the path. This can be usefull when crossing a curved brigde for example :
	/* if waypoints are place all over the bridge's curve, the unit will follow
	/* that curve instead of trying to find the shorstest path, which would look
	/* bad (even being the shortest one).
	/* [#] But this has also an inconvenient : units movements would all look the
	/* same as they are obliged to go through fixed points on the map. The solution
	/* to prevent this effect is to add a randomness zone around each waypoint in
	/* which the unit picks a random point and walks to it. The size of the zone
	/* is variable and can be set in the zone's INI.
	/* [#] As in the previous functions, change "debug" to true if you wan't to
	/* understand how this function works.
	*/


	bool debug = false;
	if (debug) {Log("Tring to find waypoints from (%.0f,%.0f) to (%.0f,%.0f)", xi, yi, destx, desty);}

	std::vector<Point> waypoints;
	waypoints.reserve(50);

	if (!mZoneMgr->mActualZone.bWaypoints)
	{
	    if (debug) {Log("This zone doesn't have any waypoint");}
		return waypoints;
	}

	Waypoint* firstWaypoint = FindNearestWaypoint(xi, yi);
	if (Dist(xi, yi*mSceneMgr->fAspectRatio, firstWaypoint->fX, firstWaypoint->fY*mSceneMgr->fAspectRatio) > Dist(xi, yi*mSceneMgr->fAspectRatio, destx, desty*mSceneMgr->fAspectRatio))
	{
		if (debug) {Log("No need to use waypoints");}
		return waypoints;
	}
	if (debug) {Log("Using %s (%.0f,%.0f) as start", firstWaypoint->sName.c_str(), firstWaypoint->fX, firstWaypoint->fY);}

	Waypoint* destWaypoint = FindNearestWaypoint(destx, desty);
	if (debug) {Log("Using %s (%.0f,%.0f) as end", destWaypoint->sName.c_str(), destWaypoint->fX, destWaypoint->fY);}
	if (firstWaypoint == destWaypoint)
	{
		if (debug) {Log("Only one waypoint needed");}
		return waypoints;
	}

	float bestDist = -1.0f;
	float bestG;
	bool destFound = false;
	Waypoint* bestWaypoint;
	Waypoint* actualWaypoint = firstWaypoint;
	actualWaypoint->bOpened = true;
	actualWaypoint->fG = 0.0f;
	float g = 0.0f;

	while (actualWaypoint != destWaypoint)
	{
		if (debug) {Log("\n# Using %s (%.0f,%.0f), g=%.0f", actualWaypoint->sName.c_str(), actualWaypoint->fX, actualWaypoint->fY, actualWaypoint->fG);}
		std::multimap<float, Waypoint*>::iterator iterChild;
		bestWaypoint = NULL;
		bestDist = -1.0f;
		for (iterChild = actualWaypoint->lChildList.begin(); iterChild != actualWaypoint->lChildList.end(); iterChild++)
		{
			Waypoint* wp = iterChild->second;

			if (wp == destWaypoint)
			{
				if (debug) {Log("### Found destination waypoint !");}
				bestWaypoint = destWaypoint;
				destFound = true;
			}

			if (!wp->bUseless && (wp->lChildList.size() != 0))
			{
				if (debug) {Log("\n ## %s (%.0f,%.0f)", wp->sName.c_str(), wp->fX, wp->fY);}
				if (wp->bOpened)
				{
					if (debug) {Log(" ### Actual nodes's g is %f, could be %f (%.0f + %.0f)", actualWaypoint->fG, wp->fG+iterChild->first, wp->fG, iterChild->first);}
					if (actualWaypoint->fG > wp->fG+iterChild->first)
					{
						if (debug) {Log(" #### Adjusting.", wp->sName.c_str(), wp->fX, wp->fY);}
						actualWaypoint->fG = wp->fG+iterChild->first;
						actualWaypoint->mParent = wp;
					}
				}
				else
				{
					wp->mParent = actualWaypoint;
					wp->fG = g+iterChild->first;
				}
				if (!destFound && !wp->bClosed)
				{
					float distance = Dist(wp->fX, wp->fY*mSceneMgr->fAspectRatio, destWaypoint->fX, destWaypoint->fY*mSceneMgr->fAspectRatio);
					if ( (distance < bestDist) || (bestDist == -1.0f) )
					{
						if (debug) {Log(" ### Found new best child (d=%.0f)", distance);}
						bestDist = distance;
						bestWaypoint = wp;
						bestG = iterChild->first;
					}
				}
			}

			wp->bOpened = true;
		}
		if (bestWaypoint == NULL)
		{
			if (debug) {Log(" # Useless waypoint... going back.");}
			actualWaypoint->bUseless = true;
			actualWaypoint->bClosed = true;
			actualWaypoint = actualWaypoint->mParent;
			g = actualWaypoint->fG;
		}
		else
		{
			actualWaypoint->bClosed = true;
			actualWaypoint = bestWaypoint;
			g += bestG;
			actualWaypoint->fG = g;
		}
	}

	if (debug) {Log("\n# Writing path...");}

	Point p;
	p.fX = actualWaypoint->fX;
	p.fY = actualWaypoint->fY;
	waypoints.push_back(p);
	while (actualWaypoint != firstWaypoint)
	{
		std::vector<Point>::iterator iterWp3 = waypoints.begin();
		if (debug) {Log(" ## Inserting %s.", actualWaypoint->mParent->sName.c_str());}
		p.fX = actualWaypoint->mParent->fX;
		p.fY = actualWaypoint->mParent->fY;
		p.fSize = actualWaypoint->mParent->fSize;
		waypoints.insert(iterWp3, p);
		if (debug) {Log(" ## Following with %s's parent.", actualWaypoint->mParent->sName.c_str());}
		actualWaypoint = actualWaypoint->mParent;
	}

	std::vector<Point>::iterator iterWp2 = waypoints.begin();
	waypoints.erase(iterWp2);
	waypoints.pop_back();

	if (debug)
	{
		std::vector<Point>::iterator iterWp;
		for (iterWp = waypoints.begin(); iterWp != waypoints.end(); iterWp++)
		{
			Point wp = *iterWp;
			Log("%.0f, %.0f", wp.fX, wp.fY);
		}
	}

	if (debug) {Log("\n# Setting values back to default...");}
	std::map<std::string, Waypoint>::iterator iterWp1;
	for (iterWp1 = mZoneMgr->mActualZone.lWPntList.begin(); iterWp1 != mZoneMgr->mActualZone.lWPntList.end(); iterWp1++)
	{
		Waypoint* wp = &iterWp1->second;
		wp->bUseless = false;
		wp->bOpened = false;
		wp->bClosed = false;
	}

	return waypoints;
}

std::vector<Point> GetShortestPath( float xi, float yi, float destx, float desty, float range )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "getShortestPath", true);
		Chrono c(prof);
	#endif
	/* [#] In this function, we use a pathfinding algorithm that is close to A* :
	/*  - We divide the collision bitmap in nodes
	/*  - We analyse the first node (the one on which the player is) and its sur-
	/* rounding nodes and we choose the one which is closest to our destination.
	/*  - Then we set this node as the new base node and we analyse each of its
	/* surrounding nodes the same way we did with the first, and we continue with
	/* the best node again, until the destination node is reached or until there
	/* is no more free node available (= no path).
	/*  - If the algorithm finds no path, it returns the closest aligned node
	/* (could be better if it returned the path to the closest node it has found)
	/*  - If the destination node is reached, we go back from node to parent until
	/* the first node is reached : here is the path.
	*/

	// Variable definition

	// Set to true if you want log output. It will help you understand the function.
	// ##[Warning]## : heavy CPU usage !
	bool debug = false;

	// Set to true if you want to add 8 more direction to look at.
	// It will not necessary increase CPU usage, as the 8 new nodes
	// are more far than the others, reducing the number of visited
	// nodes if one is chosen to continue the path.
	// Adding 8 directions will help finding the real shortest path
	// and will smooth the resulting path.
	bool addMorePossibleNodes = false;

	bool searchRange;
	if (range <= 0.0f)
		searchRange = false;
	else
		searchRange = true;

	std::vector<Point> path;

	if (Dist(xi, yi, destx, desty) < PRECISION)
	{
		Point p;
		p.fX = destx;
		p.fY = desty;
		path.push_back(p);
		return path;
	}

	path.reserve(500);

	int zw = ToInt(mZoneMgr->mActualZone.iW);
	int zh = ToInt(mZoneMgr->mActualZone.iH);

	int i=2, j, potentialNodes;
	if (addMorePossibleNodes)
		potentialNodes = 16;
	else
		potentialNodes = 8;
	bool noPath = false, originReached = false, unaccessible = false;
	float g, g1, g2, g3;
	int r=0, usefullNodes=0;
	Node* p = NULL; // Pointer to the parent node
	float f, h=0;
	int x, y;

	float precision1 = PRECISION;
	float precision2 = PRECISION*1.41f;
	float precision3 = PRECISION*2.24f;

	// actualNode : stores the adress of the node stored in node[x][y]
	Node* actualNode = NULL;

	// Create arays and maps
	__gnu_cxx::hash_map<int, Node> node; // used to get a node ID with its coordinates
	node.clear();
	Node* childNode[16] = {NULL};
	std::map<int, Node*> closed;
	std::multimap<float, Node*> opened;
	Node* bestOpenedNode = NULL;
	Node* closestNode = NULL;

	int yPRECISION = ToInt(PRECISION*mSceneMgr->fAspectRatio);

	if (debug)
	{
		Log("Trying to go from : x: %d, y: %d ; to : x: %d, y: %d", ToInt(xi), ToInt(yi), ToInt(destx), ToInt(desty));
	}

	// First, try to see if the path is wide open
	path.push_back(GetNearestAlignedFreePoint(ToInt(xi), ToInt(yi), ToInt(destx), ToInt(desty)));
	if (debug) {Log("Nearest : x : %f, y : %f", path.begin()->fX, path.begin()->fY);}
	// And if so, there is no need to build a path : just return the destination
	if ( (path.begin()->fX == destx) && (path.begin()->fY == desty) )
	{
		if (debug) {Log("No obstacle between destination and origin.\n No need to search for a path.");}
		return path;
	}

	x=ToInt(xi); y=ToInt(yi);

	p = &node[x/PRECISION+y/yPRECISION*zw/PRECISION];
	p->fX = x;
	p->fY = y;

	bool searching=true;

	while (searching)
	{
		g1 = p->fG+precision1;
		g2 = p->fG+precision2;
		g3 = p->fG+precision3;

		switch (r)
		{
			case 0:
				x+=PRECISION;
				g=g1;
				break;
			case 1:
				y-=yPRECISION;
				g=g2;
				break;
			case 2:
				x-=PRECISION;
				g=g1;
				break;
			case 3:
				x-=PRECISION;
				g=g2;
				break;
			case 4:
				y+=yPRECISION;
				g=g1;
				break;
			case 5:
				y+=yPRECISION;
				g=g2;
				break;
			case 6:
				x+=PRECISION;
				g=g1;
				break;
			case 7:
				x+=PRECISION;
				g=g2;
				break;
			case 8:
				x+=PRECISION;
				g=g3;
				break;
			case 9:
				y-=2*yPRECISION;
				g=g3;
				break;
			case 10:
				y-=yPRECISION;
				x-=PRECISION;
				g=g3;
				break;
			case 11:
				x-=2*yPRECISION;
				g=g3;
				break;
			case 12:
				x-=PRECISION;
				y+=yPRECISION;
				g=g3;
				break;
			case 13:
				y+=2*yPRECISION;
				g=g3;
				break;
			case 14:
				y+=yPRECISION;
				x+=PRECISION;
				g=g3;
				break;
			case 15:
				x+=2*PRECISION;
				g=g3;
				break;
		}

		actualNode = &node[x/PRECISION+y/yPRECISION*zw/PRECISION];
		actualNode->fX = x;
		actualNode->fY = y;

		if ( (fabs(destx-x)<PRECISION) && (fabs(desty-y)<yPRECISION) )
		{
			Point testPoint = GetNearestAlignedFreePoint(ToInt(p->fX), ToInt(p->fY), ToInt(destx), ToInt(desty));
			if (testPoint == Point(ToInt(destx), ToInt(desty)))
			{
				actualNode->fX = destx;
				actualNode->fY = desty;
				actualNode->mParent = p;
				if (debug)
				{
					Log("## : destination reached ! Building path...");
				}
				noPath = false;
				searching = false;
				break;
			}
			else if (debug)
			{
				Log("## : destination reached but not accessible...");
			}
		}

		// Check if it collides with something or if it's in the closed list
		if (!actualNode->bClosed)
		{
	   		if (!CheckPointCollision(x, y))
			{
				Point testPoint = GetNearestAlignedFreePoint(ToInt(p->fX), ToInt(p->fY), ToInt(x), ToInt(y));
				// If there is no obstacle between the parent node and the tested one...
				if (testPoint == Point(x, y))
				{
					// Calculate heuristic : two methods
					//  # Distance :
					//h = dist(x, y*mSceneMgr->fAspectRatio, destx, desty*mSceneMgr->fAspectRatio);
					//  # Manhattan :
					h = fabs(destx-x) + fabs(desty-y)*mSceneMgr->fAspectRatio;

					f = g + h;

					// If the node is aready opened...
					if (actualNode->bOpened)
					{
						// Check is its F is higher than the one found with the test node...
						if (f < actualNode->fF)
						{
							// ... and if so, change its parent and its F and G value
							actualNode->mParent = p;
							actualNode->fF = f;
							actualNode->fG = g;
							childNode[usefullNodes] = actualNode;
							if (debug)
							{
								Log(" #1 : actual node is to be changed, new child[%d] (f:%f) (%d, %d)", usefullNodes, childNode[usefullNodes]->fF, x, y);
							}
							usefullNodes += 1;
						}
						else
						{
							childNode[usefullNodes] = actualNode;
							if (debug)
							{
								Log(" #2 : actual node doesn't need to be changed, new child[%d] (f:%f)", usefullNodes, childNode[usefullNodes]->fF);
							}
							usefullNodes += 1;
						}
					}
					else // Else, it's the first time this node is visited
					{
						if (searchRange)
						{
							float distance = Dist
							(
								actualNode->fX, actualNode->fY*mSceneMgr->fAspectRatio,
								destx, desty*mSceneMgr->fAspectRatio
							);
							if (distance <= range)
							{
								actualNode->mParent = p;
								if (debug)
								{
									Log("## : range reached ! Building path...");
								}
								noPath = false;
								searching = false;
								break;
							}
						}

						actualNode->Set(x, y, p, f, g);
						actualNode->bOpened = true;
						actualNode->bClosed = false;
						actualNode->bWalkable = true;
						opened.insert(std::make_pair(f, actualNode));
						childNode[usefullNodes] = actualNode;
						if (debug)
						{
							Log(" #3 : new node found, new child[%d] (f:%f)", usefullNodes, childNode[usefullNodes]->fF);
						}
						usefullNodes += 1;
					}
				}
				else // Else the node is not accessible
				{
					if (debug)
					{
						Log(" #6 : unaccessible node");
					}
					potentialNodes -= 1;
				}
			}
			else // Else, the node is not walkable
			{
				if (debug)
				{
					Log(" #5 : unwalkable node");
				}
				potentialNodes -= 1;
			}
		}
		else // Else, it's a closed node
		{
			if (debug)
			{
				Log(" #4 : closed node");
			}
			potentialNodes -= 1;
		}


		// If the 8 nodes that surround the base node are useless...
		if (potentialNodes == 0)
		{
			// ...flag the base node as useless
			p->bUseless = true;
		}

		r++;

		// If we have parsed the 8 or 16 surrounding nodes...
		if ( (r==16 && (addMorePossibleNodes)) || ((!addMorePossibleNodes) && (r==8)) )
		{
			if (debug)
			{
				Log("## 1 : all surrounding nodes parsed");
			}

			// Use the opened list to find the best node...
			if (!opened.empty())
			{
				p = opened.begin()->second;
			}
			else
			{
				noPath = true;
				searching = false;
				break;
			}

			if (debug)
			{
				Log("## 6 : continue with node [%.0f, %.0f]", p->fX, p->fY);
			}
			x = ToInt(p->fX);
			y = ToInt(p->fY);
			p->bClosed = true;
			p->bOpened = false;
			opened.erase(opened.begin());

			// ... and we set some variables to their initial value, ready for another loop
			if (addMorePossibleNodes)
				potentialNodes = 16;
			else
				potentialNodes = 8;
			usefullNodes = 0;
			r = 0;
		}
		i++;
	}

	// If we have found a path...
	if (!noPath)
	{
		Node *temp, *prevNode;
		if (!searchRange)
			(*path.begin()) = Point(destx,desty);
		else
			(*path.begin()) = actualNode->GetPoint();

		temp = actualNode->mParent;

		if ( (temp == NULL) || (temp->mParent == NULL) )
		{
			if (debug) {Log("### : Path found (1 point) !");}
			return path;
		}

		// ... store nodes by moving from child to parent until we reach the origin
		std::vector<Point>::iterator iter = path.begin();
		iter++;
		while (!originReached)
		{
			if ( temp->mParent->GetPoint() == Point(xi, yi) )
			{
				path.push_back(temp->GetPoint());
				path.push_back(Point(xi, yi));
				originReached = true;
				break;
			}
			path.push_back(temp->GetPoint());
			prevNode = temp;
			temp = prevNode->mParent;
			iter++;
		}

		if (debug)
		{
			Log("### : Path found (%d points, %d visited nodes) !", path.size(), node.size());
		}
	}

	// And simplify the path
	if (path.size() > 1)
	{
		if (debug)
		{
			Log(" ");
			std::vector<Point>::iterator iter1;
			for (iter1 = path.begin(); iter1 != path.end(); iter1++)
			{
				Log(" %f, %f", iter1->fX, iter1->fY);
			}
			Log(" ");
		}

		path = SimplifyPath(path);

		if (debug)
		{
			std::vector<Point>::iterator iter2;
			for (iter2 = path.begin(); iter2 != path.end(); iter2++)
			{
				Log(" %f, %f", iter2->fX, iter2->fY);
			}
			Log(" ", iter2->fX, iter2->fY);
		}

		return path;
	}
	else
	{
		if (debug)
		{
			std::vector<Point>::iterator iter;
			for (iter = path.begin(); iter != path.end(); iter++)
			{
				Log(" %f, %f", iter->fX, iter->fY);
			}
		}

		return path;
	}
}

std::vector<Point> SimplifyPath( std::vector<Point> path )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "simplifyPath", false);
		Chrono c(prof);
	#endif
	/* [#] This function is used to reduce the number of point contained in a
	/* path returned by the above function.
	/* [#] The way it works is simple :
	/*  - Take a point as a base
	/*  - Look at the next point to see if it is reachable by going straight
	/* ahead and if so, check with the next point.
	/*  - When a point is not reachable, the previous point is stored in the new
	/* path and we go on this way until the final point is reached.
	/* [#] We also use the iteration to re-order the path in the right way (the
	/* path returned by the above function is to be followed from the end to the
	/* beggining).
	/* [#] When the first simplification is done, all useless points are removed.
	/* We then start another simplification to shorten the path even more.
	*/

	bool debug = false;

	// If the path is only composed of 2 points, there is nothing to simplify
	if (path.size()==2)
	{
		if (debug) {Log("Path can't be simplified", path.size());}
		return path;
	}

	std::vector<Point> newPath;
	std::vector<Point> tempPath;
	std::vector<Point>::iterator iter1, iter2;
	iter1 = path.end();
	iter1--;
	tempPath.push_back(*iter1); // The first point is not to be changed anyway
	bool intFound;
	bool lastPointReached = false;

	if (debug) {Log("path.size = %d", path.size());}
	if (debug) {Log("Simplification 1");}
	// First simplification
	while (!lastPointReached)
	{
		intFound = false;
		iter2 = iter1;
		if (debug) {Log(" iter2 = iter1 : (%f, %f)", iter2->fX, iter2->fY);}
		while (!intFound )
		{
			iter2--;
			if (debug) {Log("  iter2-- : (%f, %f)", iter2->fX, iter2->fY);}
			Point nearest = GetNearestAlignedFreePoint(ToInt(iter1->fX), ToInt(iter1->fY), ToInt(iter2->fX), ToInt(iter2->fY));
			if (nearest != *iter2)
			{
				if (debug) { if (nearest != *iter2) {Log("  # nearest != (*iter2) : (%f, %f)", nearest.fX, nearest.fY);}}
				iter1 = iter2;
				if (debug) {Log("	iter1 = iter2 : (%f, %f)", iter1->fX, iter1->fY);}
				iter1++;
				if (debug) {Log("	iter1++ : (%f, %f)", iter1->fX, iter1->fY);}
				intFound = true;
			}
			else
			{
				if (iter2 == path.begin())
				{
					if (debug) {Log("  # iter2 = path.begin()");}
					lastPointReached = true;
				}
			}
		}
		if (debug) {Log(" push iter1 : (%f, %f)", iter1->fX, iter1->fY);}
		tempPath.push_back(*iter1);
	}
	if (debug) {Log("push path.begin() : (%f, %f)", path.begin()->fX, path.begin()->fY);}

	if (debug)
	{
		Log(" ");
		std::vector<Point>::iterator iter3;
		for (iter3 = tempPath.begin(); iter3 != tempPath.end(); iter3++)
		{
			Log(" %f, %f", iter3->fX, iter3->fY);
		}
		Log(" ");
	}

	if (tempPath.size() > 2)
	{
		// Second simplification
		if (debug) {Log("tempPath.size = %d", tempPath.size());}
		lastPointReached = false;
		iter1 = tempPath.begin();
		if (debug) {Log(" ");}
		if (debug) {Log("Simplification 2");}

		while (!lastPointReached)
		{
			newPath.push_back(*iter1);
			if (debug) {Log(" push iter1 : (%f, %f)", iter1->fX, iter1->fY);}
			intFound = false;
			iter2 = iter1;
			if (debug) {Log(" iter2 = iter1 : (%f, %f)", iter2->fX, iter2->fY);}
			while (!intFound)
			{
				iter2++;
				if (debug) {Log("  iter2++ : (%f, %f)", iter2->fX, iter2->fY);}
				if (iter2 == tempPath.end())
				{
					if (debug) {Log("  # iter2 = tempPath.end()");}
					lastPointReached = true;
					iter2--;
					newPath.push_back(*iter2);
					break;
				}
				Point nearest = GetNearestAlignedFreePoint(ToInt(iter1->fX), ToInt(iter1->fY), ToInt(iter2->fX), ToInt(iter2->fY));
				if (nearest != (*iter2))
				{
					if (debug) {Log("  # nearest != (*iter2) : (%f, %f)", nearest.fX, nearest.fY);}
					iter1 = iter2;
					if (debug) {Log("	iter1 = iter2 : (%f, %f)", iter1->fX, iter1->fY);}
					iter1--;
					if (debug) {Log("	iter1-- : (%f, %f)", iter1->fX, iter1->fY);}
					intFound = true;
				}
				else
				{
					if (debug) {Log("  # nearest == (*iter2)");}
				}
			}
		}
		if (debug) {Log("newPath.size = %d", newPath.size());}
		if (debug) {Log(" ");}
		return newPath;
	}
	else
	{
		return tempPath;
	}
}

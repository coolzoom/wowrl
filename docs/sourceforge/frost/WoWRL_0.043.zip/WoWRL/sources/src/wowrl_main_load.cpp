/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_lua.h"
#include "wowrl_scenemanager.h"
#include "wowrl_unitmanager.h"
#include "wowrl_zonemanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_fontmanager.h"
#include "wowrl_modelmanager.h"
#include "wowrl_gfxmanager.h"

extern GUIManager *mGUIMgr;
extern SceneManager *mSceneMgr;
extern ZoneManager *mZoneMgr;
extern FontManager *mFontMgr;
extern GUIManager *mGUIMgr;
extern UnitManager *mUnitMgr;
extern ModelManager *mModelMgr;
extern GFXManager *mGFXMgr;
extern HGE* hge;

using namespace std;

bool LoadFrame()
{
    static string classes_file;
    static string effects_file;
    static string cursors_file;
    static string fonts_file;
    static int state1 = 1;
    static int state2 = 1;

    if (mSceneMgr->iLoaderState == 0)
    {
        mGUIMgr->Init();

        int error = luaL_dofile(mSceneMgr->luaVM, "Tables/def_table.lua");
        if (error) LUA::LogL(mSceneMgr->luaVM);

        Log("Parsing Scripts/config.lua...");
        mZoneMgr->mActualZone.sName = LUA::GetGlobalString("Files_starting_zone");

        mSceneMgr->fAspectRatio = 1.0f/LUA::GetGlobalFloat("Game_aspect_ratio");
        mSceneMgr->fInCombatTimer = LUA::GetGlobalFloat("Game_out_of_combat_timer");
        mSceneMgr->fRegenTimer = LUA::GetGlobalFloat("Game_regen_tick");
        mSceneMgr->iMaxComputedPaths = LUA::GetGlobalInt("Game_max_computed_path");

        mGUIMgr->bShowStatusBars = LUA::GetGlobalBool("UI_show_status_bars");
        mGUIMgr->bShowEnemiesStatusBars = LUA::GetGlobalBool("UI_show_enemies_status_bars");
        mGUIMgr->fScrollingTextMaxLife = LUA::GetGlobalFloat("UI_scrolling_texts_duration");
        mGUIMgr->fScrollingTextSpeed = LUA::GetGlobalFloat("UI_scrolling_texts_speed");
        mGUIMgr->bScrollingTextFade = LUA::GetGlobalBool("UI_scrolling_texts_fade");
        mGUIMgr->fErrorTextsDuration = LUA::GetGlobalFloat("UI_error_texts_duration");
        mGUIMgr->fErrorTextsFadeDelay = LUA::GetGlobalFloat("UI_error_texts_fade_delay");

        Log("Parsing Scripts/config.lua : done.\n");

        string fnt = LUA::GetGlobalString("Fonts_default_font");
        mGUIMgr->mDefaultFont = mFontMgr->GetFont(true, fnt, 15, false, false);
        if (mGUIMgr->mDefaultFont == NULL) {Log("# Error # : missing default font...");}
        mGUIMgr->mScrollingTextFont = mFontMgr->GetFont(true, fnt, 16, true, false); // outlined
        mGUIMgr->mErrorFont = mFontMgr->GetFont(true, fnt, 18, true, false); // outlined
        mFontMgr->mSystemFont = mGUIMgr->mScrollingTextFont;

        mGUIMgr->mLoadingBar.Init();

        mSceneMgr->bJumpToNextState = true;
        mGUIMgr->mLoadingBar.fFilling += 0.05f;
        mGUIMgr->mLoadingBar.sCaption = mSceneMgr->tStrTable->GetString("gui_loading_zone");
    }
    else if (mSceneMgr->iLoaderState == 1)
    {
        bool finished, state;
        state = mZoneMgr->ParseZoneDyn(mSceneMgr->luaVM, state1, state2, &finished, 0.35f);
        if (finished)
        {
            mSceneMgr->bJumpToNextState = true;
            mGUIMgr->mLoadingBar.sCaption = mSceneMgr->tStrTable->GetString("gui_loading_cursors");
            state1 = 1;
            state2 = 1;
        }
        else
        {
            if (state)
            {
                state1++;
                state2 = 1;
            }
            else
                state2++;
        }
    }
    else if (mSceneMgr->iLoaderState == 2)
    {
        mGUIMgr->ParseCursors(mSceneMgr->luaVM);
        mSceneMgr->bJumpToNextState = true;
        mGUIMgr->mLoadingBar.fFilling += 0.05f;
        mGUIMgr->mLoadingBar.sCaption = mSceneMgr->tStrTable->GetString("gui_loading_classes");
    }
    else if (mSceneMgr->iLoaderState == 3)
    {
        bool finished, state;
        state = mUnitMgr->ParseClassesDyn(mSceneMgr->luaVM, state1, &finished, 0.05f);
        if (finished)
        {
            mSceneMgr->bJumpToNextState = true;
            mGUIMgr->mLoadingBar.sCaption = mSceneMgr->tStrTable->GetString("gui_loading_models");
            state1 = 1;
            state2 = 0;
        }
        else
        {
            if (state)
                state1++;
        }
    }
    else if (mSceneMgr->iLoaderState == 4)
    {
        bool finished = true;
        bool state;
        //state = mGFXMgr->ParseAnimationsDyn(mSceneMgr->luaVM, state1, state2, &finished, 0.3f);
        state = mModelMgr->ParseModelsDyn(mSceneMgr->luaVM, state1, state2, &finished, 0.3f);
        if (finished)
        {
            mSceneMgr->bJumpToNextState = true;
            mGUIMgr->mLoadingBar.sCaption = mSceneMgr->tStrTable->GetString("gui_loading_effects");
            state1 = 1;
            state2 = 1;
        }
        else
        {
            if (state)
            {
                state1++;
                state2 = 0;
            }
            else
                state2++;
        }
    }
    else if (mSceneMgr->iLoaderState == 5)
    {
        mGFXMgr->ParseEffects(mSceneMgr->luaVM);
        mSceneMgr->bJumpToNextState = true;
        mGUIMgr->mLoadingBar.fFilling += 0.15f;
        mGUIMgr->mLoadingBar.sCaption = mSceneMgr->tStrTable->GetString("gui_loading_ui");
    }
    else if (mSceneMgr->iLoaderState == 6)
    {
        // Create sprites
        Log("Creating system data...");
        HTEXTURE px_tex = mGFXMgr->LoadTexture("pixel.png");
        mGFXMgr->pixel = mGFXMgr->CreateSprite(px_tex,0,0,1,1);

        // Create the screen BBs
        mSceneMgr->mScreenLRect = mGFXMgr->CreateRect(0, 0, 6, mGFXMgr->iSHeight);
        mSceneMgr->mScreenTRect = mGFXMgr->CreateRect(0, 0, mGFXMgr->iSWidth, 6);
        mSceneMgr->mScreenRRect = mGFXMgr->CreateRect(mGFXMgr->iSWidth-6, 0, mGFXMgr->iSWidth, mGFXMgr->iSHeight);
        mSceneMgr->mScreenBRect = mGFXMgr->CreateRect(0, mGFXMgr->iSHeight-6, mGFXMgr->iSWidth, mGFXMgr->iSHeight);
        mGFXMgr->mScrRect = mGFXMgr->CreateRect(0, 0, mGFXMgr->iSWidth, mGFXMgr->iSHeight);

        // Choose the cursor
        mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal");

        Log("Creating system data : done.");

        // Reading tables
        Log("Reading tables...");
        mUnitMgr->tLevelToHealth = new hgeStringTable("Tables/lvl_health.tbl");
        mUnitMgr->tLevelToMana = new hgeStringTable("Tables/lvl_mana.tbl");
        mUnitMgr->tLevelToXPNeeded = new hgeStringTable("Tables/lvl_xp_needed.tbl");
        Log("Reading tables : done.");

        Log("Creating units...");

        // Run the initialization script
        int error = luaL_dofile(mSceneMgr->luaVM, "Scripts/init.lua");
        if (error) LUA::LogL(mSceneMgr->luaVM);

        Log("Creating units : done.");

        mGFXMgr->UpdateVertexBuffer();

        // Load the UI
        Log("Loading UI...");
        mGUIMgr->LoadUI(mSceneMgr->luaVM);
        Log("Loading UI : done.");

        mSceneMgr->bJumpToNextState = true;
        mGUIMgr->mLoadingBar.fFilling += 0.05f;
    }
    else if (mSceneMgr->iLoaderState == 7)
    {
        Log("Now playing !\n");
        mSceneMgr->iGameState = GAME_STATE_GAME;
        hge->System_SetState(HGE_FPS, mGFXMgr->iMaxFPS);
    }

    if (mSceneMgr->bJumpToNextState)
    {
        mSceneMgr->bJumpToNextState = false;
        mSceneMgr->iLoaderState++;
    }

    return false;
}

bool LoadRender()
{
    mGFXMgr->Prepare2D();
    // Begin rendering.
    hge->Gfx_BeginScene();
    mGUIMgr->mLoadingBackground->RenderStretch(0, 0, mGFXMgr->iSWidth, mGFXMgr->iSHeight);
    mGUIMgr->mLoadingBar.Render();

    hge->Gfx_EndScene();

    return false;
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          Scene manager source          */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the SceneManager class.            */
/*       A SceneManager is obviously a    */
/*  class that manages the scene and its  */
/*  components (units, background ...)    */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_global.h"
#include "wowrl_pathfinding.h"
#include "wowrl_lua.h"
#include "wowrl_guimanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_zonemanager.h"
#include "wowrl_unit.h"
#include "wowrl_item.h"

#include "wowrl_scenemanager.h"

extern HGE *hge;
extern GUIManager *mGUIMgr;
extern TimeManager *mTimeMgr;
extern GFXManager *mGFXMgr;
extern InputManager *mInputMgr;
extern ZoneManager *mZoneMgr;

using namespace std;

SceneManager::SceneManager()
{
	sLog = "|t";

	fsFile.open("WoWRL2.log", ios::trunc);

	iLoaderState = 0;
	bJumpToNextState = false;

	mBgRect = new hgeRect();
	fPanSpeed = 500.0f;
	fDX = 0.0f; fDY = 0.0f;
	fDGX = 0.0f; fDGY = 0.0f;

	bPanning = false;
	bMouseOverPlayField = true;

	bGamePaused = false;

	bDebugParser = false;
}

SceneManager::~SceneManager()
{
    mSceneMgr = NULL;
}

SceneManager* SceneManager::mSceneMgr = NULL;

SceneManager* SceneManager::GetSingleton()
{
	if (mSceneMgr == NULL)
		mSceneMgr = new SceneManager;
	return mSceneMgr;
}

void SceneManager::DeleteThis()
{
	//fsFile.close();
	map<int, Item*>::iterator iterItem;
	while (!lItemList.empty())
	{
		iterItem = lItemList.begin();
		delete iterItem->second;
		lItemList.erase(iterItem);
	}
}

Item* SceneManager::ParseItem( int item_id )
{
	if (lItemList.find(item_id) == lItemList.end())
	{
		if (this->bDebugParser) Log(" Parsing item %d...", item_id);

		lua_getglobal(luaVM, "Items");
		lua_rawgeti(luaVM, -1, item_id);

		Item* item;
		int iType = LUA::GetFieldInt("type", false, -1);

		if ( (iType == ITEM_TYPE_ARMOR) || (iType == ITEM_TYPE_TABARD) || (iType == ITEM_TYPE_OFFHAND) )
		{
		    Armor* a = new Armor();
		    a->iDurabilityMax = 0;
            a->iDurabilityCur = 0;
            a->mBonus.Clear();
		    item = a;
		}
		else if (iType == ITEM_TYPE_SHIELD)
		{
		    Shield* s = new Shield();
		    s->iDurabilityMax = 0;
            s->iDurabilityCur = 0;
            s->mBonus.Clear();
		    item = s;
		}
		else if (iType == ITEM_TYPE_WEAPON)
		{
		    Weapon* w = new Weapon();
		    w->iDurabilityMax = 0;
            w->iDurabilityCur = 0;
            w->mBonus.Clear();
		    item = w;
		}
		else if (iType == ITEM_TYPE_BAG)
		{
		    Bag* b = new Bag();
		    item = b;
		}
		else if ( (iType == ITEM_TYPE_CONS) || (iType == ITEM_TYPE_JEWELRY) )
		{
		    Consumable* c = new Consumable();
		    c->iCharges = LUA::GetFieldInt("charges", false, -1);
		    item = c;
		}
		else
		{
		    Item* i = new Item();
		    item = i;
		}

        item->iID = item_id;
        item->iType = iType;
        item->iQuality = LUA::GetFieldInt("quality", false, 0);
        item->iBinds = LUA::GetFieldInt("binds", false, 0);
        item->iReqLevel = LUA::GetFieldInt("requieres_lvl", false, 0);
        item->iUnique = LUA::GetFieldInt("unique", false, 0);
        item->bSellable = LUA::GetFieldBool("sellable", false, false);
        if (item->bSellable)
        {
            item->iSellPrice = LUA::GetFieldInt("sell_price", false, 0);
            item->iBuyPrice = LUA::GetFieldInt("buy_price", false, 0);
        }
        item->bSoulbound = false;
        item->mOnEquip = NULL;
        item->mOnUse = NULL;
        item->mOnHit = NULL;
		item->iReqClass = -1;
		item->sReqSkill = "";
		item->sReqSkillLevel = 0;
		item->fCooldown = 0.0f;

		lua_pop(luaVM, 2);

		lItemList[item_id] = item;

		return item;
	}
	else
		return lItemList[item_id];
}

void SceneManager::RequestWPPath( Unit* u )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "SceneManager::requestWPPath", false);
		Chrono c(prof);
	#endif
	if (u->pDestPoint == Point(u->GetGX(), u->GetGY()))
	{
		u->iWaypointIndice == -1;
		u->bOrderGiven = true;
		u->bFollowing = true;
		vector<Point> path;
		path.push_back(u->pDestPoint);
		u->lPath = path;
		if (u->iOrder != MOVEMENT_LEASHING)
			u->iOrder = MOVEMENT_MOVE;
	}
	float index = hge->Timer_GetTime();
	while (this->lRequestWPList.find(index) != this->lRequestWPList.end())
	{
		index += 0.001;
	}
	this->lRequestWPList[index] = u;
	u->fPlaceInWPQueue = index;
}

void SceneManager::BuildWPPaths()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "SceneManager::buildWPPaths", false);
		Chrono c(prof);
	#endif
	if (!this->lRequestWPList.empty())
	{
		int pathBuilded = 0;
		map<float, Unit*>::iterator iter = this->lRequestWPList.begin();
		while (pathBuilded < iMaxComputedPaths)
		{
			Unit* u = iter->second;
			if (u->fPlaceInWPQueue == iter->first)
			{
				u->lWPath = GetWaypoints
				(
					ToInt(u->GetGX()),
					ToInt(u->GetGY()),
					ToInt(u->pDestPoint.fX),
					ToInt(u->pDestPoint.fY)
				);
				u->bOrderGiven = true;

				pathBuilded++;

				this->lRequestWPList.erase(iter);
				iter = this->lRequestWPList.begin();
			}
			if (iter == this->lRequestWPList.end())
				break;
		}
	}
}

void SceneManager::RequestPath( Unit* u )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "SceneManager::requestPath", false);
		Chrono c(prof);
	#endif
	float index = hge->Timer_GetTime();
	while (this->lRequestList.find(index) != this->lRequestList.end())
	{
		index += 0.001;
	}
	this->lRequestList[index] = u;
	u->fPlaceInQueue = index;
	u->bPathRequested = true;
	u->bPathObtained = false;
}

void SceneManager::BuildPaths()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "SceneManager::buildPaths", false);
		Chrono c(prof);
	#endif
	if (!this->lRequestList.empty())
	{
		int pathBuilded = 0;
		map<float, Unit*>::iterator iter = this->lRequestList.begin();
		while (pathBuilded < iMaxComputedPaths)
		{
			Unit* u = iter->second;
			if (u->fPlaceInQueue == iter->first)
			{
				vector<Point>::iterator iter2 = u->lWPath.begin();
				for (int i=0; i < u->iWaypointIndice; i++)
				{
					iter2++;
				}
				if (iter2->fSize != 0.0f)
				{
					float ySize = iter2->fSize/1.6f;
					float randomY = hge->Random_Float(-ySize, ySize);
					float randomX = hge->Random_Float(-iter2->fSize, iter2->fSize)*sin(randomY/ySize);
					u->lPath = GetShortestPath
					(
						ToInt(u->GetGX()),
						ToInt(u->GetGY()),
						ToInt(iter2->fX+randomX),
						ToInt(iter2->fY+randomY)
					);
				}
				else
				{
					u->lPath = GetShortestPath
					(
						ToInt(u->GetGX()),
						ToInt(u->GetGY()),
						ToInt(iter2->fX),
						ToInt(iter2->fY)
					);
				}

				u->bPathRequested = false;
				u->bPathObtained = true;
				this->lRequestList.erase(iter);
				iter = this->lRequestList.begin();
				pathBuilded++;
			}
			if (iter == this->lRequestList.end())
				break;
		}
	}
}

void SceneManager::RequestDirectPath( Unit* u )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "SceneManager::requestDirectPath", false);
		Chrono c(prof);
	#endif
	float index = hge->Timer_GetTime();
	while (this->lRequestDList.find(index) != this->lRequestDList.end())
	{
		index += 0.001;
	}
	this->lRequestDList[index] = u;
	u->fPlaceInDQueue = index;
	u->bPathRequested = true;
	u->bPathObtained = false;
}

void SceneManager::BuildDirectPaths()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "SceneManager::buildDirectPaths", false);
		Chrono c(prof);
	#endif
	if (!this->lRequestDList.empty())
	{
		int pathBuilded = 0;
		map<float, Unit*>::iterator iter = this->lRequestDList.begin();
		while (pathBuilded < iMaxComputedPaths)
		{
			Unit* u = iter->second;
			if (u->fPlaceInDQueue == iter->first)
			{
				u->lPath = GetShortestPath
				(
					ToInt(u->GetGX()),
					ToInt(u->GetGY()),
					ToInt(u->pDestPoint.fX),
					ToInt(u->pDestPoint.fY)
				);
				u->bPathRequested = false;
				u->bPathObtained = true;
				this->lRequestDList.erase(iter);
				iter = this->lRequestDList.begin();
				pathBuilded++;
			}
			if (iter == this->lRequestDList.end())
				break;
		}
	}
}

void SceneManager::Update()
{
	// Reset variation
	mSceneMgr->fDX = 0;
	mSceneMgr->fDY = 0;

	// If the mouse enters a 4 pixel zone around the screen, pan the view in the direction
	// given by the mouse pointer
	bool mouseLInt = mScreenLRect->TestPoint(mInputMgr->fMX, mInputMgr->fMY);
	bool mouseTInt = mScreenTRect->TestPoint(mInputMgr->fMX, mInputMgr->fMY);
	bool mouseRInt = mScreenRRect->TestPoint(mInputMgr->fMX, mInputMgr->fMY);
	bool mouseBInt = mScreenBRect->TestPoint(mInputMgr->fMX, mInputMgr->fMY);

	if (mouseLInt || mouseTInt || mouseRInt || mouseBInt)
	{
		mGUIMgr->mCursor = mGUIMgr->SwitchCursor("pan");
		mGUIMgr->mCursor->fRot = -1.0f;
		if (mouseLInt && !(mouseTInt && mouseRInt && mouseBInt))
		{
			mGUIMgr->mCursor->fRot = M_PI;
			fDX = fPanSpeed*mTimeMgr->GetDelta();
		}
		if (mouseTInt && !(mouseLInt && mouseRInt && mouseBInt))
		{
			if (mGUIMgr->mCursor->fRot == -1.0f)
				mGUIMgr->mCursor->fRot = 3*M_PI_2;
			else
				mGUIMgr->mCursor->fRot = (mGUIMgr->mCursor->fRot+3*M_PI_2)/2.0f;
			fDY = fPanSpeed*mTimeMgr->GetDelta();
		}
		if (mouseRInt && !(mouseLInt && mouseTInt && mouseBInt))
		{
			if (mGUIMgr->mCursor->fRot == -1.0f)
				mGUIMgr->mCursor->fRot = 0.0f;
			else
				mGUIMgr->mCursor->fRot = -M_PI_2/2.0f;
			fDX = -fPanSpeed*mTimeMgr->GetDelta();
		}
		if (mouseBInt && !(mouseLInt && mouseTInt && mouseRInt))
		{
			if (mGUIMgr->mCursor->fRot == -1.0f)
				mGUIMgr->mCursor->fRot = M_PI_2;
			else
				mGUIMgr->mCursor->fRot = (mGUIMgr->mCursor->fRot+M_PI_2)/2.0f;
			fDY = -fPanSpeed*mTimeMgr->GetDelta();
		}
		bPanning = true;
	}
	else
	{
		if (bPanning)
		{
			mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal");
			bPanning = false;
		}
	}

	fGX += fDX;
	fGY += fDY;
	fDGX = fDX;
	fDGY = fDY;

	// Detect loss of intersections between screen BBs and the background
	mBgRect->x1 = fGX+6;
	mBgRect->y1 = fGY+6;
	mBgRect->x2 = fGX+mZoneMgr->mActualZone.iW-6;
	mBgRect->y2 = fGY+mZoneMgr->mActualZone.iH-6;
	bScreenLInt = mBgRect->Intersect(mScreenLRect);
	bScreenTInt = mBgRect->Intersect(mScreenTRect);
	bScreenRInt = mBgRect->Intersect(mScreenRRect);
	bScreenBInt = mBgRect->Intersect(mScreenBRect);

	// If the background goes away from a screen bounding boxes, discard the previous changes
	if (!bScreenLInt)
	{
		fGX -= fDX;
		fDX = 0;
	}
	if (!bScreenTInt)
	{
		fGY -= fDY;
		fDY = 0;
	}
	if (!bScreenRInt)
	{
		fGX -= fDX;
		fDX = 0;
	}
	if (!bScreenBInt)
	{
		fGY -= fDY;
		fDY = 0;
	}

	mInputMgr->SetGlobalDisplacement(fGX, fGY);
}

void SceneManager::LogString( string baseStr, ... )
{
	va_list args;
	va_start(args, baseStr);
	char buffer[baseStr.length()+sizeof(args)];
	vsprintf(buffer, (mTimeMgr->GetPlayTime() + " : " + baseStr).c_str(), args);
	va_end(args);

	sLog += buffer;
	sLog += '\n';
	/*fsFile.open("WoWRL2.log", ios::app);
	fsFile << buffer;
	fsFile << '\n';
	fsFile.close();*/
}

void SceneManager::PrintLog()
{
	Log("|t\n");
	Log("## String Log : ##");
	Log(sLog);
}


/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"

#include "wowrl_lightmanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_lua.h"
#include "wowrl_model.h"
#include "wowrl_modelmanager.h"

using namespace std;

extern ModelManager* mModelMgr;
extern LightManager* mLightMgr;
extern HGE* hge;

void GFXManager::SetSceneMatrices()
{
    D3DXMatrixLookAtLH(&mViewMat,
                       &D3DXVECTOR3(5.0f, 6.0f, 0.0f),    // camera position
                       &D3DXVECTOR3(0.0f, 0.0f, 0.0f),    // look-at
                       &D3DXVECTOR3(0.0f, 1.0f, 0.0f));   // up direction

    float zoom = 3.0f;
    D3DXMatrixOrthoLH(&mProjectionMat,
                      zoom*(256.0f/256.0f),
                      zoom,
                      1.0f,
                      50.0f);

    UpdateVertexShader(NULL, -2);

    mViewProjMat = mViewMat * mProjectionMat;

    D3DXMatrixViewport(&mViewport);
}

void GFXManager::Prepare3D()
{
    //hge->System_SetState(HGE_ZBUFFER, true);
    mDxDevice->SetVertexDeclaration(mVertexDecl);
    mDxDevice->SetVertexShader(mVertexShader);
    mDxDevice->SetPixelShader(mPixelShader);
    mDxDevice->SetSoftwareVertexProcessing(false);

    mDxDevice->SetStreamSource(0, mVertexBuffer, 0, sizeof(Vertex));

    mCurrentTexture = 0;
}

void GFXManager::Prepare2D()
{
    //hge->System_SetState(HGE_ZBUFFER, false);
    hge->Gfx_Set2D();
}

/*int GFXManager::AddTriangle(Triangle t)
{
    lGlobalTriangleList.push_back(t);
    return lGlobalTriangleList.size()-1;
}

Triangle* GFXManager::GetTriangle(int i)
{
    if (i <= lGlobalTriangleList.size())
        return &lGlobalTriangleList[i];
    else
        return NULL;
}*/

void GFXManager::SetTexture( LPDIRECT3DTEXTURE9 tex )
{
    if (tex != mCurrentTexture)
    {
        mDxDevice->SetTexture(0, tex);
        mCurrentTexture = tex;
    }
}

void GFXManager::UpdateVertexBuffer()
{
    if (mVertexBuffer != NULL)
    {
        mVertexBuffer->Release();
        mVertexBuffer = NULL;
    }

    if (mModelMgr->iVertexNbr > 0)
    {
        mGFXMgr->mDxDevice->CreateVertexBuffer(mModelMgr->iVertexNbr*sizeof(Vertex),
                                               0,
                                               VERTEX_FVF,
                                               D3DPOOL_MANAGED,
                                               &mVertexBuffer,
                                               NULL);

        if (mVertexBuffer != NULL)
        {
            VOID* pVoid;

            // Lock the buffer and load the vertices into it
            mVertexBuffer->Lock(0, 0, (void**)&pVoid, 0);
            memcpy(pVoid, mModelMgr->lVertexList, mModelMgr->iVertexNbr*sizeof(Vertex));
            mVertexBuffer->Unlock();
        }

        delete[] mModelMgr->lVertexList;
        mModelMgr->lVertexList = NULL;
    }
    else
        mGFXMgr->mDxDevice->CreateVertexBuffer(sizeof(Vertex),
                                               0,
                                               VERTEX_FVF,
                                               D3DPOOL_MANAGED,
                                               &mVertexBuffer,
                                               NULL);
}

void GFXManager::CreateVertexShader()
{
    LPD3DXBUFFER pCode = NULL;
    LPD3DXBUFFER pErrors = NULL;

    // Assemble the vertex shader
    D3DXCompileShaderFromFile(
        "Shaders\\vertex_3d.vsh",
        NULL, NULL,
        "main", "vs_2_0",
        0,
        &pCode,
        &pErrors,
        &mVSConstantTable
    );

    if (pErrors != NULL)
    {
        Log("Error :\n%s", (char*)pErrors->GetBufferPointer());
        pErrors->Release();
        pErrors = NULL;
    }
    else
    {
        D3DVERTEXELEMENT9 decl[] =
        {
            {0, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
            {0, 3*sizeof(float), D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_BLENDWEIGHT, 0},
            {0, 7*sizeof(float), D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_BLENDINDICES, 0},
            {0, 11*sizeof(float), D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
            D3DDECL_END()
        };

        mDxDevice->CreateVertexDeclaration(decl, &mVertexDecl);
        mDxDevice->CreateVertexShader((DWORD*)pCode->GetBufferPointer(), &mVertexShader);

        mVSCWorldViewProj = mVSConstantTable->GetConstantByName(NULL, "mWorldViewProj");
        //mVSCWorld = mVSConstantTable->GetConstantByName(NULL, "mWorld");
        mVSCBoneMat = mVSConstantTable->GetConstantByName(NULL, "mBoneMat");
        //mVSCMeshID = mVSConstantTable->GetConstantByName(NULL, "mMeshID");

        //hge->Gfx_SetVertexShader("Shaders\\vertex_2d.vsh");
    }

    pCode->Release();
    pCode = NULL;
}

void GFXManager::UpdateVertexShader( Model* m, int group )
{
    if (group == -2)
    {
        // Updates to do only once per frame
        // Set ambient light
        D3DXVECTOR4 mLightAmbient;
        Vector3 amb = mLightMgr->GetAmbient();
        mLightAmbient.x = amb.x/255;
        mLightAmbient.y = amb.y/255;
        mLightAmbient.z = amb.z/255;
        mLightAmbient.w = 1.0f;
        mPSConstantTable->SetVector(mGFXMgr->mDxDevice, mPSCLightAmbient, &mLightAmbient);
    }
    if (group == -1 || group == 0)
    {
        D3DXMATRIXA16 mWorldViewProjMat = mWorldMat * mViewProjMat;
        mVSConstantTable->SetMatrix(mGFXMgr->mDxDevice, mVSCWorldViewProj, &mWorldViewProjMat);
        //mVSConstantTable->SetMatrix(mGFXMgr->mDxDevice, mVSCWorld, &mWorldMat);
    }
    /*if (group == -1 || group == 1)
    {
        // Update lights for this model
        if (m != NULL)
        {
            vector<D3DLIGHT9> lLightList = mLightMgr->GetLights(m->GetPosition());

            int*         mLightType = new int[4];
            D3DXVECTOR4* mLightColor = new D3DXVECTOR4[4];

            D3DXVECTOR4* mLightPos = new D3DXVECTOR4[4];
            D3DXVECTOR4* mLightAttenFactors = new D3DXVECTOR4[4];

            vector<D3DLIGHT9>::iterator iterLight = lLightList.begin();
            for (int i = 0; i < 4; i++, iterLight++)
            {
                D3DLIGHT9* l = &(*iterLight);

                if (l->Type == 0)
                {
                    mLightType[i] = 0;
                }
                else
                {
                    mLightType[i] = l->Type;
                    mLightColor[i].x = l->Diffuse.r;
                    mLightColor[i].y = l->Diffuse.g;
                    mLightColor[i].z = l->Diffuse.b;
                    mLightColor[i].w = l->Diffuse.a;
                    mLightPos[i].x = l->Position.x;
                    mLightPos[i].y = l->Position.y;
                    mLightPos[i].z = l->Position.z;
                    mLightPos[i].w = 1;
                    mLightAttenFactors[i].x = l->Attenuation0;
                    mLightAttenFactors[i].y = l->Attenuation1;
                    mLightAttenFactors[i].z = l->Attenuation2;
                    mLightAttenFactors[i].w = 1;
                }
            }

            mPSConstantTable->SetIntArray(mGFXMgr->mDxDevice, mPSCLightType, mLightType, 4);
            mPSConstantTable->SetVectorArray(mGFXMgr->mDxDevice, mPSCLightColor, mLightColor, 4);
            mPSConstantTable->SetVectorArray(mGFXMgr->mDxDevice, mPSCLightPos, mLightPos, 4);
            mPSConstantTable->SetVectorArray(mGFXMgr->mDxDevice, mPSCLightAttenFactors, mLightAttenFactors, 4);

            delete[] mLightType;
            delete[] mLightColor;
            delete[] mLightPos;
            delete[] mLightAttenFactors;
        }
    }*/
}

void GFXManager::CreatePixelShader()
{
    LPD3DXBUFFER pCode = NULL;
    LPD3DXBUFFER pErrors = NULL;

    // Assemble the pixel shader
    D3DXCompileShaderFromFile(
        "Shaders\\pixel_3d.psh",
        NULL, NULL,
        "main", "ps_2_0",
        0,
        &pCode,
        &pErrors,
        &mPSConstantTable
    );

    if (pErrors != NULL)
    {
        Log("Error :\n%s", (char*)pErrors->GetBufferPointer());
        pErrors->Release();
        pErrors = NULL;
    }
    else
    {
        mDxDevice->CreatePixelShader((DWORD*)pCode->GetBufferPointer(), &mPixelShader);

        mPSCLightAmbient = mPSConstantTable->GetConstantByName(NULL, "mLightAmbient");
        /*mPSCLightType = mPSConstantTable->GetConstantByName(NULL, "mLightType");
        mPSCLightColor = mPSConstantTable->GetConstantByName(NULL, "mLightColor");
        mPSCLightPos = mPSConstantTable->GetConstantByName(NULL, "mLightPos");
        mPSCLightAttenFactors = mPSConstantTable->GetConstantByName(NULL, "mLightAttenFactors");*/

        //hge->Gfx_SetPixelShader("Shaders\\pixel_2d.psh");
    }

    pCode->Release();
    pCode = NULL;
}

void GFXManager::SetWorldMatrix(D3DXMATRIX mat)
{
    mWorldMat = mat;
}

void GFXManager::SetViewMatrix(D3DXMATRIX mat)
{
    mViewMat = mat;
    mViewProjMat = mViewMat * mProjectionMat;
}

void GFXManager::SetProjectionMatrix(D3DXMATRIX mat)
{
    mProjectionMat = mat;
    mViewProjMat = mViewMat * mProjectionMat;
}

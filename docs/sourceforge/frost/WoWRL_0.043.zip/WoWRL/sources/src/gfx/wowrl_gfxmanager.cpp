/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            GFXManager source           */
/*                                        */
/*  ## : This class contains all graphics */
/*  related function and lists.           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_global.h"
#include "wowrl_structs.h"
#include "wowrl_unitmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_zonemanager.h"
#include "wowrl_scenemanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_timemanager.h"
#include "wowrl_lua.h"
#include "wowrl_model.h"

#include "wowrl_gfxmanager.h"

using namespace std;

extern UnitManager *mUnitMgr;
extern GUIManager *mGUIMgr;
extern ZoneManager *mZoneMgr;
extern SceneManager *mSceneMgr;
extern InputManager *mInputMgr;
extern TimeManager *mTimeMgr;
extern HGE *hge;

GFXManager::GFXManager()
{
	bDebugParser = false;
	bDebugRenderList = false;
	bForceUpdate = true;

    mVertexBuffer = NULL;
    mVSConstantTable = NULL;
    mPSConstantTable = NULL;
    mVertexShader = NULL;
    mVertexDecl = NULL;
    mPixelShader = NULL;

    mCurrentTexture = NULL;
}

GFXManager* GFXManager::mGFXMgr = NULL;

GFXManager* GFXManager::GetSingleton()
{
	if (mGFXMgr == NULL)
		mGFXMgr = new GFXManager;
	return mGFXMgr;
}

GFXManager::~GFXManager()
{
    if (mVertexBuffer != NULL)
        mVertexBuffer->Release();

    if (mVSConstantTable != NULL)
        mVSConstantTable->Release();

    if (mPSConstantTable != NULL)
        mPSConstantTable->Release();

    if (mVertexShader != NULL)
        mVertexShader->Release();

    if (mVertexDecl != NULL)
        mVertexDecl->Release();

    if (mPixelShader != NULL)
        mPixelShader->Release();

    mGFXMgr = NULL;
}

/*bool GFXManager::ParseAnimationsDyn( lua_State *luaVM, int state1, int state2, bool* finished, float filling )
{
	static map<string, Class>::iterator iterC = mUnitMgr->lClasseList.begin();
	static PAnim anim;
	static int anim_nbr = 0;

	if (state1 == 1)
	{
		Log("Parsing Tables/animset_table.lua...");
		int error = luaL_dofile(luaVM,"Tables/animset_table.lua");
		if (error) LUA::LogL(luaVM);

		lua_getglobal(luaVM, "AnimSets");

		*finished = false;
		return true;
	}
	else
	{
		if (state2 == 0)
		{
			Class* c = &iterC->second;
			if (this->bDebugParser) Log("  Loading %s's animset...", c->sName.c_str());
			lua_getfield(luaVM, -1, c->sAnimSetName.c_str());
			c->fScale = LUA::GetFieldFloat("scale", false, 1.0f);
			c->fShadowScale = LUA::GetFieldFloat("shadow_scale", false, 1.0f);
			c->fStatusBarSize = LUA::GetFieldFloat("status_bar_size");
			c->fStatusBarYOffset = LUA::GetFieldFloat("status_bar_y_offset");

			if (lPAnimList.find(c->sAnimSetName) != lPAnimList.end())
			{
				lua_pop(luaVM, 1);
				mGUIMgr->mLoadingBar.fFilling += filling/mUnitMgr->lClasseList.size();
				iterC++;
				if (iterC == mUnitMgr->lClasseList.end())
				{
					Log("Parsing Tables/animset_table.lua : done.");
					lua_pop(luaVM, 1);
					*finished = true;
					return true;
				}
				else
				{
					*finished = false;
					return true;
				}
			}

			anim.sName = c->sAnimSetName;

			lua_getfield(luaVM, -1, "states");

			anim_nbr = 0;
			for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
			{
				anim_nbr++;
			}

			lua_pushnil(luaVM);

			*finished = false;
			return false;
		}
		else
		{
			if (!lua_next(luaVM, -2))
			{
				lPAnimList[iterC->second.sAnimSetName] = anim;
				anim.lAnimations.clear();

				lua_pop(luaVM, 2);

				iterC++;
				if (iterC == mUnitMgr->lClasseList.end())
				{
					Log("Parsing Tables/animset_table.lua : done.");
					lua_pop(luaVM, 1);
					*finished = true;
					return true;
				}
				else
				{
					*finished = false;
					return true;
				}
			}

			string a_name = LUA::GetFieldString("name");
			if (this->bDebugParser) Log("   Loading state : %s", a_name.c_str());
			bool loop = LUA::GetFieldBool("loop", false, true);

			lua_getfield(luaVM, -1, "sub_animations");

			Animation a;
			for (int i=0; i <= 7; i++)
			{
				lua_rawgeti(luaVM, -1, i);
				if (lua_isnil(luaVM, -1))
					LUA::Print("Missing subanimation " + ToString(i));
				else if (!lua_isstring(luaVM, -1))
					LUA::Print("Field is expected to be a string");
				else
				{
					string str = lua_tostring(luaVM, -1);
					a.lStateList[i] = lLuaAnimList[str];
					if (loop)
						a.lStateList[i]->Play();
					else
					{
						a.lStateList[i]->SetMode(HGEANIM_FWD | HGEANIM_NOLOOP);
						a.lStateList[i]->Play();
					}
				}
				lua_pop(luaVM, 1);
			}

			anim.lAnimations[a_name] = a;

			mGUIMgr->mLoadingBar.fFilling += (filling/mUnitMgr->lClasseList.size())/anim_nbr;

			lua_pop(luaVM, 2);

			*finished = false;
			return false;
		}
	}
}*/

void GFXManager::ParseEffects( lua_State* luaVM )
{
	Log("Parsing Tables/fx_table.lua...");
	int error = luaL_dofile(luaVM, "Tables/fx_table.lua");
	if (error) LUA::LogL(luaVM);

	lua_getglobal(luaVM, "Effects");

	for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
	{
		SEffect e;
		e.sName = LUA::GetFieldString("name");
		e.fLife = LUA::GetFieldFloat("life_duration", false, 0.0f);
		string type = LUA::GetFieldString("type");
		e.fOffX = LUA::GetFieldFloat("offset_x", false, 0.0f);
		e.fOffY = LUA::GetFieldFloat("offset_y", false, 0.0f);
		if (type == "multi_angle_anim")
		{
			e.iType = FX_ANIMATED_EFFECT;
			e.mAFX.iType = FX_MULTI_ANGLE_ANIM;
			e.mAFX.fFadeIn = LUA::GetFieldFloat("fade_in", false, 0.0f);
			e.mAFX.fFadeOut = LUA::GetFieldFloat("fade_out", false, 0.0f);
			e.mAFX.fScale = LUA::GetFieldFloat("scale", false, 1.0f);
			string blend_mode = LUA::GetFieldString("blend_mode", false, "");
			bool loop = LUA::GetFieldBool("loop", false, true);

			lua_getfield(luaVM, -1, "sub_animations");
			for (int i=0; i <= 7; i++)
			{
				lua_rawgeti(luaVM, -1, i);
				if (lua_isnil(luaVM, -1))
					LUA::Print("Missing subanimation " + ToString(i));
				else if (!lua_isstring(luaVM, -1))
					LUA::Print("Field is expected to be a string");
				else
				{
					string str = lua_tostring(luaVM, -1);
					e.mAFX.lStateList[i] = lLuaAnimList[str];
					if (loop)
						e.mAFX.lStateList[i]->Play();
					else
					{
						e.mAFX.lStateList[i]->SetMode(HGEANIM_FWD | HGEANIM_NOLOOP);
						e.mAFX.lStateList[i]->Play();
					}
					if (blend_mode == "add")
						e.mAFX.lStateList[i]->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHAADD | BLEND_NOZWRITE);
				}
				lua_pop(luaVM, 1);
			}
			lua_pop(luaVM, 1);
		}
		else if (type == "single_angle_anim")
		{
			e.iType = FX_ANIMATED_EFFECT;
			e.mAFX.iType = FX_SINGLE_ANGLE_ANIM;
			e.mAFX.fFadeIn = LUA::GetFieldFloat("fade_in", false, 0.0f);
			e.mAFX.fFadeOut = LUA::GetFieldFloat("fade_out", false, 0.0f);
			e.mAFX.fScale = LUA::GetFieldFloat("scale", false, 1.0f);
			string blend_mode = LUA::GetFieldString("blend_mode", false, "");
			bool loop = LUA::GetFieldBool("loop", false, true);

			e.mAFX.mAnim = lLuaAnimList[LUA::GetFieldString("animation")];
			if (loop)
				e.mAFX.mAnim->Play();
			else
			{
				e.mAFX.mAnim->SetMode(HGEANIM_FWD | HGEANIM_NOLOOP);
				e.mAFX.mAnim->Play();
			}
			if (blend_mode == "add")
				e.mAFX.mAnim->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHAADD | BLEND_NOZWRITE);
		}
		else if (type == "psys")
		{
			e.iType = FX_PARTICLE_SYSTEM;
			e.mPFX.fDelay = LUA::GetFieldFloat("delay", false, 0.0f);
			string blend_mode = LUA::GetFieldString("blend_mode", false, "");
			hgeSprite* spr = lLuaSpriteList[LUA::GetFieldString("sprite")];
			if (blend_mode == "add")
				spr->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHAADD | BLEND_NOZWRITE);
			string file = LUA::GetFieldString("file");
			e.mPFX.mPSys = new hgeParticleSystem(file.c_str(), spr);
		}
		else
		{
			Log("# Error # : Unknown effect type : \"%s\".", type.c_str());
			continue;
		}

		this->lFXList[e.sName] = e;
	}

	lua_pop(luaVM, 1);

	Log("Parsing Tables/fx_table.lua : done.");
}

void GFXManager::BuildRenderList()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(6, "GFXManager::buildRenderList", false);
		Chrono c(prof);
	#endif

	bool debug = false;

	// Update render order every 0.1 sec
	static float timer = 0.0f;
	bool rebuild;

	timer += mTimeMgr->GetDelta();
	if (timer >= 0.33f)
	{
		rebuild = true;
		timer = 0.0f;
	}
	else
		rebuild = false;

	//rebuild = true;

	if ( (bForceUpdate == true) || (rebuild) )
	{
		bDebugRenderList = debug;
		lZSortedList.clear();
		lZSortedUnitList.clear();
		map<int, Unit*>::iterator iterUnit;
		for (iterUnit = mUnitMgr->lUnitList.begin(); iterUnit != mUnitMgr->lUnitList.end(); iterUnit++)
		{
			Unit *u = iterUnit->second;
			if (!mSceneMgr->bGamePaused)
				u->Update();
			else
				u->SetBox();
			if (u->GetBox()->Intersect(mScrRect))
			{
				float z = u->GetZ();
				Object obj;
				obj.iType = OBJ_TYPE_UNIT;
				obj.mPtr = u;
				while (this->lZSortedList.find(z) != this->lZSortedList.end())
				{
					z += 0.01f;
				}
				this->lZSortedList[z] = obj;
				this->lZSortedUnitList[z] = u;
			}
		}

		map<float, Object> relZList;

		map<string, Doodad*>::iterator iterDoodad;
		for (iterDoodad = mZoneMgr->mActualZone.lDoodadList.begin(); iterDoodad != mZoneMgr->mActualZone.lDoodadList.end(); iterDoodad++)
		{
			relZList.clear();
			Doodad *d = iterDoodad->second;
			if (this->bDebugRenderList) {Log("#Doodad %s :", d->sName.c_str());}

			if (d->GetBox()->Intersect(mScrRect))
			{
				if (d->bInTop)
					this->lRenderInTopList[d->GetZ()] = d;
				else
				{
					map<float, Object>::iterator iterZ;
					for (iterZ = this->lZSortedList.begin(); iterZ != this->lZSortedList.end(); iterZ++)
					{
						// Check every unit or doodad that is in close range
						if (d->Intersects(iterZ->second))
						{
							// Get relative Z for each
							float z;
							if (iterZ->second.iType == OBJ_TYPE_UNIT)
							{
								Unit* tempUnit = static_cast<Unit*>(iterZ->second.mPtr);
								if (this->bDebugRenderList) {Log("  %s :", tempUnit->GetName().c_str());}
								z = - d->GetRelativeDepth(tempUnit->GetGPoint());
							}
							else if (iterZ->second.iType == OBJ_TYPE_DOODAD)
							{
								Doodad* tempDoodad = static_cast<Doodad*>(iterZ->second.mPtr);
								if (this->bDebugRenderList) {Log("  %s :", tempDoodad->sName.c_str());}
								z = tempDoodad->GetRelativeDepth(d->GetPoint());
							}

							if (z != 0.0f)
							{
								// A little offset to prevent duplicates
								while (relZList.find(z) != relZList.end())
								{
									z += 0.01f;
								}

								if (this->bDebugRenderList) {Log("   relZ = %f :", z);}

								// ... and store it in a map
								relZList[z] = iterZ->second;
							}
							else
							{
								if (this->bDebugRenderList) {Log("   relZ = 0");}
							}
						}
					}
					float z;
					if (relZList.empty())
					{
						// If the map is empty, then set unit's Z to its global value
						z = d->GetZ();
						// ...and add little offset if needed to prevent duplicates
						while (this->lZSortedList.find(z) != this->lZSortedList.end())
						{
							z += 0.01f;
						}

						if (this->bDebugRenderList) {Log(" relZ is empty : z = %f", z);}
					}
					else
					{
						if (relZList.size() == 1)
						{
							// Else if there is only one object in range, set unit's Z to the
							// object's + the relative Z.
							if (relZList.begin()->second.iType == OBJ_TYPE_UNIT)
							{
								Unit* tempUnit = static_cast<Unit*>(relZList.begin()->second.mPtr);
								if (relZList.begin()->first >= 0.0f)
								{
									if (d->GetZ() >= tempUnit->GetZ())
										z = d->GetZ();
									else
										z = tempUnit->GetRZ()+0.01f;
								}
								else if (relZList.begin()->first < 0.0f)
								{
									if (d->GetZ() < tempUnit->GetZ())
										z = d->GetZ();
									else
										z = tempUnit->GetRZ()-0.01f;
								}
								if (this->bDebugRenderList) {Log(" relZ contains only one object (%s) : z = %f", tempUnit->GetName().c_str(), z);}
							}
							else if (relZList.begin()->second.iType == OBJ_TYPE_DOODAD)
							{
								Doodad* tempDoodad = static_cast<Doodad*>(relZList.begin()->second.mPtr);
								if (relZList.begin()->first >= 0.0f)
								{
									if (d->GetZ() >= tempDoodad->GetZ())
										z = d->GetZ();
									else
										z = tempDoodad->GetZ()+0.01f;
								}
								else if (relZList.begin()->first < 0.0f)
								{
									if (d->GetZ() < tempDoodad->GetZ())
										z = d->GetZ();
									else
										z = tempDoodad->GetZ()-0.01f;
								}
								if (this->bDebugRenderList) {Log(" relZ contains only one object (%s) : z = %f", tempDoodad->sName.c_str(), z);}
							}
						}
						else if (relZList.size() > 1)
						{
							// And if there is more than two objects...
							float z1, z2;
							map<float, Object>::iterator iter0, iter1, iter2, iter3;

							// We get the two objects with the highest and lowest Z value
							float bestZ, worstZ;
							iter0 = relZList.begin();
							if (iter0->second.iType == OBJ_TYPE_UNIT)
								bestZ = worstZ = static_cast<Unit*>(iter0->second.mPtr)->GetZ();
							else if (iter0->second.iType == OBJ_TYPE_DOODAD)
								bestZ = worstZ = static_cast<Doodad*>(iter0->second.mPtr)->GetZ();
							iter1 = iter2 = iter0;
							for (iter0 = relZList.begin(); iter0 != relZList.end(); iter0++)
							{
								float z;
								if (iter0->second.iType == OBJ_TYPE_UNIT)
									z = static_cast<Unit*>(iter0->second.mPtr)->GetZ();
								else if (iter0->second.iType == OBJ_TYPE_DOODAD)
									z = static_cast<Doodad*>(iter0->second.mPtr)->GetZ();

								if (z < worstZ)
								{
									worstZ = z;
									iter1 = iter0;
								}
								if (z > bestZ)
								{
									bestZ = z;
									iter2 = iter0;
								}
							}

							iter3 = relZList.upper_bound(0.0f);
							if (this->bDebugRenderList) {Log(" relZ contains more than one object :");}

							if (iter1->first <= 0.0f)
							{
								// There is no positive Z value, set Z to the nearest from zero + relZ
								if (this->bDebugRenderList) {Log("  none of them have a positive relZ,");}
								if (iter1->second.iType == OBJ_TYPE_UNIT)
								{
									Unit* tempUnit = static_cast<Unit*>(iter1->second.mPtr);
									z = tempUnit->GetZ()+iter1->first;
									if (this->bDebugRenderList) {Log(" take the latest object (%s) : z = %f+%f = %f", tempUnit->GetName().c_str(), tempUnit->GetZ(), iter1->first, z);}
								}
								else if (iter1->second.iType == OBJ_TYPE_DOODAD)
								{
									Doodad* tempDoodad = static_cast<Doodad*>(iter1->second.mPtr);
									z = tempDoodad->GetZ()+iter1->first*0.01f;
									if (this->bDebugRenderList) {Log(" take the latest object (%s) : z = %f+%f = %f", tempDoodad->sName.c_str(), tempDoodad->GetZ(), iter1->first*0.01f, z);}
								}
							}
							else if (iter2->first >= 0.0f)
							{
								if (this->bDebugRenderList) {Log(" none of them have a negative relZ");}
								// There is no negative Z value, set Z to the nearest from zero + relZ
								if (iter2->second.iType == OBJ_TYPE_UNIT)
								{
									Unit* tempUnit = static_cast<Unit*>(iter2->second.mPtr);
									z = tempUnit->GetZ()+iter2->first;
									if (this->bDebugRenderList) {Log(" take the first object (%s) : z = %f+%f = %f", tempUnit->GetName().c_str(), tempUnit->GetZ(), iter2->first, z);}
								}
								else if (iter2->second.iType == OBJ_TYPE_DOODAD)
								{
									Doodad* tempDoodad = static_cast<Doodad*>(iter2->second.mPtr);
									z = tempDoodad->GetZ()+iter2->first*0.01f;
									if (this->bDebugRenderList) {Log(" take the first object (%s) : z = %f+%f = %f", tempDoodad->sName.c_str(), tempDoodad->GetZ(), iter2->first*0.01f, z);}
								}
							}
							else
							{
								if (this->bDebugRenderList) {Log(" there are positive and negative relZ");}
								// Else get the average of the two closest from 0
								if (iter3->second.iType == OBJ_TYPE_UNIT)
								{
									Unit* tempUnit = static_cast<Unit*>(iter3->second.mPtr);
									z1 = tempUnit->GetZ();
									if (this->bDebugRenderList) {Log("  take the nearest from 0 (%s) : z1 = %f", tempUnit->GetName().c_str(), z1);}
								}
								else if (iter3->second.iType == OBJ_TYPE_DOODAD)
								{
									Doodad* tempDoodad = static_cast<Doodad*>(iter3->second.mPtr);
									z1 = tempDoodad->GetZ();
									if (this->bDebugRenderList) {Log("  take the nearest from 0 (%s) : z1 = %f", tempDoodad->sName.c_str(), z1);}
								}
								iter3--;
								if (iter3->second.iType == OBJ_TYPE_UNIT)
								{
									Unit* tempUnit = static_cast<Unit*>(iter3->second.mPtr);
									z2 = tempUnit->GetZ();
									if (this->bDebugRenderList) {Log("  and the one just before (%s) : z2 = %f", tempUnit->GetName().c_str(), z2);}
								}
								else if (iter3->second.iType == OBJ_TYPE_DOODAD)
								{
									Doodad* tempDoodad = static_cast<Doodad*>(iter3->second.mPtr);
									z2 = tempDoodad->GetZ();
									if (this->bDebugRenderList) {Log("  and the one just before (%s) : z2 = %f", tempDoodad->sName.c_str(), z2);}
								}
								z = (z1+z2)/2;
								if (this->bDebugRenderList) {Log(" and get the average between those two : z = %f", z);}
							}
						}
					}
					Object obj;
					obj.iType = OBJ_TYPE_DOODAD;
					obj.mPtr = d;
					// A little offset to prevent duplicates
					while (this->lZSortedList.find(z) != this->lZSortedList.end())
					{
						z += 0.01f;
					}
					if (this->bDebugRenderList) {Log(" %s : z = %f", d->sName.c_str(), z);}
					this->lZSortedList[z] = obj;
				}
			}
		}
	}
	else if (!mSceneMgr->bGamePaused)
	{
		// Just update all units.
		map<int, Unit*>::iterator iterUnit;
		for (iterUnit = mUnitMgr->lUnitList.begin(); iterUnit != mUnitMgr->lUnitList.end(); iterUnit++)
		{
			iterUnit->second->Update();
		}
	}
	bForceUpdate = false;
}

void GFXManager::ForceUpdate()
{
	bForceUpdate = true;
}

HTEXTURE GFXManager::LoadTexture( string file, bool mipmaps )
{
	if (lTextureList.find(file) != lTextureList.end())
	{
	  	return lTextureList[file];
	}
	else
	{
		if (file == "") {Log("# Error # : can't load texture : missing file name");}
		else
		{
			lTextureList[file] = hge->Texture_Load(file.c_str(), 0, mipmaps);
			return lTextureList[file];
		}
	}
}

void GFXManager::FreeTextures()
{
	map<string, HTEXTURE>::iterator iterTex;
	for (iterTex = this->lTextureList.begin(); iterTex != this->lTextureList.end(); iterTex++)
	{
		hge->Texture_Free(iterTex->second);
	}
}

hgeSprite* GFXManager::CreateSprite( HTEXTURE tex, float x, float y, float w, float h, bool GUI )
{
	hgeSprite* spr = new hgeSprite(tex, x, y, w, h);
	if (GUI)
		mGUIMgr->lGUIspriteList.push_back(spr);
	else
		lSpriteList.push_back(spr);
	return spr;
}

hgeSprite* GFXManager::CreateSprite( hgeSprite* base, bool GUI )
{
	hgeSprite* spr = new hgeSprite(*base);
	if (GUI)
		mGUIMgr->lGUIspriteList.push_back(spr);
	else
		lSpriteList.push_back(spr);
	return spr;
}

void GFXManager::DeleteSprites()
{
	vector<hgeSprite*>::iterator iter;
	while (!lSpriteList.empty())
	{
		iter = lSpriteList.begin();
		delete *iter;
		lSpriteList.erase(iter);
	}

	hge->Target_Free(mGFXMgr->mMainTarget);
	delete mGFXMgr->mMainSprite;
	mGFXMgr->mMainSprite = NULL;
}

hgeAnimation* GFXManager::CreateAnimation( HTEXTURE tex, int frames, float fps, float x, float y, float w, float h )
{
	hgeAnimation* anim = new hgeAnimation(tex, frames, fps, x, y, w, h);
	lAnimList.push_back(anim);
	return anim;
}

void GFXManager::DeleteAnimations()
{
	vector<hgeAnimation*>::iterator iter;
	while (!lAnimList.empty())
	{
		iter = lAnimList.begin();
		delete *iter;
		lAnimList.erase(iter);
	}
}

hgeRect* GFXManager::CreateRect( float x1, float y1, float x2, float y2 )
{
	hgeRect* rect = new hgeRect(x1, y1, x2, y2);
	lRectList.push_back(rect);
	return rect;
}

void GFXManager::DeleteRects()
{
	vector<hgeRect*>::iterator iter;
	while (!lRectList.empty())
	{
		iter = lRectList.begin();
		delete *iter;
		lRectList.erase(iter);
	}
}

hgeParticleSystem* GFXManager::CreatePSys( string file, hgeSprite* spr )
{
	hgeParticleSystem* psys = new hgeParticleSystem(file.c_str(), spr);
	lPSysList.push_back(psys);
	return psys;
}

void GFXManager::DeletePSys()
{
	vector<hgeParticleSystem*>::iterator iter;
	while (!lPSysList.empty())
	{
		iter = lPSysList.begin();
		delete *iter;
		lPSysList.erase(iter);
	}
}

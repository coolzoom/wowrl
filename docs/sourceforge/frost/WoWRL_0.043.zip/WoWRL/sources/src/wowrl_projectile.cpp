/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Projectile source           */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Projectile class.              */
/*       A Projecille is used whenever a  */
/*  spell is casted, a bullet is fired,   */
/*  an arrow is thrown, ... it can follow */
/*  its target and it has a particle      */
/*  system linked to it.                  */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge/hge.h"
#include "hge/hgerect.h"
#include "hge/hgeparticle.h"

#include "wowrl_unit.h"
#include "wowrl_global.h"
#include "wowrl_distortion.h"
#include "wowrl_scenemanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_timemanager.h"

#include "wowrl_projectile.h"

extern HGE *hge;
extern SceneManager *mSceneMgr;
extern InputManager *mInputMgr;
extern GFXManager *mGFXMgr;
extern TimeManager *mTimeMgr;

Projectile::Projectile() : fX(0.0f), fY(0.0f), mDestination(NULL), mPSys(NULL)
{
}

Projectile::Projectile( Spell* spell,
						Unit* destination,
						Unit* origin ) :
							mSpell(spell),
							mDestination(destination),
							mOrigin(origin),
							mPSys(NULL),
							bArrived(false)
{
	sPSysName = mSpell->sAttackEffect;
	fX = origin->GetGX()+mGFXMgr->lFXList[sPSysName].fOffX*origin->GetScale();
	fY = origin->GetGY()+mGFXMgr->lFXList[sPSysName].fOffY*origin->GetScale();
	fSpeed = mSpell->fProjSpeed;
}

Projectile::~Projectile()
{
    if (mPSys != NULL) {delete mPSys;}
}

hgeParticleSystem* Projectile::GetPSys()
{
	if (sPSysName != sOldPSysName)
	{
		if (mPSys != NULL) {delete mPSys;}
		mPSys = new hgeParticleSystem(*mGFXMgr->lFXList[sPSysName].mPFX.mPSys);
		sOldPSysName = sPSysName;
	}
	return mPSys;
}

float Projectile::GetZ()
{
	float z = fY-mSceneMgr->fGY;
    return z;
}

Unit* Projectile::GetParent()
{
	return mOrigin;
}

Unit* Projectile::GetDestination()
{
	return mDestination;
}

Spell* Projectile::GetSpell()
{
	return mSpell;
}

void Projectile::SetDestination(Unit* destination)
{
	if (destination != NULL)
		{mDestination = destination;}
}

bool Projectile::UpdatePos()
{
	hgeVector destVec;
	destVec.x = mDestination->GetGX()-fX;
	destVec.y = mDestination->GetGY()-(mDestination->GetRace()->fStatusBarYOffset/2.0f)*mDestination->GetScale()-fY;

	float coefx, coefy;
	coefx = (fSpeed/1.4142f)*cos(destVec.Angle());
	coefy = (fSpeed/1.4142f)*sin(destVec.Angle());

	hgeRect* particleRect = new hgeRect(fX+mSceneMgr->fGX-5,fY+mSceneMgr->fGY-5,fX+mSceneMgr->fGX+5,fY+mSceneMgr->fGY+5);
	bool collides = mDestination->Intersects(particleRect);
	delete particleRect;

	if (!collides)
	{
		fX += coefx*mTimeMgr->GetDelta();
		fY += coefy*mTimeMgr->GetDelta();
		bArrived = false;
		return true;
	}
	else
	{
		bArrived = true;
		mDestination->Receive(mSpell, mOrigin);
		return false;
	}
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Effect source             */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Effect class.                  */
/*       An Effect is used to store all   */
/*  kind of special effects, such as      */
/*  particle systems or animated sprites. */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_scenemanager.h"

#include "wowrl_effect.h"

extern SceneManager* mSceneMgr;

void Effect::Render(float x, float y)
{
	if (iType == FX_ANIMATED_EFFECT)
	{
		mAnim->RenderEx(x+fOffX, y+fOffY, 0.0f, fScale);
	}
	else if (iType == FX_PARTICLE_SYSTEM)
	{
		mPSys->MoveTo(x-mSceneMgr->fGX+fOffX, y-mSceneMgr->fGY+fOffY);
		mPSys->Transpose(mSceneMgr->fGX, mSceneMgr->fGY);
		mPSys->Render();
	}
}

void Effect::RenderEx(float x, float y, float angle, float h_scale, float v_scale)
{
	if (v_scale == 0.0f)
		v_scale = h_scale;

	if (iType == FX_ANIMATED_EFFECT)
	{
		mAnim->RenderEx(x+fOffX*h_scale, y+fOffY*v_scale, angle, h_scale*fScale, v_scale*fScale);
	}
	else if (iType == FX_PARTICLE_SYSTEM)
	{
		mPSys->MoveTo(x-mSceneMgr->fGX+fOffX*h_scale, y-mSceneMgr->fGY+fOffY*v_scale);
		mPSys->Transpose(mSceneMgr->fGX, mSceneMgr->fGY);
		mPSys->Render();
	}
}

void Effect::SetColor(DWORD col)
{
	if (iType == FX_ANIMATED_EFFECT)
	{
		mAnim->SetColor(col);
	}
}

void Effect::Play()
{
	if (iType == FX_ANIMATED_EFFECT)
	{
		mAnim->Play();
	}
	else if (iType == FX_PARTICLE_SYSTEM)
	{
		mPSys->Fire();
	}
}

void Effect::Stop()
{
	if (iType == FX_ANIMATED_EFFECT)
	{
		mAnim->Stop();
	}
	else if (iType == FX_PARTICLE_SYSTEM)
	{
		mPSys->Stop();
	}
}

void Effect::Update(float dt)
{
	if (iType == FX_ANIMATED_EFFECT)
	{
		mAnim->Update(dt);
	}
	else if (iType == FX_PARTICLE_SYSTEM)
	{
		mPSys->Update(dt);
	}
}

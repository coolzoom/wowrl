/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               Main source              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_scenemanager.h"
#include "wowrl_fontmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_unitmanager.h"
#include "wowrl_zonemanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_modelmanager.h"
#include "wowrl_lightmanager.h"
#include "wowrl_unit.h"
#include "wowrl_projectile.h"
#include "wowrl_point.h"
#include "wowrl_global.h"
#include "wowrl_pathfinding.h"
#include "wowrl_collision.h"
#include "wowrl_distortion.h"
#include "wowrl_doodad.h"
#include "wowrl_statusbar.h"
#include "wowrl_structs.h"
#include "wowrl_lua.h"
#include "wowrl_effect.h"
#include "wowrl_gui.h"

using namespace std;

// Global variables
HGE *hge = 0;
SceneManager*   mSceneMgr;
FontManager*    mFontMgr;
GUIManager*     mGUIMgr;
TimeManager*    mTimeMgr;
UnitManager*    mUnitMgr;
ZoneManager*    mZoneMgr;
GFXManager*     mGFXMgr;
InputManager*   mInputMgr;
ModelManager*   mModelMgr;
LightManager*   mLightMgr;

Chrono* frameChrono;

// Function called by HGE once per frame.
bool FrameFunc()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(8, "FrameFunc", false);
		Chrono c(prof);
	#endif

	if (mInputMgr->bShiftPressed)
	{
		if (mInputMgr->KeyIsPressed(HGEK_ESCAPE, true))
			return true;
	}
	else
	{
		if (mInputMgr->KeyIsPressed(HGEK_ESCAPE))
			return true;
	}

	if (mInputMgr->KeyIsPressed(HGEK_PAUSE, true))
		mSceneMgr->bGamePaused = !mSceneMgr->bGamePaused;

	switch (mSceneMgr->iGameState)
	{
/********************************/
		case GAME_STATE_GAME:
/********************************/
		{
			return GameFrame();
		}
/********************************/
		case GAME_STATE_LOADING:
/********************************/
		{
			return LoadFrame();
		}
	}

	return false;
}


bool RenderFunc()
{
    //#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(8, "RenderFunc", true);
		Chrono c(prof);
	//#endif

	switch (mSceneMgr->iGameState)
	{
/********************************/
		case GAME_STATE_GAME:
/********************************/
		{
		    return GameRender();
		}
/********************************/
		case GAME_STATE_LOADING:
/********************************/
		{
		    return LoadRender();
		}
	}

	return false;
}


bool RestoreFunc()
{
	map<string, GUIElement*>::iterator iterGUI;
	for (iterGUI = mGUIMgr->lGuiList.begin(); iterGUI != mGUIMgr->lGuiList.end(); iterGUI++)
	{
		GUIElement* g = iterGUI->second;
		if (g->mTarget && g->mSpr)
		{
			g->mSpr->SetTexture(hge->Target_GetTexture(g->mTarget));
			if (g->bUseBackdrop)
				if (g->mBackdrop.mTarget && g->mBackdrop.mSpr)
					g->mBackdrop.mSpr->SetTexture(hge->Target_GetTexture(g->mBackdrop.mTarget));
		}
		g->bRebuildCache = true;
		g->bRebuildBackdrop = true;
	}

	map<int, Unit*>::iterator iterUnit;
	for (iterUnit = mUnitMgr->lUnitList.begin(); iterUnit != mUnitMgr->lUnitList.end(); iterUnit++)
	{
	    Unit* u = iterUnit->second;
	    if (u->GetModel() != NULL)
            if (u->GetModel()->GetSprite() != NULL)
                u->GetModel()->GetSprite()->SetTexture(hge->Target_GetTexture(u->GetModel()->GetRTarget()));
	}

	mGFXMgr->mMainSprite->SetTexture(hge->Target_GetTexture(mGFXMgr->mMainTarget));

	return false;
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	srand((unsigned)time(0));

	// Initialize HGE
	hge = hgeCreate(HGE_VERSION);
	hge->Random_Seed(0);

	hge->System_SetState(HGE_LOGFILE, "WoWRL.log"); // Initialize the Log file
	hge->System_SetState(HGE_TITLE, "WoW Raid Leader"); // Set the frame title
	hge->System_SetState(HGE_FRAMEFUNC, FrameFunc);
	hge->System_SetState(HGE_RENDERFUNC, RenderFunc);
	hge->System_SetState(HGE_GFXRESTOREFUNC, RestoreFunc);

	// Create managers
	mSceneMgr = SceneManager::GetSingleton();
	mUnitMgr = UnitManager::GetSingleton();
	mFontMgr = FontManager::GetSingleton();
	mGUIMgr = GUIManager::GetSingleton();
	mTimeMgr = TimeManager::GetSingleton();
	mZoneMgr = ZoneManager::GetSingleton();
	mGFXMgr = GFXManager::GetSingleton();
	mInputMgr = InputManager::GetSingleton();
	mModelMgr = ModelManager::GetSingleton();
    mLightMgr = LightManager::GetSingleton();

    //mTimeMgr->SetProfiling(true);

	mSceneMgr->fGameVersion = GAME_VERSION;
	Log("##########################");
	Log("# Starting WoWRL v.%.3f #", mSceneMgr->fGameVersion);
	Log("##########################\n");

	// Initialize LUA
	mSceneMgr->luaVM = lua_open();
	if (mSceneMgr->luaVM == NULL)
	{
		Log("# Error initializing lua.");
		return 0;
	}
	LUA::OpenLibs(mSceneMgr->luaVM);
	LUA::RegisterAll(mSceneMgr->luaVM);
	// Set panic function
	lua_atpanic(mSceneMgr->luaVM, LUA::LogL);

	Log("Parsing display config...");

	int error = luaL_dofile(mSceneMgr->luaVM, "Scripts/config.lua");
	if (error) LUA::LogL(mSceneMgr->luaVM);

	mGFXMgr->iSWidth = LUA::GetGlobalInt("Display_screen_width");
	mGFXMgr->iSHeight = LUA::GetGlobalInt("Display_screen_height");
	int sDepth = LUA::GetGlobalInt("Display_screen_depth");
	mGFXMgr->iMaxFPS = LUA::GetGlobalInt("Display_max_fps");
	bool windowed = !LUA::GetGlobalBool("Display_fullscreen");
	mSceneMgr->sLocale = LUA::GetGlobalString("Game_locale");
	string strTableFile = "Tables/locale_" + mSceneMgr->sLocale + ".str";

	Log("Parsing display config : done.\n");

	mSceneMgr->tStrTable = new hgeStringTable(strTableFile.c_str());

	hge->System_SetState(HGE_FPS, HGEFPS_UNLIMITED);
	hge->System_SetState(HGE_WINDOWED, windowed);
	hge->System_SetState(HGE_SCREENWIDTH, mGFXMgr->iSWidth);
	hge->System_SetState(HGE_SCREENHEIGHT, mGFXMgr->iSHeight);
	hge->System_SetState(HGE_SCREENBPP, sDepth);

	hge->System_SetState(HGE_ICON, MAKEINTRESOURCE (1));

	hge->System_SetState(HGE_USESOUND, false); // Disactivate sound
	hge->System_SetState(HGE_ZBUFFER, true);

	if(hge->System_Initiate())
	{
		// Create the main render target
		mGFXMgr->mDxDevice = hge->Gfx_GetDevice();
		mGFXMgr->mMainTarget = hge->Target_Create(mGFXMgr->iSWidth, mGFXMgr->iSHeight, false);
		mGFXMgr->mMainSprite = new hgeSprite
		(
			hge->Target_GetTexture(mGFXMgr->mMainTarget),
			0, 0,
			mGFXMgr->iSWidth, mGFXMgr->iSHeight
		);

		mLightMgr->SetAmbient(Vector3(255,255,255));
        //mLightMgr->AddPointLight(0.0f, 0.0f, 0.0f, 20.0f, ARGB(255, 255, 255, 255));

		// Initialize shaders
        mGFXMgr->CreateVertexShader();
        mGFXMgr->CreatePixelShader();
        mGFXMgr->SetSceneMatrices();

		// Create loading bar
		string loadingBar = "UI/ui_default_loading_bar.png";
		HTEXTURE lTex = mGFXMgr->LoadTexture(loadingBar);
		mGUIMgr->mLoadingBar.mBorder = mGFXMgr->CreateSprite(lTex,1,57,250,30);
		mGUIMgr->mLoadingBar.mBorder->SetHotSpot(125, 0);
		mGUIMgr->mLoadingBar.mSpark = mGFXMgr->CreateSprite(lTex,84,30,7,24);
		mGUIMgr->mLoadingBar.mSpark->SetHotSpot(5, 0);
		mGUIMgr->mLoadingBar.mSpark->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHABLEND | BLEND_NOZWRITE);
		mGUIMgr->mLoadingBar.mGauge = mGFXMgr->CreateSprite(lTex,1,29,26,26);
		mGUIMgr->mLoadingBar.mBackground = mGFXMgr->CreateSprite(lTex,1,1,246,26);
		mGUIMgr->mLoadingBar.mBackground->SetHotSpot(123, 0);
		mGUIMgr->mLoadingBar.fFilling = 0.0f;

		//int fileNbr = hge->Random_Int(1,2);
		int fileNbr = 1;

		// Load the loading background
		if (mGFXMgr->iSWidth == 1024)
		{
			HTEXTURE bgTex = mGFXMgr->LoadTexture("Zones/LoadingScreen/loading_screen_" + ToString(fileNbr)+ "_1024.jpg");
			mGUIMgr->mLoadingBackground = mGFXMgr->CreateSprite(bgTex,0,0,1024,768);
		}
		else
		{
			HTEXTURE bgTex = mGFXMgr->LoadTexture("Zones/LoadingScreen/loading_screen_" + ToString(fileNbr)+ "_1280.jpg");
			mGUIMgr->mLoadingBackground = mGFXMgr->CreateSprite(bgTex,0,0,1280,1024);
		}
		mGUIMgr->mLoadingBar.sCaption = mSceneMgr->tStrTable->GetString("gui_loading");

		// Load ressources and start
		mSceneMgr->iGameState = GAME_STATE_LOADING;

		frameChrono = new Chrono(mTimeMgr->GetProfiler(8, "Frame", false), false);

		hge->System_Start();

		delete frameChrono;
	}
	else
	{
		MessageBox(NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_APPLMODAL);
	}

	Log("Game ended.\n");
	Log("Average FPS : %d", mTimeMgr->GetAverageFPS());

	// End, delete/free everything
	Log("Freeing resources :");
	Log("   Closing UI...");
	mGUIMgr->CloseUI(mSceneMgr->luaVM);
	Log("   Freeing textures...");
	mGFXMgr->FreeTextures();
	Log("   Deleting sprites...");
	mGFXMgr->DeleteSprites();
	Log("   Deleting animations...");
	mGFXMgr->DeleteAnimations();
	Log("   Deleting particle systems...");
	mGFXMgr->DeletePSys();
	Log("   Deleting rects...");
	mGFXMgr->DeleteRects();
	Log("   Deleting doodads...");
	mZoneMgr->DeleteDoodads();
	Log("   Deleting units...");
	mUnitMgr->DeleteUnits();
	Log("   Deleting fonts...");
	mFontMgr->DeleteFonts();

	Log("Done.");

	mSceneMgr->PrintLog();
	mSceneMgr->DeleteThis();

	// Print out profiling info
	mTimeMgr->Print();

	lua_close(mSceneMgr->luaVM);

	delete mSceneMgr;
	delete mFontMgr;
	delete mTimeMgr;
	delete mGUIMgr;
	delete mUnitMgr;
	delete mZoneMgr;
	delete mGFXMgr;
	delete mInputMgr;
	delete mModelMgr;
    delete mLightMgr;

	hge->System_Shutdown();
	hge->Release();

	return 0;
}

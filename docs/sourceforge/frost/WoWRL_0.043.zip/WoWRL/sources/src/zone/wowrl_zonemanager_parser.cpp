/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_lua.h"
#include "wowrl_scenemanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_global.h"

#include "wowrl_zonemanager.h"

using namespace std;

extern SceneManager *mSceneMgr;
extern GUIManager *mGUIMgr;
extern GFXManager *mGFXMgr;
extern HGE *hge;

bool ZoneManager::ParseZoneDyn( lua_State* luaVM, int state1, int state2, bool* finished, float filling )
{
	static int part_nbr = 0;
	static int doodad_nbr = 0;

	if (state1 == 1)
	{
		Log("Parsing %s...",  mActualZone.sName.c_str());
		if (!FileExists(mActualZone.sName))
		{
		    Log("# Critical error # : couldn't find zone file \"%s\"\n\nExiting...", mActualZone.sName.c_str());
		    exit(0);
		}
		else
		{
            int error = luaL_dofile(luaVM,  mActualZone.sName.c_str());
            if (error) LUA::LogL(luaVM);
            lua_getglobal(luaVM, "Zone");
            mActualZone.iW = LUA::GetFieldInt("width");
            mActualZone.iH = LUA::GetFieldInt("height");
            mActualZone.fDistScaleMax = mActualZone.fDistScaleMin = LUA::GetFieldFloat("scale", false, 1.0f);
            mActualZone.fDistVScaleMax = mActualZone.fDistVScaleMin = LUA::GetFieldFloat("vscale", false, 1.0f);
            mActualZone.fDistAngleMax = mActualZone.fDistAngleMin = 0.0f;
            mSceneMgr->fGX = -LUA::GetFieldFloat("start_x", false, mActualZone.iW/2.0f);
            mSceneMgr->fGY = -LUA::GetFieldFloat("start_y", false, mActualZone.iH/2.0f);
            mActualZone.iPartSize = 1024;
            lua_getfield(luaVM, -1, "Background");

            for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
            {
                part_nbr++;
            }

            *finished = false;
            mGUIMgr->mLoadingBar.fFilling += 0.01f;
            return true;
		}
	}
	else if (state1 == 2)
	{
		if (state2 > part_nbr)
		{
			lua_pop(luaVM, 1);
			*finished = false;
			return true;
		}

		static float x = 0.0f;
		static float y = 0.0f;
		int i = state2;

		BGPart* tmpBGPart = new BGPart();
		tmpBGPart->iID = i;
		tmpBGPart->fX = x;
		tmpBGPart->fY = y;

		lua_rawgeti(luaVM, -1, i);

		string bg = LUA::GetFieldString("background");
		string dist = LUA::GetFieldString("distortion", false, "");

		// Loading textures
		tmpBGPart->mBg = mGFXMgr->CreateSprite(mGFXMgr->LoadTexture(bg), 0, 0, 1024.0f, 1024.0f);

		if ( (dist == "0") || (dist == "none") || (dist == "") )
		{
			tmpBGPart->bDistData = false;
			tmpBGPart->dwGlobalDist = ARGB(255, 0, 255, 255);
		}
		else
		{
			tmpBGPart->bDistData = true;
			HTEXTURE dist_tex = mGFXMgr->LoadTexture(dist);
			tmpBGPart->mDist = hge->Texture_Lock(dist_tex);
			hge->Texture_Unlock(dist_tex);
		}

		float index = (y/1024.0f) * (mActualZone.iW/1024.0f) + (x/1024.0f);

		this->mActualZone.lPartList[index] = tmpBGPart;

		i++;
		x += 1024.0f;
		if (x >= mActualZone.iW)
		{
			x = 0.0f;
			y += 1024.0f;
		}

		mGUIMgr->mLoadingBar.fFilling += ((filling-0.02f)/2)/part_nbr;

		lua_pop(luaVM, 1);
		*finished = false;
		return false;
	}
	else if (state1 == 3)
	{
		mGUIMgr->ParseUI(LUA::GetFieldString("UI", false, ""));

		lua_getfield(luaVM, -1, "Doodads");

		if (!lua_isnil(luaVM, -1))
		{
            for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
            {
                doodad_nbr++;
            }

            lua_pushnil(luaVM);
		}

		*finished = false;
		mGUIMgr->mLoadingBar.fFilling += 0.01f;
		return true;
	}
	else if (state1 == 4)
	{
		if (doodad_nbr == 0)
		{
			mGUIMgr->mLoadingBar.fFilling += ((filling-0.02f)/2);

			lua_pop(luaVM, 1);

			*finished = false;
			return true;
		}
		else
		{
            if (!lua_next(luaVM, -2))
            {
                lua_pop(luaVM, 1);

                *finished = false;
                return true;
            }

            Doodad* d = new Doodad();
            d->sName = LUA::GetFieldString("name");
            if (this->bDebugParser) {Log(" Loading doodad \"%s\"...", d->sName.c_str());}
            d->mSprite = mGFXMgr->lLuaSpriteList[LUA::GetFieldString("sprite")];
            d->SetX(LUA::GetFieldFloat("x", false, 0.0f));
            d->SetY(LUA::GetFieldFloat("y", false, 0.0f));
            d->bInTop = LUA::GetFieldBool("always_in_top", false, false);
            if (!d->bInTop)
                d->fOrientation = LUA::GetFieldFloat("orientation");
            d->SetBox();

            this->mActualZone.lDoodadList[d->sName] = d;

            lua_pop(luaVM, 1);

            mGUIMgr->mLoadingBar.fFilling += ((filling-0.02f)/2)/doodad_nbr;

            *finished = false;
            return false;
		}
	}
	else if (state1 == 5)
	{
		lua_getfield(luaVM, -1, "Waypoints");

        int waypointNbr = 0;

		if (!lua_isnil(luaVM, -1))
		{
            for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
            {
                Waypoint w;
                w.sName = LUA::GetFieldString("name");
                w.fX = LUA::GetFieldFloat("x");
                w.fY = LUA::GetFieldFloat("y");
                w.fSize = LUA::GetFieldFloat("size");
                w.bUseless = false;
                w.bOpened = false;
                w.bClosed = false;
                w.mParent = NULL;

                mActualZone.lWPntList[w.sName] = w;

                waypointNbr++;
            }
            for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
            {
                string wpName = LUA::GetFieldString("name");
                Waypoint* w = &mActualZone.lWPntList[wpName];

                lua_getfield(luaVM, -1, "childs");
                for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
                {
                    string childName = LUA::GetFieldString("name");
                    float dist = LUA::GetFieldFloat("distance");

                    w->lChildList.insert(make_pair(dist, &mActualZone.lWPntList[childName]));
                }
                lua_pop(luaVM, 1);
            }
		}

		lua_pop(luaVM, 1);

        if (waypointNbr == 0)
            mActualZone.bWaypoints = false;
        else
            mActualZone.bWaypoints = true;

		*finished = false;
		return true;
	}
	else
	{
		lua_pop(luaVM, 1);
		Log("Parsing %s : done.", mActualZone.sName.c_str());
		*finished = true;
		return true;
	}
}


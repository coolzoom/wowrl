/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Zone source               */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Zone class.                    */
/*       A Zone stores all the infos that */
/*  are used in a particular place. It    */
/*  contains the collision and distortion */
/*  maps, all the doodads that are ren-   */
/*  dered, the links between zones, ...   */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge/hge.h"

#include "wowrl_structs.h"

#include "wowrl_zone.h"

BGPart* Zone::GetBGPart( float x, float y )
{
    if ( (x > 0) && (x < iW) && (y > 0) && (y < iH) )
    {
        std::map<float, BGPart*>::iterator iter;
        float index = floor(y/iPartSize)*iW/iPartSize+floor(x/iPartSize);
        iter = lPartList.lower_bound(index);
        return iter->second;
    }
    else
    {
        return NULL;
    }
}

void Zone::DeleteThis()
{
	std::map<float, BGPart*>::iterator iterParts;
	for (iterParts = lPartList.begin(); iterParts != lPartList.end(); iterParts++)
	{
		delete iterParts->second->mBg;
		delete iterParts->second;
	}
}

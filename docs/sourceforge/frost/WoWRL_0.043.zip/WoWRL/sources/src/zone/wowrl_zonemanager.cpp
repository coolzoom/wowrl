/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              .... source               */
/*                                        */
/*  ## : ...                              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"

#include "wowrl_zonemanager.h"

extern HGE *hge;

using namespace std;

ZoneManager::ZoneManager()
{
	fBgX = 0.0f;
	fBgY = 0.0f;
	bDebugParser = false;
}

ZoneManager::~ZoneManager()
{
	mZoneMgr = NULL;
}

ZoneManager* ZoneManager::mZoneMgr = NULL;

ZoneManager* ZoneManager::GetSingleton()
{
	if (mZoneMgr == NULL)
		mZoneMgr = new ZoneManager;
	return mZoneMgr;
}

void ZoneManager::DeleteDoodads()
{
	map<string, Doodad*>::iterator iterDoodad;
	for (iterDoodad = mActualZone.lDoodadList.begin(); iterDoodad != mActualZone.lDoodadList.end(); iterDoodad++)
	{
		//iterDoodad->second->DeleteThis();
		delete iterDoodad->second;
	}
	mActualZone.lDoodadList.clear();
}

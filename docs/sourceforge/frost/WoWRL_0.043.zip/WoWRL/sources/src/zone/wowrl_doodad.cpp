/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Doodad source             */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Doodad class.                  */
/*       A Doodad is a part of the back-  */
/*  ground that can be rendered above     */
/*  units, but it can also be rendered    */
/*  beneath units, depending on depth.    */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include <string>
#include "hge/hgevector.h"
#include "hge/hgesprite.h"

#include "wowrl_distortion.h"
#include "wowrl_global.h"
#include "wowrl_point.h"
#include "wowrl_scenemanager.h"
#include "wowrl_unit.h"

#include "wowrl_doodad.h"


extern HGE *hge;
extern SceneManager *mSceneMgr;

Doodad::Doodad() : fZ(-1.0f), bLocked(true)
{
	mSprite = NULL;
	mBox = NULL;
}

Doodad::~Doodad()
{
    this->DeleteThis();
}

void Doodad::SetX(float x) {fX = x;}
void Doodad::SetY(float y) {fY = y;}
float Doodad::GetX() {return fX+mSceneMgr->fGX;}
float Doodad::GetY() {return fY+mSceneMgr->fGY;}

Point Doodad::GetPoint()
{
	Point p;
	p.fX = fX;
	p.fY = fY;
	return p;
}

float Doodad::GetZ()
{
	// Check Z value only the first time or if the doodad is not locked
	if ( (fZ==-1.0f) || (!bLocked) )
	{
		fZ = fY;
	}
    return fZ;
}

void Doodad::SetBox()
{
	fOldX = mSceneMgr->fGX;
	fOldY = mSceneMgr->fGY;
	if (mBox != NULL) {delete mBox;}
	mBox = new hgeRect();
	this->mSprite->GetBoundingBox(this->GetX(), this->GetY(), mBox);
}

hgeRect* Doodad::GetBox()
{
	if ( (fOldX != mSceneMgr->fGX) || (fOldY != mSceneMgr->fGY) )
	{
		mBox->Set
		(
			mBox->x1+(mSceneMgr->fGX-fOldX),
			mBox->y1+(mSceneMgr->fGY-fOldY),
			mBox->x2+(mSceneMgr->fGX-fOldX),
			mBox->y2+(mSceneMgr->fGY-fOldY)
		);
		fOldX = mSceneMgr->fGX;
		fOldY = mSceneMgr->fGY;
	}
    return mBox;
}

void Doodad::DeleteThis()
{
	if (mBox != NULL) {delete mBox; mBox=NULL;}
}

float Doodad::GetRelativeDepth(Point p)
{
	/* [#] This function returns the relative depth value between this doodad and
	/* the given point. It is used to build the render list, as it will tell if
	/* the object on the point is behind or above the doodad.
	*/

	float relz;
	hgeVector pvec;
	pvec.x = p.fX-fX;
	pvec.y = p.fY-fY;
	hgeVector ovec;
	ovec.x = cos(DegToRad(fOrientation));
	ovec.y = -sin(DegToRad(fOrientation));

	// We get the distance between p and the virtual line which represents the orientation
	Point line;
	line.fX = fX + ovec.x;
	line.fY = fY + ovec.y;
	float u = (p.fX-fX)*ovec.x + (p.fY-fY)*ovec.y;
	Point nP;
	nP.fX = fX + u*(ovec.x);
	nP.fY = fY + u*(ovec.y);
	relz = Dist(p, nP);

	float angle = ovec.Angle()-pvec.Angle();
	angle = RadToDeg(angle);
	if (angle < -180.0f)
	{
		angle = 360.0f+angle;
	}

	/* Now, angle is a float value that is ranging between -180 and 180.
	/*  # angle = 0 or -180 : the point is at the same depth as the doodad.
	/*	   	-> 0, the unit is rendered behind (first), -180 it is rendered above (last)
	/*  # angle < 0 : the point is nearer than the doodad.
	/*    	-> the unit is rendered above (last)
	/*	# angle > 0 : the point is more far than the doodad.
	/*		-> the unit is rendered behind (first)
	*/

	if (angle >= 0.0f)
	{
		return -relz;
	}
	else if (angle < 0.0f)
	{
		return relz;
	}
}

bool Doodad::Intersects( Object o )
{
	if (o.iType == OBJ_TYPE_UNIT)
	{
		Unit* u = static_cast<Unit*>(o.mPtr);
		return this->GetBox()->Intersect(u->GetBox());
	}
	else if (o.iType == OBJ_TYPE_DOODAD)
	{
		Doodad* d = static_cast<Doodad*>(o.mPtr);
		return this->GetBox()->Intersect(d->GetBox());
	}
}

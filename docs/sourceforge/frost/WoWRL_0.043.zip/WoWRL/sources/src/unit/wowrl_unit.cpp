/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Unit source               */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Unit class.                    */
/*       A Unit is a character that can   */
/*  move, attack, heal, resurrect, etc.   */
/*  It is the most important class of the */
/*  game. Most of the functions are self  */
/*  explanatory, so they are not heavily  */
/*  commented.                            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include <map>
#include <string>
#include <vector>
#include "hge/hge.h"
#include "hge/hgeanim.h"
#include "hge/hgevector.h"

#include "wowrl_global.h"
#include "wowrl_doodad.h"
#include "wowrl_distortion.h"
#include "wowrl_scenemanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_unitmanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_zonemanager.h"
#include "wowrl_statusbar.h"
#include "wowrl_pathfinding.h"
#include "wowrl_lua.h"
#include "wowrl_model.h"
#include "wowrl_modelmanager.h"
#include "wowrl_animmanager.h"

#include "wowrl_unit.h"

#define ATTACK_NO      0
#define ATTACK_PREPARE 1
#define ATTACK_CAST    2
#define ATTACK_ATTACK  3

extern HGE *hge;
extern SceneManager *mSceneMgr;
extern InputManager *mInputMgr;
extern GUIManager *mGUIMgr;
extern TimeManager *mTimeMgr;
extern UnitManager *mUnitMgr;
extern GFXManager *mGFXMgr;
extern ZoneManager *mZoneMgr;
extern ModelManager *mModelMgr;

using namespace std;

Unit::Unit()
{
	fSpeed = 150.0f;
	iLevel = 1;
	this->Init();
}

Unit::Unit( string name, float x, float y, int lvl, Race* r, int gender, Class* c, float speed ) :
            sName(name),
            fX(x), fY(y),
            iLevel(lvl),
            fSpeed(speed)
{
	this->Init();
	this->SetRace(r, gender);
	this->SetClass(c);
	this->UpdateStats();
}

Unit::~Unit()
{
    this->DeleteThis();
}

void Unit::Init()
{
    iID = -1;
    fScale = 1.0f;
	fOrientation = 0.0f;
	fActionTimer = 0.0f;
	fRegenTimer = 0.0f;
	fGlobalCoolDown = 0.0f;
	iPointIndice = 0;
	iWaypointIndice = 0;
	iTextNbr = 0;
	sAnimState = "stand";
	iAttackState = ATTACK_NO;
	sOldAnimState = "";
	fRZ = 0.0f;
	mTarget = NULL;
	bHostile = false;
	bSelected = false;
	bAttacking = false;
	bHealing = false;
	bResurrecting = false;
	bEmote = false;
	bInCombat = false;
	bFXPlaying = false;
	bFollowing = false;
	bFollowingWp = false;
	bOrderGiven = false;
	bDead = false;
	bDying = false;
	bFinishAnim = true;
	bHidden = false;
	bMoving = false;
	bAggro = false;
	bRebuildAggroList = false;
	bRebuildAggroedList = false;
	bPathRequested = false;
	bPathObtained = false;
	mBox = NULL;
	mSBox = NULL;
	mModel = NULL;

	fOldGX = mSceneMgr->fGX;
	fOldGY = mSceneMgr->fGY;
	cColor.fR = 0;
	cColor.fG = 0;
	cColor.fB = 0;

	mStats.iStrengh = ToInt(250*iLevel/70.0f);
	mStats.iAgility = ToInt(250*iLevel/70.0f);
	mStats.iStamina = ToInt(250*iLevel/70.0f);
	mStats.iIntellect = ToInt(250*iLevel/70.0f);
	mStats.iSpirit = ToInt(250*iLevel/70.0f);
	mStats.iSpellPower = ToInt(250*iLevel/70.0f);
	mStats.iAttackPower = ToInt(250*iLevel/70.0f);
	mStats.iRegen5sHealth = ToInt(15*iLevel/70.0f);
	mStats.iRegen5sMana = ToInt(25*iLevel/70.0f);
	mStats.iCrit = ToInt(0.20f*iLevel/70.0f);
	mStats.iCritSpell = ToInt(0.20f*iLevel/70.0f);
	mStats.iHit = ToInt(0.10f*iLevel/70.0f);
	mStats.iPenetration = ToInt(30*iLevel/70.0f);

	mStats.iHealth = 0;
	mStats.iMana = 0;
	fHealth = 1;
	fMana = 1;
	fAggroRange = 35.0f;

}

void Unit::SetID(int id)
{
    if (iID == -1)
        iID = id;
}

int Unit::GetID()
{
    return iID;
}

float Unit::GetX()
{
	return fX+mSceneMgr->fGX;
}

float Unit::GetY()
{
	return fY+mSceneMgr->fGY;
}

float Unit::GetGX()
{
	return fX;
}

float Unit::GetGY()
{
	return fY;
}

Point Unit::GetPoint()
{
	Point p;
	p.fX = this->GetX();
	p.fY = this->GetY();
	return p;
}

Point Unit::GetGPoint()
{
	Point p;
	p.fX = fX;
	p.fY = fY;
	return p;
}

float Unit::GetRot()
{
	return fRot;
}

float Unit::GetSpeed()
{
	return fSpeed;
}

// Return the scale factor given by the distortion map
float Unit::GetScale()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::GetScale", false);
		Chrono c(prof);
	#endif
	//float mdist = GetPointDistortion(ToInt(fX), ToInt(fY));
	fScale = mZoneMgr->mActualZone.fDistScaleMin/*-mdist*(mZoneMgr->mActualZone.fDistScaleMin-mZoneMgr->mActualZone.fDistScaleMax)*/;
	return fScale;
}

// Return the vertical scale factor the same way
float Unit::GetVScale()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::GetVScale", false);
		Chrono c(prof);
	#endif
	//float mdist = GetPointDistortion(ToInt(fX), ToInt(fY));
	fVScale = mZoneMgr->mActualZone.fDistVScaleMin/*-mdist*(mZoneMgr->mActualZone.fDistVScaleMin-mZoneMgr->mActualZone.fDistVScaleMax)*/;
	return fVScale;
}

// And the rotation of the sprite, the same way too
float Unit::GetAngle()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::GetAngle", false);
		Chrono c(prof);
	#endif
	float mdist = GetPointDistortion(ToInt(fX), ToInt(fY));
	float angle = mZoneMgr->mActualZone.fDistAngleMin-mdist*(mZoneMgr->mActualZone.fDistAngleMin-mZoneMgr->mActualZone.fDistAngleMax);
	angle = angle*2*M_PI/360;
	return angle;
}

// Return the global depth acording to the depth map
float Unit::GetZ()
{
	return fY;
}

float Unit::GetRZ()
{
	if (fRZ == 0.0f)
		return fY;
	else
		return fRZ;
}

// The relative depth is just a difference between two global depth
float Unit::GetRelativeDepth(Point p)
{
	return p.fY-fY;
}

// Return the shadow color to apply the sprite when rendering
float Unit::GetShadow()
{
	fShadow = GetPointShadow(ToInt(fX), ToInt(fY));
	return fShadow;
}

string Unit::GetAnimState()
{
	return sAnimState;
}

/*hgeAnimation* Unit::SetAnimation( int frameNbr, bool keepSameFrame )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::SetAnimation", false);
		Chrono c(prof);
	#endif
	int old_frame;
	if (mAnimation != NULL)
		old_frame = mAnimation->GetFrame();
	else
		old_frame = 0;

	if (mAnimation != NULL) {delete mAnimation;}
		mAnimation = new hgeAnimation(*mGFXMgr->lPAnimList[mClass->sAnimSetName].lAnimations[sAnimState].lStateList[iRot]);
	if (frameNbr == -1 && !keepSameFrame)
	{
		frameNbr = hge->Random_Int(0, mAnimation->GetFrames());
	}
	else if (keepSameFrame)
	{
		if (old_frame > mAnimation->GetFrames())
		{
			frameNbr = 0;
		}
		else
		{
			frameNbr = old_frame;
		}
	}

	mAnimation->SetFrame(frameNbr);
}*/

// Return the actual animation of the unit an update it if needed
/*hgeAnimation* Unit::GetAnimation()
{
	if (mAnimation == NULL)
		this->SetAnimation();

	return mAnimation;
}*/

// The same kind of function for animated effects
map<string, Effect> Unit::GetEffectList()
{
	return lEffectList;
}


/*string Unit::GetEffectName()
{
	return lEffectListstate;
}*/

// Initialise the unit's bounding box
void Unit::SetBox()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::SetBox", false);
		Chrono c(prof);
	#endif
	if (mBox != NULL) {delete mBox;}
	mBox = new hgeRect();
	if (mModel != NULL)
	{
        if (mModel->GetSprite() != NULL)
        {
            mModel->GetSprite()->GetBoundingBox(GetX(), GetY(), mBox);
        }
	}
	/***/
}

// And retrieve it, updating when needed
hgeRect* Unit::GetBox()
{
	if (mBox == NULL)
		this->SetBox();

	return mBox;
}

void Unit::SetStandBox()
{
	if (mSBox != NULL) {delete mSBox;}
	mSBox = new hgeRect();
	if (mModel != NULL)
	{
        if (mModel->GetSprite() != NULL)
        {
            mModel->GetSprite()->GetBoundingBox(GetX(), GetY(), mSBox);
        }
	}
	/***/
}

hgeRect* Unit::GetStandBox()
{
	if (mSBox == NULL)
		this->SetStandBox();

	return mSBox;
}

// Get the unit's color (shadow)
RGB Unit::GetColor()
{
	if (fShadow+cColor.fR > 255)
	{
		cColor.fR = 255-fShadow;
	}
	if (fShadow+cColor.fG > 255)
	{
		cColor.fG = 255-fShadow;
	}
	if (fShadow+cColor.fB > 255)
	{
		cColor.fB = 255-fShadow;
	}
	return cColor;
}

// Get the status bar taking into account the unit state
StatusBar* Unit::GetStatusBar()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::GetStatusBar", false);
		Chrono c(prof);
	#endif
	if (mGUIMgr->lStatusBarList.find(iID) == mGUIMgr->lStatusBarList.end())
	{
		// If the status bar does not yet exists, add it to the statusBarList
		mGUIMgr->CreateStatusBar(this);
		mStatusBar = &mGUIMgr->lStatusBarList[iID];
		if (mStatusBar->mGauge != NULL) {delete mStatusBar->mGauge;}
		mStatusBar->mGauge = new hgeSprite(*mGUIMgr->mStatusBGauge);
		mStatusBar->mBgLeft = new hgeSprite(*mGUIMgr->mStatusBDeadBgLeft);
		mStatusBar->mBgMiddle = new hgeSprite(*mGUIMgr->mStatusBDeadBgMiddle);
		mStatusBar->mBgRight = new hgeSprite(*mGUIMgr->mStatusBDeadBgRight);

		mStatusBar->fSize = mRace->fStatusBarSize*fScale;

		if (mStatusBar->fSize<18)
		{
			mStatusBar->fSize = 18;
		}

		DWORD color = ARGB(180, 255, 255, 255);
		mStatusBar->mBgLeft->SetColor(color);
		mStatusBar->mBgRight->SetColor(color);
		mStatusBar->mBgMiddle->SetColor(color);
	}

	RGB color;

	if (this->IsDead())
	{
		//mStatusBar->state = zone.respawn[sName]/zone.respawnTime;
		mStatusBar->fState = 1.0f;
		color.fR = 150; color.fG = 150; color.fB = 150;
		mStatusBar->cColor = color;
	}
	else
	{
		mStatusBar->fState = fHealth/mStats.iHealth;
		if (mStatusBar->fState >= 0.5f)
		{
			RGB color;
			color.fR = (1-mStatusBar->fState)*2*255; color.fG = 255; color.fB = 0;
			mStatusBar->cColor = color;
		}
		if (mStatusBar->fState < 0.5f)
		{
			RGB color;
			color.fR = 255; color.fG = mStatusBar->fState*2*255; color.fB = 0;
			mStatusBar->cColor = color;
		}
	}
	return mStatusBar;
}

// Determine whether the unit collides with a given object
bool Unit::Intersects( Object o )
{
	if (o.iType == OBJ_TYPE_UNIT)
	{
		Unit* u = static_cast<Unit*>(o.mPtr);
		return this->GetBox()->Intersect(u->GetBox());
	}
	else if (o.iType == OBJ_TYPE_DOODAD)
	{
		Doodad* d = static_cast<Doodad*>(o.mPtr);
		return this->GetBox()->Intersect(d->GetBox());
	}
}


void Unit::SetX( float x )
{
	fX = x-mSceneMgr->fGX;
}

void Unit::SetY( float y )
{
	fY = y-mSceneMgr->fGY;
}

void Unit::SetRot( float rot )
{
	if (fRot != rot)
	{
		fRot = rot;
		mModel->SetOrientation(Vector3(0, rot, 0));
	}
}

int AngleToRot( float angle )
{
    int rot = 0;

	angle = angle/(2*M_PI);

	if (angle<0)
	{
		angle = 1+angle;
	}
	angle = 360*angle;

	if ((angle>22.5) && (angle<=67.5))
		rot = 5;
	else if ((angle>67.5) && (angle<=112.5))
		rot = 4;
	else if ((angle>112.5) && (angle<=157.5))
		rot = 3;
	else if ((angle>157.5) && (angle<=202.5))
		rot = 2;
	else if ((angle>202.5) && (angle<=247.5))
		rot = 1;
	else if ((angle>247.5) && (angle<=292.5))
		rot = 0;
	else if ((angle>292.5) && (angle<=337.5))
		rot = 7;
	else if ((angle>337.5) || (angle<=22.5))
		rot = 6;

    return rot;
}

void Unit::SetSpeed( float speed )
{
	fSpeed = speed;
}

void Unit::SetScale( float scale )
{
	fScale = scale;
}

void Unit::SetAnimState( AnimID state, bool pauseAfter )
{
	if (mModel != NULL)
	{
	    if (mModel->mAnimMgr->GetAnimID() != state)
	    {
            mModel->mAnimMgr->SetAnim(state, pauseAfter);
            mModel->mAnimMgr->Play();
	    }
	}
}

void Unit::AddEffect( string effectstate )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::addEffect", false);
		Chrono c(prof);
	#endif
	bFXPlaying = true;
	if (lEffectList.find(effectstate) != lEffectList.end())
	{
		Effect* e = &lEffectList[effectstate];
		e->bEnded = false;
		if (e->fFadeIn != 0.0f)
			e->bFade = true;
		e->bFadedIn = false;
		e->bFadedOut = false;
		e->fFadeOut = mGFXMgr->lFXList[effectstate].mAFX.fFadeOut;
		e->fLifeTimer = 0.0f;
		e->fFadeTimer = 0.0f;
		if (e->iType == FX_ANIMATED_EFFECT)
			e->mAnim->Play();
		else if (e->iType == FX_PARTICLE_SYSTEM)
			e->mPSys->Fire();
	}
	else
	{
		Effect e;
		SEffect* se = &mGFXMgr->lFXList[effectstate];
		e.sName = se->sName;
		e.iType = se->iType;
		e.fLife = se->fLife;
		e.bEnded = false;
		e.fLifeTimer = 0.0f;
		e.fOffX = se->fOffX;
		e.fOffY = se->fOffY;
		if (se->iType == FX_ANIMATED_EFFECT)
		{
			e.fFadeIn = se->mAFX.fFadeIn;
			e.fFadeOut = se->mAFX.fFadeOut;
			e.fScale = se->mAFX.fScale;
			if (e.fFadeIn != 0.0f)
				e.bFade = true;
			e.bFadedIn = false;
			e.bFadedOut = false;
			e.fFadeTimer = 0.0f;
			if (se->mAFX.iType == FX_SINGLE_ANGLE_ANIM)
				e.mAnim = new hgeAnimation(*mGFXMgr->lFXList[effectstate].mAFX.mAnim);
			else if (se->mAFX.iType == FX_MULTI_ANGLE_ANIM)
			{
			    e.iRot = AngleToRot(fRot);
				e.mAnim = new hgeAnimation(*mGFXMgr->lFXList[effectstate].mAFX.lStateList[e.iRot]);
			}
			e.mAnim->Play();
		}
		else if (se->iType == FX_PARTICLE_SYSTEM)
		{
			e.fDelay = se->mPFX.fDelay;
			e.mPSys = new hgeParticleSystem(*mGFXMgr->lFXList[effectstate].mPFX.mPSys);
			e.mPSys->Fire();
		}

		lEffectList[effectstate] = e;
	}
}

void Unit::SetColor( RGB color )
{
	cColor = color;
}

void Unit::SetColor( int R, int G, int B )
{
	cColor.fR = R;
	cColor.fG = G;
	cColor.fB = B;
}

void Unit::DeleteThis()
{
	if (mBox != NULL) {delete mBox; mBox=NULL;}
	if (mSBox != NULL) {delete mSBox; mSBox=NULL;}
	if (mModel != NULL)
	{
	    mModelMgr->RemoveModel(mModel);
	    delete mModel;
	    mModel=NULL;
    }
	map<string, Effect>::iterator iterFX;
	while (!lEffectList.empty())
	{
		iterFX = lEffectList.begin();
		Effect* e = &iterFX->second;
		if (e->mAnim != NULL) {delete e->mAnim; e->mAnim=NULL;}
		if (e->mPSys != NULL) {delete e->mPSys; e->mPSys=NULL;}
		lEffectList.erase(iterFX);
	}
}

/********** Mixed funcs ***********/

Class* Unit::GetClass()
{
	return mClass;
}

Race* Unit::GetRace()
{
	return mRace;
}

Model* Unit::GetModel()
{
    return mModel;
}

void Unit::SetClass( Class* c )
{
	mClass = c;
	mSpec = mClass->mDefaultSpec;
	mSpell = mSpec->mDefaultSpell;
	mStats.iPowerType = mClass->iPowerType;
}

void Unit::SetRace( Race* r, int gender )
{
    mRace = r;

    if (mModel != NULL)
    {
        mModelMgr->RemoveModel(mModel);
        delete mModel;
        mModel = NULL;
    }

    if (gender == GENDER_MALE)
        mModel = mModelMgr->CopyModel(r->mMaleModel);
    else if (gender == GENDER_FEMALE)
        mModel = mModelMgr->CopyModel(r->mFemaleModel);
    else
        mModel = NULL;

    if (mModel != NULL)
    {
        mModel->SetParent(this);
        SetRot(hge->Random_Float(0,2*M_PI));

        // Show base submeshes
        mModel->Hide();
        // Body
        int ID = mModel->GetSubMeshID(MODEL_SUBMCAT_BODY, 0);
        while (ID != -1)
        {
            mModel->Show(ID);
            mModel->SetSubMeshTexture(ID, mModel->mBodyTex);
            ID = mModel->GetSubMeshID(MODEL_SUBMCAT_BODY, 0);
        }
        // Hands
        ID = mModel->GetSubMeshID(MODEL_SUBMCAT_GLOVES, 1);
        while (ID != -1)
        {
            mModel->Show(ID);
            mModel->SetSubMeshTexture(ID, mModel->mBodyTex);
            ID = mModel->GetSubMeshID(MODEL_SUBMCAT_GLOVES, 1);
        }
        // Legs
        ID = mModel->GetSubMeshID(MODEL_SUBMCAT_LEGS_LOW, 1);
        while (ID != -1)
        {
            mModel->Show(ID);
            mModel->SetSubMeshTexture(ID, mModel->mBodyTex);
            ID = mModel->GetSubMeshID(MODEL_SUBMCAT_LEGS_LOW, 1);
        }
        ID = mModel->GetSubMeshID(MODEL_SUBMCAT_LEGS_UP, 1);
        while (ID != -1)
        {
            mModel->Show(ID);
            mModel->SetSubMeshTexture(ID, mModel->mBodyTex);
            ID = mModel->GetSubMeshID(MODEL_SUBMCAT_LEGS_UP, 1);
        }
        // Ears
        ID = mModel->GetSubMeshID(MODEL_SUBMCAT_EARS, 1);
        while (ID != -1)
        {
            mModel->Show(ID);
            mModel->SetSubMeshTexture(ID, mModel->mBodyTex);
            ID = mModel->GetSubMeshID(MODEL_SUBMCAT_EARS, 1);
        }
        // Back
        ID = mModel->GetSubMeshID(MODEL_SUBMCAT_CAPES, 1);
        while (ID != -1)
        {
            mModel->Show(ID);
            mModel->SetSubMeshTexture(ID, mModel->mBodyTex);
            ID = mModel->GetSubMeshID(MODEL_SUBMCAT_CAPES, 1);
        }
    }
}

void Unit::RenderSprite()
{
    if (mModel != NULL)
    {
        mModel->Render();
    }
}

void Unit::LookAt(Point p)
{
    hgeVector vec(GetGX()-p.fX, (GetGY()-p.fY)/mSceneMgr->fAspectRatio);
    SetRot(vec.Angle()+M_PI_2);
}

/********* Gameplay funcs **********/

string Unit::GetName()
{
	return sName;
}

int Unit::GetLevel()
{
	return iLevel;
}

Spell* Unit::GetDefaultSpell()
{
	return this->mClass->mDefaultSpec->mDefaultSpell;
}

bool Unit::IsHostile( Unit* u )
{
	if (u == NULL)
		return bHostile;
	else
		return ((u->IsHostile() && !bHostile) || (!u->IsHostile() && bHostile));
}

bool Unit::IsSelected()
{
	return bSelected;
}

bool Unit::IsAttacking()
{
	return bAttacking;
}

bool Unit::IsActing(bool onlyActions)
{
    if (onlyActions)
        return (bAttacking || bHealing || bResurrecting);
    else
        return (bAttacking || bHealing || bResurrecting || bEmote);
}

bool Unit::IsDead()
{
	return bDead;
}

float Unit::GetHealth()
{
	return fHealth;
}

float Unit::GetMaxHealth()
{
	return mStats.iHealth;
}

float Unit::GetMana()
{
	return fMana;
}

float Unit::GetMaxMana()
{
	return mStats.iMana;
}

float Unit::GetActionState()
{
	if (iAttackState != ATTACK_ATTACK)
	{
		return fActionTimer/mSpell->fCastTime;
	}
	else
	{
		return 1.0f;
	}
}

Spell* Unit::GetSpell()
{
	return mSpell;
}

void Unit::SetHostile( bool hostile )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::SetHostile", false);
		Chrono c(prof);
	#endif
	if (bHostile != hostile)
	{
		if (hostile == true)
		{
			mUnitMgr->lHostileList[iID] = this;
			map<Unit*, float>::iterator iter;
			for (iter = lAggroedList.begin(); iter != lAggroedList.end(); iter++)
			{
				iter->first->RebuildAggroList();
			}
			lAggroedList.clear();
			bHostile = true;

			this->SetSelected(false);
		}
		else
		{
			if (mUnitMgr->lHostileList.find(iID) != mUnitMgr->lHostileList.end())
			{
				mUnitMgr->lHostileList.erase(iID);
				bHostile = false;
			}
			else
			{
				Log("# WARNING # : Trying to remove \"%s\" from hostile unit list : not found.", sName.c_str());
				return;
			}
		}
	}
}

void Unit::SetSelected( bool selected )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::SetSelected", false);
		Chrono c(prof);
	#endif
	if (bSelected != selected)
	{
		if (selected == true)
		{
			mUnitMgr->lSelectedList[iID] = this;
			bSelected = true;
		}
		else
		{
			if (mUnitMgr->lSelectedList.find(iID) != mUnitMgr->lSelectedList.end())
			{
				mUnitMgr->lSelectedList.erase(iID);
				bSelected = false;
			}
			else
			{
				Log("# WARNING # : Trying to remove \"%s\" from selected unit list : not found.", sName.c_str());
				return;
			}
		}
	}
}

void Unit::SetMaxHealth( float u_max_health, bool fill )
{
	if (u_max_health > 0)
	{
		mStats.iHealth = ToInt(u_max_health);
		if (fill || fHealth > mStats.iHealth)
			fHealth = mStats.iHealth;

		//m_force_max_health = true;
	}
}

void Unit::SetMaxMana( float u_max_mana, bool fill )
{
	if (u_max_mana > 0)
	{
		mStats.iMana = ToInt(u_max_mana);
		if (fill || fMana > mStats.iMana)
			fMana = mStats.iMana;

		//m_force_max_mana = true;
	}
}

// Order the unit to target another
void Unit::Target( Unit* u_target )
{
	mTarget = u_target;
}

Unit* Unit::GetTarget()
{
	return mTarget;
}

// Order the unit to beggin casting a given spell
void Unit::Incant( Spell* spell, Unit* target = NULL )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::incant", false);
		Chrono c(prof);
	#endif
	if (bOrderGiven && (spell->fCastTime > 0.0f))
	{
		mUnitMgr->lOrderList.erase(iID);
		bOrderGiven = false;
	}
	string reason;
	if (this->IsCastable(spell, &reason))
	{
		mSpell = spell;
		if (target != NULL)
			this->Target(target);
		if (mTarget != NULL)
		{
			if (!mSpell->bSelfOnly)
			{
				this->LookAt(Point(mTarget->GetGX(), mTarget->GetGY()));
			}

			this->SetAnimState(mSpell->mIncantAnim);
			iAttackState = ATTACK_PREPARE;

			if (mSpell->bGCD)
                fGlobalCoolDown = mClass->fGCD;

			string exec = "";
			exec += "local unit = \"" + ToString(iID) + "\";\n";
			exec += "local target = \"" + mTarget->GetName() + "\";\n";
			exec += "local spell = Spells[\"" + mSpell->sName + "\"];\n";
			exec += mSpell->sOnCastBegin + "\n";
			int error = luaL_dostring(mSceneMgr->luaVM, exec.c_str());
			if (error) LUA::LogL(mSceneMgr->luaVM);

			if (mSpell->bHasCastEffect)
			{
				bFXPlaying = true;
				this->AddEffect(mSpell->sCastEffect);
			}
		}
	}
	else
	{
		if (!this->IsHostile())
			mGUIMgr->AddErrorMessage(sName + " : " + mSceneMgr->tStrTable->GetString(reason.c_str()));
	}
}

// Tell the unit to cast its spell if it has enough mana/rage/energy
// and if it is in range.
bool Unit::Cast( Spell* spell )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::cast", false);
		Chrono c(prof);
	#endif
	bool casted;

	if (spell->bSelfOnly || IsTargetInRange(spell))
	{
		if (spell->fCost == 0.0f && spell->fCostP == 0.0f)
		{
			if (spell->bPutsInCombat)
				this->SetInCombat();
			casted = true;
		}
		else if (spell->fCostP != 0.0f)
		{
			if ( (fMana-spell->fCostP*mStats.iMana) < 0.0f)
				casted = false;
			else
			{
				fMana -= ToInt(spell->fCostP*mStats.iMana);
				if (spell->bPutsInCombat)
					this->SetInCombat();
				casted = true;
			}
		}
		else
		{
			if ( (fMana-spell->fCost) < 0.0f)
				casted = false;
			else
			{
				fMana -= ToInt(spell->fCost);
				if (spell->bPutsInCombat)
					this->SetInCombat();
				casted = true;
			}
		}
	}
	else
		casted = false;

	if (casted)
	{
		string exec = "";
		exec += "local unit = \"" + ToString(iID) + "\";\n";
		exec += "local target = \"" + mTarget->GetName() + "\";\n";
		exec += "local spell = Spells[\"" + mSpell->sName + "\"];\n";
		exec += mSpell->sOnCasted + "\n";
		int error = luaL_dostring(mSceneMgr->luaVM, exec.c_str());
		if (error) LUA::LogL(mSceneMgr->luaVM);
		return true;
	}
	else
		return false;
}

// Return true if the spell is castable
bool Unit::IsCastable( Spell* spell, string* reason, bool ignoreRange, bool ignoreTargetType )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::IsCastable", false);
		Chrono c(prof);
	#endif
	if (this->IsDead())
	{
		if (reason != NULL)
			*reason = "error_is_dead";
		return false;
	}

	if (!spell->bUsableInCombat)
	{
		if (bInCombat)
		{
			if (reason != NULL)
				*reason = "error_is_in_combat";
			return false;
		}
	}

	if (spell->fCostP != 0.0f)
	{
		if ( (fMana-spell->fCostP*mStats.iMana) < 0.0f)
		{
			if (reason != NULL)
				*reason = "error_out_of_mana";
			return false;
		}
	}
	else if (spell->fCost != 0.0f)
	{
		if ( (fMana-spell->fCost) < 0.0f)
		{
			if (reason != NULL)
				*reason = "error_out_of_mana";
			return false;
		}
	}

	if (!spell->bSelfOnly && !ignoreRange)
	{
		if (!this->IsTargetInRange(spell))
		{
			if (reason != NULL)
				*reason = "error_out_of_range";
			return false;
		}
	}

	if ( (spell->iTargetType != SPELL_TARGET_ALL) && !ignoreTargetType && !spell->bSelfOnly )
	{
		if (mTarget != NULL)
		{
			if (mTarget->IsDead())
			{
				if ( (spell->iTargetType == SPELL_TARGET_HOSTILES) ||
					 (spell->iTargetType == SPELL_TARGET_FRIENDS) )
				{
					if (reason != NULL)
						*reason = "error_wrong_ttype_dead";
					return false;
				}
				if ( (spell->iTargetType == SPELL_TARGET_DEAD_FRIENDS) &&
					 (mTarget->IsHostile(this)) )
				{
					if (reason != NULL)
						*reason = "error_wrong_ttype_h";
					return false;
				}
				if ( (spell->iTargetType == SPELL_TARGET_DEAD_HOSTILES) &&
					 (!mTarget->IsHostile(this)) )
				{
					if (reason != NULL)
						*reason = "error_wrong_ttype_f";
					return false;
				}
			}
			else
			{
				if ( (spell->iTargetType == SPELL_TARGET_DEADS) ||
					 (spell->iTargetType == SPELL_TARGET_DEAD_FRIENDS) ||
					 (spell->iTargetType == SPELL_TARGET_DEAD_HOSTILES) )
				{
					if (reason != NULL)
						*reason = "error_wrong_ttype_living";
					return false;
				}
				if ( (spell->iTargetType == SPELL_TARGET_HOSTILES) &&
					 (!mTarget->IsHostile(this)) )
				{
					if (reason != NULL)
						*reason = "error_wrong_ttype_f";
					return false;
				}
				if ( (spell->iTargetType == SPELL_TARGET_FRIENDS) &&
					 (mTarget->IsHostile(this)) )
				{
					if (reason != NULL)
						*reason = "error_wrong_ttype_h";
					return false;
				}
			}
		}
	}

	if (fGlobalCoolDown != 0.0f)
	{
	    if (reason != NULL)
			*reason = "error_gcd";
        return false;
	}

	return true;
}

// Cast a spell on the unit
void Unit::Receive( Spell* spell, Unit* caster )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::receive", false);
		Chrono c(prof);
	#endif
	string exec = "";
	exec += "local unit = \"" + ToString(caster->GetID()) + "\";\n";
	exec += "local target = \"" + ToString(iID) + "\";\n";
	exec += "local spell = Spells[\"" + spell->sName + "\"];\n";
	exec += spell->sOnImpact + "\n";
	int error = luaL_dostring(mSceneMgr->luaVM, exec.c_str());
	if (error) LUA::LogL(mSceneMgr->luaVM);
}

void Unit::Damage( Spell* spell, Unit* caster, int value, bool aggro )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::damage", false);
		Chrono c(prof);
	#endif
	this->SetInCombat();
	fHealth -= value;
	if (fHealth <= 0)
	{
		this->Die();
	}
	if ( aggro && this->IsHostile() && !caster->IsHostile() )
	{
		if (caster == mTarget)
			caster->AddAggroTo(this, value);
		else
		{
			if (!caster->IsInAggroListOf(this))
				this->AddUnitToAggroList(caster);
			float distance = Dist
			(
				this->GetX(), this->GetY()*mSceneMgr->fAspectRatio,
				caster->GetX(), caster->GetY()*mSceneMgr->fAspectRatio
			);

			if (distance <= 5.0f) // melee range
				caster->AddAggroTo(this, value*0.9f);
			else
				caster->AddAggroTo(this, value*0.7f);
		}
	}

	// Generate event
	Event e;
	e.iArgNbr = 1;
	e.bCumulable = true;
	string s;

	if (this->IsHostile())
	{
		if (spell->bMelee)
		{
			e.iID = EVENT_CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS;
			e.sName = "CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS";
			s = mSceneMgr->tStrTable->GetString("msg_creature_vs_party_hits");
		}
		else
		{
			e.iID = EVENT_CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMMAGE;
			e.sName = "CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMMAGE";
			s = mSceneMgr->tStrTable->GetString("msg_creature_vs_party_spell");
		}
	}
	else
	{
		if (spell->bMelee)
		{
			e.iID = EVENT_CHAT_MSG_COMBAT_PARTY_HITS;
			e.sName = "CHAT_MSG_COMBAT_PARTY_HITS";
			s = mSceneMgr->tStrTable->GetString("msg_party_hits");
		}
		else
		{
			e.iID = EVENT_CHAT_MSG_SPELL_PARTY_DAMAGE;
			e.sName = "CHAT_MSG_SPELL_PARTY_DAMAGE";
			s = mSceneMgr->tStrTable->GetString("msg_party_spell");
		}
	}

	s = ParseStringAttack(s, caster, spell, value);
	e.lArgList[0] = Argument(ARG_TYPE_STRING, s);
	mGUIMgr->lEventList.push_back(e);
}

void Unit::Heal( Unit* caster, int value, bool aggro )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::heal", false);
		Chrono c(prof);
	#endif
	if (caster->IsInCombat())
		this->SetInCombat();
	fHealth += value;
	if (fHealth > mStats.iHealth)
	{
		fHealth = mStats.iHealth;
	}
	if ( aggro && !this->IsHostile() && !caster->IsHostile() )
	{
		if (!this->lAggroedList.empty())
		{
			caster->SetInCombat();
			map<Unit*, float>::iterator iter;
			for (iter = this->lAggroedList.begin(); iter != this->lAggroedList.end(); iter++)
			{
				Unit* u = iter->first;
				if (!caster->IsInAggroListOf(u))
				{
					u->AddUnitToAggroList(caster);
				}
				if (caster == u->GetTarget())
					caster->AddAggroTo(u, value);
				else
				{
					float distance = Dist
					(
						u->GetX(), u->GetY()*mSceneMgr->fAspectRatio,
						caster->GetX(), caster->GetY()*mSceneMgr->fAspectRatio
					);

					if (distance <= 5.0f) // melee range
						caster->AddAggroTo(u, value*0.9f);
					else
						caster->AddAggroTo(u, value*0.7f);
				}
			}
		}
	}
}

float Unit::GetGCD()
{
    return fGlobalCoolDown;
}

int Unit::GetTextNbr()
{
	iTextNbr++;
	return iTextNbr;
}

int	Unit::GetPowerType()
{
	return mStats.iPowerType;
}

// Order the unit to stop doing what it does
void Unit::Stop(bool ignoreAnim)
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::stop", false);
		Chrono c(prof);
	#endif
	if (bAttacking == true)
	{
		if (mSpell->bHasCastEffect)
		{
			Effect* e = &lEffectList[mSpell->sCastEffect];
			if (e->fFadeOut == 0.0f)
			{
				e->bEnded = true;
			}
			else
			{
				e->bFadedIn = true;
				e->bFade = true;
			}
		}
		if (!ignoreAnim)
            this->SetAnimState(ANIM_STAND);
		iAttackState = ATTACK_NO;
		fActionTimer = 0.0f;
		mUnitMgr->lAttackerList.erase(iID);
		mUnitMgr->lActingList.erase(iID);
		bAttacking = false;
	}
	if (bHealing == true)
	{
		if (mSpell->bHasCastEffect)
		{
			Effect* e = &lEffectList[mSpell->sCastEffect];
			if (e->fFadeOut == 0.0f)
			{
				e->bEnded = true;
			}
			else
			{
				e->bFadedIn = true;
				e->bFade = true;
			}
		}
		if (!ignoreAnim)
            this->SetAnimState(ANIM_STAND);
		iAttackState = ATTACK_NO;
		fActionTimer = 0.0f;
		mUnitMgr->lHealerList.erase(iID);
		mUnitMgr->lActingList.erase(iID);
		bHealing = false;
	}
	if (bResurrecting == true)
	{
		if (mSpell->bHasCastEffect)
		{
			Effect* e = &lEffectList[mSpell->sCastEffect];
			if (e->fFadeOut == 0.0f)
			{
				e->bEnded = true;
			}
			else
			{
				e->bFadedIn = true;
				e->bFade = true;
			}
		}
		if (!ignoreAnim)
            this->SetAnimState(ANIM_STAND);
		iAttackState = ATTACK_NO;
		fActionTimer = 0.0f;
		mUnitMgr->lReserList.erase(iID);
		mUnitMgr->lActingList.erase(iID);
		bResurrecting = false;
	}
	if ( (this->bFollowing == true) || (this->bMoving == true) )
	{
		mUnitMgr->lOrderList.erase(iID);
	}

	bEmote = false;

	this->bFollowingWp = false;
	this->bOrderGiven = false;
	this->bFollowing = false;
	this->bMoving = false;
	this->lPath.clear();
	this->lWPath.clear();
}

// Tells the unit to die
void Unit::Die()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::die", false);
		Chrono c(prof);
	#endif
	if (!this->IsDead())
	{
		this->SetSelected(false);
		this->Stop();
		map<Unit*, float>::iterator iter;
		for (iter = lAggroedList.begin(); iter != lAggroedList.end(); iter++)
		{
			iter->first->RebuildAggroList();
		}
		lAggroedList.clear();
		multimap<float, Unit*>::iterator iter2;
		for (iter2 = lAggroList.begin(); iter2 != lAggroList.end(); iter2++)
		{
			iter2->second->RebuildAggroedList();
		}
		lAggroList.clear();
		fHealth = 0;
		fMana = 0;
		mUnitMgr->lDeadList[iID] = this;
		this->SetAnimState(ANIM_DEATH, true);
		iAttackState = ATTACK_NO;
		//mAnimation->Play();
		bDying = true;
		bDead = true;

		if (this->IsHostile())
		{
			Event e;
			e.iID = EVENT_CHAT_MSG_COMBAT_HOSTILE_DEATH;
			e.sName = "CHAT_MSG_COMBAT_HOSTILE_DEATH";
			e.iArgNbr = 1;
			e.bCumulable = true;
			string s = mSceneMgr->tStrTable->GetString("msg_friendly_death");
			s = ParseString(s);
			e.lArgList[0] = Argument(ARG_TYPE_STRING, s);
			mGUIMgr->lEventList.push_back(e);
		}
		else
		{
			Event e;
			e.iID = EVENT_CHAT_MSG_COMBAT_FRIENDLY_DEATH;
			e.sName = "CHAT_MSG_COMBAT_FRIENDLY_DEATH";
			e.iArgNbr = 1;
			e.bCumulable = true;
			string s = mSceneMgr->tStrTable->GetString("msg_friendly_death");
			s = ParseString(s);
			e.lArgList[0] = Argument(ARG_TYPE_STRING, s);
			mGUIMgr->lEventList.push_back(e);
		}
	}
	else
	{
		this->SetSelected(false);
	}
}

// Tells the unit to resurrect
void Unit::Res( int health, int mana, Unit* u )
{
	if (this->IsDead())
	{
		fHealth = health;
		fMana = mana;
		mUnitMgr->lDeadList.erase(iID);
		this->SetAnimState(ANIM_STAND);
		iAttackState = ATTACK_NO;
		bDead = false;
		this->SetX(u->GetX());
		this->SetY(u->GetY());
	}
}

// Update the attack : animation, cast time, effect
void Unit::UpdateAction()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::updateAction", false);
		Chrono c(prof);
	#endif

	if (fGlobalCoolDown != 0.0f)
	{
	    fGlobalCoolDown -= mTimeMgr->GetDelta();
	    if (floor(fGlobalCoolDown*1000) <= 0)
            fGlobalCoolDown = 0.0f;
	}

	bool bDebugThis = false;
	if ( this->IsActing() && (mTarget != NULL) )
	{
		if (bDebugThis) Log("2");
		if (!mSpell->bSelfOnly)
		{
			if (mTarget->IsHostile(this))
			{
				if ((mSpell->iTargetType == SPELL_TARGET_DEAD_FRIENDS) ||
					(mSpell->iTargetType == SPELL_TARGET_FRIENDS))
					this->Stop();
			}
			else
			{
				if ((mSpell->iTargetType == SPELL_TARGET_DEAD_HOSTILES) ||
					(mSpell->iTargetType == SPELL_TARGET_HOSTILES))
					this->Stop();
			}
			if (mTarget->IsDead())
			{
				if ((mSpell->iTargetType != SPELL_TARGET_DEADS) &&
					(mSpell->iTargetType != SPELL_TARGET_DEAD_FRIENDS) &&
					(mSpell->iTargetType != SPELL_TARGET_DEAD_HOSTILES))
					this->Stop();
			}
		}

		if (this->IsActing())
		{
			if (bDebugThis) Log("2.2");
			if (mTarget != NULL && !mSpell->bSelfOnly)
			{
				if (bDebugThis) Log("2.2.1");
				this->LookAt(Point(mTarget->GetGX(), mTarget->GetGY()));
			}
			if (iAttackState == ATTACK_PREPARE)
			{
				if (bDebugThis) Log("2.2.2");
				fActionTimer += mTimeMgr->GetDelta();
				AnimSequence* a = mModel->mAnimMgr->GetAnim(mSpell->mCastAnim);
				if (fActionTimer >= mSpell->fCastTime-(a->iEnd-a->iStart)/1000.0f)
				{
				    this->SetAnimState(mSpell->mCastAnim);

				    if (this->Cast(mSpell))
					{
						if (bDebugThis) Log("2.2.2.1.1");
                        bProjectile = false;

						if (mSpell->bHasCastEffect)
						{
							if (bDebugThis) Log("2.2.2.1.1.1");
							if (lEffectList[mSpell->sCastEffect].fFadeOut == 0.0f)
							{
								lEffectList[mSpell->sCastEffect].bEnded = true;
							}
							else
							{
								lEffectList[mSpell->sCastEffect].bFade = true;
								lEffectList[mSpell->sCastEffect].fFadeOut = 0.2f;
							}
						}
						if (!mSpell->bHasAttackEffect)
						{
							if (bDebugThis) Log("2.2.2.1.1.2");
							mTarget->Receive(mSpell, this);
						}
						if (mTarget->IsDead() && (mSpell->iTargetType != SPELL_TARGET_DEADS))
						{
							if (bDebugThis) Log("2.2.2.1.1.3");
							bFinishAnim = false;
						}
						iAttackState = ATTACK_CAST;
					}
					else
					{
						if (bDebugThis) Log("2.2.2.1.2");
						this->Stop();
					}
				}
			}
            if (iAttackState == ATTACK_CAST)
            {
                fActionTimer += mTimeMgr->GetDelta();
                if ( (fActionTimer >= mGFXMgr->lFXList[mSpell->sAttackEffect].mPFX.fDelay) && !(bProjectile) && (mSpell->bHasAttackEffect) )
                {
                    if (bDebugThis) Log("2.2.3.1");
                    mUnitMgr->CreateProjectile(mSpell, mTarget, this);
                    bProjectile = true;
                }
				if (fActionTimer >= mSpell->fCastTime)
				{
                    iAttackState = ATTACK_ATTACK;
                    fActionTimer = 0.0f;
				}
			}
			if (iAttackState == ATTACK_ATTACK)
			{
				if (bDebugThis) Log("2.2.3");

				if (fGlobalCoolDown == 0.0f)
				{
					if (bDebugThis) Log("2.2.3.2");
					if (!mSpell->bLoop)
					{
						if (bDebugThis) Log("2.2.3.2.1");
						this->Stop(true);
					}
					else
					{
						if (bDebugThis) Log("2.2.3.2.2");
						if (this->IsCastable(mSpell))
						{
							if (bDebugThis) Log("2.2.3.2.2.1");
							this->SetAnimState(mSpell->mIncantAnim);
							iAttackState = ATTACK_PREPARE;
						}
						else
						{
							if (bDebugThis) Log("2.2.3.2.2.2");
							this->Stop(true);
						}
					}

					fActionTimer = 0.0f;
					bFinishAnim = true;
					if (mSpell->bHasCastEffect)
					{
						if (bDebugThis) Log("2.2.3.2.3");
						this->AddEffect(mSpell->sCastEffect);
					}
				}
			}
		}
	}
}

// Updates everything related to the unit
void Unit::Update()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::update", false);
		Chrono c(prof);
	#endif
	this->UpdateBuffs();
	this->UpdateEffects();
	this->UpdateAction();
	if (!this->IsDead())
		this->UpdateRegen();
	this->UpdateMovement();
	this->UpdateAggro();
	this->SetBox();

	if ( (bDying) /*&& !(mAnimation->IsPlaying())*/ )
		bDying = false;

	//mAnimation->Update(mTimeMgr->GetDelta());

	if (lAggroedList.empty() && lAggroList.empty())
	{
		if (bInCombat)
		{
			fInCombatTimer -= mTimeMgr->GetDelta();
			if (fInCombatTimer <= 0.0f)
				bInCombat = false;
		}
	}

	/*static bool plop = false;
	if ((sName == "Kaloth" && bAggro) || (sName == "Kaloth" && plop))
	{
		plop = true;
		Log("# %s :", sName.c_str());
		Log(" - bOrderGiven = %d", bOrderGiven);
		Log(" - bMoving = %d", bMoving);
		Log(" - bFollowing = %d", bFollowing);
		Log(" - iPointIndice = %d", iPointIndice);
		Log(" - path.size() = %d", lPath.size());
		Log(" - bFollowingWp = %d", bFollowingWp);
		Log(" - iWaypointIndice = %d", iWaypointIndice);
		Log(" - wPath.size() = %d", lWPath.size());
		Log(" - isActing() = %d", isActing());
		if (mTarget != NULL)
			Log(" - mTarget = %s", mTarget->GetName().c_str());
		else
			Log(" - mTarget = null");
	}*/
}

void Unit::UpdateBuffs()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::updateBuffs", false);
		Chrono c(prof);
	#endif
	map<string, Buff>::iterator iterBuff, lastParsed;
	lastParsed = NULL;
	for (iterBuff = lBuffList.begin(); iterBuff != lBuffList.end(); iterBuff++)
	{
		Buff* b = &iterBuff->second;
		b->fLife += mTimeMgr->GetDelta();
		if (b->fLife >= b->mBuff->fDuration)
		{
			lBuffList.erase(iterBuff);
			if (lBuffList.empty())
				break;
			if (lastParsed == NULL)
			{
				iterBuff = lBuffList.begin();
				continue;
			}
			else
				iterBuff = lastParsed;
		}
		lastParsed = iterBuff;
	}
}

void Unit::UpdateEffects()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::updateEffects", false);
		Chrono c(prof);
	#endif
	map<string, Effect>::iterator iterFX, lastParsed;
	lastParsed = NULL;
	for (iterFX = lEffectList.begin(); iterFX != lEffectList.end(); iterFX++)
	{
		Effect* e = &iterFX->second;
		if (e->bEnded)
		{
			if (e->mAnim != NULL) {delete e->mAnim;}
			if (e->mPSys != NULL) {delete e->mPSys;}
			lEffectList.erase(iterFX);
			if (lEffectList.empty())
				break;
			if (lastParsed == NULL)
			{
				iterFX = lEffectList.begin();
				continue;
			}
			else
				iterFX = lastParsed;
		}
		else
		{
			if (mGFXMgr->lFXList[e->sName].iType == FX_ANIMATED_EFFECT)
			{
				if (mGFXMgr->lFXList[e->sName].mAFX.iType == FX_MULTI_ANGLE_ANIM)
				{
					if (AngleToRot(fRot) != e->iRot)
					{
					    e->iRot = AngleToRot(fRot);
						int frame = e->mAnim->GetFrame();
						delete e->mAnim;
						e->mAnim = new hgeAnimation(*mGFXMgr->lFXList[e->sName].mAFX.lStateList[e->iRot]);
						e->mAnim->SetFrame(frame);
						e->mAnim->Play();
					}
				}
			}
			e->Update(mTimeMgr->GetDelta());
			if (e->fLife != 0.0f)
				e->fLifeTimer += mTimeMgr->GetDelta();
			if (e->fLifeTimer > e->fLife)
			{
				if (e->mAnim != NULL) {delete e->mAnim;}
				if (e->mPSys != NULL) {delete e->mPSys;}
				lEffectList.erase(iterFX);
				if (lEffectList.empty())
					break;
				if (lastParsed == NULL)
				{
					iterFX = lEffectList.begin();
					continue;
				}
				else
					iterFX = lastParsed;
			}
			else
			{
				if ( ((e->fFadeIn == 0.0f) && (e->fFadeOut == 0.0f))
				  || ((e->bFadedIn == true) && (e->bFade == false)) )
				{
					// Render the effect, nothing special
					e->SetColor(ARGB(255, 255, 255, 255));
				}
				else if ( (e->fFadeIn != 0.0f) && (e->bFadedIn == false) && (e->bFade == true)  )
				{
					// Fade in the effect
					e->fFadeTimer += mTimeMgr->GetDelta()/e->fFadeIn;
					if (e->fFadeTimer > 1.0f)
					{
						e->fFadeTimer = 1.0f;
						e->bFadedIn = true;
						e->bFade = false;
					}
					int alpha = ToInt(e->fFadeTimer*255);
					e->SetColor(ARGB(alpha, 255, 255, 255));
				}
				else if ( (e->fFadeOut != 0.0f) && (e->bFadedIn == true) && (e->bFade == true) )
				{
					// Fade out the effect
					e->fFadeTimer -= mTimeMgr->GetDelta()/e->fFadeOut;
					if (e->fFadeTimer <= 0.0f)
					{
						if (e->mAnim != NULL) {delete e->mAnim;}
						if (e->mPSys != NULL) {delete e->mPSys;}
						lEffectList.erase(iterFX);
						if (lEffectList.empty())
							break;
						if (lastParsed == NULL)
						{
							iterFX = lEffectList.begin();
							continue;
						}
						else
							iterFX = lastParsed;
					}
					else
					{
						int alpha = ToInt(e->fFadeTimer*255);
						e->SetColor(ARGB(alpha, 255, 255, 255));
					}
				}
			}
			lastParsed = iterFX;
		}
	}

	if (lEffectList.empty())
		bFXPlaying = false;
}

void Unit::UpdateRegen()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::updateRegen", false);
		Chrono c(prof);
	#endif
	float m_regen_health = mClass->fHealthGainedPerSpirit*mStats.iSpirit + mClass->fHealthGainedPerTick;
	float m_regen_mana = mClass->fManaGainedPerSpirit*mStats.iSpirit + mClass->fManaGainedPerTick;

	if (bInCombat)
	{
		m_regen_health *= mClass->fRegenHealthInCombat;
		m_regen_mana *= mClass->fRegenManaInCombat;
	}

	fRegenTimer += mTimeMgr->GetDelta();
	if (fRegenTimer >= mSceneMgr->fRegenTimer)
	{
		fRegenTimer = 0.0f;

		fHealth += ToInt(m_regen_health);
		if (fHealth > mStats.iHealth)
		{
			fHealth = mStats.iHealth;
		}
		fMana += ToInt(m_regen_mana);
		if (fMana > mStats.iMana)
		{
			fMana = mStats.iMana;
		}
	}
}

void Unit::UpdateStats()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::updateStats", false);
		Chrono c(prof);
	#endif
	int stam_health;
	if (mStats.iStamina*10-180 < 0)
		stam_health = 0;
	else
		stam_health = mStats.iStamina*10-180;

	int n_max_health = stam_health + mUnitMgr->GetBaseHealth(iLevel, mClass);

	if (mStats.iHealth == 0)
	{
		mStats.iHealth = n_max_health;
		fHealth = n_max_health;
	}
	else
		mStats.iHealth = n_max_health;

	int intel_mana;
	if (mStats.iIntellect*15-280 < 0)
		intel_mana = 0;
	else
		intel_mana = mStats.iIntellect*15-280;

	int n_max_mana = intel_mana + mUnitMgr->GetBaseMana(iLevel, mClass);

	if (mStats.iMana != n_max_mana)
	{
		if (mStats.iMana == 0)
		{
			mStats.iMana = n_max_mana;
			fMana = n_max_mana;
		}
		else
			mStats.iMana = n_max_mana;
	}
}

void Unit::UpdateMovement()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::updateMovement", false);
		Chrono c(prof);
	#endif
	if (bOrderGiven)
	{
		SetAnimState(ANIM_RUN);
		if (iOrder == MOVEMENT_LEASHING)
		{
			bool move = this->FollowWaypointPath();
			if (!move)
			{
				bOrderGiven = bOldOrderGiven;
				pDestPoint = pOldDestPoint;
				iOrder = iOldOrder;
				lPath = lOldPath;
				iPointIndice = iOldPointIndice;
				lWPath = lOldWPath;
				iWaypointIndice = iOldWaypointIndice;
				bFollowing = bOldFollowing;
				bMoving = bOldMoving;
				iOrder == MOVEMENT_MOVE;
			}
		}
		else if (iOrder == MOVEMENT_APPROACH)
		{
			bool move = this->FollowWaypointPath();
			if (!move || this->IsTargetInRange(mSpell))
			{
				iOrder == MOVEMENT_MOVE;
				this->Stop();
				this->Incant(mSpell, mTarget);
			}
		}
		else if (iOrder == MOVEMENT_APPROACH_AGGRO)
		{
			bool move = this->FollowPath();
			float distance = Dist
			(
				this->GetX(), this->GetY()*mSceneMgr->fAspectRatio,
				mTarget->GetX(), mTarget->GetY()*mSceneMgr->fAspectRatio
			);
			// The unit stops approaching if its target is under 75% of its attack range.
			if ( !move || (distance <= mSpell->fRange*0.75f*10.0f) )
			{
				this->Stop();
				this->Incant(mSpell, mTarget);
			}
		}
		else if (iOrder == MOVEMENT_MOVE)
		{
			bool move = this->FollowWaypointPath();
			if (!move)
			{
				bOrderGiven = false;
				mUnitMgr->lOrderList.erase(iID);
			}
		}
	}
	else
	{
		if (!this->IsActing() && !this->IsDead())
			SetAnimState(ANIM_STAND);
	}
}

void Unit::UpdateAggro()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::updateAggro", false);
		Chrono c(prof);
	#endif
	if (!this->IsDead())
	{
		if (this->IsHostile())
		{
			if (bAggro)
			{
				if (mTarget->IsDead())
				{
					this->Stop();
					this->BuildAggroList(true);
					if (lAggroList.empty())
					{
						this->GoBackToOldState();
						bAggro = false;
					}
				}
				else if (mTarget->IsHostile())
				{
					this->Stop();
					this->BuildAggroList(true);
					if (lAggroList.empty())
					{
						this->GoBackToOldState();
						bAggro = false;
					}
				}
				else
				{
					this->BuildAggroList(false);
					float distance = Dist
					(
						this->GetX(), this->GetY()*mSceneMgr->fAspectRatio,
						mTarget->GetX(), mTarget->GetY()*mSceneMgr->fAspectRatio
					);
					if (distance <= mSpell->fRange*0.75f*10.0f)
					{
						if (!this->IsActing())
						{
							this->Stop();
							this->Incant(mSpell, mTarget);
						}
					}
					else if (distance > mSpell->fRange*10.0f)
					{
						if (!this->IsActing())
						{
							if (fPathfindingTimer >= 1.0f || !bOrderGiven)
							{
								this->lPath = GetShortestPath
								(
									ToInt(this->GetGX()),
									ToInt(this->GetGY()),
									ToInt(mTarget->GetGX()),
									ToInt(mTarget->GetGY()),
									(mSpell->fRange*0.75f)*10.0f
								);
								this->pDestPoint = this->lPath.back();
								fPathfindingTimer = 0.0f;
								bOrderGiven = true;
							}
							fPathfindingTimer += mTimeMgr->GetDelta();
						}
					}
				}
			}

			if ( !bAggro && (iOrder != MOVEMENT_LEASHING) )
			{
				map<int, Unit*>::iterator iterUnit;
				for (iterUnit = mUnitMgr->lUnitList.begin(); iterUnit != mUnitMgr->lUnitList.end(); iterUnit++)
				{
					Unit* u = iterUnit->second;
					if ( !u->IsHostile() && !u->IsDead() && (u != this) )
					{
						float distance = Dist
						(
							this->GetX(), this->GetY()*mSceneMgr->fAspectRatio,
							u->GetX(), u->GetY()*mSceneMgr->fAspectRatio
						);
						if (distance <= fAggroRange*10.0f)
						{
							// Storing old state
							pOldPos.Set(this->GetGX(), this->GetGY());
							bOldOrderGiven = bOrderGiven;
							pOldDestPoint = pDestPoint;
							iOldOrder = iOrder;
							lOldPath = lPath;
							iOldPointIndice = iPointIndice;
							lOldWPath = lWPath;
							iOldWaypointIndice = iWaypointIndice;
							bOldFollowing = bFollowing;
							bOldMoving = bMoving;
							bFollowing = false;
							bMoving = false;

							if (distance <= mSpell->fRange*10.0f)
							{
								this->Incant(mSpell, u);
								bOrderGiven = false;
							}
							else
							{
								this->lPath = GetShortestPath
								(
									ToInt(this->GetGX()),
									ToInt(this->GetGY()),
									ToInt(u->GetGX()),
									ToInt(u->GetGY()),
									(mSpell->fRange*0.75f)*10.0f
								);
								this->pDestPoint = this->lPath.back();
								this->Target(u);
								iOrder = MOVEMENT_APPROACH_AGGRO;
								bOrderGiven = true;
							}

							u->SetInCombat();
							this->AddUnitToAggroList(u);
							u->AddAggroTo(this, 10.0f);
							bAggro = true;
							break;
						}
					}
				}
			}
		}
		else
		{
			BuildAggroedList();
		}
	}
}

void Unit::SetInCombat()
{
	bInCombat = true;
	fInCombatTimer = mSceneMgr->fInCombatTimer;
}

bool Unit::IsInCombat()
{
	return bInCombat;
}

bool Unit::IsInSpellRange( float x, float y )
{
	float distance = Dist(this->GetX(), this->GetY()*mSceneMgr->fAspectRatio, x, y*mSceneMgr->fAspectRatio);
	return (distance <= mSpell->fRange*10.0f);
}

bool Unit::IsTargetInRange( Spell* s )
{
	if (s == NULL)
		s = mSpell;

	if ( (mTarget == NULL) || (s->bSelfOnly) )
		return true;

	float distance = Dist
	(
		this->GetX(), this->GetY()*mSceneMgr->fAspectRatio,
		mTarget->GetX(), mTarget->GetY()*mSceneMgr->fAspectRatio
	);
	return (distance <= s->fRange*10.0f);
}

void Unit::MoveInRange( Unit* target )
{
	if (target == NULL)
		target = mTarget;

	pDestPoint = target->GetGPoint();
	iOrder = MOVEMENT_APPROACH;
	bOrderGiven = false;
	mSceneMgr->RequestWPPath(this);
	bPathRequested = false;
	bPathObtained = false;
	bFollowing = false;
	bFollowingWp = false;
}

void Unit::GoBackToOldState()
{
	pDestPoint = pOldPos;
	mSceneMgr->RequestWPPath(this);
	this->lAggroList.clear();
	iOrder = MOVEMENT_LEASHING;
}

void Unit::SetAggroRange( float aRange )
{
	if (aRange > 0.0f)
		fAggroRange = aRange;
}

void Unit::AddAggroTo( Unit* u, float aggro )
{
	//Log("%s adds %.0f threat points to %s's threatList (total : %.0f)", sName.c_str(), aggro, u->GetName().c_str(), lAggroedList[u] + aggro);
	u->RebuildAggroList();
	lAggroedList[u] += aggro;
}

bool Unit::IsInAggroListOf( Unit* u )
{
	if (lAggroedList.find(u) != lAggroedList.end())
	{
		return true;
	}
	else
	{
		return false;
	}
}

void Unit::AddUnitToAggroList( Unit* u )
{
	this->lAggroList.insert(make_pair(0.0f, u));
	u->lAggroedList[this] = 0.0f;
}

void Unit::RebuildAggroedList()
{
	bRebuildAggroedList = true;
}

void Unit::BuildAggroedList()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::buildAggroedList", false);
		Chrono c(prof);
	#endif
	if (bRebuildAggroedList)
	{
		map<Unit*, float>::iterator iter, lastParsed = NULL;
		for (iter = lAggroedList.begin(); iter != lAggroedList.end(); iter++)
		{
			if (iter->first->IsDead() || !iter->first->IsHostile())
			{
				lAggroedList.erase(iter);
				if (lAggroedList.empty())
					break;
				if (lastParsed == NULL)
				{
					iter = lAggroedList.begin();
					continue;
				}
				else
					iter = lastParsed;
			}
			else
				lastParsed = iter;
		}
	}

	bRebuildAggroedList = false;
}

void Unit::RebuildAggroList()
{
	bRebuildAggroList = true;
}

void Unit::BuildAggroList( bool rebuild )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::buildAggroList", false);
		Chrono c(prof);
	#endif
	multimap<float, Unit*>::iterator iter;

	if ( bRebuildAggroList || rebuild )
	{
		multimap<float, Unit*> tempAggroList = lAggroList;
		lAggroList.clear();
		//Log(" # %s's threat list :", sName.c_str());
		//int i = 1;
		for (iter = tempAggroList.begin(); iter != tempAggroList.end(); iter++)
		{
			if (!iter->second->IsDead() && !iter->second->IsHostile())
			{
				//Log("[%d] %s : %.0f", i, iter->second->GetName().c_str(), iter->second->lAggroedList[this]);
				lAggroList.insert(make_pair(iter->second->lAggroedList[this], iter->second));
				//i++;
			}
		}
	}

	if (!lAggroList.empty())
	{
		// Check if there is several units at the top of the aggro list
		Unit* old_target = mTarget;
		iter = lAggroList.end(); iter--;

		pair<multimap<float, Unit*>::iterator, multimap<float, Unit*>::iterator> iPair;
		iPair = lAggroList.equal_range(iter->first);

		if (iPair.first == iPair.second)
			this->Target(iter->second);
		else
		{
			// ... and if we find the old target
			for (iter = iPair.first; iter != iPair.second; iter++)
			{
				if (iter->second == old_target)
				{
					this->Target(old_target);
					break;
				}
				else
					this->Target(iter->second);
			}
		}
	}
	else
		bAggro = false;

	bRebuildAggroList = false;
}

// Make a unit walk to a point
bool Unit::GoTo( Point pDestPoint )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "Unit::goTo", false);
		Chrono c(prof);
	#endif
	hgeVector orderVec;
	hgeVector newVec;
	float speed = this->GetSpeed()*this->GetScale();
	orderVec.x = pDestPoint.fX-this->GetGX();
	orderVec.y = pDestPoint.fY-this->GetGY();

	float coefx, coefy;
	coefx = (speed/1.4142f)*cos(orderVec.Angle());
	coefy = (speed/1.4142f)*sin(orderVec.Angle());
	newVec.x = pDestPoint.fX-(this->GetGX()+coefx*mTimeMgr->GetDelta());
	newVec.y = pDestPoint.fY-(this->GetGY()+coefy*mTimeMgr->GetDelta());

	if ((orderVec.Dot(&newVec) < 0) ||
        ((fabs(orderVec.x) < 1) && (fabs(orderVec.y) < 1)))
	{
	    // Unit is arrived at detination
		this->SetX(pDestPoint.fX+mSceneMgr->fGX);
		this->SetY(pDestPoint.fY+mSceneMgr->fGY);
		bMoving = false;
		return false;
	}
	else
	{
	    this->SetX(this->GetX()+coefx*mTimeMgr->GetDelta());
		this->SetY(this->GetY()+coefy*mTimeMgr->GetDelta());
		bMoving = true;
		return true;
	}

	/*if ( !((fabs(pDestPoint.fX-this->GetGX()) < 1) && (fabs(pDestPoint.fY-this->GetGY()) < 1)) )
	{
		this->SetX(this->GetX()+coefx*mTimeMgr->GetDelta());
		this->SetY(this->GetY()+coefy*mTimeMgr->GetDelta());
		this->LookAt(pDestPoint);
		bMoving = true;
		return true;
	}
	else
	{
		// Unit is arrived at detination
		this->SetX(pDestPoint.fX+mSceneMgr->fGX);
		this->SetY(pDestPoint.fY+mSceneMgr->fGY);
		bMoving = false;
		return false;
	}*/
}

// Make a unit follow a lPath
bool Unit::FollowPath()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "Unit::followPath", false);
		Chrono c(prof);
	#endif
	if (lPath.size() == 1)
	{
	    this->LookAt(*lPath.begin());
		bool bMoving = this->GoTo(*lPath.begin());
		if (!bMoving)
			lPath.clear();
		bFollowing = bMoving;
		return bMoving;
	}
	else if (lPath.size() != 0)
	{
		if (!bFollowing)
		{
			iPointIndice = 0;
			bFollowing = true;
		}

		std::vector<Point>::iterator iter = lPath.begin();
		for (int i=0; i < iPointIndice; i++)
		{
			iter++;
		}

		if (iPointIndice == lPath.size())
		{
			// Unit has followed the whole lPath
			bFollowing = false;
			lPath.clear();
			return false;
		}
		else
		{
			if (!this->GoTo(*iter))
			{
				iPointIndice++;
				if (iPointIndice != lPath.size())
                    this->LookAt(*(iter+1));
			}
			return true;
		}
	}
}

bool Unit::FollowWaypointPath()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(1, "Unit::followWaypointPath", false);
		Chrono c(prof);
	#endif
	if ( (lWPath.size() == 0) || (iWaypointIndice == -1) )
	{
		if (!bPathRequested && !bPathObtained)
		{
			mSceneMgr->RequestDirectPath(this);
		}
		if (bPathObtained)
		{
			bool bMoving = this->FollowPath();
			if (!bMoving)
			{
				bFollowingWp = false;
				bPathObtained = false;
				return false;
			}
			else
				return true;
		}
		else
			return true;
	}
	else
	{
		if (!bFollowingWp)
		{
			iWaypointIndice = 0;
			bFollowingWp = true;
		}
		if (!bPathRequested && !bPathObtained)
		{
			mSceneMgr->RequestPath(this);
		}

		if (this->bPathObtained)
		{
			bool bMoving = this->FollowPath();
			if (!bMoving)
			{
				iWaypointIndice++;
				if (iWaypointIndice == lWPath.size())
				{
					iWaypointIndice = -1;
					lWPath.clear();
				}
				bPathObtained = false;
			}
		}

		return true;
	}
}

void Unit::AddBuff( string buff_name )
{
	if (lBuffList.find(buff_name) != lBuffList.end())
	{
		Log("1");
		Buff* b = &lBuffList[buff_name];
		b->iCount++;
		if (b->iCount > b->mBuff->iMaxCount)
			b->iCount = b->mBuff->iMaxCount;
		b->fLife = 0.0f;
	}
	else
	{
		Log("2 : %s", buff_name.c_str());
		Buff b;
		SBuff* sb = mUnitMgr->ParseBuff(mSceneMgr->luaVM, buff_name);
		b.sName = sb->sName;
		Log("3 : %s", b.sName.c_str());
		b.mBuff = sb;
		b.iCount = 1;
		b.fLife = 0.0f;

		lBuffList[buff_name] = b;
	}
}

multimap<float, Buff*> Unit::GetBuffList()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::GetBuffList", false);
		Chrono c(prof);
	#endif
	multimap<float, Buff*> buffList;
	map<string, Buff>::iterator iterBuff;
	for (iterBuff = lBuffList.begin(); iterBuff != lBuffList.end(); iterBuff++)
	{
		buffList.insert(make_pair(
            iterBuff->second.fLife - iterBuff->second.mBuff->fDuration,
            &iterBuff->second
        ));
	}

	return buffList;
}

void Unit::InitAB()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(2, "Unit::initAB", false);
		Chrono c(prof);
	#endif
	ActionButton ab;
	ab.iType = GUI_CASTBUTTON_STOP;
	lAButtonList[0] = ab;
	int i = 1;
	map<std::string, SpellData>::iterator iterSpell;
	for (iterSpell = mClass->lSpellList.begin(); iterSpell != mClass->lSpellList.end(); iterSpell++)
	{
		if (i>120)
			break;

		ab.iType = GUI_CASTBUTTON_SPELL;
		ab.mSpell = iterSpell->second.mSpell;

		lAButtonList[i] = ab;
		i++;
	}
	for (i; i<=120; i++)
	{
		ActionButton ab;
		ab.iType = GUI_CASTBUTTON_EMPTY;
		ab.mSpell = NULL;
		ab.mItem = NULL;
		lAButtonList[i] = ab;
	}
}

ActionButton* Unit::GetABList()
{
	return lAButtonList;
}

bool Unit::IsCasting()
{
	if (mSpell != NULL)
	{
		if ( IsActing(true) && (mSpell->fCastTime > 0.0f) )
			return true;
	}

	return false;
}

bool Unit::Intersects(const hgeRect* rect)
{
    bool inter = false;
    if (mBox != NULL)
    {
        inter = mBox->Intersect(rect);
        if (inter)
        {
            if (mModel != NULL)
            {
                hgeRect* nRect = new hgeRect(*rect);
                nRect->x1 = (nRect->x1 - GetX())/GetScale() + mModel->GetRTargetSize()/2;
                nRect->x2 = (nRect->x2 - GetX())/GetScale() + mModel->GetRTargetSize()/2;
                nRect->y1 = (nRect->y1 - GetY())/GetScale() + mModel->GetRTargetSize()/2;
                nRect->y2 = (nRect->y2 - GetY())/GetScale() + mModel->GetRTargetSize()/2;
                inter = mModel->Intersect(nRect);
                delete nRect;
            }
        }
    }
    return inter;
}

bool Unit::TestPoint(float x, float y)
{
    bool inter = false;
    if (mBox)
    {
        inter = mBox->TestPoint(mInputMgr->fMX, mInputMgr->fMY);
        if (inter)
        {
            if (mModel != NULL)
            {
                inter = mModel->TestPoint((x - GetX())/GetScale() + mModel->GetRTargetSize()/2, (y - GetY())/GetScale() + mModel->GetRTargetSize()/2);
            }
        }
    }
    return inter;
}

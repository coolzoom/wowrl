/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_scenemanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_modelmanager.h"
#include "wowrl_structs.h"
#include "wowrl_lua.h"

#include "wowrl_unitmanager.h"

using namespace std;

extern SceneManager *mSceneMgr;
extern GUIManager *mGUIMgr;
extern TimeManager *mTimeMgr;
extern GFXManager *mGFXMgr;
extern ModelManager *mModelMgr;
extern HGE *hge;

Spell* UnitManager::ParseSpell( lua_State* luaVM, string spell_name, bool regLUA = false )
{
	Spell s = lSpellList[spell_name];

	if (regLUA || !s.bLoaded)
	{
		if (bDebugParser && !regLUA) Log(" Parsing %s...", spell_name.c_str());

		lua_getglobal(luaVM, "Spells");
		lua_getfield(luaVM, -1, spell_name.c_str());

		if (lua_istable(luaVM, -1))
		{
            s.sName = spell_name;
            LUA::SetFieldString("name", spell_name.c_str(), luaVM);
            LUA::GetFieldString("display_name", true, "", false, luaVM);
            LUA::GetFieldString("description", true, "", false, luaVM);
            LUA::GetFieldInt("rank", false, -1, true, luaVM);
            s.fCastTime = LUA::GetFieldFloat("cast_time", false, -1.0f, true, luaVM);
            LUA::GetFieldFloat("crits", false, 0.0f, true, luaVM);
            s.fCost = LUA::GetFieldFloat("cost", false, 0.0f, true, luaVM);
            s.fCostP = LUA::GetFieldFloat("cost_percent", false, 0.0f, true, luaVM);
            LUA::GetFieldString("cost_type", false, "", true, luaVM);
            s.fRange = LUA::GetFieldFloat("range", false, 5.0f, true, luaVM);
            s.bSelfOnly = LUA::GetFieldBool("self_only", false, false, true, luaVM);
            s.bUsableInCombat = LUA::GetFieldBool("usable_in_combat", false, true, true, luaVM);
            s.bPutsInCombat = LUA::GetFieldBool("puts_in_combat", false, true, true, luaVM);
            s.bLoop = LUA::GetFieldBool("loop", false, true, true, luaVM);
            s.bGCD = LUA::GetFieldBool("global_cooldown", false, true, true, luaVM);
            s.iSchool = LUA::GetFieldInt("school", false, SPELL_SCHOOL_NONE, true, luaVM);

            s.mCastAnim = (AnimID)LUA::GetFieldInt("cast_anim", false, ANIM_STAND, true, luaVM);
            s.mIncantAnim = (AnimID)LUA::GetFieldInt("incant_anim", false, ANIM_STAND, true, luaVM);

            s.sCastEffect = LUA::GetFieldString("cast_effect", false, "", true, luaVM);
            if (s.sCastEffect == "")
                s.bHasCastEffect = false;
            else
                s.bHasCastEffect = true;
            s.sAttackEffect = LUA::GetFieldString("attack_effect", false, "", true, luaVM);
            if (s.sAttackEffect == "")
                s.bHasAttackEffect = false;
            else
                s.bHasAttackEffect = true;
            LUA::GetFieldString("icon", false, "Icons/INV_Misc_QuestionMark.png", true, luaVM);

            s.bHasProj = LUA::GetFieldBool("projectile", false, false, true, luaVM);
            if (s.bHasProj)
                s.fProjSpeed = LUA::GetFieldFloat("projectile_speed", false, 600.0f, true, luaVM);

            s.bChanneled = LUA::GetFieldBool("channeled", false, false, true, luaVM);

            string target = LUA::GetFieldString("target", false, "all", true, luaVM);

            if (target == "hostiles")
                s.iTargetType = SPELL_TARGET_HOSTILES;
            else if (target == "all")
                s.iTargetType = SPELL_TARGET_ALL;
            else if (target == "friends")
                s.iTargetType = SPELL_TARGET_FRIENDS;
            else if (target == "deads")
                s.iTargetType = SPELL_TARGET_DEADS;
            else if (target == "dead_friends")
                s.iTargetType = SPELL_TARGET_DEAD_FRIENDS;
            else if (target == "dead_hostiles")
                s.iTargetType = SPELL_TARGET_DEAD_HOSTILES;
            else
            {
                s.iTargetType = SPELL_TARGET_HOSTILES;
                Log("# Warning # : unknown target value \"%s\" in %s.", target.c_str(), spell_name.c_str());
            }

            lua_getfield(luaVM, -1, "scripts");

            s.sOnCastBegin = LUA::GetFieldString("OnCastBegin", false, "", true, luaVM);
            s.sOnCasted = LUA::GetFieldString("OnCasted", false, "", true, luaVM);
            s.sOnImpact = LUA::GetFieldString("OnImpact", false, "", true, luaVM);
            s.sOnUpdate = LUA::GetFieldString("OnUpdate", false, "", true, luaVM);

            lua_pop(luaVM, 3);

            lSpellList[spell_name] = s;

            s.bLoaded = true;
		}
		else
		{
			Log("# Error # : can't find spell \"%s\"", spell_name.c_str());
			lua_pop(luaVM, 2);
			return NULL;
		}
	}

	return &lSpellList[spell_name];
}

SBuff* UnitManager::ParseBuff( lua_State* luaVM, string buff_name )
{
	if (lBuffList.find(buff_name) == lBuffList.end())
	{
		if (bDebugParser) Log(" Parsing %s...", buff_name.c_str());
		lua_getglobal(luaVM, "Buffs");
		lua_getfield(luaVM, -1, buff_name.c_str());

		if (lua_istable(luaVM, -1))
		{
			SBuff b;
			b.sName = buff_name;
			LUA::GetFieldString("display_name", luaVM);
			LUA::GetFieldString("description", luaVM);
			b.fDuration = LUA::GetFieldFloat("duration", false, -1.0f, luaVM);
			b.iMaxCount = LUA::GetFieldInt("max_count", false, 1, luaVM);

			LUA::GetFieldString("icon", false, "Icons/INV_Misc_QuestionMark.png");

			lua_pop(luaVM, 2);

			lBuffList[buff_name] = b;
		}
		else
		{
			Log("# Error # : can't find buff \"%s\"", buff_name.c_str());
			lua_pop(luaVM, 2);
			return NULL;
		}
	}

	return &lBuffList[buff_name];
}

bool UnitManager::ParseClassesDyn( lua_State* luaVM, int state1, bool* finished, float filling )
{
	static int class_nbr = 0;

	if (state1 == 1)
	{
		Log("Parsing Tables/buff_table.lua...");
		int error = luaL_dofile(mSceneMgr->luaVM, "Tables/buff_table.lua");
		if (error) LUA::LogL(mSceneMgr->luaVM);
		Log("Parsing Tables/buff_table.lua : done.");

		Log("Parsing Tables/spell_scripts_table.lua...");
		error = luaL_dofile(mSceneMgr->luaVM, "Tables/spell_scripts_table.lua");
		if (error) LUA::LogL(mSceneMgr->luaVM);
		Log("Parsing Tables/spell_scripts_table.lua : done.");

		Log("Parsing Tables/spell_table.lua...");
		error = luaL_dofile(mSceneMgr->luaVM, "Tables/spell_table.lua");
		if (error) LUA::LogL(mSceneMgr->luaVM);
		Log("Parsing Tables/spell_table.lua : done.");

		Log("Parsing Tables/item_table.lua...");
		error = luaL_dofile(mSceneMgr->luaVM, "Tables/item_table.lua");
		if (error) LUA::LogL(mSceneMgr->luaVM);
		Log("Parsing Tables/item_table.lua : done.");

		Log("Parsing Tables/race_table.lua...");
		error = luaL_dofile(mSceneMgr->luaVM, "Tables/race_table.lua");
		if (error) LUA::LogL(mSceneMgr->luaVM);
		Log("Parsing Tables/race_table.lua : done.");

		Log("Parsing Tables/class_table.lua...");
		error = luaL_dofile(luaVM, "Tables/class_table.lua");
		if (error) LUA::LogL(luaVM);
		lua_getglobal(luaVM, "Classes");

		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			class_nbr++;
		}

		lua_pushnil(luaVM);
		*finished = false;
		return true;
	}
	else if (state1 == 2)
	{
		if (!lua_next(luaVM, -2))
		{
			*finished = false;
			return true;
		}

		Class c;

		c.sName = LUA::GetFieldString("name");
		c.sDisplayName = LUA::GetFieldString("display_name");
		c.iID = LUA::GetFieldInt("id");
		string icon_file = LUA::GetFieldString("icon", false, "Icons/INV_Misc_QuestionMark.png");
		c.mIcon = mGFXMgr->CreateSprite(mGFXMgr->LoadTexture(icon_file, true), 0, 0, 64, 64);
		//c.sAnimSetName = LUA::GetFieldString("animset");
		c.fHealthGainedPerSpirit = LUA::GetFieldFloat("health_gained_per_spirit", false, 0.0f);
		c.fHealthGainedPerTick = LUA::GetFieldFloat("health_gained_per_tick", false, 0.0f);
		c.fManaGainedPerSpirit = LUA::GetFieldFloat("mana_gained_per_spirit", false, 0.0f);
		c.fManaGainedPerTick = LUA::GetFieldFloat("mana_gained_per_tick", false, 0.0f);
		c.iPowerType = LUA::GetFieldInt("power_type", false, 5);
		c.fRegenHealthInCombat = LUA::GetFieldFloat("regen_health_in_combat", false, 0.0f);
		c.fRegenManaInCombat = LUA::GetFieldFloat("regen_mana_in_combat", false, 0.0f);
		c.fGCD = LUA::GetFieldFloat("global_cooldown", false, 1.5f);

		lua_getfield(luaVM, -1, "spells");
		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			if (!lua_isnil(luaVM, -1))
			{
				SpellData cs;
				string spell_name = LUA::GetFieldString("name");
				cs.mSpell = ParseSpell(luaVM, spell_name);
				cs.iCost = LUA::GetFieldInt("cost", false, 0);
				cs.iLevelRequiered = LUA::GetFieldInt("available_at_lvl", false, 1);
				c.lSpellList[spell_name] = cs;
			}
		}
		lua_pop(luaVM, 1);

		lua_getfield(luaVM, -1, "talent_trees");
		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			if (!lua_isnil(luaVM, -1))
			{
				Specialisation s;
				s.sName = LUA::GetFieldString("name");
				s.sDisplayName = LUA::GetFieldString("display_name");
				s.sRole = LUA::GetFieldString("role");
				s.mDefaultSpell = &lSpellList[LUA::GetFieldString("default_spell")];
				c.lSpecList[s.sName] = s;
			}
		}
		lua_pop(luaVM, 1);

		lClasseList[c.sName] = c;
		lClasseList[c.sName].mDefaultSpec = &lClasseList[c.sName].lSpecList[LUA::GetFieldString("default_spec")];

		mGUIMgr->mLoadingBar.fFilling += filling/class_nbr;

		lua_pop(luaVM, 1);
		*finished = false;
		return false;
	}
	else
	{
		lua_pop(luaVM, 1);
		Log("Parsing Tables/class_table.lua : done.");
		*finished = true;
		return true;
	}
}

Race* UnitManager::ParseRace( lua_State* luaVM, string race_name )
{
	if (lRaceList.find(race_name) == lRaceList.end())
	{
		if (bDebugParser) Log(" Parsing %s...", race_name.c_str());
		lua_getglobal(luaVM, "Races");
		if (lua_istable(luaVM, -1))
		{
            lua_getfield(luaVM, -1, race_name.c_str());

            if (lua_istable(luaVM, -1))
            {
                Race r;
                r.sName = race_name;
                r.sDisplayName = LUA::GetFieldString("display_name", "luaVM");
                string model = LUA::GetFieldString("model_male", false, "", luaVM);
                if (model != "")
                    r.mMaleModel = mModelMgr->LoadModelTable(luaVM, model);
                else
                    r.mMaleModel = NULL;

                model = LUA::GetFieldString("model_female", false, "", luaVM);
                if (model != "")
                    r.mFemaleModel = mModelMgr->LoadModelTable(luaVM, model);
                else
                    r.mFemaleModel = NULL;

                if ( (r.mFemaleModel == NULL) && (r.mMaleModel == NULL) )
                    Log("# Warning # : no model defined for race \"%s\"", race_name.c_str());

                r.fShadowScale = LUA::GetFieldFloat("shadow_scale", false, 1.0f, false, luaVM);
                r.fStatusBarSize = LUA::GetFieldFloat("status_bar_size", false, 64.0f, false, luaVM);
                r.fStatusBarYOffset = LUA::GetFieldFloat("status_bar_offset_y", false, 0.0f, false, luaVM);

                lua_pop(luaVM, 2);

                lRaceList[race_name] = r;
            }
            else
            {
                Log("# Error # : can't find race \"%s\"", race_name.c_str());
                lua_pop(luaVM, 2);
                return NULL;
            }
		}
		else
		{
		    Log("# Critical # : can't find \"Races\" table");
            lua_pop(luaVM, 1);
            return NULL;
		}
	}

	return &lRaceList[race_name];
}

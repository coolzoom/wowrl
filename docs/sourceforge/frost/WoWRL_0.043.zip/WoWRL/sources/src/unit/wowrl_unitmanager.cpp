/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           UnitManager source           */
/*                                        */
/*  ## : A class that takes care of       */
/*  units, including movement and various */
/*  updates.                              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_global.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_structs.h"
#include "wowrl_lua.h"
#include "wowrl_projectile.h"
#include "wowrl_scenemanager.h"

#include "wowrl_unitmanager.h"

using namespace std;

extern TimeManager *mTimeMgr;
extern GFXManager *mGFXMgr;
extern SceneManager *mSceneMgr;
extern HGE *hge;

UnitManager::UnitManager()
{
	bDebugParser = false;
	bCastingSpell = false;
	bOrderGiven = false;
	bSelected = false;
	bCastable = false;

	fPSpeed = 300.0f;

	mLeadingUnit = NULL;
	mNewOvering = NULL;
	mLastOvering = NULL;
	mCastedButton = NULL;
	mCasterUnit = NULL;
	mTargetUnit = NULL;

	iUnitNbr = 0;
}

UnitManager::~UnitManager()
{
	mUnitMgr = NULL;
}

UnitManager* UnitManager::mUnitMgr = NULL;

UnitManager* UnitManager::GetSingleton()
{
	if (mUnitMgr == NULL)
		mUnitMgr = new UnitManager;
	return mUnitMgr;
}

void UnitManager::CreateProjectile( Spell* spell, Unit* target, Unit* origin )
{
	string oname = origin->GetName();
	if (lProjectileList.find(oname) == lProjectileList.end())
	{
		lProjectileList[oname] = Projectile(spell, target, origin);
	}
	string fxname = spell->sAttackEffect;
	lProjectileList[oname].GetPSys()->MoveTo(
		origin->GetX()+mGFXMgr->lFXList[fxname].fOffX,
		origin->GetY()+mGFXMgr->lFXList[fxname].fOffY
	);
	lProjectileList[oname].GetPSys()->Stop(true);
	lProjectileList[oname].GetPSys()->Fire();
}

void UnitManager::DeleteUnits()
{
	map<int, Unit*>::iterator iterUnit;
	for (iterUnit = lUnitList.begin(); iterUnit != lUnitList.end(); iterUnit++)
	{
		//iterUnit->second->DeleteThis();
		delete iterUnit->second;
	}
	lUnitList.clear();
}

Unit* UnitManager::CreateUnit( string name, float x, float y, int lvl, Race* r, int gender, Class* c, float speed )
{
    lNameToIDMap[name] = iUnitNbr;
    Unit* u = new Unit(name, x, y, lvl, r, gender, c, speed);
    u->SetBox();
    u->SetStandBox();
    u->InitAB();
    u->SetID(iUnitNbr);

    lUnitList[iUnitNbr] = u;

    iUnitNbr++;

	return lUnitList[lNameToIDMap[name]];
}

Unit* UnitManager::GetUnitByName( string name )
{
	if (lNameToIDMap.find(name) != lNameToIDMap.end())
	{
		return lUnitList[lNameToIDMap[name]];
	}
	else
	{
		return NULL;
	}
}

Unit* UnitManager::GetUnitByID( int id )
{
	if (lUnitList.find(id) != lUnitList.end())
	{
		return lUnitList[id];
	}
	else
	{
		return NULL;
	}
}

void UnitManager::DeselectAll()
{
	map<int, Unit*>::iterator iter;
	for (iter = lUnitList.begin(); iter != lUnitList.end(); iter++)
	{
		iter->second->SetSelected(false);
	}
}

Class* UnitManager::GetClass( string name )
{
	if (lClasseList.find(name) != lClasseList.end())
	{
		Class *c = &lClasseList[name];
		return c;
	}
	else
	{
		Log("# ERROR # : No class found with the name %s", name.c_str());
	}
}

Race* UnitManager::GetRace( string name )
{
	return ParseRace(mSceneMgr->luaVM, name);
}

int UnitManager::GetBaseHealth( int lvl, Class* c )
{
	string s = c->sName + "_" + ToString(lvl);
	return ToInt(tLevelToHealth->GetString(s.c_str()));
}

int UnitManager::GetBaseMana( int lvl, Class* c )
{
	string s = c->sName + "_" + ToString(lvl);
	return ToInt(tLevelToMana->GetString(s.c_str()));
}

int UnitManager::GetXPNeeded( int lvl )
{
	string s = "xp_" + ToString(lvl);
	return ToInt(tLevelToXPNeeded->GetString(s.c_str()));
}


/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Stats source              */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Stats class.                   */
/*       Stats are a set of attributes    */
/*  that are given to a unit.             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_stats.h"

void Stats::Clear()
{
	iArmor = 0;
	iHealth = 0;
	iMana = 0;
	iPowerType = 0;
	iStamina = 0;
	iIntellect = 0;
	iAgility = 0;
	iSpirit = 0;
	iStrengh = 0;
	iBlock = 0;

	iResistAll = 0;
	iResistFrost = 0;
	iResistFire = 0;
	iResistNature = 0;
	iResistShadow = 0;
	iResistArcane = 0;

	iSpellPower = 0;
	iAttackPower = 0;
	iRegen5sHealth = 0;
	iRegen5sMana = 0;
	iCrit = 0;
	iCritSpell = 0;
	iHit = 0;
	iPenetration = 0;
}

Stats Stats::operator+ (Stats s1)
{
	Stats s;
	s.iArmor = iArmor + s1.iArmor;
	if (s.iArmor < 0) s.iArmor = 0;
	s.iHealth = iHealth + s1.iHealth;
	if (s.iHealth < 1) s.iHealth = 1;
	if (s.iPowerType == s1.iPowerType)
	{
		s.iMana = iMana + s1.iMana;
		if (s.iMana < 1) s.iMana = 1;
	}
	s.iStamina = iStamina + s1.iStamina;
	if (s.iStamina < 0) s.iStamina = 0;
	s.iIntellect = iIntellect + s1.iIntellect;
	if (s.iIntellect < 0) s.iIntellect = 0;
	s.iAgility = iAgility + s1.iAgility;
	if (s.iAgility < 0) s.iAgility = 0;
	s.iSpirit = iSpirit + s1.iSpirit;
	if (s.iSpirit < 0) s.iSpirit = 0;
	s.iStrengh = iStrengh + s1.iStrengh;
	if (s.iStrengh < 0) s.iStrengh = 0;
	s.iBlock = iBlock + s1.iBlock;
	if (s.iBlock < 0) s.iBlock = 0;

	s.iResistAll = iResistAll + s1.iResistAll;
	if (s.iResistAll < 0) s.iResistAll = 0;
	s.iResistFrost = iResistFrost + s1.iResistFrost;
	if (s.iResistFrost < 0) s.iResistFrost = 0;
	s.iResistFire = iResistFire + s1.iResistFire;
	if (s.iResistFire < 0) s.iResistFire = 0;
	s.iResistNature = iResistNature + s1.iResistNature;
	if (s.iResistNature < 0) s.iResistNature = 0;
	s.iResistShadow = iResistShadow + s1.iResistShadow;
	if (s.iResistShadow < 0) s.iResistShadow = 0;
	s.iResistArcane = iResistArcane + s1.iResistArcane;
	if (s.iResistArcane < 0) s.iResistArcane = 0;

	s.iSpellPower = iSpellPower + s1.iSpellPower;
	if (s.iSpellPower < 0) s.iSpellPower = 0;
	s.iAttackPower = iAttackPower + s1.iAttackPower;
	if (s.iAttackPower < 0) s.iAttackPower = 0;
	s.iRegen5sHealth = iRegen5sHealth + s1.iRegen5sHealth;
	if (s.iRegen5sHealth < 0) s.iRegen5sHealth = 0;
	s.iRegen5sMana = iRegen5sMana + s1.iRegen5sMana;
	if (s.iRegen5sMana < 0) s.iRegen5sMana = 0;
	s.iCrit = iCrit + s1.iCrit;
	if (s.iCrit < 0) s.iCrit = 0;
	s.iCritSpell = iCritSpell + s1.iCritSpell;
	if (s.iCritSpell < 0) s.iCritSpell = 0;
	s.iHit = iHit + s1.iHit;
	if (s.iHit < 0) s.iHit = 0;
	s.iPenetration = iPenetration + s1.iPenetration;
	if (s.iPenetration < 0) s.iPenetration = 0;

	return s;
}

Stats Stats::operator- (Stats s1)
{
	Stats s;
	s.iArmor = iArmor - s1.iArmor;
	if (s.iArmor < 0) s.iArmor = 0;
	s.iHealth = iHealth - s1.iHealth;
	if (s.iHealth < 1) s.iHealth = 1;
	if (s.iPowerType == s1.iPowerType)
	{
		s.iMana = iMana - s1.iMana;
		if (s.iMana < 1) s.iMana = 1;
	}
	s.iStamina = iStamina - s1.iStamina;
	if (s.iStamina < 0) s.iStamina = 0;
	s.iIntellect = iIntellect - s1.iIntellect;
	if (s.iIntellect < 0) s.iIntellect = 0;
	s.iAgility = iAgility - s1.iAgility;
	if (s.iAgility < 0) s.iAgility = 0;
	s.iSpirit = iSpirit - s1.iSpirit;
	if (s.iSpirit < 0) s.iSpirit = 0;
	s.iStrengh = iStrengh - s1.iStrengh;
	if (s.iStrengh < 0) s.iStrengh = 0;
	s.iBlock = iBlock - s1.iBlock;
	if (s.iBlock < 0) s.iBlock = 0;

	s.iResistAll = iResistAll - s1.iResistAll;
	if (s.iResistAll < 0) s.iResistAll = 0;
	s.iResistFrost = iResistFrost - s1.iResistFrost;
	if (s.iResistFrost < 0) s.iResistFrost = 0;
	s.iResistFire = iResistFire - s1.iResistFire;
	if (s.iResistFire < 0) s.iResistFire = 0;
	s.iResistNature = iResistNature - s1.iResistNature;
	if (s.iResistNature < 0) s.iResistNature = 0;
	s.iResistShadow = iResistShadow - s1.iResistShadow;
	if (s.iResistShadow < 0) s.iResistShadow = 0;
	s.iResistArcane = iResistArcane - s1.iResistArcane;
	if (s.iResistArcane < 0) s.iResistArcane = 0;

	s.iSpellPower = iSpellPower - s1.iSpellPower;
	if (s.iSpellPower < 0) s.iSpellPower = 0;
	s.iAttackPower = iAttackPower - s1.iAttackPower;
	if (s.iAttackPower < 0) s.iAttackPower = 0;
	s.iRegen5sHealth = iRegen5sHealth - s1.iRegen5sHealth;
	if (s.iRegen5sHealth < 0) s.iRegen5sHealth = 0;
	s.iRegen5sMana = iRegen5sMana - s1.iRegen5sMana;
	if (s.iRegen5sMana < 0) s.iRegen5sMana = 0;
	s.iCrit = iCrit - s1.iCrit;
	if (s.iCrit < 0) s.iCrit = 0;
	s.iCritSpell = iCritSpell - s1.iCritSpell;
	if (s.iCritSpell < 0) s.iCritSpell = 0;
	s.iHit = iHit - s1.iHit;
	if (s.iHit < 0) s.iHit = 0;
	s.iPenetration = iPenetration - s1.iPenetration;
	if (s.iPenetration < 0) s.iPenetration = 0;
}

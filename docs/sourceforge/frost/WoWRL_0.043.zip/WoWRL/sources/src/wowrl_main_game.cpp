/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_lua.h"
#include "wowrl_scenemanager.h"
#include "wowrl_unitmanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_zonemanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_fontmanager.h"
#include "wowrl_modelmanager.h"
#include "wowrl_pathfinding.h"
#include "wowrl_collision.h"
#include "wowrl_distortion.h"
#include "wowrl_model.h"
#include "wowrl_gui.h"
#include "wowrl_projectile.h"
#include "wowrl_statusbar.h"

extern TimeManager *mTimeMgr;
extern InputManager *mInputMgr;
extern SceneManager *mSceneMgr;
extern UnitManager *mUnitMgr;
extern GFXManager *mGFXMgr;
extern ZoneManager *mZoneMgr;
extern GUIManager *mGUIMgr;
extern FontManager *mFontMgr;
extern ModelManager *mModelMgr;
extern HGE* hge;

using namespace std;

float timerAlpha;

bool debugMain = false;

bool GameFrame()
{
    #ifdef PROFILE
        Profiler* prof1 = mTimeMgr->GetProfiler(8, "FrameFunc - Inputs", false);
        Chrono c1(prof1);
    #endif

    if (debugMain) Log("1");

    // Get delta time and FPS
    mTimeMgr->Update();

    if (debugMain) Log("2");

    // Get keys and mouse events
    mInputMgr->Update();

    if (debugMain) Log("3");

    // Update the view
    mSceneMgr->Update();

    if (debugMain) Log("4");

    if (mInputMgr->KeyIsPressed(HGEK_DELETE))
    {
        // Kill selected
        if (mUnitMgr->bSelected)
        {
            map<int, Unit*>::iterator iter;
            while (mUnitMgr->lSelectedList.empty() == false)
            {
                iter = mUnitMgr->lSelectedList.begin();
                iter->second->Die();
            }
            mUnitMgr->bSelected = false;
        }
    }

    static bool spawned = false;
    static int uNbr=0;

    if (mInputMgr->KeyIsPressed(HGEK_NUMPAD1))
    {
        // Spawn a mage
        if (!spawned)
        {
            uNbr++;
            Log("scourge, %d", mUnitMgr->GetRace("scourge"));
            Unit* u = mUnitMgr->CreateUnit(
                "Player"+ToString(uNbr),
                mInputMgr->fGMX, mInputMgr->fGMY,
                hge->Random_Int(1,70),
                mUnitMgr->GetRace("scourge"),
                GENDER_FEMALE,
                mUnitMgr->GetClass("mage"),
                mUnitMgr->fPSpeed
            );
            mGFXMgr->ForceUpdate();
            spawned = true;
        }
    }
    else
        spawned = false;

    if (mInputMgr->KeyIsPressed(HGEK_NUMPAD2))
    {
        // Spawn a hunter
        if (!spawned)
        {
            uNbr++;
            Unit* u = mUnitMgr->CreateUnit(
                "Player"+ToString(uNbr),
                mInputMgr->fGMX, mInputMgr->fGMY,
                hge->Random_Int(1,70),
                mUnitMgr->GetRace("tauren"),
                GENDER_MALE,
                mUnitMgr->GetClass("hunter"),
                mUnitMgr->fPSpeed
            );
            mGFXMgr->ForceUpdate();
            spawned = true;
        }
    }
    else
        spawned = false;

    if (mInputMgr->KeyIsPressed(HGEK_NUMPAD3))
    {
        // Spawn a priest
        if (!spawned)
        {
            uNbr++;
            Unit* u = mUnitMgr->CreateUnit(
                "Player"+ToString(uNbr),
                mInputMgr->fGMX, mInputMgr->fGMY,
                hge->Random_Int(1,70),
                mUnitMgr->GetRace("troll"),
                GENDER_FEMALE,
                mUnitMgr->GetClass("priest"),
                mUnitMgr->fPSpeed
            );
            mGFXMgr->ForceUpdate();
            spawned = true;
        }
    }
    else
        spawned = false;

    if (mInputMgr->KeyIsPressed(HGEK_C))
    {
        if (mUnitMgr->bSelected)
        {
            map<int, Unit*>::iterator iter;
            for (iter = mUnitMgr->lSelectedList.begin(); iter != mUnitMgr->lSelectedList.end(); iter++)
            {
                if (!iter->second->IsDead())
                    iter->second->SetInCombat();
            }
        }
    }

    if (mInputMgr->KeyIsPressed(HGEK_T))
    {
        int error = luaL_dofile(mSceneMgr->luaVM, "Scripts/test.lua");
        if (error) LUA::LogL(mSceneMgr->luaVM);
    }

    if (mInputMgr->KeyIsPressed(HGEK_H))
    {
        if (mUnitMgr->bSelected)
        {
            map<int, Unit*>::iterator iter;
            while (mUnitMgr->lSelectedList.empty() == false)
            {
                iter = mUnitMgr->lSelectedList.begin();
                if (!iter->second->IsDead())
                {
                    iter->second->SetHostile(true);
                }
                else
                {
                    iter->second->SetSelected(false);
                }
            }
            mUnitMgr->bSelected = false;
        }
    }

    if (mInputMgr->KeyIsPressed(HGEK_S) && mInputMgr->bShiftPressed)
    {
        mGUIMgr->bShowEnemiesStatusBars = !mGUIMgr->bShowEnemiesStatusBars;
    }
    else if (mInputMgr->KeyIsPressed(HGEK_S))
    {
        mGUIMgr->bShowStatusBars = !mGUIMgr->bShowStatusBars;
    }

    if (mInputMgr->KeyIsPressed(HGEK_G))
    {
        map<float, Object>::iterator iter;
        for (iter = mGFXMgr->lZSortedList.begin(); iter != mGFXMgr->lZSortedList.end(); iter++)
        {
            if (iter->second.iType == OBJ_TYPE_UNIT)
            {
                Unit *u = static_cast<Unit*>(iter->second.mPtr);
                if (u->IsSelected())
                    Log("[%f] %s (S)", iter->first, u->GetName().c_str());
                else
                    Log("[%f] %s", iter->first, u->GetName().c_str());
            }
            else if (iter->second.iType == OBJ_TYPE_DOODAD)
            {
                Doodad *d = static_cast<Doodad*>((*iter).second.mPtr);
                Log("[%f] %s", iter->first, d->sName.c_str());
            }
        }
    }

    if (mInputMgr->KeyIsPressed(HGEK_U))
    {
        Log("# GUI # :");
        Log(" - AddOns list :");
        map<string, AddOn>::iterator iter1;
        for (iter1 = mGUIMgr->lAddOnList.begin(); iter1 != mGUIMgr->lAddOnList.end(); iter1++)
        {
            Log("	 - %s (%d)", iter1->second.sName.c_str(), iter1->second.bEnabled);
        }

        Log("\n - GUIElement list :");

        map<string, GUIElement*>::iterator iter2;
        for (iter2 = mGUIMgr->lGuiList.begin(); iter2 != mGUIMgr->lGuiList.end(); iter2++)
        {
            if (!iter2->second->bChild)
                iter2->second->Print(1);
        }
    }

    if (mInputMgr->KeyIsPressed(HGEK_R))
    {
        mSceneMgr->luaVM = mGUIMgr->ReLoadUI(mSceneMgr->luaVM);
    }

    if (mInputMgr->KeyIsPressed(HGEK_P))
    {
        mTimeMgr->SetProfiling(true);
    }

    #ifdef PROFILE
        c1.Stop();
    #endif

    if (debugMain) Log("5");

    /* ---------------------------------------------------- */
    /* Handle clicking : movements                          */
    /* ---------------------------------------------------- */

    #ifdef PROFILE
        Profiler* prof2 = mTimeMgr->GetProfiler(8, "FrameFunc - Interpret clicks", false);
        Chrono c2(prof2);
    #endif

    // Parse all units to define wether the mouse is hovering one
    bool attack = false;
    if (mSceneMgr->bMouseOverPlayField)
    {
        Unit* target = NULL;
        mUnitMgr->mNewOvering = NULL;

        map<float, Unit*>::iterator iterUnit;
        for (iterUnit = mGFXMgr->lZSortedUnitList.begin(); iterUnit != mGFXMgr->lZSortedUnitList.end(); iterUnit++)
        {
            Unit* u = iterUnit->second;
            attack = u->TestPoint(mInputMgr->fMX, mInputMgr->fMY);

            if (attack)
            {
                mUnitMgr->mNewOvering = u;
            }

            if (!u->IsDead() && u->IsHostile() && mUnitMgr->bSelected)
            {
                if (attack)
                {
                    target = u;
                    if (!mSceneMgr->bPanning)
                        mGUIMgr->mCursor = mGUIMgr->SwitchCursor("attack");
                    break;
                }
                else
                {
                    if (!mSceneMgr->bPanning)
                        mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal");
                }
            }
            else
                attack = false;
        }

        if ( (mUnitMgr->mNewOvering != mUnitMgr->mLastOvering) &&
             (!mGUIMgr->mSelSquare.IsActive()) &&
             ((mInputMgr->fDMX != 0.0f) || (mInputMgr->fDMY != 0.0f)) )
        {
            int asking = LUA::GetGlobalInt("AskingForTooltip", false);
            lua_pushboolean(mSceneMgr->luaVM, true);
            lua_setglobal(mSceneMgr->luaVM, "ChangeToolTipContent");
            if (mUnitMgr->mNewOvering != NULL)
            {
                lua_newtable(mSceneMgr->luaVM);
                lua_setglobal(mSceneMgr->luaVM, "NewContent");
                lua_getglobal(mSceneMgr->luaVM, "NewContent");
                LUA::SetFieldString("type", "unit");
                LUA::SetFieldString("id", mUnitMgr->mNewOvering->GetName());
                lua_pop(mSceneMgr->luaVM, 1);

                if (mUnitMgr->mLastOvering == NULL)
                {
                    asking++;
                    lua_pushnumber(mSceneMgr->luaVM, asking);
                    lua_setglobal(mSceneMgr->luaVM, "AskingForTooltip");
                }
            }
            else
            {
                asking--;
                lua_pushnumber(mSceneMgr->luaVM, asking);
                lua_setglobal(mSceneMgr->luaVM, "AskingForTooltip");
            }
            mUnitMgr->mLastOvering = mUnitMgr->mNewOvering;
        }

        if ( (mInputMgr->iMRState==2)          &&
             (mUnitMgr->bSelected)             &&
             (!mGUIMgr->mSelSquare.IsActive()) &&
             (!mUnitMgr->bCastingSpell) )
        {
            if (mInputMgr->bAltPressed) // It's a target order
            {
                map<int, Unit*>::iterator iterSelected;
                for (iterSelected = mUnitMgr->lSelectedList.begin(); iterSelected != mUnitMgr->lSelectedList.end(); iterSelected++)
                {
    // TODO (Corentin#1#): Keep track of spell target.
                    iterSelected->second->Target(mUnitMgr->mNewOvering);
                }
            }
            else
            {
                if (attack) // It's, obviously, an attack order
                {
                    map<int, Unit*>::iterator iter;
                    for (iter = mUnitMgr->lSelectedList.begin(); iter != mUnitMgr->lSelectedList.end(); iter++)
                    {
                        Unit* u = iter->second;
                        if (!u->IsDead())
                        {
                            string reason;
                            u->Target(target);
                            if (u->IsCastable(u->GetDefaultSpell(), &reason, true))
                            {
                                if (u->IsInSpellRange(target->GetX(), target->GetY()))
                                    u->Incant(u->GetDefaultSpell(), target);
                                else
                                {
                                    u->MoveInRange(target);
                                    if (mUnitMgr->lOrderList.find(u->GetID()) == mUnitMgr->lOrderList.end())
                                    {
                                        mUnitMgr->lOrderList[u->GetID()] = u;
                                    }
                                }
                            }
                            else
                                mGUIMgr->AddErrorMessage(u->GetName() + " : " + mSceneMgr->tStrTable->GetString(reason.c_str()));
                        }
                    }
                }
                else // It's a movement order
                {
                    if (!CheckPointCollision(ToInt(mInputMgr->fGMX), ToInt(mInputMgr->fGMY)))
                    {
                        // If the destination is not obstruded, set it to the mouse position
                        mUnitMgr->mLeadingUnit->pDestPoint.Set(ToInt(mInputMgr->fGMX), ToInt(mInputMgr->fGMY));
                    }
                    else
                    {
                        // Else define which is the nearest free point to go
                        mUnitMgr->mLeadingUnit->pDestPoint = GetNearestFreePoint(
                            mUnitMgr->mLeadingUnit->GetGX(), mUnitMgr->mLeadingUnit->GetGY(),
                            ToInt(mInputMgr->fGMX), ToInt(mInputMgr->fGMY)
                        );
                    }

                    vector<Point> destPoint;
                    // If Ctrl is not pressed, make several destinations
                    if (!mInputMgr->bCtrlPressed)
                    {
                        // Get the size of the unit
                        hgeRect* tmpRect = mUnitMgr->mLeadingUnit->GetBox();
                        float space = tmpRect->x2-tmpRect->x1;
                        // And call the function
                        destPoint = GetDestPoints(mUnitMgr->mLeadingUnit, mUnitMgr->lSelectedList.size(), space);
                    }
                    // Else, make only one
                    vector<Point>::iterator iterPoint = destPoint.begin();

                    // Then parse all selected units to give them orders
                    map<int, Unit*>::iterator iter;
                    for (iter = mUnitMgr->lSelectedList.begin(); iter != mUnitMgr->lSelectedList.end(); iter++)
                    {
                        Unit *u = iter->second;
                        if (!u->IsDead())
                        {
                            u->Stop();

                            // If ctrl is not pressed, give this unit a unique destination
                            if (!mInputMgr->bCtrlPressed)
                            {
                                u->pDestPoint = *iterPoint;
                                iterPoint++;
                            }
                            else // Else, all units are going to the same point
                            {
                                u->pDestPoint = mUnitMgr->mLeadingUnit->pDestPoint;
                            }

                            // Get the path
                            mSceneMgr->RequestWPPath(u);
                            u->bPathRequested = false;
                            u->bPathObtained = false;
                            u->bFollowing = false;
                            u->bFollowingWp = false;
                            u->iOrder = MOVEMENT_MOVE;

                            // Add the unit to the order list
                            if (mUnitMgr->lOrderList.find(u->GetID()) == mUnitMgr->lOrderList.end())
                            {
                                mUnitMgr->lOrderList[u->GetID()] = u;
                            }

                            mUnitMgr->bOrderGiven = true;
                        }
                    }
                }
            }
        }
        else if ( (mInputMgr->iMRState==2) && (mUnitMgr->bCastingSpell) )
        {
            mUnitMgr->bCastingSpell = false;
            mUnitMgr->mCastedButton = NULL;
            if (!mSceneMgr->bPanning)
                mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal");
        }
    }

    if (!attack && !mSceneMgr->bPanning)
    {
        if (CheckPointCollision(ToInt(mInputMgr->fGMX), ToInt(mInputMgr->fGMY)))
            mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_imp");
        else
            mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal");
    }

    /* ---------------------------------------------------- */
    /* Handle clicking : selections and actions             */
    /* ---------------------------------------------------- */

    if (debugMain) Log("6");

    if (mUnitMgr->bCastingSpell)
    {
        if (mUnitMgr->mCastedButton->mSpell->iTargetType == SPELL_TARGET_HOSTILES)
        {
            bool attack=false;
            map<int, Unit*>::iterator iterHostile;
            for (iterHostile = mUnitMgr->lHostileList.begin(); iterHostile != mUnitMgr->lHostileList.end(); iterHostile++)
            {
                Unit* u = iterHostile->second;
                attack = u->TestPoint(mInputMgr->fMX, mInputMgr->fMY);
                if (attack)
                {
                    mUnitMgr->mTargetUnit = u;
                    if (!mSceneMgr->bPanning)
                        mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action");
                    mUnitMgr->bCastable = true;
                    break;
                }
                else
                {
                    if (!mSceneMgr->bPanning)
                        mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action_imp");
                    mUnitMgr->bCastable = false;
                }
            }
        }
        if (mUnitMgr->mCastedButton->mSpell->iTargetType == SPELL_TARGET_FRIENDS)
        {
            bool attack=false;
            map<int, Unit*>::iterator iterUnit;
            for (iterUnit = mUnitMgr->lUnitList.begin(); iterUnit != mUnitMgr->lUnitList.end(); iterUnit++)
            {
                Unit *u = iterUnit->second;
                if (!u->IsHostile())
                {
                    attack = u->TestPoint(mInputMgr->fMX, mInputMgr->fMY);
                    if (attack)
                    {
                        mUnitMgr->mTargetUnit = u;
                        if (!mSceneMgr->bPanning)
                            mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action");
                        mUnitMgr->bCastable = true;
                        break;
                    }
                    else
                    {
                        if (!mSceneMgr->bPanning)
                            mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action_imp");
                        mUnitMgr->bCastable = false;
                    }
                }
            }
        }
        else if (mUnitMgr->mCastedButton->mSpell->iTargetType == SPELL_TARGET_ALL)
        {
            bool attack=false;
            map<int, Unit*>::iterator iterUnit;
            for (iterUnit = mUnitMgr->lUnitList.begin(); iterUnit != mUnitMgr->lUnitList.end(); iterUnit++)
            {
                Unit *u = iterUnit->second;
                attack = u->TestPoint(mInputMgr->fMX, mInputMgr->fMY);
                if (attack)
                {
                    mUnitMgr->mTargetUnit = u;
                    if (!mSceneMgr->bPanning)
                        mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action");
                    mUnitMgr->bCastable = true;
                    break;
                }
                else
                {
                    if (!mSceneMgr->bPanning)
                        mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action_imp");
                    mUnitMgr->bCastable = false;
                }
            }
        }
        else if (mUnitMgr->mCastedButton->mSpell->iTargetType == SPELL_TARGET_DEADS)
        {
            bool attack=false;
            map<int, Unit*>::iterator iterDeath;
            for (iterDeath = mUnitMgr->lDeadList.begin(); iterDeath != mUnitMgr->lDeadList.end(); iterDeath++)
            {
                Unit *u = iterDeath->second;
                attack = u->TestPoint(mInputMgr->fMX, mInputMgr->fMY);
                if (attack)
                {
                    mUnitMgr->mTargetUnit = u;
                    if (!mSceneMgr->bPanning)
                        mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action");
                    mUnitMgr->bCastable = true;
                    break;
                }
                else
                {
                    if (!mSceneMgr->bPanning)
                        mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action_imp");
                    mUnitMgr->bCastable = false;
                }
            }
        }
        else if (mUnitMgr->mCastedButton->mSpell->iTargetType == SPELL_TARGET_DEAD_FRIENDS)
        {
            bool attack=false;
            map<int, Unit*>::iterator iterDeath;
            for (iterDeath = mUnitMgr->lDeadList.begin(); iterDeath != mUnitMgr->lDeadList.end(); iterDeath++)
            {
                Unit *u = iterDeath->second;
                if (!u->IsHostile())
                {
                    attack = u->TestPoint(mInputMgr->fMX, mInputMgr->fMY);
                    if (attack)
                    {
                        mUnitMgr->mTargetUnit = u;
                        if (!mSceneMgr->bPanning)
                            mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action");
                        mUnitMgr->bCastable = true;
                        break;
                    }
                    else
                    {
                        if (!mSceneMgr->bPanning)
                            mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action_imp");
                        mUnitMgr->bCastable = false;
                    }
                }
            }
        }
        else if (mUnitMgr->mCastedButton->mSpell->iTargetType == SPELL_TARGET_DEAD_HOSTILES)
        {
            bool attack=false;
            map<int, Unit*>::iterator iterDeath;
            for (iterDeath = mUnitMgr->lDeadList.begin(); iterDeath != mUnitMgr->lDeadList.end(); iterDeath++)
            {
                Unit *u = iterDeath->second;
                if (u->IsHostile())
                {
                    attack = u->TestPoint(mInputMgr->fMX, mInputMgr->fMY);
                    if (attack)
                    {
                        mUnitMgr->mTargetUnit = u;
                        if (!mSceneMgr->bPanning)
                            mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action");
                        mUnitMgr->bCastable = true;
                        break;
                    }
                    else
                    {
                        if (!mSceneMgr->bPanning)
                            mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action_imp");
                        mUnitMgr->bCastable = false;
                    }
                }
            }
        }
    }

    // Simple selection : only one unit is selected
    if ( (mInputMgr->iMLState == 2) && (mSceneMgr->bMouseOverPlayField) )
    {
        if (!mUnitMgr->bCastingSpell)
        {
            if (!mUnitMgr->mNewOvering)
            {
                mUnitMgr->DeselectAll();
            }
            else
            {
                if (!mInputMgr->bShiftPressed)
                {
                    mUnitMgr->DeselectAll();
                }
                if (mInputMgr->bCtrlPressed)
                {
                    Class* c = mUnitMgr->mNewOvering->GetClass();
                    map<int, Unit*>::iterator iter;
                    for (iter = mUnitMgr->lUnitList.begin(); iter != mUnitMgr->lUnitList.end(); iter++)
                    {
                        Unit *u = iter->second;
                        if (!u->IsHostile())
                        {
                            if (u->GetClass() == c)
                            {
                                u->SetSelected(true);
                            }
                        }
                    }
                }
                else
                {
                    if (mUnitMgr->mNewOvering->IsSelected())
                        mUnitMgr->mNewOvering->SetSelected(false);
                    else
                        mUnitMgr->mNewOvering->SetSelected(true);
                }
            }

            if (!mUnitMgr->lSelectedList.empty())
                mUnitMgr->bSelected = true;
            else
                mUnitMgr->bSelected = false;
        }
        else
        {
            if (mUnitMgr->bCastable)
            {
                Unit* u = mUnitMgr->mCasterUnit;
                Unit* t = mUnitMgr->mTargetUnit;
                u->Stop();
                u->Target(t);
                string reason;
                if (u->IsCastable(mUnitMgr->mCastedButton->mSpell, &reason, true))
                {
                    string reason;
                    if (u->IsTargetInRange(mUnitMgr->mCastedButton->mSpell))
                        u->Incant(mUnitMgr->mCastedButton->mSpell, t);
                    else
                    {
                        u->Target(t);
                        u->MoveInRange(t);
                        if (mUnitMgr->lOrderList.find(u->GetID()) == mUnitMgr->lOrderList.end())
                        {
                            mUnitMgr->lOrderList[u->GetID()] = u;
                        }
                    }
                }
                else
                    mGUIMgr->AddErrorMessage(mUnitMgr->mCasterUnit->GetName() + " : " + mSceneMgr->tStrTable->GetString(reason.c_str()));

                mUnitMgr->bCastingSpell = false;
                mUnitMgr->bCastable = false;
                mUnitMgr->mCastedButton = NULL;
                if (!mSceneMgr->bPanning)
                    mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal");
            }
        }
    }

    #ifdef PROFILE
        c2.Stop();
    #endif

    #ifdef PROFILE
        Profiler* prof3 = mTimeMgr->GetProfiler(8, "FrameFunc - Updates", false);
        Chrono c3(prof3);
    #endif

    if (debugMain) Log("7");

    // Update the UI...
    mGUIMgr->UpdateUI();

    if (debugMain) Log("8");

    // Update the selection square
    mGUIMgr->mSelSquare.Update();

    if (debugMain) Log("9");

    /* ---------------------------------------------------- */
    /* End loop maths                                       */
    /* ---------------------------------------------------- */

    // Global alpha glow
    timerAlpha += mTimeMgr->GetDelta();
    if (timerAlpha > M_PI_2)
        timerAlpha = 0;

    /* ---------------------------------------------------- */
    /* Updates                                              */
    /* ---------------------------------------------------- */

    // Update leading unit
    if (mUnitMgr->bSelected)
    {
        if (mUnitMgr->lSelectedList.empty())
        {
            mUnitMgr->mLeadingUnit = NULL;
            mUnitMgr->bSelected = false;
        }
        else
        {
            mUnitMgr->mLeadingUnit = NULL;
            map<int, Unit*>::iterator iter;
            for (iter = mUnitMgr->lSelectedList.begin(); iter != mUnitMgr->lSelectedList.end(); iter++)
            {
                if (!iter->second->IsDead())
                {
                    mUnitMgr->mLeadingUnit = iter->second;
                    break;
                }
            }
            if (mUnitMgr->mLeadingUnit == NULL)
            {
                mUnitMgr->mLeadingUnit = mUnitMgr->lSelectedList.begin()->second;
            }
        }
    }
    else
    {
        mUnitMgr->mLeadingUnit = NULL;
    }

    if (debugMain) Log("10");

    if (!mSceneMgr->bGamePaused)
    {
        // Update scrolling combat texts
        mGUIMgr->UpdateScrollingTexts();

        if (debugMain) Log("11");

        // Update error texts
        mGUIMgr->UpdateErrorTexts();

        if (debugMain) Log("12");

        // Build a certain amount of the requested paths
        mSceneMgr->BuildWPPaths();

        if (debugMain) Log("13");

        // Build some other paths
        mSceneMgr->BuildPaths();

        if (debugMain) Log("14");

        mSceneMgr->BuildDirectPaths();

        if (debugMain) Log("15");

        #ifdef PROFILE
            Profiler* prof5 = mTimeMgr->GetProfiler(8, "FrameFunc - Updates - Projectiles", false);
            Chrono c5(prof5);
        #endif

        // Update all projectiles and their particle system
        map<string, Projectile>::iterator iterProj, lastProj;
        lastProj = NULL;
        for (iterProj = mUnitMgr->lProjectileList.begin(); iterProj != mUnitMgr->lProjectileList.end(); iterProj++)
        {
            Projectile *p = &iterProj->second;
            if (!p->UpdatePos())
            {
                p->GetPSys()->Stop();
                mUnitMgr->lProjectileList.erase(iterProj);
                if (mUnitMgr->lProjectileList.empty())
                {
                    break;
                }
                if (lastProj == NULL)
                {
                    iterProj = mUnitMgr->lProjectileList.begin();
                    continue;
                }
                else
                    iterProj = lastProj;
            }
            else
            {
                p->GetPSys()->MoveTo(p->fX, p->fY);
                p->GetPSys()->Transpose(mSceneMgr->fGX, mSceneMgr->fGY);
                p->GetPSys()->Update(mTimeMgr->GetDelta());
            }
            lastProj = iterProj;
        }

        if (debugMain) Log("16");
    }
    else
    {
        map<string, Projectile>::iterator iterProj, lastProj;
        lastProj = NULL;
        for (iterProj = mUnitMgr->lProjectileList.begin(); iterProj != mUnitMgr->lProjectileList.end(); iterProj++)
        {
            Projectile *p = &iterProj->second;
            p->GetPSys()->MoveTo(p->fX, p->fY);
            p->GetPSys()->Transpose(mSceneMgr->fGX, mSceneMgr->fGY);
        }
    }

    mGFXMgr->BuildRenderList();

    if (debugMain) Log("17");

    if (mUnitMgr->bOrderGiven)
    {
        SetGlowing(mGUIMgr->mOrderCircle, timerAlpha);
        if (mUnitMgr->lOrderList.empty())
            mUnitMgr->bOrderGiven = false;
    }

    // Update the cursor animation if it has one
    if (mGUIMgr->mCursor->bAnimated)
        mGUIMgr->mCursor->mAnim->Update(mTimeMgr->GetDelta());

    // Update target links color
    if (mUnitMgr->bSelected)
    {
        mGUIMgr->fTargetLinkTimer += mTimeMgr->GetDelta()/2;
        if (mGUIMgr->fTargetLinkTimer > 1.0f)
            mGUIMgr->fTargetLinkTimer = 0.0f;

        mGUIMgr->dwTargetLinkColorF1 = ARGB(
            255, 0,
            127.5f*sin((mGUIMgr->fTargetLinkTimer+0.25f)*2*M_PI)+127.5f,
            0
        );
        mGUIMgr->dwTargetLinkColorF2 = ARGB(
            255, 0,
            127.5f*sin(mGUIMgr->fTargetLinkTimer*2*M_PI)+127.5f,
            0
        );
        mGUIMgr->dwTargetLinkColorF3 = ARGB(
            255, 0,
            127.5f*sin((mGUIMgr->fTargetLinkTimer-0.25f)*2*M_PI)+127.5f,
            0
        );

        mGUIMgr->dwTargetLinkColorE1 = ARGB(
            255,
            127.5f*sin((mGUIMgr->fTargetLinkTimer+0.25f)*2*M_PI)+127.5f,
            0, 0
        );
        mGUIMgr->dwTargetLinkColorE2 = ARGB(
            255,
            127.5f*sin(mGUIMgr->fTargetLinkTimer*2*M_PI)+127.5f,
            0, 0
        );
        mGUIMgr->dwTargetLinkColorE3 = ARGB(
            255,
            127.5f*sin((mGUIMgr->fTargetLinkTimer-0.25f)*2*M_PI)+127.5f,
            0, 0
        );
    }

    #ifdef PROFILE
        c3.Stop();
    #endif

    return false;
}

bool GameRender()
{
    // Update the vertex buffer if needed
    mModelMgr->UpdateVertexList(true);

    map<float, Unit*>::iterator iterUnit;
    map<int, Unit*>::iterator iterUnit2;
    mGFXMgr->Prepare3D();

    // Update units' sprites
    for (iterUnit = mGFXMgr->lZSortedUnitList.begin(); iterUnit != mGFXMgr->lZSortedUnitList.end(); iterUnit++)
    {
        iterUnit->second->RenderSprite();
    }

    mGFXMgr->Prepare2D();
    // Begin rendering.
    hge->Gfx_BeginScene(mGFXMgr->mMainTarget);
    hge->Gfx_Clear(ARGB(255, 0, 0, 0));
    mGFXMgr->mDxDevice->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, FALSE);
    mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

    // Render the background first
    hge->System_SetState(HGE_TEXTUREFILTER, false);
    std::map<float, BGPart*>::iterator iterParts;
    for (iterParts = mZoneMgr->mActualZone.lPartList.begin(); iterParts != mZoneMgr->mActualZone.lPartList.end(); iterParts++)
    {
        BGPart* tmpPart = iterParts->second;
        tmpPart->mBg->Render(tmpPart->fX+mSceneMgr->fGX, tmpPart->fY+mSceneMgr->fGY);
    }
    hge->System_SetState(HGE_TEXTUREFILTER, true);

    // Render order circles
    if (mUnitMgr->bOrderGiven)
    {
        map<int, Unit*>::iterator iter = mUnitMgr->lOrderList.begin();
        Unit *u = iter->second;
        float mdist = GetPointDistortion(ToInt(u->pDestPoint.fX), ToInt(u->pDestPoint.fY));
        float scale = mZoneMgr->mActualZone.fDistScaleMin-mdist*(mZoneMgr->mActualZone.fDistScaleMin-mZoneMgr->mActualZone.fDistScaleMax);
        for (iter = mUnitMgr->lOrderList.begin(); iter != mUnitMgr->lOrderList.end(); iter++)
        {
            u = iter->second;
            if (u->IsSelected())
            {
                float s_scale = u->GetRace()->fShadowScale;
                float vscale = mZoneMgr->mActualZone.fDistVScaleMin-mdist*(mZoneMgr->mActualZone.fDistVScaleMin-mZoneMgr->mActualZone.fDistVScaleMax);
                mGUIMgr->mOrderCircle->RenderEx(u->pDestPoint.fX+mSceneMgr->fGX, u->pDestPoint.fY+mSceneMgr->fGY, 0.0f, 2.0f*scale*s_scale, 1.4f*scale*s_scale*vscale);
            }
        }
    }

    // Render selection, death and hostile circles and shadows
    for (iterUnit = mGFXMgr->lZSortedUnitList.begin(); iterUnit != mGFXMgr->lZSortedUnitList.end(); iterUnit++)
    {
        Unit *u = iterUnit->second;
        float ux = u->GetX();
        float uy = u->GetY();
        float scale = u->GetScale();
        float s_scale = u->GetRace()->fShadowScale;
        mGUIMgr->mPShadow->RenderEx(ux, uy, 0.0f, scale*s_scale);
        if (u->IsDead() && u->IsSelected())
            mGUIMgr->mDeathCircle->RenderEx(ux, uy, 0.0f, 2.0f*scale*s_scale, 1.2f*scale*s_scale);
        else
        {
            if (u->IsSelected())
                mGUIMgr->mSelectionCircle->RenderEx(ux, uy, 0.0f, 2.0f*scale*s_scale, 1.2f*scale*s_scale);
            if (u->IsHostile() && !u->IsDead())
                mGUIMgr->mHostileCircle->RenderEx(ux, uy, 0.0f, 2.0f*scale*s_scale, 1.2f*scale*s_scale);
        }
    }

    // Render target links
    for (iterUnit2 = mUnitMgr->lSelectedList.begin(); iterUnit2 != mUnitMgr->lSelectedList.end(); iterUnit2++)
    {
        Unit* u = iterUnit2->second;
        Unit* t = u->GetTarget();
        if (t != NULL)
        {
            DWORD col1, col2, col3;
            if (t->IsHostile())
            {
                col1 = mGUIMgr->dwTargetLinkColorE1;
                col2 = mGUIMgr->dwTargetLinkColorE2;
                col3 = mGUIMgr->dwTargetLinkColorE3;
            }
            else
            {
                col1 = mGUIMgr->dwTargetLinkColorF1;
                col2 = mGUIMgr->dwTargetLinkColorF2;
                col3 = mGUIMgr->dwTargetLinkColorF3;
            }

            hgeVector vec = hgeVector(u->GetX()-t->GetX(), u->GetY()-t->GetY());
            hgeVector vecO = vec;
            vecO.Normalize(); vecO.Rotate(M_PI_2);

            mGUIMgr->mTargetLink1.v[0].col = col1;
            mGUIMgr->mTargetLink1.v[0].x = u->GetX()-vecO.x;
            mGUIMgr->mTargetLink1.v[0].y = u->GetY()-vecO.y;
            mGUIMgr->mTargetLink1.v[1].col = col1;
            mGUIMgr->mTargetLink1.v[1].x = u->GetX()+vecO.x;
            mGUIMgr->mTargetLink1.v[1].y = u->GetY()+vecO.y;
            mGUIMgr->mTargetLink1.v[2].col = col2;
            mGUIMgr->mTargetLink1.v[2].x = u->GetX()-vec.x/2+vecO.x;
            mGUIMgr->mTargetLink1.v[2].y = u->GetY()-vec.y/2+vecO.y;
            mGUIMgr->mTargetLink1.v[3].col = col2;
            mGUIMgr->mTargetLink1.v[3].x = u->GetX()-vec.x/2-vecO.x;
            mGUIMgr->mTargetLink1.v[3].y = u->GetY()-vec.y/2-vecO.y;

            mGUIMgr->mTargetLink2.v[0].col = col2;
            mGUIMgr->mTargetLink2.v[0].x = u->GetX()-vec.x/2-vecO.x;
            mGUIMgr->mTargetLink2.v[0].y = u->GetY()-vec.y/2-vecO.y;
            mGUIMgr->mTargetLink2.v[1].col = col2;
            mGUIMgr->mTargetLink2.v[1].x = u->GetX()-vec.x/2+vecO.x;
            mGUIMgr->mTargetLink2.v[1].y = u->GetY()-vec.y/2+vecO.y;
            mGUIMgr->mTargetLink2.v[2].col = col3;
            mGUIMgr->mTargetLink2.v[2].x = t->GetX()+vecO.x;
            mGUIMgr->mTargetLink2.v[2].y = t->GetY()+vecO.y;
            mGUIMgr->mTargetLink2.v[3].col = col3;
            mGUIMgr->mTargetLink2.v[3].x = t->GetX()-vecO.x;
            mGUIMgr->mTargetLink2.v[3].y = t->GetY()-vecO.y;

            hge->Gfx_RenderQuad(&mGUIMgr->mTargetLink1);
            hge->Gfx_RenderQuad(&mGUIMgr->mTargetLink2);
        }
    }

    // Render units and doodads
    map<float, Object>::iterator iterObj;
    for (iterObj = mGFXMgr->lZSortedList.begin(); iterObj != mGFXMgr->lZSortedList.end(); iterObj++)
    {
        if (iterObj->second.iType == OBJ_TYPE_UNIT)
        {
            Unit *u = static_cast<Unit*>(iterObj->second.mPtr);
            if (u->GetModel() != NULL)
            {
                hgeSprite* s = u->GetModel()->GetSprite();
                if (s != NULL)
                {
                    float ux = u->GetX();
                    float uy = u->GetY();
                    float scale = u->GetScale();
                    float shadow = u->GetShadow();
                    RGB color = u->GetColor();

                    if (mUnitMgr->mNewOvering == u)
                    {
                        if (u->IsDead())
                            s->SetColor(ARGB(100, 255, 255, 255));
                        else if (u->IsHostile())
                            s->SetColor(ARGB(100, 255, 0, 0));
                        else
                            s->SetColor(ARGB(100, 0, 255, 0));
                        s->SetBlendMode(BLEND_COLORADD | BLEND_ALPHAADD | BLEND_NOZWRITE);
                        for (float f = 0.0f; f < 1.0f; f += 0.1f)
                        {
                            s->RenderEx(ux+2*cos(f*2*M_PI), uy+2*sin(f*2*M_PI), 0.0f, scale);
                        }
                        s->SetBlendMode(BLEND_DEFAULT);
                    }

                    s->SetColor(ARGB(255, shadow+color.fR, shadow+color.fG, shadow+color.fB));
                    s->RenderEx(ux, uy, 0.0f, scale);

                    // Render effects
                    if (u->bFXPlaying)
                    {
                        map<string, Effect> fxList = u->GetEffectList();
                        map<string, Effect>::iterator iterFX;
                        for (iterFX = fxList.begin(); iterFX != fxList.end(); iterFX++)
                        {
                            iterFX->second.RenderEx(ux, uy, 0.0f, scale);
                        }
                    }
                }
            }
        }
        else if (iterObj->second.iType == OBJ_TYPE_DOODAD)
        {
            Doodad* d = static_cast<Doodad*>(iterObj->second.mPtr);
            d->mSprite->Render(floor(d->GetX()),floor(d->GetY()));
        }
    }

    // Render projectiles
    map<string, Projectile>::iterator iterProj;
    for (iterProj = mUnitMgr->lProjectileList.begin(); iterProj != mUnitMgr->lProjectileList.end(); iterProj++)
    {
        iterProj->second.GetPSys()->Render();
    }

    // Render always in top doodads
    map<float, Doodad*>::iterator iterDoodad;
    for (iterDoodad = mGFXMgr->lRenderInTopList.begin(); iterDoodad != mGFXMgr->lRenderInTopList.end(); iterDoodad++)
    {
        Doodad* d = iterDoodad->second;
        d->mSprite->Render(ToInt(d->GetX()), ToInt(d->GetY()));
    }

    // Render status bars
    if (mGUIMgr->bShowStatusBars)
    {
        for (iterUnit = mGFXMgr->lZSortedUnitList.begin(); iterUnit != mGFXMgr->lZSortedUnitList.end(); iterUnit++)
        {
            if (!(iterUnit->second->IsHostile() && mGUIMgr->bShowEnemiesStatusBars))
            {
                StatusBar* sb = iterUnit->second->GetStatusBar();
                sb->Render();
            }
        }
    }

    mGUIMgr->RenderScrollingTexts();

    // Render the selection square
    mGUIMgr->mSelSquare.Render();

/* --------------------------------- */
/*  RENDER UI                        */
/* --------------------------------- */

    // Pause text
    if (mSceneMgr->bGamePaused)
    {
        mGUIMgr->mErrorFont->SetColor(ARGB(255, 255, 60, 60));
        mGUIMgr->mErrorFont->printf
        (
            mGFXMgr->iSWidth/2.0f, mGFXMgr->iSHeight-195, HGETEXT_CENTER,
            mSceneMgr->tStrTable->GetString("game_paused")
        );
    }

    hge->Gfx_EndScene();
    hge->Gfx_BeginScene(mGFXMgr->mMainTarget);
    mGFXMgr->mDxDevice->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, FALSE);
    //mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ONE);
    mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

    // LUA UI
    multimap<int, GUIElement*>::iterator iterGUI2;
    for (iterGUI2 = mGUIMgr->lSortedGUIList.begin(); iterGUI2 != mGUIMgr->lSortedGUIList.end(); iterGUI2++)
    {
        GUIElement* g = iterGUI2->second;
        g->Render(false);
    }

    hge->Gfx_EndScene();
    hge->Gfx_BeginScene(mGFXMgr->mMainTarget);
    mGFXMgr->mDxDevice->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, FALSE);
    mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

    // Error texts
    vector<ErrorText>::iterator iter;
    float errorY = 115.0f;
    for (iter = mGUIMgr->lErrorTextList.begin(); iter != mGUIMgr->lErrorTextList.end(); iter++)
    {
        mGUIMgr->mErrorFont->SetColor(ARGB(ToInt(iter->fAlpha), 255, 60, 60));
        mGUIMgr->mErrorFont->printf
        (
            mGFXMgr->iSWidth/2.0f, errorY, HGETEXT_CENTER,
            iter->sCaption.c_str()
        );
        errorY += 25.0f;
    }

    // FPS counter
    if (mFontMgr->mSystemFont != NULL)
    {
        mFontMgr->mSystemFont->SetColor(ARGB(255, 255, 255, 255));
        mFontMgr->mSystemFont->printf
        (
            mGFXMgr->iSWidth-10, mGFXMgr->iSHeight-20, HGETEXT_RIGHT,
            "FPS : %d",
            mTimeMgr->GetFPS()
        );
    }

    // Render the cursor above all
    if (mGUIMgr->mCursor->bAnimated)
    {
        mGUIMgr->mCursor->mAnim->RenderEx(mInputMgr->fMX, mInputMgr->fMY, mGUIMgr->mCursor->fRot, 1.0f);
    }
    else
    {
        mGUIMgr->mCursor->mSprite->RenderEx(mInputMgr->fMX, mInputMgr->fMY, mGUIMgr->mCursor->fRot, 1.0f);
    }

    hge->Gfx_EndScene();

    hge->Gfx_BeginScene();
    mGFXMgr->mDxDevice->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, FALSE);
    mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    hge->Gfx_Clear(ARGB(255, 0, 0, 0));
    mGFXMgr->mMainSprite->Render(0, 0);

    // End rendering, update the screen
    hge->Gfx_EndScene();

    /*static int frameCount = 1;
    Log("[%d]", frameCount);
    frameCount++;*/

    return false;
}

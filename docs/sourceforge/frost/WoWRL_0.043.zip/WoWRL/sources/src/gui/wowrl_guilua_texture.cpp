/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_gfxmanager.h"

#include "wowrl_gui.h"

using namespace std;

extern GFXManager *mGFXMgr;
extern HGE *hge;
extern bool debugGUI;

GUI::Texture::Texture(lua_State* luaVM) : GUI::LayeredRegion(luaVM)
{
	sPName = lua_tostring(luaVM, 1);
	sName = lua_tostring(luaVM, 2);
}

int GUI::Texture::SetTexCoord(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 4)
	{
		LUA::PrintError("Too few argument in \"Texture:SetTexCoord\" (4 expected : left, right, top, bottom)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of Texture:SetTexCoord must be a number (left)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of Texture:SetTexCoord must be a number (right)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of Texture:SetTexCoord must be a number (top)");
		error++;
	}
	if (!lua_isnumber(luaVM, 4))
	{
		LUA::PrintError("Argument 4 of Texture:SetTexCoord must be a number (bottom)");
		error++;
	}

	if (error == 0)
	{
		if (mBase != NULL)
		{
			if (mBase->mSprite != NULL)
			{
				float tw = hge->Texture_GetWidth(mBase->mSprite->GetTexture(), true);
				float th = hge->Texture_GetHeight(mBase->mSprite->GetTexture(), true);
				float sx = tw*lua_tonumber(luaVM, 1);
				float sy = th*lua_tonumber(luaVM, 3);
				float sw = tw*(lua_tonumber(luaVM, 2)-lua_tonumber(luaVM, 1));
				float sh = th*(lua_tonumber(luaVM, 4)-lua_tonumber(luaVM, 3));

				mBase->mSprite->SetTextureRect(sx, sy, sw, sh);

				mBase->mParent->RebuildCache();
			}
		}
	}

	return 0;
}

int GUI::Texture::SetTexture(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		LUA::PrintError("Too few argument in \"Texture:SetTexture\" (one expected : texture file)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		LUA::PrintError("Argument of Texture:SetTexture must be a string (texture file)");
		error++;
	}

	if (error == 0)
	{
		if (mBase != NULL)
		{
			string nfile = lua_tostring(luaVM, 1);
			if (nfile != mBase->sFile)
			{
				mBase->sFile = nfile;

				if (mBase->sFile == "")
					mBase->bReady = false;
				else
				{
					HTEXTURE tex = mGFXMgr->LoadTexture(mBase->sFile, false);
					if (tex)
					{
						float sw, sh;
						sw = hge->Texture_GetWidth(tex);
						sh = hge->Texture_GetHeight(tex);
						mBase->mSprite = mGFXMgr->CreateSprite
						(
							tex, 0, 0, sw, sh, true
						);
						if (mBase->mSprite != NULL)
						{
							mBase->mSprite->SetColor(mBase->dwColor);
							mBase->fScale = mBase->fW/sw;
							mBase->fVScale = mBase->fH/sh;
							mBase->bReady = true;
						}
						else
							mBase->bReady = false;
					}
					else
						mBase->bReady = false;
				}
				mBase->mParent->RebuildCache();
			}
		}
	}

	return 0;
}

int GUI::Texture::SetVertexColor(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 3)
	{
		LUA::PrintError("Too few argument in \"Texture:SetVertexColor\" (3 or 4 expected : red, green, blue (+alpha))");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of Texture:SetVertexColor must be a number (red)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of Texture:SetVertexColor must be a number (green)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of Texture:SetVertexColor must be a number (blue)");
		error++;
	}
	if ( (lua_gettop(luaVM) >= 4) && (!lua_isnumber(luaVM, 4)) )
	{
		LUA::PrintError("Argument 4 of Texture:SetVertexColor must be a number (alpha)");
		error++;
	}

	if (error == 0)
	{
		if (mBase != NULL)
		{
			float a, r, g, b;
			r = lua_tonumber(luaVM, 1);
			g = lua_tonumber(luaVM, 2);
			b = lua_tonumber(luaVM, 3);
			if (lua_gettop(luaVM) >= 4)
				a = lua_tonumber(luaVM, 4);
			else
				a = GETA(mBase->dwColor)/255.0f;

			DWORD color = ARGB(a*255, r*255, g*255, b*255);

			if (mBase->dwColor != color)
			{
				mBase->dwColor = color;
				if (mBase->mSprite != NULL)
				{
					mBase->mSprite->SetColor(mBase->dwColor);
				}
				mBase->mParent->RebuildCache();
			}
		}
	}

	return 0;
}


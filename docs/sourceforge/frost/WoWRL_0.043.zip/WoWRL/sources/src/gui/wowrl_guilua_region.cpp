/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_scenemanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_gfxmanager.h"

#include "wowrl_gui.h"


using namespace std;

extern InputManager *mInputMgr;
extern GUIManager *mGUIMgr;
extern GFXManager *mGFXMgr;
extern bool debugGUI;

int GUI::Region::GetBottom(lua_State* luaVM)
{
	if (mRBase != NULL)
		lua_pushnumber(luaVM, mGFXMgr->iSHeight+mRBase->GetY(false)+mRBase->fH);
	return 1;
}

int GUI::Region::GetCenter(lua_State* luaVM)
{
	if (mRBase != NULL)
	{
		lua_pushnumber(luaVM, mRBase->GetX(false)+mRBase->fW/2);
		lua_pushnumber(luaVM, mGFXMgr->iSHeight+mRBase->GetY(false)+mRBase->fH/2);
	}
	return 2;
}

int GUI::Region::GetHeight(lua_State* luaVM)
{
	if (mRBase != NULL)
		lua_pushnumber(luaVM, mRBase->fH);
	return 1;
}

int GUI::Region::GetLeft(lua_State* luaVM)
{
	if (mRBase != NULL)
		lua_pushnumber(luaVM, mRBase->GetX(false));
	return 1;
}

int GUI::Region::GetName(lua_State* luaVM)
{
	if (mRBase != NULL)
		lua_pushstring(luaVM, mRBase->sName.c_str());
	return 1;
}

int GUI::Region::GetParent(lua_State* luaVM)
{
	if (mRBase != NULL)
	{
		if (mRBase->mParent != NULL)
		{
			lua_getglobal(luaVM, mRBase->mParent->sName.c_str());
			lua_pushvalue(luaVM, -1);
		}
		else
			lua_pushnil(luaVM);
	}

	return 1;
}

int GUI::Region::GetPoint(lua_State* luaVM)
{
	if (mRBase != NULL)
	{
		Anchor a = mRBase->lAnchorList[0];
		switch (a.iAnchorPt)
		{
			case GUI_ANCHOR_TOPLEFT: lua_pushstring(luaVM, "TOPLEFT"); break;
			case GUI_ANCHOR_TOP: lua_pushstring(luaVM, "TOPL"); break;
			case GUI_ANCHOR_TOPRIGHT: lua_pushstring(luaVM, "TOPRIGHT"); break;
			case GUI_ANCHOR_RIGHT: lua_pushstring(luaVM, "RIGHT"); break;
			case GUI_ANCHOR_BOTTOMRIGHT: lua_pushstring(luaVM, "BOTTOMRIGHT"); break;
			case GUI_ANCHOR_BOTTOM: lua_pushstring(luaVM, "BOTTOM"); break;
			case GUI_ANCHOR_BOTTOMLEFT: lua_pushstring(luaVM, "BOTTOMLEFT"); break;
			case GUI_ANCHOR_LEFT: lua_pushstring(luaVM, "LEFT"); break;
			case GUI_ANCHOR_CENTER: lua_pushstring(luaVM, "CENTER"); break;
		}
		lua_pushstring(luaVM, a.sParentName.c_str());
		switch (a.iRelativePt)
		{
			case GUI_ANCHOR_TOPLEFT: lua_pushstring(luaVM, "TOPLEFT"); break;
			case GUI_ANCHOR_TOP: lua_pushstring(luaVM, "TOPL"); break;
			case GUI_ANCHOR_TOPRIGHT: lua_pushstring(luaVM, "TOPRIGHT"); break;
			case GUI_ANCHOR_RIGHT: lua_pushstring(luaVM, "RIGHT"); break;
			case GUI_ANCHOR_BOTTOMRIGHT: lua_pushstring(luaVM, "BOTTOMRIGHT"); break;
			case GUI_ANCHOR_BOTTOM: lua_pushstring(luaVM, "BOTTOM"); break;
			case GUI_ANCHOR_BOTTOMLEFT: lua_pushstring(luaVM, "BOTTOMLEFT"); break;
			case GUI_ANCHOR_LEFT: lua_pushstring(luaVM, "LEFT"); break;
			case GUI_ANCHOR_CENTER: lua_pushstring(luaVM, "CENTER"); break;
		}
		lua_pushnumber(luaVM, a.fX);
		lua_pushnumber(luaVM, a.fY);
	}
	return 5;
}

int GUI::Region::GetRight(lua_State* luaVM)
{
	if (mRBase != NULL)
		lua_pushnumber(luaVM, mRBase->GetX(false)+mRBase->fW);
	return 1;
}

int GUI::Region::GetTop(lua_State* luaVM)
{
	if (mRBase != NULL)
		lua_pushnumber(luaVM, mGFXMgr->iSHeight+mRBase->GetY(false));
	return 1;
}

int GUI::Region::GetWidth(lua_State* luaVM)
{
	if (mRBase != NULL)
		lua_pushnumber(luaVM, mRBase->fW);
	return 1;
}

int GUI::Region::Hide(lua_State* luaVM)
{
	if (mRBase != NULL)
	{
		if (!mRBase->bHidden)
		{
			mRBase->bHidden = true;
			if (mEBase != NULL)
			{
				mEBase->RebuildCache();
				if ( (mEBase->iType == GUI_OBJECT_TYPE_EDITBOX) && mGUIMgr->HasFocus(mEBase) )
				{
					mGUIMgr->LooseFocus(mEBase);
				}
			}
			else if (mRBase->mParent != NULL)
			{
				mRBase->mParent->RebuildCache();
			}
		}
	}
	return 0;
}

int GUI::Region::IsShown(lua_State* luaVM)
{
	if (mRBase != NULL)
		lua_pushboolean(luaVM, !mRBase->bHidden);
	return 1;
}

int GUI::Region::IsVisible(lua_State* luaVM)
{
	if (mRBase != NULL)
		lua_pushboolean(luaVM, mRBase->IsVisible());
	return 1;
}

int GUI::Region::RebuildCache(lua_State*)
{
	if (mEBase != NULL)
	{
		mEBase->RebuildCache();
		mEBase->bRebuildBackdrop = true;
	}
	else if (mABase != NULL)
	{
		if (mABase->mParent != NULL)
		{
			mABase->mParent->RebuildCache();
			mABase->mParent->bRebuildBackdrop = true;
		}
	}

	return 0;
}

int GUI::Region::SetHeight(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		LUA::PrintError("Too few argument in \"Region:SetHeight\" (one expected : region height)");
		return 0;
	}
	else if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of Region:SetHeight must be a number (region height)");
		error++;
	}

	if (error == 0)
	{
		if (mRBase != NULL)
		{
			float h = lua_tonumber(luaVM, 1);
			if (h != mRBase->fH)
			{
				mRBase->fH = h;
				if (mABase != NULL)
				{
					mABase->mText.fH = mABase->fH;
					if (mABase->iType == GUI_OBJECT_TYPE_FSMSGFRAME)
					{
						mABase->fH -= mABase->mParent->iSMFInsT + mABase->mParent->iSMFInsB;
						mABase->mText.fH = mABase->fH;
					}
				}
				else if (mEBase != NULL)
				{
					if (mEBase->bUseBackdrop)
					{
						if (mEBase->mBackdrop.bTile)
							mEBase->mBackdrop.mBackground->SetTextureRect(
								0, 0,
								mEBase->fW-mEBase->mBackdrop.fInsL-mEBase->mBackdrop.fInsR,
								mEBase->fH-mEBase->mBackdrop.fInsT-mEBase->mBackdrop.fInsB
							);
						if (mEBase->fH < 2*mEBase->mBackdrop.fEdgeSize)
						{
							mEBase->fH = 2*mEBase->mBackdrop.fEdgeSize;
						}
					}
					mEBase->bRecreateCache = true;
					mEBase->fTD = 0;
					mEBase->fBD = 0;
					mEBase->AdjustCache(false);
				}

				if (mRBase->mParent != NULL)
				{
					mRBase->mParent->AdjustCache();
					mRBase->mParent->RebuildCache();
				}
			}
		}
	}

	return 0;
}

int GUI::Region::SetPoint(lua_State* luaVM)
{
	int error = 0;
	bool offsetDefined = false;
	if (lua_gettop(luaVM) < 3)
	{
		LUA::PrintError("Too few argument in \"Region:SetPoint\" (3 or 5 expected : point, relativeTo, relativePoint [, offx, offy])");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of Region:SetPoint must be a string (anchor point)");
		error++;
	}
	if (!lua_isstring(luaVM, 2) && !lua_isnil(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of Region:SetPoint must be a string (or nil) (anchor parent)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of Region:SetPoint must be a string (parent point)");
		error++;
	}
	if (lua_gettop(luaVM) >= 5)
	{
		offsetDefined = true;
		if (!lua_isnumber(luaVM, 4))
		{
			LUA::PrintError("Argument 4 of Region:SetPoint must be a number (x offset)");
			error++;
		}
		if (!lua_isnumber(luaVM, 5))
		{
			LUA::PrintError("Argument 5 of Region:SetPoint must be a number (y offset)");
			error++;
		}
	}

	if (error == 0)
	{
		if (mRBase != NULL)
		{
			bool noParent;
			if (lua_isnil(luaVM, 2))
				noParent = true;
			else
				noParent = false;

			string point, relativeTo, relativePoint;
			float ox, oy;

			point = lua_tostring(luaVM, 1);

			if (!noParent)
				relativeTo = lua_tostring(luaVM, 2);

			relativePoint = lua_tostring(luaVM, 3);

			if (offsetDefined)
			{
				ox = lua_tonumber(luaVM, 4);
				oy = lua_tonumber(luaVM, 5);
			}

			if ((mGUIMgr->lGuiList.find(relativeTo) != mGUIMgr->lGuiList.end()) ||
				(noParent))
			{
				Anchor a;
				if (point == string("TOPLEFT"))
					a.iAnchorPt = GUI_ANCHOR_TOPLEFT;
				else if (point == string("TOP"))
					a.iAnchorPt = GUI_ANCHOR_TOP;
				else if (point == string("TOPRIGHT"))
					a.iAnchorPt = GUI_ANCHOR_TOPRIGHT;
				else if (point == string("RIGHT"))
					a.iAnchorPt = GUI_ANCHOR_RIGHT;
				else if (point == string("BOTTOMRIGHT"))
					a.iAnchorPt = GUI_ANCHOR_BOTTOMRIGHT;
				else if (point == string("BOTTOM"))
					a.iAnchorPt = GUI_ANCHOR_BOTTOM;
				else if (point == string("BOTTOMLEFT"))
					a.iAnchorPt = GUI_ANCHOR_BOTTOMLEFT;
				else if (point == string("LEFT"))
					a.iAnchorPt = GUI_ANCHOR_LEFT;
				else if (point == string("CENTER"))
					a.iAnchorPt = GUI_ANCHOR_CENTER;

				if (!noParent)
				{
					a.sParentName = relativeTo;
					a.mParent = mGUIMgr->lGuiList[relativeTo];
				}

				if (relativePoint == string("TOPLEFT"))
					a.iRelativePt = GUI_ANCHOR_TOPLEFT;
				else if (relativePoint == string("TOP"))
					a.iRelativePt = GUI_ANCHOR_TOP;
				else if (relativePoint == string("TOPRIGHT"))
					a.iRelativePt = GUI_ANCHOR_TOPRIGHT;
				else if (relativePoint == string("RIGHT"))
					a.iRelativePt = GUI_ANCHOR_RIGHT;
				else if (relativePoint == string("BOTTOMRIGHT"))
					a.iRelativePt = GUI_ANCHOR_BOTTOMRIGHT;
				else if (relativePoint == string("BOTTOM"))
					a.iRelativePt = GUI_ANCHOR_BOTTOM;
				else if (relativePoint == string("BOTTOMLEFT"))
					a.iRelativePt = GUI_ANCHOR_BOTTOMLEFT;
				else if (relativePoint == string("LEFT"))
					a.iRelativePt = GUI_ANCHOR_LEFT;
				else if (relativePoint == string("CENTER"))
					a.iRelativePt = GUI_ANCHOR_CENTER;

				if (offsetDefined)
				{
					a.fX = ox;
					a.fY = oy;
				}

				Anchor a2 = mRBase->lAnchorList[0];
				if ((a.fX != a2.fX)               ||
					(a.fY != a2.fY)               ||
					(a.iAnchorPt != a2.iAnchorPt) ||
					(a.mParent != a2.mParent)     ||
					(a.iRelativePt != a2.iRelativePt))
				{
					mRBase->lAnchorList[0] = a;
					if (mRBase->mParent != NULL)
					{
						mRBase->mParent->AdjustCache();
						mRBase->mParent->RebuildCache();
					}
				}
			}
			else
				LUA::PrintError("Error in " + mRBase->sName + ":SetPoint : unknown object \"" + relativeTo + "\"");
		}
	}

	return 0;
}

int GUI::Region::SetWidth(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		LUA::PrintError("Too few argument in \"Region:SetWidth\" (one expected : region width)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of Region:SetWidth must be a number (region width)");
		error++;
	}

	if (error == 0)
	{
		if (mRBase != NULL)
		{
			float w = lua_tonumber(luaVM, 1);
			if (w != mRBase->fW)
			{
				mRBase->fW = w;
				if (mABase != NULL)
				{
					mABase->mText.fW = mABase->fW;
					if (mABase->iType == GUI_OBJECT_TYPE_FSMSGFRAME)
					{
						mABase->fW -= mABase->mParent->iSMFInsL + mABase->mParent->iSMFInsR;
						mABase->mText.fW = mABase->fW;
					}
				}
				else if (mEBase != NULL)
				{
					if (mEBase->bUseBackdrop)
					{
						if (mEBase->mBackdrop.bTile)
							mEBase->mBackdrop.mBackground->SetTextureRect(
								0, 0,
								mEBase->fW-mEBase->mBackdrop.fInsL-mEBase->mBackdrop.fInsR,
								mEBase->fH-mEBase->mBackdrop.fInsT-mEBase->mBackdrop.fInsB
							);
						if (mEBase->fW < 2*mEBase->mBackdrop.fEdgeSize)
						{
							mEBase->fW = 2*mEBase->mBackdrop.fEdgeSize;
						}
					}
					mEBase->bRecreateCache = true;
					mEBase->fTD = 0;
					mEBase->fBD = 0;
					mEBase->AdjustCache(false);
				}

				if (mRBase->mParent != NULL)
				{
					mRBase->mParent->AdjustCache();
					mRBase->mParent->RebuildCache();
				}
			}
		}
	}

	return 0;
}

int GUI::Region::Show(lua_State* luaVM)
{
	if (mRBase != NULL)
	{
		if (mRBase->bHidden)
		{
			mRBase->bHidden = false;
			if (mEBase != NULL)
			{
				if (mEBase->mParent != NULL)
					mEBase->mParent->AdjustCache();
				mEBase->RebuildCache(true);
				if ( (mEBase->iType == GUI_OBJECT_TYPE_EDITBOX) && mEBase->bAutoFocus )
					mGUIMgr->RequestFocus(mEBase);
			}
			else if (mRBase->mParent != NULL)
			{
				mRBase->mParent->AdjustCache();
				mRBase->mParent->RebuildCache(true);
			}
		}
	}
	return 0;
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              .... source               */
/*                                        */
/*  ## : ...                              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_xml.h"

#include "wowrl_guimanager.h"

extern TimeManager *mTimeMgr;
extern GFXManager *mGFXMgr;
extern HGE *hge;

using namespace std;

void GUIManager::ParseUI( string file )
{
	// Default UI
	string status_bar_file = "UI/ui_default_status_bar.png";
	string circle_file = "UI/ui_default_circle.png";
	string order_file = "UI/ui_default_order.png";
	string shadow_file = "UI/ui_default_shadow.png";
	string carret_file = "UI/ui_default_carret.png";

	//  -- loading textures
	mGFXMgr->LoadTexture(status_bar_file);
	mGFXMgr->LoadTexture(circle_file, true);
	mGFXMgr->LoadTexture(order_file, true);
	mGFXMgr->LoadTexture(shadow_file, true);
	mGFXMgr->LoadTexture(carret_file, false);
	//  -- statusbar
	this->mStatusBBgLeft = mGFXMgr->CreateSprite(mGFXMgr->lTextureList[status_bar_file],0,0,3,8);
	this->mStatusBBgMiddle = mGFXMgr->CreateSprite(mGFXMgr->lTextureList[status_bar_file],3,0,29,8);
	this->mStatusBBgRight = mGFXMgr->CreateSprite(mGFXMgr->lTextureList[status_bar_file],0,0,3,8);
	this->mStatusBBgRight->SetFlip(true,false);
	this->mStatusBDeadBgLeft = mGFXMgr->CreateSprite(mGFXMgr->lTextureList[status_bar_file],0,8,3,8);
	this->mStatusBDeadBgMiddle = mGFXMgr->CreateSprite(mGFXMgr->lTextureList[status_bar_file],3,8,29,8);
	this->mStatusBDeadBgRight = mGFXMgr->CreateSprite(mGFXMgr->lTextureList[status_bar_file],0,8,3,8);
	this->mStatusBDeadBgRight->SetFlip(true,false);
	this->mStatusBGauge = mGFXMgr->CreateSprite(mGFXMgr->lTextureList[status_bar_file],3,18,29,2);
	// -- player shadow
	this->mPShadow = mGFXMgr->CreateSprite(mGFXMgr->lTextureList[shadow_file],0,0,128,128);
	this->mPShadow->SetHotSpot(64,64);
	// -- selection circle
	this->mSelectionCircle = mGFXMgr->CreateSprite(mGFXMgr->lTextureList[circle_file],0,0,32,32);
	this->mSelectionCircle->SetColor(ARGB(255, 20, 220, 64));
	this->mSelectionCircle->SetHotSpot(16,16);
	this->mDeathCircle = mGFXMgr->CreateSprite(mGFXMgr->lTextureList[circle_file],0,0,32,32);
	this->mDeathCircle->SetColor(ARGB(120, 100, 100, 100));
	this->mDeathCircle->SetHotSpot(16,16);
	this->mHostileCircle = mGFXMgr->CreateSprite(mGFXMgr->lTextureList[circle_file],0,0,32,32);
	this->mHostileCircle->SetColor(ARGB(180, 220, 64, 20));
	this->mHostileCircle->SetHotSpot(16,16);
	// -- order circle
	this->mOrderCircle = mGFXMgr->CreateSprite(mGFXMgr->lTextureList[order_file],0,0,32,32);
	this->mOrderCircle->SetColor(ARGB(255, 20, 220, 64));
	this->mOrderCircle->SetHotSpot(16,16);
	// -- carret
	this->mCarret = mGFXMgr->CreateSprite(mGFXMgr->lTextureList[carret_file], 0, 0, 4, 16);
	this->mCarret->SetHotSpot(1, 0);
}

void GUIManager::ParseCursors(lua_State* luaVM)
{
	Log("Parsing Tables/cursor_table.lua...");

	int error = luaL_dofile(luaVM, "Tables/cursor_table.lua");
	if (error) LUA::LogL(luaVM);

	lua_getglobal(luaVM, "Cursors");
	for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
	{
		if (!lua_isnil(luaVM, -1))
		{
			Cursor tmpCur;
			tmpCur.sName = LUA::GetFieldString("name");
			tmpCur.fRot = 0.0f;
			tmpCur.bAnimated = LUA::GetFieldBool("animated", false, false);
			if (tmpCur.bAnimated)
				tmpCur.mAnim = mGFXMgr->lLuaAnimList[LUA::GetFieldString("anim")];
			else
				tmpCur.mSprite = mGFXMgr->lLuaSpriteList[LUA::GetFieldString("sprite")];

			this->lCursorList[tmpCur.sName] = tmpCur;
		}
	}

	lua_pop(luaVM, 1);

	Log("Parsing Tables/cursor_table.lua : done.");
}

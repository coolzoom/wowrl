/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               GUI source               */
/*                                        */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_scenemanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_timemanager.h"
#include "wowrl_global.h"

#include "wowrl_gui.h"

#define MAX_TARGET_SIZE 2048

extern SceneManager *mSceneMgr;
extern InputManager *mInputMgr;
extern GUIManager *mGUIMgr;
extern GFXManager *mGFXMgr;
extern TimeManager *mTimeMgr;
extern HGE* hge;
using namespace std;

bool bDebugGUI = false;

GUIElement::GUIElement() : GUIBase()
{
	fW = -1;
	fH = -1;

	iHitInsL = 0;
    iHitInsR = 0;
    iHitInsT = 0;
    iHitInsB = 0;

	fLD = 0;
	fRD = 0;
	fTD = 0;
	fBD = 0;

	mParent = NULL;
	sParentName = "";
	sName = "";
	sVName = "";
	bHidden = false;
	bVirt = false;
	bReady = true;
	bChild = false;
	bRebuildList = true;
	bRebuildCache = true;
	bRebuildBackdrop = true;
	bRecreateCache = false;
	iFrameStrata = 2;
	bLastOn = false;
	bBaseUI = false;
	bUseBackdrop = false;
	bEnableMouse = false;
	bMovable = false;
	bDragged = false;
	bRegisteredForDrag = false;

	fValue = 1.0f;
	fMinValue = 0.0f;
	fMaxValue = 1.0f;
	mBarTexture = NULL;

	sEBText = "";
	iLetters = 0;
	iHistoryLines = 0;
	fBlinkSpeed = 0.5f;
	iCarretPos = 0;
	iSubStrStart = 0;
	iSubStrLength = 0;
	fCarretTimer = 0.0f;
	fCarretScale = 1.0f;
	iEBInsL = 0;
	iEBInsR = 0;
	iEBInsT = 0;
	iEBInsB = 0;
	bShowCarret = true;
	bNumeric = false;
	bPassword = false;
	bMultiLine = false;
	bIgnoreArrows = false;
	bAutoFocus = true;
	mCaptionFont = NULL;

	iMaxLines = 8;
	iActualLine = 1;
	iBottomLine = 1;
	iOldBottomLine = 1;
    fFadeDuration = 3.0f;
    fDisplayDuration = 10.0f;
    bFade = true;
    iSMFInsL = 0;
    iSMFInsR = 0;
    iSMFInsT = 0;
    iSMFInsB = 0;

	mTexNormal = NULL;
	mTexPushed = NULL;
	mTexDisabled = NULL;
	mTexHighlight = NULL;
	mFontNormal = NULL;
	mFontHighlight = NULL;
	mFontDisabled = NULL;
	iPushTxtOffX = 0;
	iPushTxtOffY = 0;
	bMouseDown = false;
	bButtonFontReady = false;
	bButtonTextureReady = false;
	bButtonDisabled = false;
	bAtBottom = true;
	bAtTop = true;
	sButtonText = "";
	iButtonState = GUI_BUTTON_STATE_NORMAL;

	mSpr = NULL;
	mAnchor = NULL;
}

GUIElement::GUIElement(const GUIElement &g) : GUIBase()
{
    //memcpy(this, &g, sizeof(GUIElement));

    lAnchorList = map<int, Anchor>();
    lParentList = map<string, GUIBase*>();

    lChildList = map<string, GUIElement*>();
    lVChildList = map<string, GUIElement*>();

    lArtList = map<string, GUIArt*>();

    bLastOn = false;
    bRebuildList = true;
    bDragged = false;
    mTarget = 0;
    mSpr = NULL;
    bRebuildCache = true;
    bRebuildBackdrop = true;
    bRecreateCache = true;
    mAnchor = NULL;
    //mBackdrop; /***/

    sName = g.sName;
    sBName = g.sBName;
    sVName = g.sVName;
    iType = g.iType;
    bVirt = g.bVirt;
    bReady = g.bReady;
    fX = g.fX;
    fY = g.fY;
    fW = g.fW;
    fH = g.fH;
    fAlpha = g.fAlpha;
    bHidden = g.bHidden;

    bChild = g.bChild;
    bRegisteredForDrag = g.bRegisteredForDrag;
    bEnableMouse = g.bEnableMouse;
    bMovable = g.bMovable;
    bBaseUI = g.bBaseUI;
    iFrameStrata = g.iFrameStrata;

    iHitInsL = g.iHitInsL;
    iHitInsR = g.iHitInsR;
    iHitInsT = g.iHitInsT;
    iHitInsB = g.iHitInsB;

    lFuncList = g.lFuncList;
    lRegEventList = g.lRegEventList;

    fLD = g.fLD;
    fRD = g.fRD;
    fTD = g.fTD;
    fBD = g.fBD;

    bUseBackdrop = g.bUseBackdrop;

    fValue = g.fValue;
    fMinValue = g.fMinValue;
    fMaxValue = g.fMaxValue;
    fBaseWidth = g.fBaseWidth;
    //
    sBarTextureName = g.sBarTextureName;

    sEBText = g.sEBText;
    iLetters = g.iLetters;
    iHistoryLines = g.iHistoryLines;
    iEBInsL = g.iEBInsL;
    iEBInsR = g.iEBInsR;
    iEBInsT = g.iEBInsT;
    iEBInsB = g.iEBInsB;
    fBlinkSpeed = g.fBlinkSpeed;
    fCarretTimer = g.fCarretTimer;
    iCarretPos = g.iCarretPos;
    iSubStrStart = g.iSubStrStart;
    iSubStrLength = g.iSubStrLength;
    fCarretX = g.fCarretX;
    fCarretY = g.fCarretY;
    fCarretScale = g.fCarretScale;
    bShowCarret = g.bShowCarret;
    bNumeric = g.bNumeric;
    bPassword = g.bPassword;
    bMultiLine = g.bMultiLine;
    bIgnoreArrows = g.bIgnoreArrows;
    bAutoFocus = g.bAutoFocus;
    //
    sCaptionFontName = g.sCaptionFontName;

    iMaxLines = g.iMaxLines;
    iActualLine = g.iActualLine;
    iBottomLine = g.iBottomLine;
    iOldBottomLine = g.iOldBottomLine;
    fFadeDuration = g.fFadeDuration;
    fDisplayDuration = g.fDisplayDuration;
    bFade = g.bFade;
    iSMFInsL = g.iSMFInsL;
    iSMFInsR = g.iSMFInsR;
    iSMFInsT = g.iSMFInsT;
    iSMFInsB = g.iSMFInsB;
    bAtTop = g.bAtTop;
    bAtBottom = g.bAtBottom;

    //
    iPushTxtOffX = g.iPushTxtOffX;
    iPushTxtOffY = g.iPushTxtOffY;
    bMouseDown = g.bMouseDown;
    bButtonDisabled = g.bButtonDisabled;
    bButtonFontReady = g.bButtonFontReady;
    bButtonTextureReady = g.bButtonTextureReady;
    sButtonText = g.sButtonText;
    iButtonState = g.iButtonState;

}

GUIElement::~GUIElement()
{
    this->DeleteThis();
}

GUIArt::GUIArt(const GUIArt &a) : GUIBase()
{
    //memcpy(this, &a, sizeof(GUIArt));
    lAnchorList = a.lAnchorList;
    lParentList = map<string, GUIBase*>();

    sName = a.sName;
    sBName = a.sBName;
    sVName = a.sVName;
    mParent = a.mParent;
    iType = a.iType;
    bVirt = a.bVirt;
    bReady = a.bReady;
    fX = a.fX;
    fY = a.fY;
    fW = a.fW;
    fH = a.fH;
    fAlpha = a.fAlpha;
    bHidden = a.bHidden;

    iID = a.iID;

    mSprite = NULL;
    mAnim = NULL;
    mAnchor = NULL;

    iLayer = a.iLayer;
    fScale = a.fScale;
    fVScale = a.fVScale;
    fAngle = a.fAngle;
    bUseBox = a.bUseBox;
    dwColor = a.dwColor;
    iBlend = a.iBlend;

    fAX = a.fAX;
    fAY = a.fAY;
    sFile = a.sFile;

}

void GUIElement::DeleteThis()
{
	if (mTarget != 0) {hge->Target_Free(mTarget); mTarget=0;}
	if (mSpr) {delete mSpr; mSpr=NULL;}

	if (bUseBackdrop)
	{
		if (mBackdrop.mTarget != 0) {hge->Target_Free(mBackdrop.mTarget); mBackdrop.mTarget=0;}
		if (mBackdrop.mSpr) {delete mBackdrop.mSpr; mBackdrop.mSpr=NULL;}

		if (mBackdrop.bEdgeReady)
		{
			delete mBackdrop.mEdgeL; mBackdrop.mEdgeL=NULL;
			delete mBackdrop.mEdgeR; mBackdrop.mEdgeR=NULL;
			delete mBackdrop.mEdgeT; mBackdrop.mEdgeT=NULL;
			delete mBackdrop.mEdgeB; mBackdrop.mEdgeB=NULL;
			delete mBackdrop.mCornerTL; mBackdrop.mCornerTL=NULL;
			delete mBackdrop.mCornerTR; mBackdrop.mCornerTR=NULL;
			delete mBackdrop.mCornerBL; mBackdrop.mCornerBL=NULL;
			delete mBackdrop.mCornerBR; mBackdrop.mCornerBR=NULL;
		}

		if (mBackdrop.bBgReady)
		{
			delete mBackdrop.mBackground; mBackdrop.mBackground=NULL;
		}
	}

	map<string, GUIArt*>::iterator iterArt;
	for (iterArt = lArtList.begin(); iterArt != lArtList.end(); iterArt++)
	{
	    delete iterArt->second;
	}
	lArtList.clear();
}

float GUIBase::GetX( bool relative )
{
	if (mAnchor == NULL)
		mAnchor = &lAnchorList[0];
	float px = 0.0f;
	float pw = 0.0f;
	if (mAnchor->mParent != NULL)
	{
		if (mAnchor->mParent != this)
		{
			pw = mAnchor->mParent->fW;
			if (!relative)
				px += mAnchor->mParent->GetX(false);
		}
	}
	else
	{
		pw = mGFXMgr->iSWidth;
	}

	switch (mAnchor->iAnchorPt)
	{
		case GUI_ANCHOR_TOPLEFT: px-=0; break;
		case GUI_ANCHOR_TOP: px-=fW/2.0f; break;
		case GUI_ANCHOR_TOPRIGHT: px-=fW; break;
		case GUI_ANCHOR_RIGHT: px-=fW; break;
		case GUI_ANCHOR_BOTTOMRIGHT: px-=fW; break;
		case GUI_ANCHOR_BOTTOM: px-=fW/2.0f; break;
		case GUI_ANCHOR_BOTTOMLEFT: px-=0; break;
		case GUI_ANCHOR_LEFT: px-=0; break;
		case GUI_ANCHOR_CENTER: px-=fW/2.0f; break;
	}

	switch (mAnchor->iRelativePt)
	{
		case GUI_ANCHOR_TOPLEFT: px+=0; break;
		case GUI_ANCHOR_TOP: px+=pw/2.0f; break;
		case GUI_ANCHOR_TOPRIGHT: px+=pw; break;
		case GUI_ANCHOR_RIGHT: px+=pw; break;
		case GUI_ANCHOR_BOTTOMRIGHT: px+=pw; break;
		case GUI_ANCHOR_BOTTOM: px+=pw/2.0f; break;
		case GUI_ANCHOR_BOTTOMLEFT: px+=0; break;
		case GUI_ANCHOR_LEFT: px+=0; break;
		case GUI_ANCHOR_CENTER: px+=pw/2.0f; break;
	}

	fX = px+mAnchor->fX;

	return fX;
}

float GUIBase::GetY( bool relative )
{
	if (mAnchor == NULL)
		mAnchor = &lAnchorList[0];

	float py = 0.0f;
	float ph = 0.0f;
	if (mAnchor->mParent != NULL)
	{
		if (mAnchor->mParent != this)
		{
			ph = mAnchor->mParent->fH;
			if (!relative)
				py += mAnchor->mParent->GetY(false);
		}
	}
	else
	{
		ph = mGFXMgr->iSHeight;
	}

	switch (mAnchor->iAnchorPt)
	{
		case GUI_ANCHOR_TOPLEFT: py+=0; break;
		case GUI_ANCHOR_TOP: py+=0; break;
		case GUI_ANCHOR_TOPRIGHT: py+=0; break;
		case GUI_ANCHOR_RIGHT: py+=fH/2.0f; break;
		case GUI_ANCHOR_BOTTOMRIGHT: py+=fH; break;
		case GUI_ANCHOR_BOTTOM: py+=fH; break;
		case GUI_ANCHOR_BOTTOMLEFT: py+=fH; break;
		case GUI_ANCHOR_LEFT: py+=fH/2.0f; break;
		case GUI_ANCHOR_CENTER: py+=fH/2.0f; break;
	}

	switch (mAnchor->iRelativePt)
	{
		case GUI_ANCHOR_TOPLEFT: py-=0; break;
		case GUI_ANCHOR_TOP: py-=0; break;
		case GUI_ANCHOR_TOPRIGHT: py-=0; break;
		case GUI_ANCHOR_RIGHT: py-=ph/2.0f; break;
		case GUI_ANCHOR_BOTTOMRIGHT: py-=ph; break;
		case GUI_ANCHOR_BOTTOM: py-=ph; break;
		case GUI_ANCHOR_BOTTOMLEFT: py-=ph; break;
		case GUI_ANCHOR_LEFT: py-=ph/2.0f; break;
		case GUI_ANCHOR_CENTER: py-=ph/2.0f; break;
	}

	fY = py+mAnchor->fY;

	return fY;
}

void GUIBase::Init()
{
	/* [#] This function takes care of initialization of the GUIBase class.
	/* It calls the _init() lua method which creates a pointer to this object in
	/* it's corresponding element in the LUA environnement.
	*/
	bool bDebugThis = false;

	// Initialize LUA class
	if ((iType != GUI_OBJECT_TYPE_FEDITBOX)   &&
		(iType != GUI_OBJECT_TYPE_FSMSGFRAME) &&
		(iType != GUI_OBJECT_TYPE_FNBUTTON)   &&
		(iType != GUI_OBJECT_TYPE_FHBUTTON)   &&
		(iType != GUI_OBJECT_TYPE_FDBUTTON)   &&
		(iType != GUI_OBJECT_TYPE_TNBUTTON)   &&
		(iType != GUI_OBJECT_TYPE_THBUTTON)   &&
		(iType != GUI_OBJECT_TYPE_TDBUTTON)   &&
		(iType != GUI_OBJECT_TYPE_TPBUTTON))
	{
		string exec = sName + ":_init();";
		if (bDebugThis) Log("%s", exec.c_str());
		int error = luaL_dostring(mSceneMgr->luaVM, exec.c_str());
		if (error) LUA::LogL(mSceneMgr->luaVM);
		GUIBase* p = mParent;
		string hierarchy = sBName;
		string newObj;
		while (p != NULL)
		{
			newObj = p->sName + "." + hierarchy;
			exec = newObj + " = " + sName + ";\n";
			exec += newObj + ":_init();";
			if (bDebugThis) Log("%s", exec.c_str());
			int error = luaL_dostring(mSceneMgr->luaVM, exec.c_str());
			if (error) LUA::LogL(mSceneMgr->luaVM);
			hierarchy = p->sBName + "." + hierarchy;
			p = p->mParent;
		}
	}

	// Initialize position and lAnchorList
	mAnchor = &lAnchorList[0];
	this->GetX();
	this->GetY();

}

void GUIElement::Init()
{
	/* [#] This function takes care of initialization of the GUIElement class.
	/* It calls the GUIBase::_init() function and creates the render target
	/* associated with this element.
	*/
	GUIBase* thisB = this;
	thisB->Init();

	map<string, GUIElement*>::iterator iterChild;
	for (iterChild = lChildList.begin(); iterChild != lChildList.end(); iterChild++)
	{
		GUIElement* g = iterChild->second;
		g->Init();

		map<string, GUIArt*>::iterator iter;
		for (iter = g->lArtList.begin(); iter != g->lArtList.end(); iter++)
		{
			GUIArt* a = iter->second;
			a->Init();
		}
	}

	// Initialize cache
	mTarget = hge->Target_Create(ToInt(fW), ToInt(fH), false);
	mSpr = new hgeSprite(hge->Target_GetTexture(mTarget), 0, 0, ToInt(fW), ToInt(fH));
}

void GUIElement::RebuildCache( bool child )
{
	/* [#] This function is used to tell the program to re-draw the cache the
	/* next time Render() is called. When called, this function also calls itself
	/* on the element's parent, and on all of it's child if stated.
	*/
	//Log("%s::RebuildCache()", sName.c_str());
	bRebuildCache = true;
	if (child)
	{
		map<string, GUIElement*>::iterator iterChild;
		for (iterChild = lChildList.begin(); iterChild != lChildList.end(); iterChild++)
		{
			iterChild->second->RebuildCache(true);
		}
	}
	if (mParent != NULL)
		mParent->RebuildCache();
}

bool GUIBase::IsVisible()
{
	/* [#] This function checks if this GUI object is visible or not. That means
	/* that it is shown, and all it's parent also.
	*/
	if (mParent == NULL)
		return !bHidden;
	else
	{
		return (!bHidden && mParent->IsVisible());
	}
}

void GUIArt::Render()
{
	// [#] This function renders a GUI art (texture or text).
	if (bReady && !bHidden)
	{
		// The coordinates are relative to its parent.
		fAX = this->GetX()-mParent->GetX()+mParent->fLD;
		fAY = mParent->GetY()-this->GetY()+mParent->fTD;
		if ((iType == GUI_OBJECT_TYPE_TEXTURE)  ||
			(iType == GUI_OBJECT_TYPE_TNBUTTON) ||
			(iType == GUI_OBJECT_TYPE_TPBUTTON) ||
			(iType == GUI_OBJECT_TYPE_THBUTTON) ||
			(iType == GUI_OBJECT_TYPE_TDBUTTON))
		{
			if (mSprite != NULL)
				mSprite->RenderEx(fAX, fAY, fAngle, fScale, fVScale);
		}
		else if ((iType == GUI_OBJECT_TYPE_FONTSTRING) ||
				 (iType == GUI_OBJECT_TYPE_FEDITBOX)   ||
				 (iType == GUI_OBJECT_TYPE_FSMSGFRAME) ||
				 (iType == GUI_OBJECT_TYPE_FNBUTTON)   ||
				 (iType == GUI_OBJECT_TYPE_FHBUTTON)   ||
				 (iType == GUI_OBJECT_TYPE_FDBUTTON))
		{
			if (mText.mFnt != NULL)
			{
				if (mText.iOutline != 0)
				{
					mText.mFnt->SetTracking(mText.fTracking);
					mText.mFnt->SetColor(ARGB(200, 0, 0, 0));

					// Render the text all around to acheive the outline effect
					for (float f = 0.0f; f <= 1.0f; f += 0.1f)
					{
						mText.mFnt->printfb
						(
							fAX+mText.iOutline*cos(f*2*M_PI), fAY+mText.iOutline*sin(f*2*M_PI),
							fW, fH, mText.iAlign, mText.sStr.c_str()
						);
					}

					list<FormatedString>::iterator iterStr;
					for (iterStr = mText.lFStr.begin(); iterStr != mText.lFStr.end(); iterStr++)
					{
						FormatedString* fs = &(*iterStr);
						mText.mFnt->SetColor(fs->dwColor);
						mText.mFnt->printfbd(fs->fX, fs->fY, fAX, fAY, fW, fH, mText.iAlign, fs->sStr.c_str());
					}
				}
				else
				{
					mText.mFnt->SetTracking(mText.fTracking);

					if (mText.bShadow)
					{
						mText.mFnt->SetColor(mText.dwSColor);
						mText.mFnt->printfb(fAX+mText.fSOffX, fAY-mText.fSOffY, fW, fH, mText.iAlign, mText.sStr.c_str());
					}

					list<FormatedString>::iterator iterStr;
					for (iterStr = mText.lFStr.begin(); iterStr != mText.lFStr.end(); iterStr++)
					{
						FormatedString* fs = &(*iterStr);
						mText.mFnt->SetColor(fs->dwColor);
						mText.mFnt->printfbd(fs->fX, fs->fY, fAX, fAY, fW, fH, mText.iAlign, fs->sStr.c_str());
					}
				}
			}
		}
		else if (iType == GUI_OBJECT_TYPE_TSTATUSBAR)
		{
			if (mSprite != NULL)
			{
				float x,y,w,h;
				mSprite->GetTextureRect(&x, &y, &w, &h);
				// Here we adjust the texture coordinate to achieve the status bar effect.
				w = mParent->fBaseWidth*((mParent->fValue-mParent->fMinValue)/(mParent->fMaxValue-mParent->fMinValue));
				mSprite->SetTextureRect(x, y, w, h);
				mSprite->RenderEx(fAX, fAY, fAngle, fScale, fVScale);
			}
		}
	}
}

void GUIElement::AdjustCache( bool adjustParent )
{
	if (!bBaseUI)
	{
		bool bDebugThis = false;

		// Save old displacements
		float fOldLD = fLD;
		float fOldRD = fRD;
		float fOldTD = fTD;
		float fOldBD = fBD;

		float fMaxW = fW+fRD;
		float fMaxH = fH+fBD;
		float fMinW = -fLD;
		float fMinH = -fTD;

		if (bDebugThis) Log("old disp : %f, %f, %f, %f", fLD, fRD, fTD, fBD);
		if (bDebugThis) Log("old dims : %f, %f, %f, %f", fMinW, fMaxW, fMinH, fMaxH);

		// Check childs
		map<string, GUIElement*>::iterator iterChild;
		for (iterChild = lChildList.begin(); iterChild != lChildList.end(); iterChild++)
		{
			GUIElement* g = iterChild->second;
			if (!g->bHidden)
			{
				float gx = g->GetX()-this->GetX();
				float gy = -g->GetY()+this->GetY();

				float fNewMaW = gx+g->fW+g->fRD;
				if (fNewMaW > fMaxW)
					fMaxW = fNewMaW;
				float fNewMiW = gx-g->fLD;
				if (fNewMiW < fMinW)
					fMinW = fNewMiW;

				float fNewMaH = gy+g->fH+g->fBD;
				if (fNewMaH > fMaxH)
					fMaxH = fNewMaH;
				float fNewMiH = gy-g->fTD;
				if (fNewMiH < fMinH)
					fMinH = fNewMiH;
				if (bDebugThis) Log(" child : %s, %f, %f, %f, %f", g->sName.c_str(), fNewMiW, fNewMaW, fNewMiH, fNewMaH);
			}
		}

		// Check arts
		map<std::string, GUIArt*>::iterator iterArt;
		for (iterArt = lArtList.begin(); iterArt != lArtList.end(); iterArt++)
		{
			GUIArt* a = iterArt->second;
			if (!a->bHidden)
			{
				float ax = a->GetX()-this->GetX()+mParent->fLD;
				float ay = -a->GetY()+this->GetY()+mParent->fTD;

				float fNewMaW = ax+a->fW;
				if (fNewMaW > fMaxW)
					fMaxW = fNewMaW;
				float fNewMiW = ax;
				if (fNewMiW < fMinW)
					fMinW = fNewMiW;

				float fNewMaH = ay+a->fH;
				if (fNewMaH > fMaxH)
					fMaxH = fNewMaH;
				float fNewMiH = ay;
				if (fNewMiH < fMinH)
					fMinH = fNewMiH;
				if (bDebugThis) Log("   art : %s, %f, %f, %f, %f", a->sName.c_str(), fNewMiW, fNewMaW, fNewMiH, fNewMaH);
			}
		}

		// Get new displacements
		fLD = -fMinW;
		fRD = fMaxW-fW;
		fTD = -fMinH;
		fBD = fMaxH-fH;

		if (bDebugThis) Log("new disp : %f, %f, %f, %f", fLD, fRD, fTD, fBD);

		// If at least a single one of them has changed, rebuild everything
		if ( (fOldLD != fLD) || (fOldRD != fRD) || (fOldTD != fTD) || (fOldBD != fBD) )
		{
			bRecreateCache = true;
			RebuildCache();
		}

		// And call it for its parent
		if ( (mParent != NULL) && adjustParent )
			mParent->AdjustCache();

	}
}

void GUIElement::Render( bool cache )
{
	/* [#] This function renders a GUI element on the screen or on it's parent
	/* cache depending on the provided boolean. The cache system is used to
	/* increase the GUI performance by re-drawing every element only when needed.
	*/

	if (this->IsVisible() && bReady)
	{
		if (cache)
		{
			if (bRecreateCache)
			{
				// The cache needs to be re-created (size change, mainly)
				if (bDebugGUI) {Log("%s : recreateCache...", sName.c_str());}
				float fTW = hge->Texture_GetWidth(hge->Target_GetTexture(mTarget));
				float fTH = hge->Texture_GetHeight(hge->Target_GetTexture(mTarget));
				int iNewW = ToInt(fW+fLD+fRD);
				int iNewH = ToInt(fH+fTD+fBD);
				if ( (iNewW > fTW) || (iNewH > fTH) )
				{
					// Create a new target only if it would be bigger than the previous one
					hge->Target_Free(mTarget);
					mTarget = hge->Target_Create(
						min(MAX_TARGET_SIZE, NearestPow2Up(iNewW)),
						min(MAX_TARGET_SIZE, NearestPow2Up(iNewH)),
						false
					);
				}
				delete mSpr;
				mSpr = new hgeSprite(hge->Target_GetTexture(mTarget), 0, 0, ToInt(fW+fLD+fRD), ToInt(fH+fTD+fBD));
				bRecreateCache = false;
				bRebuildCache = true;
				if (bUseBackdrop)
				{
					hge->Target_Free(mBackdrop.mTarget);
					mBackdrop.mTarget = hge->Target_Create(
						min(MAX_TARGET_SIZE, ToInt(fW)),
						min(MAX_TARGET_SIZE, ToInt(fH)),
						false
					);
					delete mBackdrop.mSpr;
					mBackdrop.mSpr = new hgeSprite(hge->Target_GetTexture(mBackdrop.mTarget), 0, 0, ToInt(fW), ToInt(fH));
					bRebuildBackdrop = true;
				}
			}

			if (bRebuildCache)
			{
				if (bDebugGUI) {Log("%s : rebuildCache...", sName.c_str());}
				if (bUseBackdrop && bRebuildBackdrop)
				{
					if (bDebugGUI) {Log(" rebuildBackdrop...", sName.c_str());}
					// Cache the backdrop
					hge->Gfx_BeginScene(mBackdrop.mTarget);
					mGFXMgr->mDxDevice->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, TRUE);
					mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
					mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
					mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLENDALPHA, D3DBLEND_ONE);
					mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLENDALPHA, D3DBLEND_INVSRCALPHA);
					hge->Gfx_Clear(ARGB(0,0,0,0));

					// Render the background
					if (mBackdrop.bBgReady)
					{
						if (fabs(fH-mBackdrop.fInsT-mBackdrop.fInsB) > 0.1f)
						{
							mBackdrop.mBackground->SetColor(mBackdrop.dwBgColor);
							if (mBackdrop.bTile)
								mBackdrop.mBackground->Render(mBackdrop.fInsL, mBackdrop.fInsT);
							else
								mBackdrop.mBackground->RenderEx(
									mBackdrop.fInsL,
									mBackdrop.fInsT,
									0.0f,
									(fW-mBackdrop.fInsL-mBackdrop.fInsR)/mBackdrop.fBgW,
									(fH-mBackdrop.fInsT-mBackdrop.fInsB)/mBackdrop.fBgH
								);
						}
					}
					else if (mBackdrop.bBgReadyC)
					{
						hgeSprite* mBgColorSpr = new hgeSprite(
							0, 0, 0,
							fW-mBackdrop.fInsL-mBackdrop.fInsR,
							fH-mBackdrop.fInsT-mBackdrop.fInsB
						);

						mBgColorSpr->SetColor(mBackdrop.dwBgColor);
						mBgColorSpr->Render(mBackdrop.fInsL, mBackdrop.fInsT);

						delete mBgColorSpr;
					}

					if (mBackdrop.bEdgeReady)
					{
						// Render corners
						mBackdrop.mCornerTL->RenderEx(0, 0, 0.0f, mBackdrop.fEdgeSize/mBackdrop.fEdgeOriginalSize);
						mBackdrop.mCornerTR->RenderEx(fW-mBackdrop.fEdgeSize, 0, 0.0f, mBackdrop.fEdgeSize/mBackdrop.fEdgeOriginalSize);
						mBackdrop.mCornerBL->RenderEx(0, fH-mBackdrop.fEdgeSize, 0.0f, mBackdrop.fEdgeSize/mBackdrop.fEdgeOriginalSize);
						mBackdrop.mCornerBR->RenderEx(fW-mBackdrop.fEdgeSize, fH-mBackdrop.fEdgeSize, 0.0f, mBackdrop.fEdgeSize/mBackdrop.fEdgeOriginalSize);
						// Render edges
						mBackdrop.mEdgeL->Render4V(
							0, mBackdrop.fEdgeSize,
							mBackdrop.fEdgeSize, mBackdrop.fEdgeSize,
							mBackdrop.fEdgeSize, fH-mBackdrop.fEdgeSize,
							0, fH-mBackdrop.fEdgeSize
						);
						mBackdrop.mEdgeR->Render4V(
							fW-mBackdrop.fEdgeSize, mBackdrop.fEdgeSize,
							fW, mBackdrop.fEdgeSize,
							fW, fH-mBackdrop.fEdgeSize,
							fW-mBackdrop.fEdgeSize, fH-mBackdrop.fEdgeSize
						);
						mBackdrop.mEdgeT->Render4V(
							fW-mBackdrop.fEdgeSize, 0,
							fW-mBackdrop.fEdgeSize, mBackdrop.fEdgeSize,
							mBackdrop.fEdgeSize, mBackdrop.fEdgeSize,
							mBackdrop.fEdgeSize, 0
						);
						mBackdrop.mEdgeB->Render4V(
							fW-mBackdrop.fEdgeSize, fH-mBackdrop.fEdgeSize,
							fW-mBackdrop.fEdgeSize, fH,
							mBackdrop.fEdgeSize, fH,
							mBackdrop.fEdgeSize, fH-mBackdrop.fEdgeSize
						);
					}

					hge->Gfx_EndScene();

					if (bDebugGUI) {Log(" done.", sName.c_str());}

					bRebuildBackdrop = false;
				}

				// Re-order childs acording to their frameStrata
				if (bRebuildList)
				{
					lSortedGUIList.clear();
					map<string, GUIElement*>::iterator iterChild;
					for (iterChild = lChildList.begin(); iterChild != lChildList.end(); iterChild++)
					{
						GUIElement* g = iterChild->second;
						lSortedGUIList.insert(make_pair(g->iFrameStrata, g));
					}
					bRebuildList = false;
				}

				// Allow them to re-draw/re-create their cache
				multimap<int, GUIElement*>::iterator iterChild2;
				for (iterChild2 = lSortedGUIList.begin(); iterChild2 != lSortedGUIList.end(); iterChild2++)
				{
					iterChild2->second->Render(true);
				}

				hge->Gfx_BeginScene(mTarget);
				mGFXMgr->mDxDevice->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, TRUE);
				mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
				mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
				mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLENDALPHA, D3DBLEND_ONE);
				mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLENDALPHA, D3DBLEND_INVSRCALPHA);
				hge->Gfx_Clear(ARGB(0,0,0,0));

				//hge->Gfx_Clear(ARGB(255,hge->Random_Int(0, 255),hge->Random_Int(0, 255),hge->Random_Int(0, 255)));

				// Render the backdrop
				if (bUseBackdrop)
				{
					mBackdrop.mSpr->Render(fLD,fTD);
				}

				// Sort arts by layers
				multimap<int, GUIArt*> sortedMap;
				map<std::string, GUIArt*>::iterator iterArt;
				for (iterArt = lArtList.begin(); iterArt != lArtList.end(); iterArt++)
				{
					sortedMap.insert(make_pair(iterArt->second->iLayer, iterArt->second));
				}

				// Then render them in the proper order
				multimap<int, GUIArt*>::iterator iterSArt;
				for (iterSArt = sortedMap.begin(); iterSArt != sortedMap.end(); iterSArt++)
				{
					GUIArt* a = iterSArt->second;
					a->Render();
				}

				// Render the carret for the EditBox
				if ( (iType == GUI_OBJECT_TYPE_EDITBOX) && bShowCarret && mGUIMgr->HasFocus(this) )
				{
					mGUIMgr->mCarret->RenderEx(fCarretX+fLD, fCarretY+2+fTD, 0.0f, fCarretScale);
				}

				if (bDebugGUI) {Log(" childs...");}

				// Render childs
				for (iterChild2 = lSortedGUIList.begin(); iterChild2 != lSortedGUIList.end(); iterChild2++)
				{
					iterChild2->second->Render(false);
				}

				hge->Gfx_EndScene();

				if (bDebugGUI) {Log("Done.");}

				bRebuildCache = false;
			}
		}
		else
		{
			if (mParent != NULL)
			{
				fGX = this->GetX()-mParent->GetX()+mParent->fLD-fLD;
				fGY = mParent->GetY()-this->GetY()+mParent->fTD-fTD;
			}
			else
			{
				fGX = this->GetX();
				fGY = -this->GetY();
			}

			// Just render the cache
			mSpr->Render(fGX, fGY);
		}
	}
}

void GUIElement::CopyVirt(GUIElement* frame)
{
	/* [#] This function copies this virtual frame's properties in the provided
	/* real frame. This function allows inheritance and templates.
	*/
	bool bDebugThis = false;
	if (frame == NULL)
	{
		if (bDebugThis) Log("Error copying %s to unknown frame", sVName.c_str());
	}
	else
	{
		if (bDebugThis) Log("Copying %s to %s", sVName.c_str(), frame->sName.c_str());
		if (bVirt && !frame->bVirt)
		{
			// Copy base parameters
			if (bDebugThis) Log("1");
			frame->bHidden = bHidden;
			frame->fW = fW;
			frame->fH = fH;
			frame->fAlpha = fAlpha;
			frame->bEnableMouse = bEnableMouse;

			frame->lFuncList = lFuncList;

			// Status bar
			frame->fValue = fValue;
			frame->fMinValue = fMinValue;
			frame->fMaxValue = fMaxValue;
			frame->fBaseWidth = fBaseWidth;
			frame->sBarTextureName = sBarTextureName;

			// Edit box
			frame->iLetters = iLetters;
			frame->iHistoryLines = iHistoryLines;
			frame->fBlinkSpeed = fBlinkSpeed;
			frame->bNumeric = bNumeric;
			frame->bPassword = bPassword;
			frame->bMultiLine = bMultiLine;
			frame->bIgnoreArrows = bIgnoreArrows;
			frame->bAutoFocus = bAutoFocus;
			frame->sCaptionFontName = sCaptionFontName;

			// Copy and update backdrop
			frame->bUseBackdrop = bUseBackdrop;
			if (bUseBackdrop)
			{
				frame->mBackdrop = mBackdrop;

				// Load edges
				if (frame->mBackdrop.sEdgeFile != "")
				{
					HTEXTURE tex1 = mGFXMgr->LoadTexture(frame->mBackdrop.sEdgeFile, false);
					float size = (int)floor(hge->Texture_GetWidth(tex1, true)/8.0f);
					frame->mBackdrop.mEdgeL = new hgeSprite(tex1, 0, 0, size, size);
					frame->mBackdrop.mEdgeR = new hgeSprite(tex1, size, 0, size, size);
					frame->mBackdrop.mEdgeT = new hgeSprite(tex1, 2*size, 0, size, size);
					frame->mBackdrop.mEdgeB = new hgeSprite(tex1, 3*size, 0, size, size);
					frame->mBackdrop.mCornerTL = new hgeSprite(tex1, 4*size, 0, size, size);
					frame->mBackdrop.mCornerTR = new hgeSprite(tex1, 5*size, 0, size, size);
					frame->mBackdrop.mCornerBL = new hgeSprite(tex1, 6*size, 0, size, size);
					frame->mBackdrop.mCornerBR = new hgeSprite(tex1, 7*size, 0, size, size);
					frame->mBackdrop.fEdgeOriginalSize = size;
					frame->mBackdrop.bEdgeReady = true;
				}
				else
					frame->mBackdrop.bEdgeReady = false;

				// Load background
				if (frame->mBackdrop.sBgFile != "")
				{
					HTEXTURE tex2;
					tex2 = mGFXMgr->LoadTexture(frame->mBackdrop.sBgFile, false);

					frame->mBackdrop.fBgW = hge->Texture_GetWidth(tex2, true);
					frame->mBackdrop.fBgH = hge->Texture_GetHeight(tex2, true);

					if (frame->mBackdrop.bTile)
						frame->mBackdrop.mBackground = new hgeSprite(tex2, 0, 0, frame->fW-frame->mBackdrop.fInsL-frame->mBackdrop.fInsR, frame->fH-frame->mBackdrop.fInsT-frame->mBackdrop.fInsB);
					else
						frame->mBackdrop.mBackground = new hgeSprite(tex2, 0, 0, frame->mBackdrop.fBgW, frame->mBackdrop.fBgH);

					frame->mBackdrop.bBgReady = true;
				}
				else
					frame->mBackdrop.bBgReady = false;

				frame->mBackdrop.mTarget = hge->Target_Create(ToInt(frame->fW), ToInt(frame->fH), false);
				frame->mBackdrop.mSpr = new hgeSprite(hge->Target_GetTexture(frame->mBackdrop.mTarget), 0, 0, ToInt(frame->fW), ToInt(frame->fH));
			}

			// Copy and update anchors
			frame->lAnchorList.clear();
			map<int, Anchor>::iterator iter;
			for (iter = lAnchorList.begin(); iter != lAnchorList.end(); iter++)
			{
				Anchor a = iter->second;
				int i = a.sParentName.find("$parent");
				if (i != a.sParentName.npos)
				{
					a.sParentName = a.sParentName.erase(i, 7);
					if (frame->mParent != NULL)
						a.sParentName.insert(i, frame->mParent->sName);
				}
				if (mGUIMgr->lParentList.find(a.sParentName) != mGUIMgr->lParentList.end())
				{
					a.mParent = mGUIMgr->lParentList[a.sParentName];
					frame->lAnchorList[iter->first] = a;
				}
				else
					Log("# Error # : unknown parent %s", a.sParentName.c_str());
			}

			// Copy and update arts
			frame->lArtList.clear();
			if (bDebugThis) Log("2");
			map<string, GUIArt*>::iterator iterArt;
			for (iterArt = lArtList.begin(); iterArt != lArtList.end(); iterArt++)
			{
				if (bDebugThis) Log("2.1");
				GUIArt* a = new GUIArt(*iterArt->second);
				a->bVirt = false;
				a->mParent = frame;
				a->sBName = a->sName;
				int i = a->sName.find("$parent");
				if (i != a->sName.npos)
				{
					a->sName = a->sName.erase(i, 7);
					a->sBName = a->sName;
					a->sName.insert(i, frame->sName);
				}

				if (bDebugThis) Log("2.2 %s", a->sName.c_str());

				if ((frame->lArtList.find(a->sName) == frame->lArtList.end()) && (a->sName != ""))
				{
					if (bDebugThis) Log("2.3");
					map<int, Anchor>::iterator iter;
					for (iter = a->lAnchorList.begin(); iter != a->lAnchorList.end(); iter++)
					{
						if (bDebugThis) Log("2.3.1");
						Anchor* an = &iter->second;
						if (an->sParentName != "")
						{
							int i = an->sParentName.find("$parent");
							if (i != an->sParentName.npos)
							{
								an->sParentName = an->sParentName.erase(i, 7);
								an->sParentName.insert(i, frame->sName);
							}
						}
					}
					if (bDebugThis) Log("2.4");
					if ( (a->iType == GUI_OBJECT_TYPE_TEXTURE) || (a->iType == GUI_OBJECT_TYPE_TSTATUSBAR) )
					{
						if (bDebugThis) Log("2.4.1");
						if (iterArt->second->bReady)
							a->mSprite = mGFXMgr->CreateSprite(iterArt->second->mSprite, true);
						string exec = a->sName + " = Texture(\"" + a->mParent->sName + "\", \"" + a->sName + "\");";
						if (bDebugThis) Log("2.4.2");
						luaL_dostring(mSceneMgr->luaVM, exec.c_str());
						if (bDebugThis) Log("2.4.3");
					}
					else if (a->iType == GUI_OBJECT_TYPE_FONTSTRING)
					{
						if (bDebugThis) Log("2.4.4");
						string exec = a->sName + " = FontString(\"" + a->mParent->sName + "\", \"" + a->sName + "\");";
						if (bDebugThis) Log("2.4.5");
						luaL_dostring(mSceneMgr->luaVM, exec.c_str());
						if (bDebugThis) Log("2.4.6");
					}
					frame->lArtList[a->sName] = a;
					mGUIMgr->lParentList[a->sName] = frame->lArtList[a->sName];
				}
				else
                    delete a;
			}

			if (bDebugThis) Log("3");
			for (iterArt = frame->lArtList.begin(); iterArt != frame->lArtList.end(); iterArt++)
			{
				if (bDebugThis) Log("3.1");
				GUIArt* a = iterArt->second;
				map<int, Anchor>::iterator iter;
				for (iter = a->lAnchorList.begin(); iter != a->lAnchorList.end(); iter++)
				{
					if (bDebugThis) Log("3.1.1");
					Anchor* an = &iter->second;
					if (mGUIMgr->lParentList.find(an->sParentName) != mGUIMgr->lParentList.end())
						an->mParent = mGUIMgr->lParentList[an->sParentName];
					else
						Log("# Error # : unknown parent %s", an->sParentName.c_str());
				}
			}

			// Update specific pointers
			if (frame->sBarTextureName != "")
			{
				int i = frame->sBarTextureName.find("$parent");
				if (i != frame->sBarTextureName.npos)
				{
					frame->sBarTextureName = frame->sBarTextureName.erase(i, 7);
					frame->sBarTextureName.insert(i, frame->sName);
				}
				if (frame->lArtList.find(frame->sBarTextureName) != frame->lArtList.end())
				{
					frame->mBarTexture = frame->lArtList[frame->sBarTextureName];
				}
			}
			if (frame->sCaptionFontName != "")
			{
				int i = frame->sCaptionFontName.find("$parent");
				if (i != frame->sCaptionFontName.npos)
				{
					frame->sCaptionFontName = frame->sCaptionFontName.erase(i, 7);
					frame->sCaptionFontName.insert(i, frame->sName);
				}
				if (frame->lArtList.find(frame->sCaptionFontName) != frame->lArtList.end())
				{
					frame->mCaptionFont = frame->lArtList[frame->sCaptionFontName];
				}
			}

			// Copy and update childs
			if (bDebugThis) Log("4");
			frame->lChildList.clear();
			frame->lVChildList.clear();
			map<string, GUIElement*>::iterator iterChild;
			for (iterChild = lVChildList.begin(); iterChild != lVChildList.end(); iterChild++)
			{
				if (bDebugThis) Log("4.1");
				GUIElement* base = iterChild->second;
				GUIElement* c = new GUIElement(*base);
				c->bVirt = false;
				c->mParent = frame;
				c->sParentName = frame->sName;
				c->sBName = c->sName;

				int i = c->sName.find("$parent");
				if (i != c->sName.npos)
				{
					c->sName = c->sName.erase(i, 7);
					c->sBName = c->sName;
					c->sName.insert(i, frame->sName);
				}
				if (bDebugThis) Log("4.2 %s", c->sName.c_str());

				if ((mGUIMgr->lGuiList.find(c->sName) == mGUIMgr->lGuiList.end()) && (c->sName != ""))
				{
					if (bDebugThis) Log("4.3");
					mGUIMgr->lGuiList[c->sName] = c;
					mGUIMgr->lParentList[c->sName] = c;
					frame->lChildList[c->sName] = c;

					base->CopyVirt(c);

					if (bDebugThis) Log("4.4");

					string exec;
					if (c->iType == GUI_OBJECT_TYPE_STATUSBAR)
						exec = c->sName + " = StatusBar(\"" + c->sName + "\");";
					else if (c->iType == GUI_OBJECT_TYPE_EDITBOX)
						exec = c->sName + " = EditBox(\"" + c->sName + "\");";
                    else if (c->iType == GUI_OBJECT_TYPE_SMSGFRAME)
                        exec = c->sName + " = ScrollingMessageFrame(\"" + c->sName + "\");";
                    else if (c->iType == GUI_OBJECT_TYPE_BUTTON)
                        exec = c->sName + " = Button(\"" + c->sName + "\");";
					else
						exec = c->sName + " = Frame(\"" + c->sName + "\");";

					luaL_dostring(mSceneMgr->luaVM, exec.c_str());

					if (bDebugThis) Log("4.5");
				}
				else
                    delete c;
			}
		}
	}
	if (bDebugThis) Log("5");
}

GUIBase* GUIBase::GetHighestVirtParent()
{
	// [#] This function returns the highest parent which is virtual.
	if (mParent != NULL)
	{
		GUIElement* tparent = mParent;
		while (tparent->bVirt)
		{
			if (tparent->mParent == NULL)
				break;
			else
				tparent = tparent->mParent;
		}
		return tparent;
	}
	else
	{
		if (iType == GUI_OBJECT_TYPE_FRAME)
			return this;
		else
			return NULL;
	}
}

int GUIElement::GetChildLevel()
{
	int iLevel = 0;
	GUIElement* p = mParent;

	while (p != NULL)
	{
		p = p->mParent;
		iLevel++;
	}

	return iLevel;
}

void GUIElement::Print(int level)
{
	/* [#] This function prints in the log a very detailed set of informations
	/* about itself, its arts and its lChildList. It's a recursive function.
	*/
	string tab = string(level*4, ' ');
	string lparent_name, aparent_name;
	if (mParent == NULL)
		lparent_name = "no parent";
	else
		lparent_name = mParent->sName;
	if (lAnchorList[0].mParent == NULL)
		aparent_name = "no parent (" + lAnchorList[0].sParentName + ")";
	else
		aparent_name = lAnchorList[0].mParent->sName;
	Log("%s - [%d] (%d) %s (%.0f, %.0f, %.2f, %.2f, %s, %s, %d)", tab.c_str(), iFrameStrata, !bHidden, sName.c_str(), fGX, fGY, fW, fH, lparent_name.c_str(), aparent_name.c_str(), lAnchorList.size());
	Log("%s   # Arts :", tab.c_str());
	map<string, GUIArt*>::iterator iter3;
	for (iter3 = lArtList.begin(); iter3 != lArtList.end(); iter3++)
	{
		GUIArt* a = iter3->second;
		string parentname;
		if (a->lAnchorList[0].mParent == NULL)
			parentname = "no parent (" + a->lAnchorList[0].sParentName + ")";
		else
			parentname = a->lAnchorList[0].mParent->sName;
		Log("%s    - (%d) %s : (anchor : %d, %s, %d)", tab.c_str(), !a->bHidden, a->sName.c_str(), a->lAnchorList[0].iAnchorPt, parentname.c_str(), a->lAnchorList[0].iRelativePt);
		Log("%s      %.0f, %.0f, %.2f, %.2f", tab.c_str(), a->fAX, a->fAY, a->fScale, a->fVScale);
	}
	Log("%s   # Childs :", tab.c_str());
	map<string, GUIElement*>::iterator iterChild;
	for (iterChild = lChildList.begin(); iterChild != lChildList.end(); iterChild++)
	{
		iterChild->second->Print(level+1);
	}
}

void GUIElement::UpdateCarret()
{
	if (iType == GUI_OBJECT_TYPE_EDITBOX)
	{
		fCarretTimer += mTimeMgr->GetDelta();
		if (fCarretTimer >= fBlinkSpeed)
		{
			bShowCarret = !bShowCarret;
			fCarretTimer = 0.0f;
			this->RebuildCache();
		}
	}
}

void GUIElement::CheckInput(float mx, float my, int lbutton, int rbutton)
{
	/* [#] This function tracks inputs on this element, such as mouse hovering,
	/* cliks, ...
	*/
	if (bEnableMouse && bReady)
	{
		if ( (mx >= fX+iHitInsL) && (mx < fX+fW-iHitInsR) && (my >= -fY+iHitInsT) && (my < fH-fY-iHitInsB)/* && mSceneMgr->bMouseOverPlayField*/ )
		{
			if (!bBaseUI)
				mSceneMgr->bMouseOverPlayField = false;

			// Mouse just entered this object
			if (!bLastOn)
			{
				if (iType == GUI_OBJECT_TYPE_BUTTON)
				{
					if (bButtonTextureReady)
					{
						mTexPushed->bHidden = true;
						if (bButtonDisabled)
						{
							mTexHighlight->bHidden = true;
							mTexNormal->bHidden = true;
							mTexDisabled->bHidden = false;
						}
						else
						{
							mTexDisabled->bHidden = true;
							mTexNormal->bHidden = false;
							mTexHighlight->bHidden = false;
						}

					}

					if (bButtonFontReady)
					{
						mFontNormal->bHidden = true;
						if (bButtonDisabled)
						{
							mFontHighlight->bHidden = true;
							mFontDisabled->bHidden = false;
						}
						else
						{
							mFontDisabled->bHidden = true;
							mFontHighlight->bHidden = false;
						}
					}

					iButtonState = GUI_BUTTON_STATE_NORMAL;
					RebuildCache();
				}

				this->On(GUI_FUNC_ENTER);
			}

			// Mouse dragged upon this object
			if ( (lbutton == 1) || (rbutton == 1) )
			{
			    if (bDragged)
			    {
			        if (!mInputMgr->bLastDragged)
                    {
                        this->On(GUI_FUNC_DRAGSTART);
                        mInputMgr->bLastDragged = true;
                    }
                    else if (bMovable)
                    {
                        mAnchor->fX -= mInputMgr->fDMX;
                        mAnchor->fY += mInputMgr->fDMY;
                        this->RebuildCache();
                    }
			    }
			}
			// Mouse cliked down on this object
			else if ( (lbutton == 2) || (rbutton == 2) )
			{
				if (iType == GUI_OBJECT_TYPE_EDITBOX)
				{
					if (!mGUIMgr->HasFocus(this))
						mGUIMgr->RequestFocus(this);

					mGUIMgr->PlaceCarret(this, mx, my);
				}

				if ( (iType == GUI_OBJECT_TYPE_BUTTON) && !bButtonDisabled )
				{
					if (bButtonTextureReady)
					{
						mTexNormal->bHidden = true;
						mTexDisabled->bHidden = true;
						mTexHighlight->bHidden = true;
						mTexPushed->bHidden = false;
					}

					if (bButtonFontReady)
					{
						mFontDisabled->bHidden = true;
						mFontHighlight->bHidden = true;
						mFontNormal->bHidden = false;
					}

					bMouseDown = true;
					iButtonState = GUI_BUTTON_STATE_PUSHED;
					RebuildCache();
				}

				this->On(GUI_FUNC_MOUSEDOWN);
				if (!mInputMgr->bLastDragged && (bRegisteredForDrag || bMovable))
                    bDragged = true;
			}
			// Mouse released on this object
			else if ( (lbutton == 3) || (rbutton == 3) )
			{
				if ( (iType == GUI_OBJECT_TYPE_BUTTON) && bMouseDown )
				{
					this->On(GUI_FUNC_CLICK);

					if (bButtonTextureReady)
					{
						mTexPushed->bHidden = true;
						if (bButtonDisabled)
						{
							mTexHighlight->bHidden = true;
							mTexNormal->bHidden = true;
							mTexDisabled->bHidden = false;
						}
						else
						{
							mTexDisabled->bHidden = true;
							mTexNormal->bHidden = false;
							mTexHighlight->bHidden = false;
						}
					}

					if (bButtonFontReady)
					{
						mFontNormal->bHidden = true;
						if (bButtonDisabled)
						{
							mFontHighlight->bHidden = true;
							mFontDisabled->bHidden = false;
						}
						else
						{
							mFontDisabled->bHidden = true;
							mFontHighlight->bHidden = false;
						}
					}

					iButtonState = GUI_BUTTON_STATE_NORMAL;
					RebuildCache();
				}

				this->On(GUI_FUNC_MOUSEUP);

				if (mInputMgr->bLastDragged && !mGUIMgr->mSelSquare.IsActive())
				{
					if (bRegisteredForDrag)
						this->On(GUI_FUNC_RECEIVEDRAG);
					mInputMgr->bLastDragged = false;
				}

				bMouseDown = false;
				bDragged = false;
			}

			bLastOn = true;
		}
		else
		{
			// Mouse left this object
			if (bLastOn)
			{
				this->On(GUI_FUNC_LEAVE);

				if (iType == GUI_OBJECT_TYPE_BUTTON)
				{
					if (bButtonTextureReady)
					{
						mTexHighlight->bHidden = true;
						mTexPushed->bHidden = true;
						if (bButtonDisabled)
						{
							mTexNormal->bHidden = true;
							mTexDisabled->bHidden = false;
						}
						else
						{
							mTexDisabled->bHidden = true;
							mTexNormal->bHidden = false;
						}

					}

					if (bButtonFontReady)
					{
						mFontHighlight->bHidden = true;
						if (bButtonDisabled)
						{
							mFontNormal->bHidden = true;
							mFontDisabled->bHidden = false;
						}
						else
						{
							mFontDisabled->bHidden = true;
							mFontNormal->bHidden = false;
						}
					}

					iButtonState = GUI_BUTTON_STATE_NORMAL;
					RebuildCache();
				}
			}

			bLastOn = false;
			bMouseDown = false;
			bDragged = false;
		}
	}
}

void GUIElement::On( int type, Event* event )
{
	if (lFuncList.find(type) != lFuncList.end())
	{
		OnFunc* f = &lFuncList[type];

		if (f->bFuncDefined)
		{
			lua_getglobal(mSceneMgr->luaVM, sName.c_str());
			lua_setglobal(mSceneMgr->luaVM, "this");

			if ((f->iType == GUI_FUNC_KEYDOWN) ||
				(f->iType == GUI_FUNC_KEYUP) )
			{
				// Set key name
			}
			else if ((f->iType == GUI_FUNC_MOUSEDOWN)  ||
				(f->iType == GUI_FUNC_MOUSEUP)    ||
				(f->iType == GUI_FUNC_DRAGSTART)  ||
				(f->iType == GUI_FUNC_RECEIVEDRAG)||
				(f->iType == GUI_FUNC_CLICK))
			{
				// Set mouse button
				lua_pushstring(mSceneMgr->luaVM, mInputMgr->sMouseButton.c_str());
				lua_setglobal(mSceneMgr->luaVM, "arg1");
			}
			else if (f->iType == GUI_FUNC_UPDATE)
			{
				// Set delta time
				lua_pushnumber(mSceneMgr->luaVM, mTimeMgr->GetDelta());
				lua_setglobal(mSceneMgr->luaVM, "arg1");
			}
			else if (f->iType == GUI_FUNC_CHAR)
			{
				// Set character
				char c[1]; c[0] = mInputMgr->GetChar(true, true);
				lua_pushstring(mSceneMgr->luaVM, c);
				lua_setglobal(mSceneMgr->luaVM, "arg1");
			}
			else if (f->iType == GUI_FUNC_EVENT)
			{
				if (event != NULL)
				{
					// Set event name
					lua_pushstring(mSceneMgr->luaVM, event->sName.c_str());
					lua_setglobal(mSceneMgr->luaVM, "event");

					// Set arguments
					for (int i = 0; i < event->iArgNbr; i++)
					{
						if (event->lArgList[i].iType == ARG_TYPE_INTEGER)
							lua_pushnumber(mSceneMgr->luaVM, event->lArgList[i].vInt);
						else if (event->lArgList[i].iType == ARG_TYPE_FLOAT)
							lua_pushnumber(mSceneMgr->luaVM, event->lArgList[i].vFloat);
						else if (event->lArgList[i].iType == ARG_TYPE_STRING)
							lua_pushstring(mSceneMgr->luaVM, event->lArgList[i].vString.c_str());
						else
							break;

						lua_setglobal(mSceneMgr->luaVM, string("arg" + ToString(i+1)).c_str());
					}
				}
			}

			lua_getglobal(mSceneMgr->luaVM, "Functions");
			lua_rawgeti(mSceneMgr->luaVM, -1, f->iFuncId);
			if (lua_isfunction(mSceneMgr->luaVM, -1))
			{
				int error = lua_pcall(mSceneMgr->luaVM, 0, 0, 0);
				if (error) LUA::LogL(mSceneMgr->luaVM);
			}
			else
				lua_pop(mSceneMgr->luaVM, 1);

			lua_pop(mSceneMgr->luaVM, 1);
		}
	}

	if (type == GUI_FUNC_LOAD)
	{
		// OnLoad must be called from parent to childs, because childs often
		// rely on parents parameters/state
		map<string, GUIElement*>::iterator iterChild;
		for (iterChild = lChildList.begin(); iterChild != lChildList.end(); iterChild++)
		{
			iterChild->second->On(GUI_FUNC_LOAD);
		}
	}
}

void GUIElement::SetOnFunction( int type, int funcId )
{
	if (lFuncList.find(type) != lFuncList.end())
	{
		OnFunc* f = &lFuncList[type];
		if (funcId != -1)
		{
			f->iFuncId = funcId;
			f->bFuncDefined = true;
		}
		else
			f->bFuncDefined = false;
	}
	else if (funcId != -1)
	{
		// This handler isn't registered yet, let's do it
		OnFunc f;
		f.iType = type;
		f.iFuncId = funcId;
		f.bFuncDefined = true;
		lFuncList[type] = f;
	}
}

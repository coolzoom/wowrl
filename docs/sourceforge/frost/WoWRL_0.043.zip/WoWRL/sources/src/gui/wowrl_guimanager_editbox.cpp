/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_guimanager.h"
#include "wowrl_gui.h"
#include "wowrl_timemanager.h"
#include "wowrl_inputmanager.h"

#define CARRET_SPEED 0.05f

extern TimeManager* mTimeMgr;
extern InputManager* mInputMgr;

using namespace std;

bool GUIManager::HasFocus( GUIElement* g )
{
	return (mFocus == g);
}

void GUIManager::RequestFocus( GUIElement* g )
{
	if (g != NULL)
	{
	    if (mFocus != NULL)
	    {
            mFocus->fCarretTimer = 0.0f;
            mFocus->bShowCarret = true;
            mFocus->RebuildCache();
	    }

		g->On(GUI_FUNC_EDITFOCUSGAINED);
		g->fCarretTimer = 0.0f;
		g->bShowCarret = true;
		mFocus = g;
		UpdateCarretPos(mFocus);
		mInputMgr->SetFocus(true);
		bNewFocus = true;
	}
}

void GUIManager::LooseFocus( GUIElement* g )
{
	if (g != NULL)
	{
		g->On(GUI_FUNC_EDITFOCUSLOST);
		g->RebuildCache();
		mFocus = NULL;
		mInputMgr->SetFocus(false);
	}
}

int GetCarretLine( GUIArt* cFnt, int carretPos )
{
	int charNbr = 0;
	int l;

	// Get the TextBox from the hgeFont
	TextBox tb = cFnt->mText.mFnt->GetTextBox(cFnt->fW, cFnt->fH, cFnt->mText.sStr.c_str());

	for (l = 0; l < tb.iLineNbr; l++)
	{
		if (carretPos <= charNbr+tb.lLines[l].iCharNbr)
		{
			// Line is found
			break;
		}

		// The "+1" is for end of line character
		charNbr += tb.lLines[l].iCharNbr +1;
	}

	return l;
}

Point GUIManager::GetCarretPos( int carretPos, hgeFont* fnt, float w, float h, string s )
{
	Point p;
	p.fY = 0;

	int charNbr = 0;
	int l;

	// Get the TextBox from the hgeFont
	TextBox tb = fnt->GetTextBox(w, h, s.c_str());

	for (l = 0; l < tb.iLineNbr; l++)
	{
		if (carretPos <= charNbr+tb.lLines[l].iCharNbr)
		{
			// Line is found, now multiply the line's height by the number
			// of line : this is the carret's vertical position.
			p.fY = tb.fLineHeight*l;
			break;
		}

		// The "+1" is for end of line character
		charNbr += tb.lLines[l].iCharNbr +1;
	}

	// Get the substring between the begining of the line and the carret
	// and get its width if rendered with the hgeFont : this is the carret's
	// horizontal position.
	p.fX = fnt->GetStringWidth(tb.lLines[l].sText.substr(0, carretPos-charNbr).c_str());

	return p;
}

Point GUIManager::GetCarretPos( GUIElement* g, bool multiLine )
{
	Point p;
	p.fY = 0;

	GUIArt* cFnt = g->mCaptionFont;

	if (multiLine)
	{
		int charNbr = 0;
		int l;

		// Get the TextBox from the hgeFont
		TextBox tb = cFnt->mText.mFnt->GetTextBox(cFnt->fW, cFnt->fH, g->sEBText.c_str());

		for (l = 0; l < tb.iLineNbr; l++)
		{
			if (g->iCarretPos <= charNbr+tb.lLines[l].iCharNbr)
			{
				// Line is found, now multiply the line's height by the number
				// of line : this is the carret's vertical position.
				break;
			}

			// The "+1" is for end of line character
			charNbr += tb.lLines[l].iCharNbr +1;
		}

		if (l == tb.iLineNbr)
		{
		    // The carret is at the very last position
		    l--;
		    p.fX = cFnt->mText.mFnt->GetStringWidth(tb.lLines[l].sText.c_str());
        }
        else
        {
            // Get the substring between the begining of the line and the carret
            // and get its width if rendered with the hgeFont : this is the carret's
            // horizontal position.
            p.fX = cFnt->mText.mFnt->GetStringWidth(tb.lLines[l].sText.substr(0, g->iCarretPos-charNbr).c_str());

        }

        p.fY = tb.fLineHeight*l;
	}
	else
	{
		string s = g->sEBText.substr(g->iSubStrStart, g->iSubStrLength);
		p.fX = cFnt->mText.mFnt->GetStringWidth(s.substr(0, g->iCarretPos-g->iSubStrStart).c_str());
	}

	return p;
}

void GUIManager::UpdateCarretPos( GUIElement* g )
{
	if (g->bMultiLine)
	{
		Point p = GetCarretPos(g, true);
		g->fCarretX = p.fX + g->iEBInsL;
		g->fCarretY = p.fY + g->iEBInsT;

		// Update font text
		g->mCaptionFont->mText.sStr = g->sEBText;
		g->mCaptionFont->mText.lFStr.front().sStr = g->sEBText;
	}
	else
	{
		float fBoxWidth = g->fW - g->iEBInsL - g->iEBInsR;

		if (g->iCarretPos - g->iSubStrStart < 0)
		{
			// Move the substring range to the left

			// Get the lower bound
			g->iSubStrStart = g->iCarretPos;
			float fNewWidth = g->mCaptionFont->mText.mFnt->GetStringWidth(
				g->sEBText.substr(g->iSubStrStart, g->iCarretPos-g->iSubStrStart).c_str()
			);
			while ( (fNewWidth < fBoxWidth*0.75f) && (g->iSubStrStart != 0) )
			{
				g->iSubStrStart--;
				fNewWidth = g->mCaptionFont->mText.mFnt->GetStringWidth(
					g->sEBText.substr(g->iSubStrStart, g->iCarretPos-g->iSubStrStart).c_str()
				);
			}
			if (g->iSubStrStart != 0)
				g->iSubStrStart++;

			// And the upper one
			g->iSubStrLength = 0;
			fNewWidth = g->mCaptionFont->mText.mFnt->GetStringWidth(
				g->sEBText.substr(g->iSubStrStart, g->iSubStrLength).c_str()
			);
			while ( (fNewWidth < fBoxWidth) && (g->iSubStrStart+g->iSubStrLength < g->sEBText.length()) )
			{
				g->iSubStrLength++;
				fNewWidth = g->mCaptionFont->mText.mFnt->GetStringWidth(
					g->sEBText.substr(g->iSubStrStart, g->iSubStrLength).c_str()
				);
			}
			if (g->iSubStrStart+g->iSubStrLength < g->sEBText.length())
				g->iSubStrLength--;

			Point p = GetCarretPos(g, false);
			g->fCarretX = p.fX + g->iEBInsL;
			g->fCarretY = g->iEBInsT;
		}
		else
		{
			float fNewWidth = g->mCaptionFont->mText.mFnt->GetStringWidth(
				g->sEBText.substr(g->iSubStrStart, g->iCarretPos-g->iSubStrStart).c_str()
			);

			if (fNewWidth > fBoxWidth)
			{
				// Move the substring range to the right

				// Get the lower bound
				g->iSubStrStart = g->iCarretPos;
				float fNewWidth = g->mCaptionFont->mText.mFnt->GetStringWidth(
					g->sEBText.substr(g->iSubStrStart, g->iCarretPos-g->iSubStrStart).c_str()
				);
				while ( (fNewWidth < fBoxWidth*0.75f) && (g->iSubStrStart != 0) )
				{
					g->iSubStrStart--;
					fNewWidth = g->mCaptionFont->mText.mFnt->GetStringWidth(
						g->sEBText.substr(g->iSubStrStart, g->iCarretPos-g->iSubStrStart).c_str()
					);
				}
				if (g->iSubStrStart != 0)
					g->iSubStrStart++;

				// And the upper one
				g->iSubStrLength = 0;
				fNewWidth = g->mCaptionFont->mText.mFnt->GetStringWidth(
					g->sEBText.substr(g->iSubStrStart, g->iSubStrLength).c_str()
				);
				while ( (fNewWidth < fBoxWidth) && (g->iSubStrStart+g->iSubStrLength != g->sEBText.length()) )
				{
					g->iSubStrLength++;
					fNewWidth = g->mCaptionFont->mText.mFnt->GetStringWidth(
						g->sEBText.substr(g->iSubStrStart, g->iSubStrLength).c_str()
					);
				}
				if (g->iSubStrStart+g->iSubStrLength != g->sEBText.length())
					g->iSubStrLength--;

				Point p = GetCarretPos(g, false);
				g->fCarretX = p.fX + g->iEBInsL;
				g->fCarretY = g->iEBInsT;
			}
			else
			{
				// Nothing special to do, just check the upper bound
				g->iSubStrLength = 0;
				fNewWidth = g->mCaptionFont->mText.mFnt->GetStringWidth(
					g->sEBText.substr(g->iSubStrStart, g->iSubStrLength).c_str()
				);
				while ( (fNewWidth < fBoxWidth) && (g->iSubStrStart+g->iSubStrLength != g->sEBText.length()) )
				{
					g->iSubStrLength++;
					fNewWidth = g->mCaptionFont->mText.mFnt->GetStringWidth(
						g->sEBText.substr(g->iSubStrStart, g->iSubStrLength).c_str()
					);
				}
				if (g->iSubStrStart+g->iSubStrLength != g->sEBText.length())
					g->iSubStrLength--;

				Point p = GetCarretPos(g, false);
				g->fCarretX = p.fX + g->iEBInsL;
				g->fCarretY = g->iEBInsT;
			}
		}

		// Update font text
		g->mCaptionFont->mText.sStr = g->sEBText.substr(g->iSubStrStart, g->iSubStrLength);
		g->mCaptionFont->mText.lFStr.front().sStr = g->sEBText.substr(g->iSubStrStart, g->iSubStrLength);
	}
}

void GUIManager::PlaceCarret(GUIElement* g, float x, float y)
{
    if (g->sEBText != "")
    {
        if (g->bMultiLine)
        {
            TextBox tb = g->mCaptionFont->mText.mFnt->GetTextBox(
                g->mCaptionFont->fW, g->mCaptionFont->fH,
                g->sEBText.c_str()
            );

            float fGX = g->GetX() + g->iEBInsL;
            float fGY = -g->GetY() + g->iEBInsT;

            int i, j;
            int iCharNbr = 0;

            float fBestDiff = fabs(y - fGY);
            // First find the proper line
            for (j = 0; j < tb.iLineNbr; j++)
            {
                if (y - tb.fLineHeight*j - fGY < tb.fLineHeight)
                    break;

                iCharNbr += tb.lLines[j].iCharNbr +1;
            }

            if (j == tb.iLineNbr)
            {
                // The cursor if not on the text zone
                g->iCarretPos = iCharNbr-1;
            }
            else
            {
                fBestDiff = fabs(x - fGX);
                // Then the proper character
                for (i = 0; i < tb.lLines[j].sText.length(); i++)
                {
                    string s = tb.lLines[j].sText.substr(0, i);
                    float fNewDiff = fabs(x - g->mCaptionFont->mText.mFnt->GetStringWidth(s.c_str()) - fGX);
                    if (fNewDiff > fBestDiff)
                    {
                        i--;
                        break;
                    }
                    else
                        fBestDiff = fNewDiff;

                    if (i == tb.lLines[j].sText.length())
                        i--;
                }

                g->iCarretPos = iCharNbr + i;
            }

            UpdateCarretPos(g);
            g->RebuildCache();
        }
        else
        {
            // No need to bother with lines : just iterate through the
            // substring until the proper character is found
            float fGX = g->GetX() + g->iEBInsL;
            int i;
            float fBestDiff = fabs(x - fGX);
            for (i = 0; i < g->mCaptionFont->mText.sStr.length(); i++)
            {
                string s = g->mCaptionFont->mText.sStr.substr(0, i);
                float fNewDiff = fabs(x - g->mCaptionFont->mText.mFnt->GetStringWidth(s.c_str()) - fGX);
                if (fNewDiff > fBestDiff)
                {
                    i--;
                    break;
                }
                else
                    fBestDiff = fNewDiff;
            }

            g->iCarretPos = g->iSubStrStart + i;

            UpdateCarretPos(g);
            g->RebuildCache();
        }
    }
}

void GUIManager::UpdateEditBox()
{
	if (mFocus != NULL)
	{
		if (mInputMgr->GetKey(true))
		{
			mFocus->bShowCarret = true;
			mFocus->fCarretTimer = 0.0f;
		}

		if (mInputMgr->KeyIsReleased(HGEK_ESCAPE, true))
		{
			mFocus->On(GUI_FUNC_ESCAPEPRESSED);
			LooseFocus(mFocus);
		}
		else
		{
			if (mFocus->mCaptionFont != NULL)
			{
				GUIArt* cFnt = mFocus->mCaptionFont;

				if (bNewFocus)
				{
					UpdateCarretPos(mFocus);
					mFocus->RebuildCache();
				}

				char c = mInputMgr->GetChar(true, true);
				if ( (c != 0) && !bNewFocus && ((cFnt->mText.sStr.length() < mFocus->iLetters) || (mFocus->iLetters == 0)) )
				{
					// Add a character before the carret
					mFocus->On(GUI_FUNC_CHAR);

					mFocus->sEBText.insert(mFocus->iCarretPos, 1, c);
					mFocus->iCarretPos++;
					UpdateCarretPos(mFocus);

					mFocus->AdjustCache();
					mFocus->RebuildCache();
				}

				if (mInputMgr->KeyIsPressed(HGEK_ENTER, true))
				{
					if (/* mInputMgr->bShiftPressed && */mFocus->bMultiLine )
					{
						// Enter to start a new line (multiline only)
						mFocus->On(GUI_FUNC_CHAR);
						mFocus->sEBText.insert(mFocus->iCarretPos, 1, '\n');
						//cFnt->mText.sStr = mFocus->sEBText;
						mFocus->iCarretPos++;
						UpdateCarretPos(mFocus);

						mFocus->AdjustCache();
						mFocus->RebuildCache();
					}

                    mFocus->On(GUI_FUNC_ENTERPRESSED);
				}

                static PeriodicTimer tBackSpace(CARRET_SPEED, false, true);
				if (mInputMgr->KeyIsDownLong(HGEK_BACKSPACE, true)) tBackSpace.Start();
				else tBackSpace.Stop();

				if ((mInputMgr->KeyIsPressed(HGEK_BACKSPACE, true)) ||
					(mInputMgr->KeyIsDownLong(HGEK_BACKSPACE, true)&& tBackSpace.Ticks()))
				{
                    // Remove the character just before the carret
                    if (mFocus->iCarretPos > 0)
                    {
                        string::iterator iter = mFocus->sEBText.begin();
                        for (int i = 0; i < mFocus->iCarretPos-1; i++)
                            iter++;
                        mFocus->sEBText.erase(iter);
                        mFocus->iCarretPos--;
                        UpdateCarretPos(mFocus);

                        mFocus->AdjustCache();
                        mFocus->RebuildCache();
                    }
				}

				static PeriodicTimer tDel(CARRET_SPEED, false, true);
				if (mInputMgr->KeyIsDownLong(HGEK_DELETE, true)) tDel.Start();
				else tDel.Stop();

				if ((mInputMgr->KeyIsPressed(HGEK_DELETE, true)) ||
					(mInputMgr->KeyIsDownLong(HGEK_DELETE, true)&& tDel.Ticks()))
				{
                    // Remove the character just after the carret
                    string::iterator iter = mFocus->sEBText.begin();
                    for (int i = 0; i < mFocus->iCarretPos; i++)
                        iter++;

                    if (iter != mFocus->sEBText.end())
                    {
                        mFocus->sEBText.erase(iter);
                        UpdateCarretPos(mFocus);

                        mFocus->AdjustCache();
                        mFocus->RebuildCache();
                    }
				}

				static PeriodicTimer tLeft(CARRET_SPEED, false, true);
				if (mInputMgr->KeyIsDownLong(HGEK_LEFT, true)) tLeft.Start();
				else tLeft.Stop();

				if ((mInputMgr->KeyIsPressed(HGEK_LEFT, true)) ||
					(mInputMgr->KeyIsDownLong(HGEK_LEFT, true) && tLeft.Ticks()))
				{
					if (mFocus->iCarretPos != 0)
					{
						// Move the carret to the left
						mFocus->iCarretPos--;
						UpdateCarretPos(mFocus);

						mFocus->RebuildCache();
					}
				}

				static PeriodicTimer tRight(CARRET_SPEED, false, true);
				if (mInputMgr->KeyIsDownLong(HGEK_RIGHT, true)) tRight.Start();
				else tRight.Stop();

				if ((mInputMgr->KeyIsPressed(HGEK_RIGHT, true)) ||
					(mInputMgr->KeyIsDownLong(HGEK_RIGHT, true) && tRight.Ticks()))
				{
					if (mFocus->iCarretPos < cFnt->mText.sStr.length())
					{
						// Move the carret to the right
						mFocus->iCarretPos++;
						UpdateCarretPos(mFocus);

						mFocus->RebuildCache();
					}
				}

				static PeriodicTimer tUp(CARRET_SPEED, false, true);
				if (mInputMgr->KeyIsDownLong(HGEK_UP, true)) tUp.Start();
				else tUp.Stop();

				if ((mInputMgr->KeyIsPressed(HGEK_UP, true)) ||
					(mInputMgr->KeyIsDownLong(HGEK_UP, true)) && tUp.Ticks())
				{
					int iCarretLine = GetCarretLine(cFnt, mFocus->iCarretPos);

					if (mFocus->iCarretPos != 0)
					{
						if ( (iCarretLine == 0) || (!mFocus->bMultiLine) )
						{
							// The carret is aready on the first line
							// so we just put it at the begining
							mFocus->iCarretPos = 0;
							mFocus->iSubStrStart = 0;
						}
						else
						{
							// Move the carret one line up
							TextBox tb = cFnt->mText.mFnt->GetTextBox(cFnt->fW, cFnt->fH, cFnt->mText.sStr.c_str());
							int iPrevLinePos = 0;
							for (int i = 0; i < iCarretLine-1; i++)
								iPrevLinePos += tb.lLines[i].iCharNbr+1;

							Line lPrev = tb.lLines[iCarretLine-1];

							Point p = GetCarretPos(mFocus, true);

							// If the carret's horizontal position is larger than the
							// previous line's width, just put it at this line's end.
							if (p.fX > lPrev.fWidth)
								mFocus->iCarretPos = iPrevLinePos + lPrev.iCharNbr;
							else
							{
								// Else, we put it at the closest horizontal position.
								float fNewWidth = 0.0f;
								float fDiff;
								float fLastDiff = lPrev.fWidth;
								int iCharPos;
								for (iCharPos = 0; iCharPos < lPrev.sText.length(); iCharPos++)
								{
									string s = lPrev.sText.substr(0, iCharPos+1);
									fNewWidth = cFnt->mText.mFnt->GetStringWidth(s.c_str());
									fDiff = fabs(fNewWidth - p.fX);
									if (fDiff > fLastDiff)
										break;

									fLastDiff = fabs(fNewWidth - p.fX);
								}

								mFocus->iCarretPos = iPrevLinePos + iCharPos;
							}
						}

						UpdateCarretPos(mFocus);

						mFocus->RebuildCache();
					}
				}

				static PeriodicTimer tDown(CARRET_SPEED, false, true);
				if (mInputMgr->KeyIsDownLong(HGEK_DOWN, true)) tDown.Start();
				else tDown.Stop();

				if ((mInputMgr->KeyIsPressed(HGEK_DOWN, true)) ||
					(mInputMgr->KeyIsDownLong(HGEK_DOWN, true)) && tDown.Ticks())
				{
					int iCarretLine = GetCarretLine(cFnt, mFocus->iCarretPos);

					if (mFocus->iCarretPos != mFocus->sEBText.length())
					{
						TextBox tb = cFnt->mText.mFnt->GetTextBox(cFnt->fW, cFnt->fH, cFnt->mText.sStr.c_str());
						if ( (iCarretLine == tb.iLineNbr-1) || (!mFocus->bMultiLine) )
						{
							// The carret is aready on the last line
							// so we just put it at the end
							mFocus->iCarretPos = mFocus->sEBText.length();
						}
						else
						{
							// Move the carret one line down
							int iNextLinePos = 0;
							for (int i = 0; i < iCarretLine+1; i++)
								iNextLinePos += tb.lLines[i].iCharNbr+1;

							Line lNext = tb.lLines[iCarretLine+1];

							Point p = GetCarretPos(mFocus, true);

							// If the carret's horizontal position is larger than the
							// next line's width, just put it at this line's end.
							if (p.fX > lNext.fWidth)
								mFocus->iCarretPos = iNextLinePos + lNext.iCharNbr;
							else
							{
								// Else, we put it at the closest horizontal position.
								float fNewWidth = 0.0f;
								float fDiff;
								float fLastDiff = lNext.fWidth;
								int iCharPos;
								for (iCharPos = 0; iCharPos < lNext.sText.length(); iCharPos++)
								{
									string s = lNext.sText.substr(0, iCharPos+1);
									fNewWidth = cFnt->mText.mFnt->GetStringWidth(s.c_str());
									fDiff = fabs(fNewWidth - p.fX);
									if (fDiff > fLastDiff)
										break;

									fLastDiff = fabs(fNewWidth - p.fX);
								}

								mFocus->iCarretPos = iNextLinePos + iCharPos;
							}
						}

						UpdateCarretPos(mFocus);

						mFocus->RebuildCache();
					}
				}

				if (mInputMgr->KeyIsPressed(HGEK_END, true))
				{
					int iCarretLine = GetCarretLine(cFnt, mFocus->iCarretPos);

					if (mFocus->iCarretPos != cFnt->mText.sStr.length())
					{
						TextBox tb = cFnt->mText.mFnt->GetTextBox(cFnt->fW, cFnt->fH, cFnt->mText.sStr.c_str());
						if ( (iCarretLine == tb.iLineNbr-1) || (!mFocus->bMultiLine) )
						{
							// The carret is aready on the last line
							// so we just put it at the end
							mFocus->iCarretPos = mFocus->sEBText.length();
							//mFocus->iSubStrLength = mFocus->sEBText.length();
						}
						else
						{
							// Get actual line's position
							int iLinePos = 0;
							for (int i = 0; i < iCarretLine; i++)
								iLinePos += tb.lLines[i].iCharNbr+1;

							// And put the carret at this line's end.
							mFocus->iCarretPos = iLinePos + tb.lLines[iCarretLine].iCharNbr;
						}

						UpdateCarretPos(mFocus);

						mFocus->RebuildCache();
					}
				}

				if (mInputMgr->KeyIsPressed(HGEK_HOME, true))
				{
					int iCarretLine = GetCarretLine(cFnt, mFocus->iCarretPos);

					if (mFocus->iCarretPos != 0)
					{
						TextBox tb = cFnt->mText.mFnt->GetTextBox(cFnt->fW, cFnt->fH, cFnt->mText.sStr.c_str());
						if ( (iCarretLine == 0) || (!mFocus->bMultiLine) )
						{
							// The carret is aready on the first line
							// so we just put it at the begining
							mFocus->iCarretPos = 0;
							mFocus->iSubStrStart = 0;
						}
						else
						{
							// Get actual line's position
							int iLinePos = 0;
							for (int i = 0; i < iCarretLine; i++)
								iLinePos += tb.lLines[i].iCharNbr+1;

							// And put the carret at this line's begining.
							mFocus->iCarretPos = iLinePos;
						}

						UpdateCarretPos(mFocus);

						mFocus->RebuildCache();
					}
				}
			}

			if (mInputMgr->KeyIsPressed(HGEK_TAB, true))
				mFocus->On(GUI_FUNC_TABPRESSED);

			if (mInputMgr->KeyIsPressed(HGEK_SPACE, true))
				mFocus->On(GUI_FUNC_SPACEPRESSED);
		}
	}

	if (bNewFocus) bNewFocus = false;
}

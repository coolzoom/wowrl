/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           LoadingBar source            */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the LoadingBar class.              */
/*       A LoadingBar is a GUI element    */
/*  that displays the state of the game   */
/*  while loading data.                   */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_fontmanager.h"
#include "wowrl_guimanager.h"

#include "wowrl_loadingbar.h"

extern FontManager* mFontMgr;
extern GUIManager* mGUIMgr;

void LoadingBar::Init()
{
	mCaptionFnt = mFontMgr->GetFont(true, "Fonts/Calibri.ttf", 14, true, false);
}

void LoadingBar::Render()
{
	mBackground->Render(mGUIMgr->fLoadingBarX, mGUIMgr->fLoadingBarY);
	mGauge->RenderEx
	(
		mGUIMgr->fLoadingBarX+2-246.0f/2.0f, mGUIMgr->fLoadingBarY,
		0.0f,
		fFilling*242.0f/26.0f,
		1.0f
	);
	mBorder->Render(mGUIMgr->fLoadingBarX, mGUIMgr->fLoadingBarY-2);

	mSpark->Render
	(
		mGUIMgr->fLoadingBarX+2-246.0f/2.0f+fFilling*242.0f,
		mGUIMgr->fLoadingBarY+1
	);

	// The font is rendered twice with a small offset to simulate a shadow
	if (mCaptionFnt != NULL)
	{
		mCaptionFnt->SetColor(ARGB(255,0,0,0));
		mCaptionFnt->printf
		(
			mGUIMgr->fLoadingBarX-113, mGUIMgr->fLoadingBarY+5, HGETEXT_LEFT, "%s",
			sCaption.c_str()
		);
		mCaptionFnt->SetColor(ARGB(255,255,255,255));
		mCaptionFnt->printf
		(
			mGUIMgr->fLoadingBarX-114, mGUIMgr->fLoadingBarY+4, HGETEXT_LEFT, "%s",
			sCaption.c_str()
		);
	}
}

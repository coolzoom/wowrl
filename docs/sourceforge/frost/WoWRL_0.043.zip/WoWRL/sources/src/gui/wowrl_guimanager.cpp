/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           GUIManager source            */
/*                                        */
/*  ## : A class that manages the GUI,    */
/*  including parsing, rendering,         */
/*  interacting and destructing.          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_scenemanager.h"
#include "wowrl_unitmanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_lua.h"
#include "wowrl_statusbar.h"
#include "wowrl_gui.h"
#include "wowrl_xml.h"

#include "wowrl_guimanager.h"

using namespace std;

extern TimeManager *mTimeMgr;
extern SceneManager *mSceneMgr;
extern InputManager *mInputMgr;
extern UnitManager *mUnitMgr;
extern GFXManager *mGFXMgr;
extern HGE *hge;

GUIManager::GUIManager()
{
}

GUIManager::~GUIManager()
{
    mGUIMgr = NULL;
}

void GUIManager::Init()
{
	// Default values
	fLoadingBarX = mGFXMgr->iSWidth/2.0f;
	fLoadingBarY = mGFXMgr->iSHeight-160;

	mDefaultFont = NULL;
	mCursor = NULL;

	iFuncCount = 1;

	mFocus = NULL;
	bNewFocus = false;

	mTargetLink1.tex = 0;
	mTargetLink1.blend = 0;
	mTargetLink2.tex = 0;
	mTargetLink2.blend = 0;
	fTargetLinkTimer = 0.0f;

	bRebuildGUIList = true;

	RegisterEvents();
}

GUIManager* GUIManager::mGUIMgr = NULL;

GUIManager* GUIManager::GetSingleton()
{
	if (mGUIMgr == NULL)
		mGUIMgr = new GUIManager;
	return mGUIMgr;
}

void GUIManager::CreateStatusBar( Unit* parent )
{
	StatusBar tmpSB;
	tmpSB.mParent = parent;
	lStatusBarList[parent->GetID()] = tmpSB;
}

void GUIManager::AddScrollingText( Unit* parent, int type, string value )
{
	ScrollingText st;
	st.mParent = parent;
	st.iType = type;
	st.sValue = value;
	hgeRect* tmpRect = parent->GetBox();
	st.fX = parent->GetGX();
	st.fY = parent->GetGY()-parent->GetRace()->fStatusBarYOffset*parent->GetScale()-25;
	st.fLifeTime = 0.0f;
	if (type == GUI_SCRTXT_TYPE_PHYSICAL)
		st.dwColor = ARGB(255, 255, 0, 0);
	else if (type == GUI_SCRTXT_TYPE_HEAL)
		st.dwColor = ARGB(255, 0, 255, 0);
	else if (type == GUI_SCRTXT_TYPE_SPELL)
		st.dwColor = ARGB(255, 255, 205, 0);

	lScrollingTextList[parent->GetName() + "_" + ToString(parent->GetTextNbr())] = st;
}

void GUIManager::UpdateScrollingTexts()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(7, "GUIManager::updateScrollingTexts", false);
		Chrono c(prof);
	#endif
	if (!lScrollingTextList.empty())
	{
		map<string, ScrollingText>::iterator iterText, lastParsed;
		lastParsed = NULL;
		for (iterText = lScrollingTextList.begin(); iterText != lScrollingTextList.end(); iterText++)
		{
			ScrollingText* st = &iterText->second;
			if (st->fLifeTime >= fScrollingTextMaxLife)
			{
				lScrollingTextList.erase(iterText);
				if (lScrollingTextList.empty())
					break;
				else
				{
					if (lastParsed == NULL)
					{
						iterText = lScrollingTextList.begin();
						continue;
					}
					else
					{
						iterText = lastParsed;
					}
				}
			}
			else
			{
				st->fLifeTime += mTimeMgr->GetDelta();
				st->fY -= fScrollingTextSpeed*mTimeMgr->GetDelta();
				if (bScrollingTextFade)
				{
					float alpha = 255*(1-(st->fLifeTime/fScrollingTextMaxLife));
					st->dwColor = ARGB(alpha, GETR(st->dwColor), GETG(st->dwColor), GETB(st->dwColor));
				}
			}
			lastParsed = iterText;
		}
	}
}

void GUIManager::RenderScrollingTexts()
{
	if (!lScrollingTextList.empty())
	{
		map<string, ScrollingText>::iterator iterText;
		for (iterText = lScrollingTextList.begin(); iterText != lScrollingTextList.end(); iterText++)
		{
			ScrollingText* st = &iterText->second;
			mScrollingTextFont->SetColor(st->dwColor);
			mScrollingTextFont->printf(
				st->fX+mSceneMgr->fGX, st->fY+mSceneMgr->fGY,
				HGETEXT_CENTER, "%s", st->sValue.c_str()
			);
		}
	}
}

Cursor* GUIManager::SwitchCursor( string sCurName )
{
	Cursor* cur;
	if (lCursorList.find(sCurName) != lCursorList.end())
	{
		cur = &lCursorList[sCurName];
		if ( (cur->bAnimated) && !(cur->mAnim->IsPlaying()) )
			cur->mAnim->Play();

		return cur;
	}
	else
		Log("# ERROR # : Unknown cursor \"%s\".", sCurName.c_str());
}

void GUIManager::AddErrorMessage( string caption )
{
	ErrorText eT;
	eT.sCaption = caption;
	eT.fLifeTime = fErrorTextsDuration;
	eT.fAlpha = 255.0f;

	lErrorTextList.insert(lErrorTextList.begin(), eT);
	if (lErrorTextList.size() == 6)
		lErrorTextList.pop_back();
}

void GUIManager::UpdateErrorTexts()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(7, "GUIManager::updateErrorTexts", false);
		Chrono c(prof);
	#endif
	if (!lErrorTextList.empty())
	{
		vector<ErrorText>::iterator iter;
		iter = lErrorTextList.end();
		while (iter != lErrorTextList.begin())
		{
			iter--;
			iter->fLifeTime -= mTimeMgr->GetDelta();
			if (iter->fLifeTime <= 0.0f)
			{
				lErrorTextList.pop_back();
				iter = lErrorTextList.end();
			}
			else if (iter->fLifeTime <= fErrorTextsFadeDelay)
			{
				iter->fAlpha = iter->fLifeTime*51;
			}
		}
	}
}

FormatedText GUIManager::ParseFormatedText(FormatedText ft)
{
	if (ft.mFnt != NULL)
	{
		ft.lFStr.clear();
		ft.sBaseStr = ft.sStr;

		int i = ft.sStr.find_first_of('|');

		int iCharRemoved = 0;
		map<int, int> lEquiv;

		// First save the position of all escape characters
		while (i != ft.sStr.npos)
		{
			int k = ft.sBaseStr.find_first_of('|', i+iCharRemoved);
			lEquiv[k] = i;
			// If "||" is found, replace it by a single "|"
			if (ft.sStr[i+1] == '|')
			{
				ft.sStr = ft.sStr.erase(i, 1);
				iCharRemoved += 1;
			}
			else if (ft.sStr[i+1] == 'c')
			{
				ft.sStr = ft.sStr.erase(i, 10);
				iCharRemoved += 10;
			}
			else if (ft.sStr[i+1] == 'r')
			{
				ft.sStr = ft.sStr.erase(i, 2);
				iCharRemoved += 2;
			}

			i = ft.sStr.find_first_of('|', i+1);
		}

		int lastPos = ft.sBaseStr.length();

		// Then start creating formated strings
		if (iCharRemoved != 0)
		{
			int j = lastPos;
			if (ft.sStr[j] == '|')
			{
				ft.sStr += '|';
				j--;
			}

			i = ft.sBaseStr.find_last_of('|', j);

			while (i != ft.sBaseStr.npos)
			{
				if (ft.sBaseStr[i+1] == 'c')
				{
					FormatedString fs;

					// Read the color data
					string s = ft.sBaseStr.substr(i+2, 2);
					float a = HexToInt((char*)s.c_str());
					s = ft.sBaseStr.substr(i+4, 2);
					float r = HexToInt((char*)s.c_str());
					s = ft.sBaseStr.substr(i+6, 2);
					float g = HexToInt((char*)s.c_str());
					s = ft.sBaseStr.substr(i+8, 2);
					float b = HexToInt((char*)s.c_str());

					// And create a new formated string with this new color
					fs.dwColor = ARGB(a, r, g, b);
					fs.sStr = ft.sBaseStr.substr(i+10, lastPos-(i+10));

					Point p = GetCarretPos(lEquiv[i], ft.mFnt, ft.fW, ft.fH, ft.sStr);
					fs.fX = p.fX;
					fs.fY = p.fY;

					ft.lFStr.push_front(fs);

					lastPos = i;
				}
				else if (ft.sBaseStr[i+1] == 'r')
				{
					FormatedString fs;
					// Create a new formated string with the default color
					fs.dwColor = ft.dwColor;
					fs.sStr = ft.sBaseStr.substr(i+2, lastPos-(i+2));

					Point p = GetCarretPos(lEquiv[i], ft.mFnt, ft.fW, ft.fH, ft.sStr);
					fs.fX = p.fX;
					fs.fY = p.fY;

					ft.lFStr.push_front(fs);

					lastPos = i;
				}

				if (i != 0)
					i = ft.sBaseStr.find_last_of('|', i-1);
				else
					i = ft.sBaseStr.npos;
			}
		}

		if ( (lastPos != 0) || (ft.sStr.empty()) )
		{
			FormatedString fs;
			fs.dwColor = ft.dwColor;
			if (!ft.sStr.empty())
				fs.sStr = ft.sStr.substr(0, lastPos);
			else
				fs.sStr = "";
			fs.fX = 0;
			fs.fY = 0;

			ft.lFStr.push_front(fs);
		}
	}

	return ft;
}

void GUIManager::RegisterFunc( GUIElement* frame, int type, string funcText )
{
	funcText = "function _intFunc" + ToString(iFuncCount) + "()\n" + funcText;
	funcText += "\nend\n";
	funcText += "Functions[" + ToString(iFuncCount) + "] = _intFunc" + ToString(iFuncCount);
	int error = luaL_dostring(mSceneMgr->luaVM, funcText.c_str());
	if (error)
		LUA::LogL(mSceneMgr->luaVM);
	else
		frame->SetOnFunction(type, iFuncCount);

	iFuncCount++;
}

void GUIManager::UpdateScrollingMsgFrame(GUIElement* g)
{
	if (g->bReady)
	{
		bool bDebugThis = false;
		if (g->iBottomLine != g->iOldBottomLine)
		{
			// Raise the new fontstring object
			if (bDebugThis) Log("1 : %d", g->iBottomLine);
			GUIArt* aNew = g->lArtList[string("Msg") + ToString(g->iBottomLine)];
			aNew->lAnchorList[0].mParent = g;
			aNew->lAnchorList[0].iAnchorPt = GUI_ANCHOR_BOTTOMLEFT;
			aNew->lAnchorList[0].iRelativePt = GUI_ANCHOR_BOTTOMLEFT;
			aNew->lAnchorList[0].fX = g->iSMFInsL;
			aNew->lAnchorList[0].fY = g->iSMFInsB;
			aNew->fW = g->fW - g->iSMFInsR - g->iSMFInsL;

			TextBox tb = aNew->mText.mFnt->GetTextBox(aNew->fW, aNew->fH, aNew->mText.sStr.c_str());
			aNew->fH = tb.iLineNbr*tb.fLineHeight;

			// Move the previous one
			int iPrevN;
			if (g->iOldBottomLine == g->iMaxLines)
				iPrevN = 1;
			else
				iPrevN = g->iOldBottomLine+1;

			if (bDebugThis) Log("2 : %d, %d", g->iOldBottomLine, iPrevN);

			GUIArt* aOld = g->lArtList[string("Msg") + ToString(g->iOldBottomLine)];
			GUIArt* aPrev = g->lArtList[string("Msg") + ToString(iPrevN)];
			aOld->lAnchorList[0].mParent = aPrev;
			aOld->lAnchorList[0].iAnchorPt = GUI_ANCHOR_BOTTOMLEFT;
			aOld->lAnchorList[0].iRelativePt = GUI_ANCHOR_TOPLEFT;
			aOld->lAnchorList[0].fX = 0;
			aOld->lAnchorList[0].fY = 0;

			// Check top inset
			float fBX = -g->GetY() + g->iSMFInsT;
			GUIArt* aAdj = NULL;

			for (int i = 0; i < g->iMaxLines; i++)
			{
				int iArtN;
				if (g->iBottomLine-i < 1)
					iArtN = g->iMaxLines+g->iBottomLine-i;
				else
					iArtN = g->iBottomLine-i;
				aAdj = g->lArtList[string("Msg") + ToString(iArtN)];
				if (aAdj->mText.sStr == "<empty>")
					break;

				float fArtY = -aAdj->GetY();
				if (bDebugThis) Log(" 3 : %d, %f < %f ?", iArtN, fArtY, fBX);
				if (fArtY < fBX)
					break;
				else
					aAdj->bHidden = false; // We make sure it is shown
			}

			if (aAdj != NULL)
			{
				aAdj->bHidden = true;
			}

			g->iOldBottomLine = g->iBottomLine;

			if (bDebugThis) Log("4");

			g->RebuildCache();
		}
	}
}

void GUIManager::LoadUI( lua_State* luaVM )
{
	bool bDebugThis = false;
	XML::InitUI();

	if (bDebugThis) Log("1");

	for (char* c = hge->Resource_EnumFolders("Interface/BaseUI/*"); c != 0; c = hge->Resource_EnumFolders())
	{
		LoadAddOn(luaVM, c, "Interface/BaseUI/");
	}
	for (char* c = hge->Resource_EnumFolders("Interface/AddOns/*"); c != 0; c = hge->Resource_EnumFolders())
	{
		LoadAddOn(luaVM, c, "Interface/AddOns/");
	}

	if (bDebugThis) Log("2");

	map<string, GUIElement*>::iterator iterElem;
	for (iterElem = lGuiList.begin(); iterElem != lGuiList.end(); iterElem++)
	{
		GUIElement* g = iterElem->second;
		if (!g->bChild)
		{
			g->Init();

			map<string, GUIArt*>::iterator iter;
			for (iter = g->lArtList.begin(); iter != g->lArtList.end(); iter++)
			{
				GUIArt* a = iter->second;
				a->Init();
			}
		}
	}

	if (bDebugThis) Log("3");

	multimap<int, GUIElement*> lLevelMap;

	for (iterElem = lGuiList.begin(); iterElem != lGuiList.end(); iterElem++)
	{
		if (bDebugThis) Log("3.1 %s", iterElem->second->sName.c_str());
		if (!iterElem->second->bChild)
			iterElem->second->On(GUI_FUNC_LOAD);
		if (bDebugThis) Log("3.1.");

		lLevelMap.insert(make_pair(iterElem->second->GetChildLevel(), iterElem->second));
	}

	if (bDebugThis) Log("4");

	// Adjust cache from childs to parents, using the level map we built
	// just before to reduce the number of calls.
	multimap<int, GUIElement*>::iterator iterElem2 = lLevelMap.end();
	while (iterElem2 != lLevelMap.begin())
	{
		iterElem2--;
		iterElem2->second->AdjustCache(false);
	}

	if (bDebugThis) Log("5");

	// Load saved variables
	char* saved = hge->Resource_EnumFiles("Saves/AddOns/*");
	while (saved != 0)
	{
		string s = "Saves/AddOns/";
		string f = saved;
		if (f.find(".lua") != f.npos)
		{
			s += f;
			int error = luaL_dofile(luaVM, s.c_str());
			if (error) LUA::LogL(luaVM);
		}

		saved = hge->Resource_EnumFiles();
	}

	if (bDebugThis) Log("6");

	bRebuildGUIList = true;
}

void GUIManager::CloseUI( lua_State* luaVM )
{
	// Delete GUI elements
	map<string, GUIElement*>::iterator iterElem;
	for (iterElem = lGuiList.begin(); iterElem != lGuiList.end(); iterElem++)
	{
		iterElem->second->DeleteThis();
		delete iterElem->second;
	}
	for (iterElem = lTemplateList.begin(); iterElem != lTemplateList.end(); iterElem++)
	{
		iterElem->second->DeleteThis();
		delete iterElem->second;
	}

	// Clear lists
	lGuiList.clear();
	lParentList.clear();
	lTemplateList.clear();

	lua_register(luaVM, "sendString", l_SendString);
	lua_register(luaVM, "concTable", l_ConcTable);

	// Write saved variables
	map<string, AddOn>::iterator iterAddOn;
	for (iterAddOn = this->lAddOnList.begin(); iterAddOn != this->lAddOnList.end(); iterAddOn++)
	{
		AddOn* a = &iterAddOn->second;
		if (a->bEnabled)
		{
			if (!a->lSavedVariableList.empty())
			{
				string sfile = "Saves/AddOns/" + a->sName + ".lua";
				fstream file(sfile.c_str(), ios::out);
				file << "\n";
				vector<string>::iterator iterVar;
				for (iterVar = a->lSavedVariableList.begin(); iterVar != a->lSavedVariableList.end(); iterVar++)
				{
					string var = *iterVar;
					lua_getglobal(luaVM, var.c_str());
					int type = lua_type(luaVM, -1);
					if (type == LUA_TNUMBER)
					{
						file << var + " = " + ToString(lua_tonumber(luaVM, -1)) + ";\n";
					}
					else if (type == LUA_TNIL)
					{
						file << var + " = nil;\n";
					}
					else if (type == LUA_TBOOLEAN)
					{
						file << var + " = " + BToString(lua_toboolean(luaVM, -1)) + ";\n";
					}
					else if (type == LUA_TSTRING)
					{
						file << var + " = \"" + lua_tostring(luaVM, -1) + "\";\n";
					}
					else if (type == LUA_TTABLE)
					{
						mSceneMgr->sTmpString = "";
						string exec = "str = \"\";\nstr = concTable(str, \"" + var + "\");\n";
						luaL_dostring(luaVM, exec.c_str());

						string s = mSceneMgr->sTmpString;
						string tab = "	";
						file << var + " = {\n";
						int tableIndent = 1;
						bool tableEnded = false;
						int lineNbr = 0;
						while (!tableEnded)
						{
							if (lineNbr > 1000)
								break;

							if (tableIndent == -1)
							{
								tableEnded = true;
							}
							else
							{
								int i = s.find(" ");
								string k = s.substr(0, i);
								s.erase(0, i+1);
								if (k == "'end'")
								{
									tableIndent--;
									tab = tab.substr(0, tab.size()-4);
									if (tableIndent == -1)
										file << tab + "}\n";
									else
										file << tab + "},\n";
								}
								else
								{
									k = "[" + k + "]";

									i = s.find(" ");
									string v = s.substr(0, i);
									s.erase(0, i+1);

									int type;
									if (v == "'table'")
										type = LUA_TTABLE;
									else
									{
										type = LUA_TNUMBER;
										int j = v.find("\"");
										if (j != v.npos)
											type = LUA_TSTRING;
										j = v.find("'");
										if (j != v.npos)
										{
											type = LUA_TBOOLEAN;
											StrRemoveSurChar(&v, '\'');
										}
									}

									if (type == LUA_TNUMBER)
									{
										file << tab + k + " = " + v + ";\n";
									}
									else if (type == LUA_TNIL)
									{
										file << tab + k + " = nil;\n";
									}
									else if (type == LUA_TBOOLEAN)
									{
										file << tab + k + " = " + v + ";\n";
									}
									else if (type == LUA_TSTRING)
									{
										file << tab + k + " = " + v + ";\n";
									}
									else if (type == LUA_TTABLE)
									{
										file << tab + k + " = {\n";
										tab += "	";
									}
								}
							}
						}
					}
				}
				file.close();
			}
		}
	}

	// Write addons activation
	fstream file("Interface/AddOns.txt", ios::out);
	for (iterAddOn = this->lAddOnList.begin(); iterAddOn != this->lAddOnList.end(); iterAddOn++)
	{
		string s = iterAddOn->second.sName;
		if (s != "")
		{
			s += ": ";
			if (iterAddOn->second.bEnabled)
				s += "1\n";
			else
				s += "0\n";

			file << s;
		}
	}
	file.close();

    lAddOnList.clear();

	// Delete UI sprites
	vector<hgeSprite*>::iterator iter;
	while (!lGUIspriteList.empty())
	{
		iter = lGUIspriteList.begin();
		delete *iter;
		lGUIspriteList.erase(iter);
	}
}

lua_State* GUIManager::ReLoadUI( lua_State* luaVM )
{
	Log("Reloading UI...");

	Log(" Closing...");

	// Delete the UI
	CloseUI(luaVM);

	// Clear LUA
	lua_close(luaVM);

	Log(" Done.");
	Log(" Loading...");

	luaVM = lua_open();
	if (luaVM == NULL)
	{
		Log("# Error initializing lua.");
		return NULL;
	}
	LUA::OpenLibs(luaVM);

	LUA::RegisterAll(luaVM);

	lua_atpanic(luaVM, LUA::LogL);

	mSceneMgr->luaVM = luaVM;

	// Reload important LUA data
	iFuncCount = 1;
	int error = luaL_dofile(luaVM, "Scripts/config.lua");
	if (error) LUA::LogL(luaVM);

	error = luaL_dofile(luaVM, "Tables/buff_table.lua");
	if (error) LUA::LogL(luaVM);

	error = luaL_dofile(luaVM, "Tables/spell_scripts_table.lua");
	if (error) LUA::LogL(luaVM);

	error = luaL_dofile(luaVM, "Tables/spell_table.lua");
	if (error) LUA::LogL(luaVM);

	map<string, Spell>::iterator iterSpell;
	for (iterSpell = mUnitMgr->lSpellList.begin(); iterSpell != mUnitMgr->lSpellList.end(); iterSpell++)
	{
		mUnitMgr->ParseSpell(luaVM, iterSpell->second.sName, true);
	}

	error = luaL_dofile(luaVM, "Tables/item_table.lua");
	if (error) LUA::LogL(luaVM);

	mSceneMgr->sLocale = LUA::GetGlobalString("Game_locale");
	string strTableFile = "Tables/locale_" + mSceneMgr->sLocale + ".str";
	delete mSceneMgr->tStrTable;
	mSceneMgr->tStrTable = new hgeStringTable(strTableFile.c_str());

	mInputMgr->SetFocus(false);

	// Load the new UI
	LoadUI(luaVM);

	Log(" Done.");

	Log("Reloading UI : done.");

	return luaVM;
}

void GUIManager::LoadAddOn( lua_State* luaVM, string name, string folder )
{
	bool bDebugThis = false;

	if (bDebugThis) Log("1");

	if (this->lAddOnList[name].bEnabled)
	{
		if (bDebugThis) Log("2");
		AddOn a;
		AddOn* pa;
		a.bEnabled = true;
		a.sFolder = folder + name;
		string tocFile = a.sFolder + "/" + name + ".toc";
		if (bDebugThis) {Log(" Loading AddOn %s", name.c_str());}
		fstream file(tocFile.c_str(), ios::in);

		if (file.is_open())
		{
			if (bDebugThis) Log("3");
			char line[256];
			while (!file.eof())
			{
				if (bDebugThis) Log("3.1");
				file.getline(line, 256);
				if ( (line[0] == '#') && (line[1] == '#') )
				{
					if (bDebugThis) Log("3.1.1");
					string temp = line;
					temp = temp.substr(3);
					int i = temp.find(":");
					if (i != temp.npos)
					{
						if (bDebugThis) Log("3.1.2");
						string field = temp.substr(0, i);
						StrRemoveSurChar(&field, ' ');
						string value = temp.substr(i+1);
						StrRemoveSurChar(&value, ' ');
						if (field == "Interface")
						{
							value = value.substr(0, 4);
							value.insert(1, ".");
							a.fUIVersion = atof(value.c_str());

							if (a.fUIVersion >= mSceneMgr->fGameVersion)
								a.bEnabled = true;
							else
							{
								Log(" # Warning # : %s is too old. Disactivating.");
								a.bEnabled = false;
							}
						}
						else if (field == "Title")
						{
							a.sName = value;
						}
						else if (field == "Version")
						{
							a.sVersion = value;
						}
						else if (field == "Author")
						{
							a.sAuthor = value;
						}
						else if (field == "SavedVariables")
						{
							while (value != "")
							{
								int j = value.find(",");
								string variable;
								if (j == value.npos)
								{
									variable = value;
									a.lSavedVariableList.push_back(variable);
									value = "";
								}
								else
								{
									variable = value.substr(0, j);
									a.lSavedVariableList.push_back(variable);
									value = value.erase(0, j+1);
									StrRemoveSurChar(&value, ' ');
								}
							}
						}
					}
				}
				else
				{
					if (bDebugThis) Log("3.1.2");
					string temp = line;
					StrRemoveSurChar(&temp, ' ');
					int i = temp.find(".lua");
					int j = temp.find(".xml");
					if ( (i != temp.npos) || (j != temp.npos) )
					{
						a.lFileList.push_back(a.sFolder + "/" + temp);
					}
					if (bDebugThis) Log("3.1.3");
				}
			}

			if (bDebugThis) Log("4");

			file.close();

			if (a.sName == "")
				Log("# Error # : missing AddOn name in %s", tocFile.c_str());
			else if (this->lAddOnList[a.sName].bLoaded)
				Log("# Error # : duplicated AddOn name : %s", a.sName.c_str());
			else
			{
				if (bDebugThis) Log("5 : %d");
				this->lAddOnList[a.sName] = a;
				pa = &this->lAddOnList[a.sName];

				fstream file2("Interface/AddOns.txt", ios::in);
				if (file2.is_open())
				{
					if (bDebugThis) Log("6");
					char line[256];
					while (!file2.eof())
					{
						if (bDebugThis) Log("7");
						file2.getline(line, 256);
						string temp = line;
						int i = temp.find(":");
						if (i != temp.npos)
						{
							if (bDebugThis) Log("8");
							string field = temp.substr(0, i);
							StrRemoveSurChar(&field, ' ');
							string value = temp.substr(i+1);
							StrRemoveSurChar(&value, ' ');
							if (field == pa->sName)
							{
								if (bDebugThis) Log("9");
								if (value != string("1"))
								{
									pa->bEnabled = false;
								}
								break;
							}
						}
					}
					file2.close();
				}

				if (bDebugThis) Log("6");

				if (pa->bEnabled)
				{
					vector<string>::iterator iterFile;
					for (iterFile = pa->lFileList.begin(); iterFile != pa->lFileList.end(); iterFile++)
					{
						if (bDebugThis) Log("6.1 %s", iterFile->c_str());
						int i = iterFile->find(".lua");
						int j = iterFile->find(".xml");
						if (i != iterFile->npos)
						{
							if (FileExists(*iterFile))
							{
								int error = luaL_dofile(luaVM, iterFile->c_str());
								if (error) LUA::LogL(luaVM);
							}
							else
								Log("# Error # : couldn't find %s", iterFile->c_str());
						}
						else if (j != iterFile->npos)
						{
							if (FileExists(*iterFile))
							{
								TiXmlDocument doc(iterFile->c_str());
								if (!doc.LoadFile())
									Log("# XML : %s: %s", iterFile->c_str(), doc.ErrorDesc());
								else
								{
									XML::ParseUIFile(pa, doc);
								}
							}
							else
								Log("# Error # : couldn't find %s", iterFile->c_str());
						}
					}
				}

				if (bDebugThis) Log("7");

				pa->bLoaded = true;
			}
		}
	}

	if (bDebugThis) Log("8");
}

void GUIManager::UpdateUI()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->GetProfiler(8, "GUIManager::updateUI", false);
		Chrono c(prof);
	#endif

    if (mUnitMgr->mLeadingUnit == NULL)
    {
        lua_pushnil(mSceneMgr->luaVM);
        lua_setglobal(mSceneMgr->luaVM, "UNIT");
    }
    else
    {
        lua_pushnumber(mSceneMgr->luaVM, mUnitMgr->mLeadingUnit->GetID());
        lua_setglobal(mSceneMgr->luaVM, "UNIT");

        if (mUnitMgr->mLeadingUnit->GetTarget() == NULL)
            lua_pushnil(mSceneMgr->luaVM);
        else
            lua_pushnumber(mSceneMgr->luaVM, mUnitMgr->mLeadingUnit->GetTarget()->GetID());
        lua_setglobal(mSceneMgr->luaVM, "TARGET");
    }

	// Update the GUI...
	mSceneMgr->bMouseOverPlayField = true;
	map<string, GUIElement*>::iterator iterGUI;
	for (iterGUI = mGUIMgr->lGuiList.begin(); iterGUI != mGUIMgr->lGuiList.end(); iterGUI++)
	{
		GUIElement* g = iterGUI->second;
		if (g->IsVisible())
		{
			g->CheckInput(mInputMgr->fMX, mInputMgr->fMY, mInputMgr->iMLState, mInputMgr->iMRState);
			g->On(GUI_FUNC_UPDATE);
			if ( (g->iType == GUI_OBJECT_TYPE_EDITBOX) && HasFocus(g) )
			{
                g->UpdateCarret();
			}
		}
		else if ( (g->iType == GUI_OBJECT_TYPE_EDITBOX) && HasFocus(g) )
		{
		    LooseFocus(g);
		}
	}
	// Call events
	for (iterGUI = mGUIMgr->lGuiList.begin(); iterGUI != mGUIMgr->lGuiList.end(); iterGUI++)
	{
		GUIElement* g = iterGUI->second;
		if (g->IsVisible())
		{
			if (g->lFuncList.find(GUI_FUNC_EVENT) != g->lFuncList.end())
			{
				vector<Event>::iterator iterEvent;
				for (iterEvent = mGUIMgr->lEventList.begin(); iterEvent != mGUIMgr->lEventList.end(); iterEvent++)
				{
					if (g->lRegEventList.find(iterEvent->iID) != g->lRegEventList.end())
					{
						g->On(GUI_FUNC_EVENT, &(*iterEvent));
					}
				}
			}
		}
	}
	mGUIMgr->lEventList.clear();

	UpdateEditBox();

	if (mGUIMgr->bRebuildGUIList)
	{
		mGUIMgr->lSortedGUIList.clear();
		for (iterGUI = mGUIMgr->lGuiList.begin(); iterGUI != mGUIMgr->lGuiList.end(); iterGUI++)
		{
			GUIElement* g = iterGUI->second;
			if (g->IsVisible())
			{
				if (!g->bChild)
				{
					mGUIMgr->lSortedGUIList.insert(make_pair(g->iFrameStrata, g));
				}
			}
		}
		mGUIMgr->bRebuildGUIList = false;
	}

	// ... and the cache
	multimap<int, GUIElement*>::iterator iterGUI2;
	for (iterGUI2 = mGUIMgr->lSortedGUIList.begin(); iterGUI2 != mGUIMgr->lSortedGUIList.end(); iterGUI2++)
	{
		GUIElement* g = iterGUI2->second;
		g->Render(true);
	}
}

void GUIManager::FireEvent(Event event)
{
	if (!event.bCumulable)
	{
		bool bEventFired = false;
		vector<Event>::iterator iter;

		for (iter = lEventList.begin(); iter != lEventList.end(); iter++)
		{
			if (iter->iID == event.iID)
			{
				bEventFired = true;
				break;
			}
		}

		if (!bEventFired)
			lEventList.push_back(event);
	}
	else
		lEventList.push_back(event);
}

void GUIManager::RegisterEvents()
{
	lEventNToSMap[EVENT_CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS] = "CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS";
	lEventSToNMap["CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS"] = EVENT_CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS;

	lEventNToSMap[EVENT_CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMMAGE] = "CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMMAGE";
	lEventSToNMap["CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMMAGE"] = EVENT_CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMMAGE;

	lEventNToSMap[EVENT_CHAT_MSG_COMBAT_PARTY_HITS] = "CHAT_MSG_COMBAT_PARTY_HITS";
	lEventSToNMap["CHAT_MSG_COMBAT_PARTY_HITS"] = EVENT_CHAT_MSG_COMBAT_PARTY_HITS;

	lEventNToSMap[EVENT_CHAT_MSG_SPELL_PARTY_DAMAGE] = "CHAT_MSG_SPELL_PARTY_DAMAGE";
	lEventSToNMap["CHAT_MSG_SPELL_PARTY_DAMAGE"] = EVENT_CHAT_MSG_SPELL_PARTY_DAMAGE;

	lEventNToSMap[EVENT_CHAT_MSG_COMBAT_FRIENDLY_DEATH] = "CHAT_MSG_COMBAT_FRIENDLY_DEATH";
	lEventSToNMap["CHAT_MSG_COMBAT_FRIENDLY_DEATH"] = EVENT_CHAT_MSG_COMBAT_FRIENDLY_DEATH;

	lEventNToSMap[EVENT_CHAT_MSG_COMBAT_HOSTILE_DEATH] = "CHAT_MSG_COMBAT_HOSTILE_DEATH";
	lEventSToNMap["CHAT_MSG_COMBAT_HOSTILE_DEATH"] = EVENT_CHAT_MSG_COMBAT_HOSTILE_DEATH;
}

int GUIManager::ToEventNbr( string sEvent )
{
	int iEvent = 0;

	if (lEventSToNMap.find(sEvent) != lEventSToNMap.end())
		iEvent = lEventSToNMap[sEvent];

	return iEvent;
}

string GUIManager::ToEventName( int iEvent )
{
	string sEvent = "";

	if (lEventNToSMap.find(iEvent) != lEventNToSMap.end())
		sEvent = lEventNToSMap[iEvent];

	return sEvent;
}

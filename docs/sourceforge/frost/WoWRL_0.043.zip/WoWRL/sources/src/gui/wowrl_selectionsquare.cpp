/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*        SelectionSquare source          */
/*                                        */
/*  ## : ...                              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_global.h"
#include "wowrl_inputmanager.h"
#include "wowrl_unitmanager.h"
#include "wowrl_scenemanager.h"
#include "wowrl_model.h"

#include "wowrl_selectionsquare.h"

extern InputManager *mInputMgr;
extern UnitManager *mUnitMgr;
extern SceneManager *mSceneMgr;
extern HGE *hge;

using namespace std;

SelectionSquare::SelectionSquare()
{
	bActive = false;
	bRenderBg = false;

	mRect = new hgeRect();

	mBg.tex = 0;
	mBg.blend = BLEND_DEFAULT;
	mBg.v[0].col = mBg.v[1].col = mBg.v[2].col = mBg.v[3].col =
		ARGB(85, 0, 255, 0);

	mBorder.tex = 0;
	mBorder.blend = BLEND_DEFAULT;
	mBorder.v[0].col = mBorder.v[1].col = mBorder.v[2].col = mBorder.v[3].col =
		ARGB(255, 0, 255, 0);
}

bool SelectionSquare::IsActive()
{
	return bActive;
}

void SelectionSquare::Update()
{
	if ( (mInputMgr->iMLState == 1) &&
		 (!mUnitMgr->bCastingSpell) &&
		 (!mInputMgr->bLastDragged) &&
		 (mSceneMgr->bMouseOverPlayField) )
	{
		if (!bActive)
		{
			fX = mInputMgr->fGMX;
			fY = mInputMgr->fGMY;
			bActive = true;
			mUnitMgr->lTempSelectedList.empty();
			mUnitMgr->lTempSelectedList = map<int, Unit*>(mUnitMgr->lSelectedList);
		}

		if (bActive)
		{
			fW = (mInputMgr->fGMX-fX);
			fH = (mInputMgr->fGMY-fY);

			if ( (fX-mInputMgr->fGMX != 0.0f) && (fY-mInputMgr->fGMY != 0.0f) )
			{
				if (fW < 0.0f)
				{
					mRect->x1 = fX+mSceneMgr->fGX+fW;
					mRect->x2 = mRect->x1-fW;
				}
				else
				{
					mRect->x1 = fX+mSceneMgr->fGX;
					mRect->x2 = mRect->x1+fW;
				}
				if (fH < 0.0f)
				{
					mRect->y1 = fY+mSceneMgr->fGY+fH;
					mRect->y2 = mRect->y1-fH;
				}
				else
				{
					mRect->y1 = fY+mSceneMgr->fGY;
					mRect->y2 = mRect->y1+fH;
				}
				map<int, Unit*>::iterator iter;
				for (iter = mUnitMgr->lUnitList.begin(); iter != mUnitMgr->lUnitList.end(); iter++)
				{
					Unit *u = iter->second;
					if (!u->IsHostile())
					{
                        if (u->Intersects(mRect))
                        {
                            if (!u->IsSelected())
                            {
                                u->SetSelected(true);
                            }
                        }
                        else
                        {
                            if (u->IsSelected())
                            {
                                if (mInputMgr->bShiftPressed)
                                {
                                    if (mUnitMgr->lTempSelectedList.find(u->GetID()) == mUnitMgr->lTempSelectedList.end())
                                    {
                                        u->SetSelected(false);
                                    }
                                }
                                else
                                    u->SetSelected(false);
                            }
                        }
					}
				}
			}
			if (!mUnitMgr->lSelectedList.empty())
				mUnitMgr->bSelected = true;
			else
				mUnitMgr->bSelected = false;
		}
	}
	else if (mInputMgr->iMLState == 0)
		bActive = false;
}

void SelectionSquare::Render()
{
	if (bActive)
	{
		float x1 = fX+mSceneMgr->fGX;
		float y1 = fY+mSceneMgr->fGY;
		float x2 = fX+mSceneMgr->fGX+fW;
		float y2 = fY+mSceneMgr->fGY+fH;
		float insetSize = 1.0f;

		// Background
		mBg.v[0].x = x1; mBg.v[0].y = y1;
		mBg.v[1].x = x2; mBg.v[1].y = y1;
		mBg.v[2].x = x2; mBg.v[2].y = y2;
		mBg.v[3].x = x1; mBg.v[3].y = y2;
		hge->Gfx_RenderQuad(&mBg);

		// Left border
		mBorder.v[0].x = x1; mBorder.v[0].y = y1;
		mBorder.v[1].x = x1+SignOf(fW)*insetSize; mBorder.v[1].y = y1;
		mBorder.v[2].x = x1+SignOf(fW)*insetSize; mBorder.v[2].y = y2;
		mBorder.v[3].x = x1; mBorder.v[3].y = y2;
		hge->Gfx_RenderQuad(&mBorder);

		// Top border
		mBorder.v[0].x = x1; mBorder.v[0].y = y1;
		mBorder.v[1].x = x2; mBorder.v[1].y = y1;
		mBorder.v[2].x = x2; mBorder.v[2].y = y1+SignOf(fH)*insetSize;
		mBorder.v[3].x = x1; mBorder.v[3].y = y1+SignOf(fH)*insetSize;
		hge->Gfx_RenderQuad(&mBorder);

		// Right border
		mBorder.v[0].x = x2-SignOf(fW)*insetSize; mBorder.v[0].y = y1;
		mBorder.v[1].x = x2; mBorder.v[1].y = y1;
		mBorder.v[2].x = x2; mBorder.v[2].y = y2;
		mBorder.v[3].x = x2-SignOf(fW)*insetSize; mBorder.v[3].y = y2;
		hge->Gfx_RenderQuad(&mBorder);

		// Bottom border
		mBorder.v[0].x = x1; mBorder.v[0].y = y2-SignOf(fH)*insetSize;
		mBorder.v[1].x = x2; mBorder.v[1].y = y2-SignOf(fH)*insetSize;
		mBorder.v[2].x = x2; mBorder.v[2].y = y2;
		mBorder.v[3].x = x1; mBorder.v[3].y = y2;
		hge->Gfx_RenderQuad(&mBorder);
	}
}

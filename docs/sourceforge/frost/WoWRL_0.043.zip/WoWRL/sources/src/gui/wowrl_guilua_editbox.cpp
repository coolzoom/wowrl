/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_guimanager.h"

#include "wowrl_gui.h"

using namespace std;

extern GUIManager* mGUIMgr;
extern bool debugGUI;

GUI::EditBox::EditBox(lua_State* luaVM) : GUI::Frame(luaVM)
{
	sName = lua_tostring(luaVM, 1);
}

int GUI::EditBox::ClearFocus(lua_State* luaVM)
{
	mGUIMgr->LooseFocus(mBase);

	return 0;
}

int GUI::EditBox::GetText(lua_State* luaVM)
{
	if (mBase != NULL)
	{
		if (mBase->mCaptionFont != NULL)
		{
			lua_pushstring(luaVM, mBase->sEBText.c_str());
		}
		else
			lua_pushnil(luaVM);
	}
	else
		lua_pushnil(luaVM);

	return 1;
}

int GUI::EditBox::SetFocus(lua_State* luaVM)
{
	mGUIMgr->RequestFocus(mBase);

	return 0;
}

int GUI::EditBox::SetText(lua_State* luaVM)
{
	int error = 0;
	if ( (lua_gettop(luaVM) >= 1) && !lua_isstring(luaVM, 1) )
	{
		LUA::PrintError("Argument of EditBox:SetText must be a string (text)");
		error++;
	}

	if (error == 0)
	{
		string nstr;
		if (lua_gettop(luaVM) >= 1)
			nstr = lua_tostring(luaVM, 1);
		else
			nstr = "";

		if (mBase->sEBText != nstr)
		{
			mBase->sEBText = nstr;
			mBase->iCarretPos = mBase->sEBText.length();
			mGUIMgr->UpdateCarretPos(mBase);

			mBase->AdjustCache();
			mBase->RebuildCache();
		}
	}

	return 0;
}



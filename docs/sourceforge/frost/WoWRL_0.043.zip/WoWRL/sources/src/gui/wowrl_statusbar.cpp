/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Status bar source            */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Status bar class.              */
/*       A Status bar is used to display  */
/*	the health of a unit.				  */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge/hgesprite.h"

#include "wowrl_global.h"
#include "wowrl_structs.h"
#include "wowrl_unit.h"

#include "wowrl_statusbar.h"

StatusBar::StatusBar() : mBgLeft(NULL),
						 mBgMiddle(NULL),
						 mBgRight(NULL),
						 mGauge(NULL)

{
}

StatusBar::~StatusBar()
{
	if (mBgLeft != NULL) {delete mBgLeft;}
	if (mBgMiddle != NULL) {delete mBgMiddle;}
	if (mBgRight != NULL) {delete mBgRight;}
	if (mGauge != NULL) {delete mGauge;}
}

void StatusBar::Render()
{
	int fBX = ToInt(mParent->GetX()-fSize/2.0f);
	int fBY = ToInt(mParent->GetY()-mParent->GetRace()->fStatusBarYOffset*mParent->GetScale()-8);

	mGauge->SetColor(ARGB(200, cColor.fR, cColor.fG, cColor.fB));
	mGauge->RenderStretch(fBX+2, fBY+2, fBX+ceil((fSize-1)*fState), fBY+6);
	mBgLeft->Render(fBX, fBY);
	mBgRight->Render(ceil(fBX+fSize-3), fBY);
	mBgMiddle->RenderStretch(fBX+3, fBY, ceil(fBX+fSize-3), fBY+8);
}

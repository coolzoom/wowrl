/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_gui.h"
#include "wowrl_lua.h"

using namespace std;

extern HGE* hge;

GUI::Button::Button(lua_State* luaVM) : GUI::Frame(luaVM)
{
	sName = lua_tostring(luaVM, 1);
}

int GUI::Button::Disable(lua_State* luaVM)
{
	if (mBase != NULL)
	{
		if (!mBase->bButtonDisabled)
		{
			mBase->bButtonDisabled = true;

			if (mBase->bButtonTextureReady)
			{
				mBase->mTexNormal->bHidden = true;
				mBase->mTexHighlight->bHidden = true;
				mBase->mTexPushed->bHidden = true;
				mBase->mTexDisabled->bHidden = false;
			}

			if (mBase->bButtonFontReady)
			{
				mBase->mFontNormal->bHidden = true;
				mBase->mFontHighlight->bHidden = true;
				mBase->mFontDisabled->bHidden = false;
			}

			mBase->bMouseDown = false;

			mBase->RebuildCache();
		}
	}

	return 0;
}

int GUI::Button::Enable(lua_State* luaVM)
{
	if (mBase != NULL)
	{
		if (mBase->bButtonDisabled)
		{
			mBase->bButtonDisabled = false;

			if (mBase->bButtonTextureReady)
			{
				mBase->mTexHighlight->bHidden = true;
				mBase->mTexPushed->bHidden = true;
				mBase->mTexDisabled->bHidden = true;
				mBase->mTexNormal->bHidden = false;
			}

			if (mBase->bButtonFontReady)
			{
				mBase->mFontHighlight->bHidden = true;
				mBase->mFontDisabled->bHidden = true;
				mBase->mFontNormal->bHidden = false;
			}

			mBase->RebuildCache();
		}
	}

	return 0;
}

int GUI::Button::GetButtonState(lua_State* luaVM)
{
	if (mBase != NULL)
	{
		if (mBase->iButtonState == GUI_BUTTON_STATE_NORMAL)
			lua_pushstring(luaVM, "NORMAL");
		else
			lua_pushstring(luaVM, "PUSHED");
	}

	return 1;
}

int GUI::Button::IsEnabled(lua_State* luaVM)
{
	if (mBase != NULL)
		lua_pushboolean(luaVM, !mBase->bButtonDisabled);
	return 1;
}

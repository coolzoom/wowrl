/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_guimanager.h"
#include "wowrl_gfxmanager.h"

#include "wowrl_gui.h"

using namespace std;

extern GUIManager *mGUIMgr;
extern GFXManager *mGFXMgr;
extern HGE* hge;
extern bool debugGUI;

GUI::Frame::Frame(lua_State* luaVM) : GUI::Region(luaVM)
{
	sName = lua_tostring(luaVM, 1);
	mBase = NULL;
}

int GUI::Frame::_init(lua_State* luaVM)
{
	if (sName != "")
	{
		if (mGUIMgr->lGuiList.find(sName) != mGUIMgr->lGuiList.end())
		{
			mBase = mGUIMgr->lGuiList[sName];
			mRBase = mBase;
			mEBase = mBase;
		}
	}

	return 0;
}

int GUI::Frame::GetBackdrop(lua_State* luaVM)
{
	/* Creates a tables containing backdrop informations :
	/* {
	/*    ["bgFile"]
	/*    ["edgeFile"]
	/*    ["tile"]
	/*    ["tileSize"]
	/*    ["edgeSize"]
	/*    ["insets"] = {
	/*         ["left"]
	/*         ["right"]
	/*         ["top"]
	/*         ["bottom"]
	/*    },
	/* },
	*/
	if (mBase != NULL)
	{
		if (mBase->bUseBackdrop)
		{
			Backdrop* b = &mBase->mBackdrop;
			lua_createtable(luaVM, 3, 3);
			LUA::SetFieldString("bgFile", b->sBgFile, luaVM);
			LUA::SetFieldString("edgeFile", b->sEdgeFile, luaVM);
			LUA::SetFieldBool("tile", b->bTile, luaVM);
			LUA::SetFieldFloat("tileSize", b->fTileSize, luaVM);
			LUA::SetFieldFloat("edgeSize", b->fEdgeSize, luaVM);
			lua_pushstring(luaVM, "insets");
			lua_createtable(luaVM, 0, 4);
			LUA::SetFieldFloat("left", b->fInsL, luaVM);
			LUA::SetFieldFloat("right", b->fInsR, luaVM);
			LUA::SetFieldFloat("top", b->fInsT, luaVM);
			LUA::SetFieldFloat("bottom", b->fInsB, luaVM);
			lua_settable(luaVM, -3);
		}
		else
			lua_pushnil(luaVM);
	}

	return 1;
}

int GUI::Frame::SetBackdrop(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		LUA::PrintError("Too few argument in \"Frame:SetBackdrop\" (one expected : backdrop table)");
		return 0;
	}
	else if ( !lua_istable(luaVM, 1) && !lua_isnil(luaVM, 1) )
	{
		LUA::PrintError("Argument of StatusBar:SetBackdrop must be a table (or nil) (backdrop table)");
		error++;
	}

	if (error == 0)
	{
		if (mBase != NULL)
		{
			if (lua_isnil(luaVM, 1))
			{
				mBase->bUseBackdrop = false;
			}
			else
			{
				lua_settop(luaVM, 1); // Remove possible junk

				Backdrop bd;

				if (mBase->bUseBackdrop)
				{
					hge->Target_Free(mBase->mBackdrop.mTarget);
					delete mBase->mBackdrop.mSpr;

					bd.dwBgColor = mBase->mBackdrop.dwBgColor;
					bd.dwEdgeColor = mBase->mBackdrop.dwEdgeColor;
					bd.bBgReadyC = mBase->mBackdrop.bBgReadyC;
				}
				else
				{
					bd.dwBgColor = ARGB(255,255,255,255);
					bd.dwEdgeColor = ARGB(255,255,255,255);
					bd.bBgReadyC = false;
				}

				bd.sBgFile = LUA::GetFieldString("bgFile", false, "", false, luaVM);
				bd.sEdgeFile = LUA::GetFieldString("edgeFile", false, "", false, luaVM);
				bd.bTile = LUA::GetFieldBool("tile", false, false, false, luaVM);
				bd.fTileSize = LUA::GetFieldFloat("tileSize", false, -1, false, luaVM);
				bd.fEdgeSize = LUA::GetFieldFloat("edgeSize", false, -1, false, luaVM);

				lua_getfield(luaVM, 1, "insets");
				bd.fInsL = LUA::GetFieldFloat("left", false, 0, false, luaVM);
				bd.fInsR = LUA::GetFieldFloat("right", false, 0, false, luaVM);
				bd.fInsT = LUA::GetFieldFloat("top", false, 0, false, luaVM);
				bd.fInsB = LUA::GetFieldFloat("bottom", false, 0, false, luaVM);

				// Create edges
				if (bd.sEdgeFile != "")
				{
					HTEXTURE tex1 = mGFXMgr->LoadTexture(bd.sEdgeFile, false);
					float size = (int)floor(hge->Texture_GetWidth(tex1, true)/8.0f);
					if (mBase->bUseBackdrop && mBase->mBackdrop.bEdgeReady)
					{
						delete mBase->mBackdrop.mEdgeL;
						delete mBase->mBackdrop.mEdgeR;
						delete mBase->mBackdrop.mEdgeT;
						delete mBase->mBackdrop.mEdgeB;
						delete mBase->mBackdrop.mCornerTL;
						delete mBase->mBackdrop.mCornerTR;
						delete mBase->mBackdrop.mCornerBL;
						delete mBase->mBackdrop.mCornerBR;
					}
					bd.mEdgeL = new hgeSprite(tex1, 0, 0, size, size);
					bd.mEdgeR = new hgeSprite(tex1, size, 0, size, size);
					bd.mEdgeT = new hgeSprite(tex1, 2*size, 0, size, size);
					bd.mEdgeB = new hgeSprite(tex1, 3*size, 0, size, size);
					bd.mCornerTL = new hgeSprite(tex1, 4*size, 0, size, size);
					bd.mCornerTR = new hgeSprite(tex1, 5*size, 0, size, size);
					bd.mCornerBL = new hgeSprite(tex1, 6*size, 0, size, size);
					bd.mCornerBR = new hgeSprite(tex1, 7*size, 0, size, size);
					bd.fEdgeOriginalSize = size;
					if (bd.fEdgeSize == -1)
						bd.fEdgeSize = bd.fEdgeOriginalSize;
					bd.bEdgeReady = true;
				}
				else
					bd.bEdgeReady = false;

				// Create background
				if (bd.sBgFile != "")
				{
					HTEXTURE tex2;
					tex2 = mGFXMgr->LoadTexture(bd.sBgFile, false);

					bd.fBgW = hge->Texture_GetWidth(tex2, true);
					bd.fBgH = hge->Texture_GetHeight(tex2, true);

					if (mBase->bUseBackdrop && mBase->mBackdrop.bBgReady)
						delete mBase->mBackdrop.mBackground;
					if (bd.bTile)
						bd.mBackground = new hgeSprite(tex2, 0, 0, mBase->fW-bd.fInsL-bd.fInsR, mBase->fH-bd.fInsT-bd.fInsB);
					else
						bd.mBackground = new hgeSprite(tex2, 0, 0, bd.fBgW, bd.fBgH);

					bd.bBgReady = true;
				}
				else
					bd.bBgReady = false;

				bd.mTarget = hge->Target_Create(ToInt(mBase->fW), ToInt(mBase->fH), false);
				bd.mSpr = new hgeSprite(hge->Target_GetTexture(bd.mTarget), 0, 0, ToInt(mBase->fW), ToInt(mBase->fH));

				mBase->mBackdrop = bd;
				mBase->bUseBackdrop = true;

				mBase->RebuildCache();
				mBase->bRebuildBackdrop = true;
			}
		}
	}

	return 0;
}

int GUI::Frame::SetBackdropColor(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 3)
	{
		LUA::PrintError("Too few argument in \"Frame:SetBackdropColor\" (3 or 4 expected : red, green, blue (+alpha))");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of Frame:SetBackdropColor must be a number (red)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of Frame:SetBackdropColor must be a number (green)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of Frame:SetBackdropColor must be a number (blue)");
		error++;
	}
	if ( (lua_gettop(luaVM) >= 4) && (!lua_isnumber(luaVM, 4)) )
	{
		LUA::PrintError("Argument 4 of Frame:SetBackdropColor must be a number (alpha)");
		error++;
	}

	if (error == 0)
	{
		if (mBase != NULL)
		{
			if (mBase->bUseBackdrop)
			{
				float a, r, g, b;
				r = lua_tonumber(luaVM, 1);
				g = lua_tonumber(luaVM, 2);
				b = lua_tonumber(luaVM, 3);
				if (lua_gettop(luaVM) >= 4)
					a = lua_tonumber(luaVM, 4);
				else
					a = 1.0f;

				DWORD color = ARGB(a*255, r*255, g*255, b*255);

				if ( (mBase->mBackdrop.dwBgColor != color) || !mBase->mBackdrop.bBgReadyC )
				{
					mBase->mBackdrop.dwBgColor = color;
					mBase->RebuildCache();
					mBase->bRebuildBackdrop = true;
					mBase->mBackdrop.bBgReadyC = true;
				}
			}
		}
	}
	return 0;
}

int GUI::Frame::RegisterEvent(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		LUA::PrintError("Too few argument in \"Frame:RegisterEvent\" (one expected : event name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		LUA::PrintError("Argument of Frame:RegisterEvent must be a string (event name)");
		error++;
	}

	if (error == 0)
	{
		if (mBase != NULL)
		{
			int iEvent = mGUIMgr->ToEventNbr(lua_tostring(luaVM, 1));
			mBase->lRegEventList[iEvent] = true;
		}
	}

	return 0;
}

int GUI::Frame::UnregisterAllEvents(lua_State* luaVM)
{
	if (mBase != NULL)
		mBase->lRegEventList.clear();

	return 0;
}

int GUI::Frame::UnregisterEvent(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		LUA::PrintError("Too few argument in \"Frame:UnregisterEvent\" (one expected : event name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		LUA::PrintError("Argument of Frame:UnregisterEvent must be a string (event name)");
		error++;
	}

	if (error == 0)
	{
		if (mBase != NULL)
		{
			int iEvent = mGUIMgr->ToEventNbr(lua_tostring(luaVM, 1));
			mBase->lRegEventList[iEvent] = false;
		}
	}

	return 0;
}

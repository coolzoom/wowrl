/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_gui.h"
#include "wowrl_guimanager.h"
#include "wowrl_lua.h"
#include "wowrl_global.h"

using namespace std;

extern GUIManager* mGUIMgr;
extern HGE* hge;

GUI::ScrollingMessageFrame::ScrollingMessageFrame(lua_State* luaVM) : GUI::Frame(luaVM)
{
	sName = lua_tostring(luaVM, 1);
}

void SetAtTop(GUIElement* mBase)
{
	// Check if the frame is at top
	int iNewN;
	if (mBase->iBottomLine == 1)
		iNewN = mBase->iMaxLines;
	else
		iNewN = mBase->iBottomLine-1;

	if (iNewN != mBase->iActualLine) // Necessary ?
	{
		bool bEmptyLine = false;
		float fBY = -mBase->GetY() + mBase->iSMFInsT;
		int iPrevAct = mBase->iActualLine;
		if (iPrevAct == 1)
			iPrevAct = mBase->iMaxLines;
		else
			iPrevAct--;

		// Check if there is no empty lines
		for (int i = 0; i < mBase->iMaxLines; i++)
		{
			int iArtN;
			if (iNewN-i < 1)
				iArtN = mBase->iMaxLines+iNewN-i;
			else
				iArtN = iNewN-i;

			GUIArt* aAdj = mBase->lArtList[string("Msg") + ToString(iArtN)];
			if (aAdj->mText.sStr == "<empty>")
			{
				bEmptyLine = true;
				break;
			}
			// Stop the search if the last message is found...
			if (iArtN == iPrevAct)
			{
				bEmptyLine = true;
				break;
			}
			// ... or if the top of the frame is reached
			float fArtY = -aAdj->GetY();
			if (fArtY < fBY)
				break;
		}

		if (!bEmptyLine)
			mBase->bAtTop = false;
		else
			mBase->bAtTop = true;
	}
}

int GUI::ScrollingMessageFrame::AddMessage(lua_State* luaVM)
{
	int error = 0;
	if ( (lua_gettop(luaVM) >= 1) && !lua_isstring(luaVM, 1) )
	{
		LUA::PrintError("Argument of ScrollingMessageFrame:AddMessage must be a string (message)");
		error++;
	}

	if (error == 0)
	{
		string nstr;
		if (lua_gettop(luaVM) >= 1)
			nstr = lua_tostring(luaVM, 1);
		else
			nstr = "";

		GUIArt* aNew = mBase->lArtList[string("Msg") + ToString(mBase->iActualLine)];
		aNew->mText.sStr = nstr;
		aNew->mText.fW = mBase->fW - mBase->iSMFInsR - mBase->iSMFInsL;
		aNew->mText = mGUIMgr->ParseFormatedText(aNew->mText);

		mBase->iActualLine++;
		if (mBase->iActualLine > mBase->iMaxLines)
			mBase->iActualLine = 1;

		if (mBase->iBottomLine == mBase->iActualLine);
		{
			mBase->iOldBottomLine = mBase->iBottomLine;
			mBase->iBottomLine++;
			if (mBase->iBottomLine > mBase->iMaxLines)
				mBase->iBottomLine = 1;
		}

		SetAtTop(mBase);

		mGUIMgr->UpdateScrollingMsgFrame(mBase);
	}

	return 0;
}

int GUI::ScrollingMessageFrame::AtBottom(lua_State* luaVM)
{
	if (mBase != NULL)
		lua_pushboolean(luaVM, mBase->bAtBottom);

	return 1;
}

int GUI::ScrollingMessageFrame::AtTop(lua_State* luaVM)
{
	if (mBase != NULL)
		lua_pushboolean(luaVM, mBase->bAtTop);

	return 1;
}

int GUI::ScrollingMessageFrame::ScrollDown(lua_State* luaVM)
{
	int iNewN;
	if (mBase->iBottomLine == mBase->iMaxLines)
		iNewN = 1;
	else
		iNewN = mBase->iBottomLine+1;

	if (iNewN != mBase->iActualLine)
	{
		mBase->iBottomLine = iNewN;

		// Check if the frame is at iBottom
		if (iNewN == mBase->iMaxLines)
			iNewN = 1;
		else
			iNewN = iNewN+1;

		if (iNewN != mBase->iActualLine)
			mBase->bAtBottom = false;
		else
			mBase->bAtBottom = true;
	}
	else
		mBase->bAtBottom = true;

	SetAtTop(mBase);

	mGUIMgr->UpdateScrollingMsgFrame(mBase);

	return 0;
}

int GUI::ScrollingMessageFrame::ScrollToBottom(lua_State* luaVM)
{
	mBase->iBottomLine = mBase->iActualLine;
	if (mBase->iBottomLine == 1)
		mBase->iBottomLine = mBase->iMaxLines;
	else
		mBase->iBottomLine = mBase->iBottomLine-1;

	mBase->bAtBottom = true;

	SetAtTop(mBase);

	mGUIMgr->UpdateScrollingMsgFrame(mBase);

	return 0;
}

int GUI::ScrollingMessageFrame::ScrollToTop(lua_State* luaVM)
{
	// Not the best method, for sure, but it works
	int iOld = mBase->iBottomLine;
	ScrollUp(luaVM);
	while (iOld != mBase->iBottomLine)
	{
		iOld = mBase->iBottomLine;
		ScrollUp(luaVM);
	}

	mBase->bAtTop = true;

	return 0;
}

int GUI::ScrollingMessageFrame::ScrollUp(lua_State* luaVM)
{
	int iNewN;
	if (mBase->iBottomLine == 1)
		iNewN = mBase->iMaxLines;
	else
		iNewN = mBase->iBottomLine-1;

	if (iNewN != mBase->iActualLine) // Necessary ?
	{
		bool bEmptyLine = false;
		float fBY = -mBase->GetY() + mBase->iSMFInsT;
		int iPrevAct = mBase->iActualLine;
		if (iPrevAct == 1)
			iPrevAct = mBase->iMaxLines;
		else
			iPrevAct--;

		// Check if there is no empty lines
		for (int i = 0; i < mBase->iMaxLines; i++)
		{
			int iArtN;
			if (iNewN-i < 1)
				iArtN = mBase->iMaxLines+iNewN-i;
			else
				iArtN = iNewN-i;

			GUIArt* aAdj = mBase->lArtList[string("Msg") + ToString(iArtN)];
			if (aAdj->mText.sStr == "<empty>")
			{
				mBase->bAtTop = true;
				bEmptyLine = true;
				break;
			}
			// Stop the search if the last message is found...
			if (iArtN == iPrevAct)
			{
				mBase->bAtTop = true;
				bEmptyLine = true;
				break;
			}
			// ... or if the top of the frame is reached
			float fArtY = -aAdj->GetY();
			if (fArtY < fBY)
				break;
		}

		if (!bEmptyLine)
		{
			mBase->iBottomLine = iNewN;
			mBase->bAtBottom = false;

			SetAtTop(mBase);
		}
	}

	mGUIMgr->UpdateScrollingMsgFrame(mBase);

	return 0;
}

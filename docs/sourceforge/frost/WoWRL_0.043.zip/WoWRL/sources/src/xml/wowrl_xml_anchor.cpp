/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_guimanager.h"
#include "wowrl_global.h"

#include "wowrl_xml.h"

using namespace std;

extern GUIManager* mGUIMgr;
extern HGE* hge;
extern bool debugXML;

void XML::ParseAnchor( TiXmlNode* node, GUIBase* parent )
{
	/* [#] This function parses an Anchor object in an XML file.
	/* An Anchor must be contained in another object, such as a Frame or a Texture.
	*/
	if (debugXML) {Log("7");}
	TiXmlNode* node2 = node->FirstChild();
	if (node2)
	{
		if (string(node2->Value()) == string("Anchor"))
		{
			Anchor a;
			TiXmlElement* elem = node2->ToElement();
			for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
			{
				if (string(attr->Name()) == string("point"))
				{
					if (string(attr->Value()) == string("TOPLEFT"))
						a.iAnchorPt = GUI_ANCHOR_TOPLEFT;
					else if (string(attr->Value()) == string("TOP"))
						a.iAnchorPt = GUI_ANCHOR_TOP;
					else if (string(attr->Value()) == string("TOPRIGHT"))
						a.iAnchorPt = GUI_ANCHOR_TOPRIGHT;
					else if (string(attr->Value()) == string("RIGHT"))
						a.iAnchorPt = GUI_ANCHOR_RIGHT;
					else if (string(attr->Value()) == string("BOTTOMRIGHT"))
						a.iAnchorPt = GUI_ANCHOR_BOTTOMRIGHT;
					else if (string(attr->Value()) == string("BOTTOM"))
						a.iAnchorPt = GUI_ANCHOR_BOTTOM;
					else if (string(attr->Value()) == string("BOTTOMLEFT"))
						a.iAnchorPt = GUI_ANCHOR_BOTTOMLEFT;
					else if (string(attr->Value()) == string("LEFT"))
						a.iAnchorPt = GUI_ANCHOR_LEFT;
					else if (string(attr->Value()) == string("CENTER"))
						a.iAnchorPt = GUI_ANCHOR_CENTER;
				}
				else if (string(attr->Name()) == string("relativeTo"))
				{
					a.sParentName = attr->Value();
				}
				else if (string(attr->Name()) == string("relativePoint"))
				{
					if (string(attr->Value()) == string("TOPLEFT"))
						a.iRelativePt = GUI_ANCHOR_TOPLEFT;
					else if (string(attr->Value()) == string("TOP"))
						a.iRelativePt = GUI_ANCHOR_TOP;
					else if (string(attr->Value()) == string("TOPRIGHT"))
						a.iRelativePt = GUI_ANCHOR_TOPRIGHT;
					else if (string(attr->Value()) == string("RIGHT"))
						a.iRelativePt = GUI_ANCHOR_RIGHT;
					else if (string(attr->Value()) == string("BOTTOMRIGHT"))
						a.iRelativePt = GUI_ANCHOR_BOTTOMRIGHT;
					else if (string(attr->Value()) == string("BOTTOM"))
						a.iRelativePt = GUI_ANCHOR_BOTTOM;
					else if (string(attr->Value()) == string("BOTTOMLEFT"))
						a.iRelativePt = GUI_ANCHOR_BOTTOMLEFT;
					else if (string(attr->Value()) == string("LEFT"))
						a.iRelativePt = GUI_ANCHOR_LEFT;
					else if (string(attr->Value()) == string("CENTER"))
						a.iRelativePt = GUI_ANCHOR_CENTER;
				}
			}

			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("Offset"))
				{
					TiXmlNode* node4 = node3->FirstChild();
					if (node4)
					{
						if (string(node4->Value()) == string("AbsDimension"))
						{
							TiXmlElement* elem = node4->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("x"))
								{
									a.fX = atof(attr->Value());
								}
								else if (string(attr->Name()) == string("y"))
								{
									a.fY = atof(attr->Value());
								}
							}
						}
					}
				}
			}

			bool newAnchor = true;

			if (parent->bVirt)
			{
				if (a.sParentName == "")
				{
					if (parent->mParent != NULL)
					{
						a.mParent = parent->mParent;
						a.sParentName = "$parent";
					}
				}
				else
				{
					if (mGUIMgr->lGuiList.find(a.sParentName) != mGUIMgr->lGuiList.end())
					{
						a.mParent = mGUIMgr->lGuiList[a.sParentName];
					}
					else
					{
						GUIBase* hparent = parent->GetHighestVirtParent();
						string tpname = a.sParentName;
						int i = tpname.find("$parent");
						if (i != tpname.npos)
						{
							tpname = tpname.erase(i, 7);
							if (parent->mParent != NULL)
								tpname.insert(i, parent->mParent->sVName);
						}
						if (hparent->lParentList.find(tpname) != hparent->lParentList.end())
						{
							a.mParent = hparent->lParentList[tpname];
						}
						else
						{
							newAnchor = false;
							Log("# XML Error # : unknown parent %s\n# Listing %s parents :", tpname.c_str(), hparent->sVName.c_str());
							map<string, GUIBase*>::iterator iter;
							for (iter = hparent->lParentList.begin(); iter != hparent->lParentList.end(); iter++)
							{
								Log("   - %s", iter->first.c_str());
							}
						}
					}
				}
			}
			else
			{
				if (a.sParentName == "")
				{
					if (parent->mParent != NULL)
					{
						a.mParent = parent->mParent;
						a.sParentName = parent->mParent->sName;
					}
				}
				else
				{
					int i = a.sParentName.find("$parent");
					if (i != a.sParentName.npos)
					{
						a.sParentName = a.sParentName.erase(i, 7);
						if (parent != NULL)
						{
							if (parent->mParent != NULL)
								a.sParentName.insert(i, parent->mParent->sName);
						}
					}
					/*if (mGUIMgr->lGuiList.find(a.sParentName) != mGUIMgr->lGuiList.end())
					{
						a.mParent = &mGUIMgr->lGuiList[a.sParentName];
					}*/
					if (mGUIMgr->lParentList.find(a.sParentName) != mGUIMgr->lParentList.end())
					{
						a.mParent = mGUIMgr->lParentList[a.sParentName];
					}
					else
					{
						newAnchor = false;
						Log("# XML Error # : unknown parent %s", a.sParentName.c_str());
					}
				}
			}

			parent->lAnchorList[parent->lAnchorList.size()] = a;
		}
	}
	if (debugXML) {Log("8");}
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_scenemanager.h"
#include "wowrl_fontmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_global.h"

#include "wowrl_xml.h"

using namespace std;

extern SceneManager* mSceneMgr;
extern FontManager* mFontMgr;
extern GUIManager* mGUIMgr;
extern HGE* hge;
extern bool debugXML;

void XML::ParseString( TiXmlNode* node, GUIElement* parent, int layer, int type )
{
	/* [#] This function parses a FontString object in an XML file. A FontString
	/* is basicaly a tool to display some text. You can display as many lines as
	/* you want, except if a text box is defined. A FontString object must be
	/* contained in a Frame (or one of its derivation).
	*/
	bool bDebugThis = false;
	if (debugXML) {Log("5");}
	if (bDebugThis) Log("0");
	GUIArt* a = new GUIArt();
	a->sName = "";
	a->iLayer = layer;
	a->mParent = parent;
	a->bVirt = parent->bVirt;
	a->iType = type;
	a->fW = parent->fW;
	a->fH = parent->fH;
	FormatedText text;
	text.iFntSize = 16;
	text.bShadow = false;
	text.iOutline = 0;
	text.iAlign = HGETEXT_LEFT | HGETEXT_TOP;
	text.sStr = "";
	text.fW = parent->fW;
	text.fH = parent->fH;
	float space = 0.0f;
	int size = 0;
	string font = "";
	if (bDebugThis) Log("0.");

	TiXmlElement* elem = node->ToElement();
	for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
	{
		if (bDebugThis) Log("1.1 : %s", attr->Name());
		if (string(attr->Name()) == string("name"))
		{
			a->sName = attr->Value();
		}
		else if (string(attr->Name()) == string("font"))
		{
			font = attr->Value();
		}
		else if (string(attr->Name()) == string("outline"))
		{
			if (string(attr->Value()) == string("THIN"))
				text.iOutline = 1;
			else if (string(attr->Value()) == string("NORMAL"))
				text.iOutline = 2;
			else if (string(attr->Value()) == string("THICK"))
				text.iOutline = 3;
		}
		else if ((string(attr->Name()) == string("text")) &&
			     (type != GUI_OBJECT_TYPE_FEDITBOX) &&
		         (type != GUI_OBJECT_TYPE_FSMSGFRAME))
			text.sStr = attr->Value();
		else if ((string(attr->Name()) == string("justifyH")) &&
		         (type != GUI_OBJECT_TYPE_FSMSGFRAME))
		{
			if (string(attr->Value()) == string("LEFT"))
				text.iAlign = HGETEXT_LEFT | HGETEXT_TOP;
			else if (string(attr->Value()) == string("CENTER"))
				text.iAlign = HGETEXT_CENTER | HGETEXT_TOP;
			else if (string(attr->Value()) == string("RIGHT"))
				text.iAlign = HGETEXT_RIGHT | HGETEXT_TOP;
		}
		else if (string(attr->Name()) == string("spacing"))
			space = atof(attr->Value());
	}

	for (TiXmlNode* node2 = node->FirstChild(); node2; node2 = node2->NextSibling())
	{
		if (bDebugThis) Log("1.2 : %s", node2->Value());
		if ((string(node2->Value()) == string("Size")) &&
			(type != GUI_OBJECT_TYPE_FEDITBOX) &&
			(type != GUI_OBJECT_TYPE_FSMSGFRAME))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsDimension"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("x"))
						{
							a->fW = atof(attr->Value());
							text.fW = a->fW;
						}
						else if (string(attr->Name()) == string("y"))
						{
							a->fH = atof(attr->Value());
							text.fH = a->fH;
						}
					}
				}
			}
		}
		else if ((string(node2->Value()) == string("Anchors")) &&
		         (type != GUI_OBJECT_TYPE_FEDITBOX) &&
		         (type != GUI_OBJECT_TYPE_FSMSGFRAME))
		{
			XML::ParseAnchor(node2, a);
		}
		else if (string(node2->Value()) == string("FontHeight"))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsValue"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("val"))
						{
							text.iFntSize = atoi(attr->Value());
						}
					}
				}
			}
		}
		else if (string(node2->Value()) == string("Color"))
		{
			float r, g, b = 0.0f;
			float al = 255.0f;
			TiXmlElement* elem = node2->ToElement();
			for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
			{
				if (string(attr->Name()) == string("r"))
					r = 255.0f*atof(attr->Value());
				else if (string(attr->Name()) == string("g"))
					g = 255.0f*atof(attr->Value());
				else if (string(attr->Name()) == string("b"))
					b = 255.0f*atof(attr->Value());
				else if (string(attr->Name()) == string("a"))
					al = 255.0f*atof(attr->Value());
			}
			text.dwColor = ARGB(al, r, g, b);
		}
		else if (string(node2->Value()) == string("Shadow"))
		{
			text.bShadow = true;
			for (TiXmlNode* node3 = node2->FirstChild(); node3; node3 = node3->NextSibling())
			{
				if (string(node3->Value()) == string("Offset"))
				{
					TiXmlNode* node4 = node3->FirstChild();
					if (node4)
					{
						if (string(node4->Value()) == string("AbsDimension"))
						{
							TiXmlElement* elem = node4->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("x"))
								{
									text.fSOffX = atof(attr->Value());
								}
								else if (string(attr->Name()) == string("y"))
								{
									text.fSOffY = atof(attr->Value());
								}
							}
						}
					}
				}
				else if (string(node3->Value()) == string("Color"))
				{
					float r, g, b = 0.0f;
					float al = 255.0f;
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("r"))
							r = 255.0f*atof(attr->Value());
						else if (string(attr->Name()) == string("g"))
							g = 255.0f*atof(attr->Value());
						else if (string(attr->Name()) == string("b"))
							b = 255.0f*atof(attr->Value());
						else if (string(attr->Name()) == string("a"))
							al = 255.0f*atof(attr->Value());
					}
					text.dwSColor = ARGB(al, r, g, b);
				}
			}
		}
	}

	if (bDebugThis) Log("2");

	a->mText = text;

	if (a->iType == GUI_OBJECT_TYPE_FEDITBOX)
		a->sName = "$parent_EBText";
	else if (a->iType == GUI_OBJECT_TYPE_FSMSGFRAME)
		a->sName = "$parent_MSGText";
	else if (a->iType == GUI_OBJECT_TYPE_FNBUTTON)
	{
		a->sName = "$parent_NormalText";
		a->bHidden = false;
		a->mText.sStr = parent->sButtonText;
	}
	else if (a->iType == GUI_OBJECT_TYPE_FHBUTTON)
	{
		a->sName = "$parent_HighlightText";
		a->bHidden = true;
		a->mText.sStr = parent->sButtonText;
	}
	else if (a->iType == GUI_OBJECT_TYPE_FDBUTTON)
	{
		a->sName = "$parent_DisabledText";
		a->bHidden = true;
		a->mText.sStr = parent->sButtonText;
	}

	if (a->sName != "")
	{
		// Default anchor
		/*if (a->lAnchorList.size() == 0)
		{
			a->lAnchorList[0].mParent = parent;
			a->lAnchorList[0].sParentName = "$parent";
		}*/

		if (bDebugThis) Log("3");
		// Update name
		a->sBName = a->sName;
		if (!parent->bVirt)
		{
			int i = a->sName.find("$parent");
			if (i != a->sName.npos)
			{
				a->sName = a->sName.erase(i, 7);
				a->sBName = a->sName;
				a->sName.insert(i, parent->sName);
			}
		}
		else
		{
			a->sVName = a->sName;
			int i = a->sVName.find("$parent");
			if (i != a->sVName.npos)
			{
				a->sVName = a->sVName.erase(i, 7);
				a->sVName.insert(i, parent->sVName);
			}
		}

		if (bDebugThis) Log("4 %s, %d", font.c_str(), text.iFntSize);

		hgeFont* tmpFnt = NULL;
		if (font != "")
			tmpFnt = mFontMgr->GetFont(true, font, text.iFntSize, false, false);

        if (bDebugThis) Log("4.");

		a->mText.mFnt = tmpFnt;
		a->mText.fTracking = space;

		if (tmpFnt != NULL)
			a->bReady = true;
		else
			a->bReady = false;

		if (bDebugThis) Log("5");

		if (!parent->bVirt)
		{
			if (a->iType == GUI_OBJECT_TYPE_FONTSTRING)
			{
				if (bDebugThis) Log("6.1");
				a->mText = mGUIMgr->ParseFormatedText(a->mText);

				string exec = a->sName + " = FontString(\"" + parent->sName + "\", \"" + a->sName + "\");";
				luaL_dostring(mSceneMgr->luaVM, exec.c_str());

				if (mGUIMgr->lParentList.find(a->sName) == mGUIMgr->lParentList.end())
				{
					parent->lArtList[a->sName] = a;
					mGUIMgr->lParentList[a->sName] = parent->lArtList[a->sName];
					if (parent->lArtList[a->sName]->lAnchorList.size() == 0)
					{
						parent->lArtList[a->sName]->lAnchorList[0].mParent = parent;
						parent->lArtList[a->sName]->lAnchorList[0].sParentName = "$parent";
					}
				}
				else
				{
					Log("# XML Error # : an object with the name %s aready exists", a->sName.c_str());
				}
				if (bDebugThis) Log("6.2");
			}
			else if (a->iType == GUI_OBJECT_TYPE_FSMSGFRAME)
			{
				parent->bReady = true;
				if (bDebugThis) Log("7.1");
				a->fH = a->mText.iFntSize;
				a->bHidden = true;
				a->mText.sStr = "<empty>";
				a->mText = mGUIMgr->ParseFormatedText(a->mText);
				for (int i = 1; i <= parent->iMaxLines; i++)
				{
					a->sName = "Msg" + ToString(i);

					GUIArt* b = new GUIArt(*a);
					b->sName = "Msg" + ToString(i);
					b->mText = a->mText;
					parent->lArtList[b->sName] = b;
				}
				if (bDebugThis) Log("7.2");
			}
			else if (a->iType == GUI_OBJECT_TYPE_FEDITBOX)
			{
				if (bDebugThis) Log("8.1");
				a->mText = mGUIMgr->ParseFormatedText(a->mText);
				parent->lArtList[a->sName] = a;
				parent->mCaptionFont = parent->lArtList[a->sName];
				if (bDebugThis) Log("8.2");
			}
			else if (a->iType == GUI_OBJECT_TYPE_FNBUTTON)
			{
				if (a->lAnchorList.size() == 0)
				{
					a->lAnchorList[0].mParent = parent;
					a->lAnchorList[0].sParentName = "$parent";
				}
				a->mText = mGUIMgr->ParseFormatedText(a->mText);
				parent->lArtList[a->sName] = a;
				parent->mFontNormal = parent->lArtList[a->sName];
			}
			else if (a->iType == GUI_OBJECT_TYPE_FHBUTTON)
			{
				if (a->lAnchorList.size() == 0)
				{
					a->lAnchorList[0].mParent = parent;
					a->lAnchorList[0].sParentName = "$parent";
				}
				a->mText = mGUIMgr->ParseFormatedText(a->mText);
				parent->lArtList[a->sName] = a;
				parent->mFontHighlight = parent->lArtList[a->sName];
			}
			else if (a->iType == GUI_OBJECT_TYPE_FDBUTTON)
			{
				if (a->lAnchorList.size() == 0)
				{
					a->lAnchorList[0].mParent = parent;
					a->lAnchorList[0].sParentName = "$parent";
				}
				a->mText = mGUIMgr->ParseFormatedText(a->mText);
				parent->lArtList[a->sName] = a;
				parent->mFontDisabled = parent->lArtList[a->sName];
			}
		}
		else
		{
			if (bDebugThis) Log("9");
			GUIBase* hparent = parent->GetHighestVirtParent();
			if (hparent->lParentList.find(a->sVName) == hparent->lParentList.end())
			{
				if (type == GUI_OBJECT_TYPE_FEDITBOX)
				{
					parent->sCaptionFontName = a->sName;
				}
				parent->lArtList[a->sName] = a;
				hparent->lParentList[a->sVName] = parent->lArtList[a->sName];
			}
			else
			{
				Log("# XML Error # : a template object with the name %s aready exists", a->sVName.c_str());
			}
			if (bDebugThis) Log("10");
		}
	}
	if (debugXML) {Log("6");}
}

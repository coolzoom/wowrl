/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_scenemanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_global.h"

#include "wowrl_xml.h"

using namespace std;

extern SceneManager* mSceneMgr;
extern GFXManager* mGFXMgr;
extern GUIManager* mGUIMgr;
extern HGE* hge;
extern bool debugXML;

void XML::ParseTexture( TiXmlNode* node, GUIElement* parent, int layer, int type )
{
	/* [#] This function parses a Texture object in an XML file. A Texture is
	/* the most important part of the GUI. It is used to display bitmap files
	/* on the screen. A Texture object must be contained in a Frame (or one of
	/* its derivation).
	*/
	bool bDebugThis = false;
	if (debugXML) {Log("3");}
	GUIArt* a = new GUIArt();
	a->iLayer = layer;
	a->sParentName = parent->sName;
	a->mParent = parent;
	a->bVirt = parent->bVirt;
	a->iType = type;
	/*a->fW = parent->fW;
	a->fH = parent->fH;*/
	a->fW = -1;
	a->fH = -1;
	HTEXTURE tex;
	int blend = BLEND_DEFAULT;
	float sx = 0.0f; float sy = 0.0f; float sw = 0.0f; float sh = 0.0f;
	float x1 = 0.0f; float y1 = 0.0f; float x2 = 1.0f; float y2 = 1.0f;
	float r = 1.0f; float g = 1.0f; float b = 1.0f; float al = 1.0f;
	bool fileFound = false;

	TiXmlElement* elem = node->ToElement();
	for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
	{
		if (string(attr->Name()) == string("name"))
		{
			if (bDebugThis) {Log("3.1");}
			a->sName = attr->Value();
			a->sBName = a->sName;
			if (!parent->bVirt)
			{
				int i = a->sName.find("$parent");
				if (i != a->sName.npos)
				{
					a->sName = a->sName.erase(i, 7);
					a->sBName = a->sName;
					a->sName.insert(i, parent->sName);
				}
			}
			else
			{
				a->sVName = a->sName;
				int i = a->sVName.find("$parent");
				if (i != a->sVName.npos)
				{
					a->sVName = a->sVName.erase(i, 7);
					a->sVName.insert(i, parent->sVName);
				}
			}
		}
		else if (string(attr->Name()) == string("file"))
		{
			if (bDebugThis) {Log("3.2");}
			a->sFile = attr->Value();
			tex = mGFXMgr->LoadTexture(a->sFile, false);
			fileFound = true;
		}
		else if (string(attr->Name()) == string("alphaMode"))
		{
			if (bDebugThis) {Log("3.3");}
			if (string(attr->Value()) == string("DISABLE"))
				blend = BLEND_DEFAULT;
			else if (string(attr->Value()) == string("BLEND"))
				blend = BLEND_DEFAULT;
			else if (string(attr->Value()) == string("ALPHAKEY"))
				blend = BLEND_DEFAULT;
			else if (string(attr->Value()) == string("ADD"))
				blend = (BLEND_COLORMUL | BLEND_ALPHAADD | BLEND_NOZWRITE);
			else if (string(attr->Value()) == string("MOD"))
				blend = BLEND_DEFAULT;
		}
	}

	for (TiXmlNode* node2 = node->FirstChild(); node2; node2 = node2->NextSibling())
	{
		if (string(node2->Value()) == string("Size"))
		{
			if (bDebugThis) {Log("3.4");}
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsDimension"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("x"))
						{
							a->fW = atof(attr->Value());
						}
						else if (string(attr->Name()) == string("y"))
						{
							a->fH = atof(attr->Value());
						}
					}
				}
			}
		}
		else if ( (type == GUI_OBJECT_TYPE_TEXTURE) && (string(node2->Value()) == string("Anchors")) )
		{
			if (bDebugThis) {Log("3.4");}
			XML::ParseAnchor(node2, a);
		}
		else if (string(node2->Value()) == string("TexCoords"))
		{
			if (bDebugThis) {Log("3.5");}
			TiXmlElement* elem = node2->ToElement();
			for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
			{
				if (string(attr->Name()) == string("left"))
					x1 = atof(attr->Value());
				else if (string(attr->Name()) == string("right"))
					x2 = atof(attr->Value());
				else if (string(attr->Name()) == string("top"))
					y1 = atof(attr->Value());
				else if (string(attr->Name()) == string("bottom"))
					y2 = atof(attr->Value());
			}
		}
		else if ( (type == GUI_OBJECT_TYPE_TEXTURE) && (string(node2->Value()) == string("Color")) )
		{
			if (bDebugThis) {Log("3.6");}
			TiXmlElement* elem = node2->ToElement();
			for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
			{
				if (string(attr->Name()) == string("r"))
					r = atof(attr->Value());
				else if (string(attr->Name()) == string("g"))
					g = atof(attr->Value());
				else if (string(attr->Name()) == string("b"))
					b = atof(attr->Value());
				else if (string(attr->Name()) == string("a"))
					al = atof(attr->Value());
			}
		}
		else if ( (type == GUI_OBJECT_TYPE_TEXTURE) && (string(node2->Value()) == string("Gradient")) )
		{
		}
	}

	if (a->iType == GUI_OBJECT_TYPE_TNBUTTON)
	{
		a->sName = parent->sName + "_NormalTexture";
		a->bHidden = false;
	}
	else if (a->iType == GUI_OBJECT_TYPE_THBUTTON)
	{
		a->sName = parent->sName + "_HighlightTexture";
		a->bHidden = true;
	}
	else if (a->iType == GUI_OBJECT_TYPE_TDBUTTON)
	{
		a->sName = parent->sName + "_DisabledTexture";
		a->bHidden = true;
	}
	else if (a->iType == GUI_OBJECT_TYPE_TPBUTTON)
	{
		a->sName = parent->sName + "_PushedTexture";
		a->bHidden = true;
	}

	if (a->sName != "")
	{
		// Default anchor
		/*if (a->lAnchorList.size() == 0)
		{
			a->lAnchorList[0].mParent = parent;
			a->lAnchorList[0].sParentName = "$parent";
		}*/

		if (fileFound)
		{
			if (bDebugThis) {Log("3.7");}
			float tw = hge->Texture_GetWidth(tex, true);
			float th = hge->Texture_GetHeight(tex, true);
			sx = tw*x1;
			sy = th*y1;
			sw = tw*(x2-x1);
			sh = th*(y2-y1);

			if (a->fW == -1) a->fW = sw;
			if (a->fH == -1) a->fH = sh;

			if (type == GUI_OBJECT_TYPE_TSTATUSBAR)
				parent->fBaseWidth = sw;

			a->fScale = a->fW/sw;
			a->fVScale = a->fH/sh;

			a->mSprite = mGFXMgr->CreateSprite(tex, sx, sy, sw, sh, true);
			a->iBlend = blend;
			a->dwColor = ARGB(255*al, 255*r, 255*g, 255*b);
			a->mSprite->SetBlendMode(BLEND_COLORMUL | a->iBlend | BLEND_NOZWRITE);
			a->mSprite->SetColor(a->dwColor);
			a->bReady = true;
		}

		if (!parent->bVirt)
		{
			if (bDebugThis) {Log("3.9");}
			if (a->iType == GUI_OBJECT_TYPE_TNBUTTON)
			{
				if (a->lAnchorList.size() == 0)
				{
					a->lAnchorList[0].mParent = parent;
					a->lAnchorList[0].sParentName = "$parent";
				}
				parent->lArtList[a->sName] = a;
				parent->mTexNormal = parent->lArtList[a->sName];
			}
			else if (a->iType == GUI_OBJECT_TYPE_THBUTTON)
			{
				if (a->lAnchorList.size() == 0)
				{
					a->lAnchorList[0].mParent = parent;
					a->lAnchorList[0].sParentName = "$parent";
				}
				parent->lArtList[a->sName] = a;
				parent->mTexHighlight = parent->lArtList[a->sName];
			}
			else if (a->iType == GUI_OBJECT_TYPE_TDBUTTON)
			{
				if (a->lAnchorList.size() == 0)
				{
					a->lAnchorList[0].mParent = parent;
					a->lAnchorList[0].sParentName = "$parent";
				}
				parent->lArtList[a->sName] = a;
				parent->mTexDisabled = parent->lArtList[a->sName];
			}
			else if (a->iType == GUI_OBJECT_TYPE_TPBUTTON)
			{
				if (a->lAnchorList.size() == 0)
				{
					a->lAnchorList[0].mParent = parent;
					a->lAnchorList[0].sParentName = "$parent";
				}
				parent->lArtList[a->sName] = a;
				parent->mTexPushed = parent->lArtList[a->sName];
			}
			else if (mGUIMgr->lParentList.find(a->sName) == mGUIMgr->lParentList.end())
			{
				if (bDebugThis) {Log("3.8");}
				string exec = a->sName + " = Texture(\"" + parent->sName + "\", \"" + a->sName + "\");";
				luaL_dostring(mSceneMgr->luaVM, exec.c_str());
				if (bDebugThis) {Log("3.8.");}

				parent->lArtList[a->sName] = a;
				if (type == GUI_OBJECT_TYPE_TSTATUSBAR)
					parent->mBarTexture = parent->lArtList[a->sName];
				mGUIMgr->lParentList[a->sName] = parent->lArtList[a->sName];
				if (parent->lArtList[a->sName]->lAnchorList.size() == 0)
				{
					parent->lArtList[a->sName]->lAnchorList[0].mParent = parent;
					parent->lArtList[a->sName]->lAnchorList[0].sParentName = "$parent";
				}
			}
			else
			{
				Log("# XML Error # : an object with the name %s aready exists", a->sName.c_str());
			}
		}
		else
		{
			if (bDebugThis) {Log("3.10");}
			GUIBase* hparent = parent->GetHighestVirtParent();
			if (hparent->lParentList.find(a->sVName) == hparent->lParentList.end())
			{
				if (type == GUI_OBJECT_TYPE_TSTATUSBAR)
				{
					parent->sBarTextureName = a->sName;
				}
				parent->lArtList[a->sName] = a;
				hparent->lParentList[a->sVName] = parent->lArtList[a->sName];
				if (parent->lArtList[a->sName]->lAnchorList.size() == 0)
				{
					parent->lArtList[a->sName]->lAnchorList[0].mParent = parent;
					parent->lArtList[a->sName]->lAnchorList[0].sParentName = "$parent";
				}
			}
			else
			{
				Log("# XML Error # : a template object with the name %s aready exists", a->sVName.c_str());
			}
		}
	}
	if (debugXML) {Log("4");}
}

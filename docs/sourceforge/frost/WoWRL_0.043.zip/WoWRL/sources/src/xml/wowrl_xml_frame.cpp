/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_scenemanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_global.h"

#include "wowrl_xml.h"

using namespace std;

extern SceneManager* mSceneMgr;
extern GUIManager* mGUIMgr;
extern GFXManager* mGFXMgr;
extern HGE* hge;
extern bool debugXML;

void XML::ParseFrame( TiXmlNode* node, GUIElement* parent, int type )
{
	/* [#] This very long function parses a Frame object in an XML file. The Frame
	/* is the base of the GUI. It is a container in which you can put as many
	/* objects as you want, would it be other Frames, Textures, ...
	/* [#] Be carefull when setting a Frame's size : every child which is too large
	/* will not be rendered completely (or even not at all).
	/* [#] The Frame object has some derivations :
	/*    - The StatusBar can do whatever a Frame can do, plus it has a special
	/*      texture which adjust itself its parameters to fit the provded filling
	/*      value.
	/*    - The EditBox, which is basicaly a place where the user can input some
	/*      text that you get and use in your AddOn.
	*/
	bool bDebugThis = false;
	if (debugXML) {Log("1");}
	if (node->ToElement())
	{
		GUIElement* frame = new GUIElement();
		frame->mParent = parent;
		frame->iType = type;
		string inherits = "";
		string pname = "";
		bool hidden = false;
		bool hiddenD = false;
		bool virt = false;
		bool newFrame = true;
		bool barTexFound = false;
		if (type == GUI_OBJECT_TYPE_SMSGFRAME)
			frame->bReady = false;

        TiXmlElement* elem = node->ToElement();
		for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
		{
			if (string(attr->Name()) == string("name"))
			{
				if (bDebugThis) {Log("1.1");}
				frame->sName = attr->Value();
				frame->sBName = frame->sName;
			}
			else if (string(attr->Name()) == string("parent"))
			{
				if (bDebugThis) {Log("1.3");}
				pname = attr->Value();
			}
			else if (string(attr->Name()) == string("virtual"))
			{
				virt = ToBool((char*)attr->Value());
			}
			else if (string(attr->Name()) == string("inherits"))
			{
				if ((mGUIMgr->lTemplateList.find(attr->Value()) != mGUIMgr->lTemplateList.end()))
				{
					inherits = attr->Value();
				}
				else
				{
					newFrame = false;
					Log("# XML Error # : unknown template %s", attr->Value());
				}
			}
		}

		if (newFrame)
		{
			if (frame->sName == "")
			{
				newFrame = false;
				Log("# XML Error # : a frame must have a name");
			}
		}

		if (newFrame)
		{
			if (bDebugThis) {Log("1.4");}
			if (parent != NULL)
			{
				// A virtual frame can't be contained into a non virtual one
				if (parent->bVirt)
					virt = true;
				else if (virt)
					newFrame = false;
			}
			if (bDebugThis) {Log("1.5");}
			if (pname != "")
			{
				// We make sure that all references to other frames are valid
				if (!virt)
				{
					int i = pname.find("$parent");
					if (i != pname.npos)
					{
						pname = pname.erase(i, 7);
						if (parent != NULL)
							pname.insert(i, parent->sName);
					}
					if (mGUIMgr->lGuiList.find(pname) != mGUIMgr->lGuiList.end())
					{
						frame->sParentName = pname;
					}
					else
					{
						newFrame = false;
						Log("# XML Error # : unknown parent frame %s", pname.c_str());
					}
				}
				else
				{
					string pvname = pname;
					int i = pvname.find("$parent");
					if (i != pvname.npos)
					{
						pvname = pvname.erase(i, 7);
						if (parent != NULL)
							pvname.insert(i, parent->sVName);
					}
					GUIBase* hparent = parent->GetHighestVirtParent();
					if ( (hparent->lParentList.find(pvname) != hparent->lParentList.end()) ||
						(mGUIMgr->lTemplateList.find(pvname) != mGUIMgr->lTemplateList.end()) )
					{
						frame->sParentName = pname;
					}
					else
					{
						newFrame = false;
						Log("# XML Error # : unknown template frame %s", pvname.c_str());
					}
				}
			}
			if (bDebugThis) {Log("1.6");}
		}

		if (newFrame)
		{
			// Then we make sure that the name given to that frame is unique
			if (bDebugThis) {Log("1.7");}
			if (!virt)
			{
				if (parent == NULL)
				{
					if (frame->sParentName != "")
					{
						frame->mParent = mGUIMgr->lGuiList[frame->sParentName];
						parent = frame->mParent;
					}
				}
				else
				{
					frame->mParent = parent;
				}
			}
			else
			{
				if (parent != NULL)
				{
					frame->mParent = parent;
				}
			}

			if (bDebugThis) {Log("1.8");}
			if (virt)
			{
				frame->bVirt = true;

				if (parent == NULL)
				{
					int i = frame->sName.find("$parent");
					if (i != frame->sName.npos)
						frame->sName = frame->sName.erase(i, 7);

					frame->sVName = frame->sName;

					if (mGUIMgr->lTemplateList.find(frame->sName) == mGUIMgr->lTemplateList.end())
					{
						mGUIMgr->lTemplateList[frame->sName] = frame;
					}
					else
					{
						newFrame = false;
						Log("# XML Error # : a template with the name %s already exists", frame->sName.c_str());
					}
				}
				else
				{
					frame->sVName = frame->sName;
					int i = frame->sVName.find("$parent");
					if (i != frame->sVName.npos)
					{
						frame->sVName = frame->sVName.erase(i, 7);
						frame->sVName.insert(i, parent->sVName);
					}

					GUIBase* hparent = parent->GetHighestVirtParent();
					if (hparent->lParentList.find(frame->sVName) == hparent->lParentList.end())
					{
						frame->bChild = true;
						hparent->lParentList[frame->sVName] = frame;
						parent->lVChildList[frame->sVName] = frame;
					}
					else
					{
						newFrame = false;
						Log("# XML Error # : a template object with the name %s already exists", frame->sVName.c_str());
					}
				}
			}
			else
			{
			    frame->bVirt = false;

				frame->sBName = frame->sName;
				int i = frame->sName.find("$parent");
				if (i != frame->sName.npos)
				{
					frame->sName = frame->sName.erase(i, 7);
					frame->sBName = frame->sName;
					if (parent != NULL)
						frame->sName.insert(i, parent->sName);
				}

				if (mGUIMgr->lParentList.find(frame->sName) == mGUIMgr->lParentList.end())
				{
					if (parent == NULL)
					{
						mGUIMgr->lParentList[frame->sName] = frame;
						mGUIMgr->lGuiList[frame->sName] = frame;
					}
					else
					{
						frame->bChild = true;
						mGUIMgr->lGuiList[frame->sName] = frame;
						parent->lChildList[frame->sName] = frame;
						mGUIMgr->lParentList[frame->sName] = frame;
					}
				}
				else
				{
					newFrame = false;
					Log("# XML Error # : an object with the name %s already exists", frame->sName.c_str());
				}
			}
			if (bDebugThis) {Log("1.8.");}
		}

        if (newFrame)
        {
            // We apply inheritance, copying the base frame's parameter to our new one
            if (inherits != "")
            {
                GUIElement* inh = mGUIMgr->lTemplateList[inherits];

                if ((inh->iType == GUI_OBJECT_TYPE_FRAME) ||
                    (frame->iType == inh->iType))
                {
                    if (!frame->bVirt)
                    {
                        if (bDebugThis) {Log("1.9.1");}
                        inh->CopyVirt(frame);
                        if (bDebugThis) {Log("1.9.2");}
                    }
                    else
                    {
                        if (bDebugThis) {Log("1.9.3");}
                        frame->bHidden = inh->bHidden;
                        frame->fW = inh->fW;
                        frame->fH = inh->fH;
                        frame->fAlpha = inh->fAlpha;

                        frame->lFuncList = inh->lFuncList;

                        frame->lChildList = inh->lChildList;
                        frame->lArtList = inh->lArtList;
                        frame->lAnchorList = inh->lAnchorList;

                        // Status bar
                        if (inh->iType == GUI_OBJECT_TYPE_STATUSBAR)
                        {
                            frame->fValue = inh->fValue;
                            frame->fMinValue = inh->fMinValue;
                            frame->fMaxValue = inh->fMaxValue;
                            frame->fBaseWidth = inh->fBaseWidth;
                            frame->sBarTextureName = inh->sBarTextureName;
                        }

                        // Edit box
                        if (inh->iType == GUI_OBJECT_TYPE_EDITBOX)
                        {
                            frame->iLetters = inh->iLetters;
                            frame->iHistoryLines = inh->iHistoryLines;
                            frame->fBlinkSpeed = inh->fBlinkSpeed;
                            frame->bNumeric = inh->bNumeric;
                            frame->bPassword = inh->bPassword;
                            frame->bMultiLine = inh->bMultiLine;
                            frame->bIgnoreArrows = inh->bIgnoreArrows;
                            frame->bAutoFocus = inh->bAutoFocus;
                            frame->sCaptionFontName = inh->sCaptionFontName;
                        }

                        frame->bUseBackdrop = inh->bUseBackdrop;
                        if (frame->bUseBackdrop)
                            frame->mBackdrop = inh->mBackdrop;

                        if (bDebugThis) {Log("1.9.4");}
                    }
                }
                else
                    Log("# XML Error # : wrong parent type for inheritance in %s", frame->sName.c_str());
            }
        }

        if (newFrame)
        {
            // We get the frame's attributes
            TiXmlElement* elem = node->ToElement();
            for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
            {
                if (string(attr->Name()) == string("hidden"))
                {
                    if (bDebugThis) {Log("1.2");}
                    if (string(attr->Value()) == string("true"))
                        hidden = true;

                    hiddenD = true;
                }
                else if (string(attr->Name()) == string("frameStrata"))
                {
                    if (string(attr->Value()) == string("TOOLTIP"))
                        frame->iFrameStrata = GUI_STRATA_TOOLTIP;
                    else if (string(attr->Value()) == string("FULLSCREEN_DIALOG"))
                        frame->iFrameStrata = GUI_STRATA_FULLSCREEN_DIALOG;
                    else if (string(attr->Value()) == string("FULLSCREEN"))
                        frame->iFrameStrata = GUI_STRATA_FULLSCREEN;
                    else if (string(attr->Value()) == string("DIALOG"))
                        frame->iFrameStrata = GUI_STRATA_DIALOG;
                    else if (string(attr->Value()) == string("HIGH"))
                        frame->iFrameStrata = GUI_STRATA_HIGH;
                    else if (string(attr->Value()) == string("MEDIUM"))
                        frame->iFrameStrata = GUI_STRATA_MEDIUM;
                    else if (string(attr->Value()) == string("LOW"))
                        frame->iFrameStrata = GUI_STRATA_LOW;
                    else if (string(attr->Value()) == string("BACKGROUND"))
                        frame->iFrameStrata = GUI_STRATA_BACKGROUND;
                }
                else if (string(attr->Name()) == string("movable"))
                {
                    frame->bMovable = ToBool((char*)attr->Value());
                }
                else if (string(attr->Name()) == string("enableMouse"))
                {
                    frame->bEnableMouse = ToBool((char*)attr->Value());
                }
                else if (string(attr->Name()) == string("toplevel"))
                {
                }
                else if (string(attr->Name()) == string("clampedToScreen"))
                {
                }

                // EditBox specific attributes
                if (type == GUI_OBJECT_TYPE_EDITBOX)
                {
                    if (string(attr->Name()) == string("letters"))
                    {
                        frame->iLetters = ToInt(attr->Value());
                    }
                    if (string(attr->Name()) == string("historyLines"))
                    {
                        frame->iHistoryLines = ToInt(attr->Value());
                    }
                    else if (string(attr->Name()) == string("blinkSpeed"))
                    {
                        frame->fBlinkSpeed = atof(attr->Value());
                    }
                    else if (string(attr->Name()) == string("numeric"))
                    {
                        frame->bNumeric = ToBool((char*)attr->Value());
                    }
                    else if (string(attr->Name()) == string("password"))
                    {
                        frame->bPassword = ToBool((char*)attr->Value());
                    }
                    else if (string(attr->Name()) == string("multiLine"))
                    {
                        frame->bMultiLine = ToBool((char*)attr->Value());
                    }
                    else if (string(attr->Name()) == string("ignoreArrows"))
                    {
                        frame->bIgnoreArrows = ToBool((char*)attr->Value());
                    }
                    else if (string(attr->Name()) == string("autoFocus"))
                    {
                        frame->bAutoFocus = ToBool((char*)attr->Value());
                    }
                }

                // ScrollingMessageFrame specific attributes
                if (type == GUI_OBJECT_TYPE_SMSGFRAME)
                {
                    if (string(attr->Name()) == string("maxLines"))
                    {
                        frame->iMaxLines = ToInt(attr->Value());
                    }
                    if (string(attr->Name()) == string("fade"))
                    {
                        frame->bFade = ToBool((char*)attr->Value());
                    }
                    if (string(attr->Name()) == string("fadeDuration"))
                    {
                        frame->fFadeDuration = atof(attr->Value());
                    }
                    if (string(attr->Name()) == string("displayDuration"))
                    {
                        frame->fDisplayDuration = atof(attr->Value());
                    }
                }

                // Button specific attributes
                if (type == GUI_OBJECT_TYPE_BUTTON)
                {
                    if (string(attr->Name()) == string("text"))
                    {
                        frame->sButtonText = attr->Value();
                    }
                }
            }
        }

		if (newFrame)
		{
			// Debug: print the frame's name
			if (bDebugThis)
			{
				if (!virt)
					Log("1.9 %s", frame->sName.c_str());
				else
					Log("1.9 %s", frame->sVName.c_str());
			}

			if (bDebugThis) {Log("1.10");}

			if (hiddenD)
				frame->bHidden = hidden;

			// Then we get this frame's elements
			for (TiXmlNode* node2 = node->FirstChild(); node2; node2 = node2->NextSibling())
			{
				if (string(node2->Value()) == string("Scripts"))
				{
					if (bDebugThis) {Log("1.10.1");}
					for (TiXmlNode* node3 = node2->FirstChild(); node3; node3 = node3->NextSibling())
					{
						// Frame handlers
						if (string(node3->Value()) == string("OnLoad"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_LOAD, node4->Value());
						}
						else if (string(node3->Value()) == string("OnEnter"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_ENTER, node4->Value());
						}
						else if (string(node3->Value()) == string("OnLeave"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_LEAVE, node4->Value());
						}
						else if (string(node3->Value()) == string("OnDragStart"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_DRAGSTART, node4->Value());
						}
						else if (string(node3->Value()) == string("OnReceiveDrag"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_RECEIVEDRAG, node4->Value());
						}
						else if (string(node3->Value()) == string("OnUpdate"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_UPDATE, node4->Value());
						}
						else if (string(node3->Value()) == string("OnMouseUp"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_MOUSEUP, node4->Value());
						}
						else if (string(node3->Value()) == string("OnMouseDown"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_MOUSEDOWN, node4->Value());
						}
						else if (string(node3->Value()) == string("OnKeyUp"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_KEYUP, node4->Value());
						}
						else if (string(node3->Value()) == string("OnKeyDown"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_KEYDOWN, node4->Value());
						}
						else if (string(node3->Value()) == string("OnHide"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_HIDE, node4->Value());
						}
						else if (string(node3->Value()) == string("OnShow"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_SHOW, node4->Value());
						}
						else if (string(node3->Value()) == string("OnEvent"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_EVENT, node4->Value());
						}

						// EditBox specific handlers
						if (frame->iType == GUI_OBJECT_TYPE_EDITBOX)
						{
							if (string(node3->Value()) == string("OnChar"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_CHAR, node4->Value());
							}
							else if (string(node3->Value()) == string("OnEnterPressed"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_ENTERPRESSED, node4->Value());
							}
							else if (string(node3->Value()) == string("OnSpacePressed"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_SPACEPRESSED, node4->Value());
							}
							else if (string(node3->Value()) == string("OnTabPressed"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_TABPRESSED, node4->Value());
							}
							else if (string(node3->Value()) == string("OnEscapePressed"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_ESCAPEPRESSED, node4->Value());
							}
							else if (string(node3->Value()) == string("OnEditFocusGained"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_EDITFOCUSGAINED, node4->Value());
							}
							else if (string(node3->Value()) == string("OnEditFocusLost"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_EDITFOCUSLOST, node4->Value());
							}
						}

						// Button specific handler
						if (frame->iType == GUI_OBJECT_TYPE_BUTTON)
						{
							if (string(node3->Value()) == string("OnClick"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_CLICK, node4->Value());
							}
						}
					}
				}
				else if (string(node2->Value()) == string("Size"))
				{
					if (bDebugThis) {Log("1.10.2");}
					TiXmlNode* node3 = node2->FirstChild();
					if (node3)
					{
						if (string(node3->Value()) == string("AbsDimension"))
						{
							TiXmlElement* elem = node3->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("x"))
								{
									frame->fW = atof(attr->Value());
								}
								else if (string(attr->Name()) == string("y"))
								{
									frame->fH = atof(attr->Value());
								}
							}
						}
					}
				}
				else if (string(node2->Value()) == string("Anchors"))
				{
					XML::ParseAnchor(node2, frame);
				}
				else if (string(node2->Value()) == string("Frames"))
				{
					if (bDebugThis) {Log("1.10.3");}
					for (TiXmlNode* node3 = node2->FirstChild(); node3; node3 = node3->NextSibling())
					{
						if (string(node3->Value()) == string("Frame"))
						{
							XML::ParseFrame(node3, frame, GUI_OBJECT_TYPE_FRAME);
						}
						else if (string(node3->Value()) == string("StatusBar"))
						{
							XML::ParseFrame(node3, frame, GUI_OBJECT_TYPE_STATUSBAR);
						}
						else if (string(node3->Value()) == string("EditBox"))
						{
							XML::ParseFrame(node3, frame, GUI_OBJECT_TYPE_EDITBOX);
						}
						else if (string(node3->Value()) == string("ScrollingMessageFrame"))
						{
							XML::ParseFrame(node3, frame, GUI_OBJECT_TYPE_SMSGFRAME);
						}
						else if (string(node3->Value()) == string("Button"))
						{
							XML::ParseFrame(node3, frame, GUI_OBJECT_TYPE_BUTTON);
						}
					}
				}
				else if (string(node2->Value()) == string("Layers"))
				{
					if (bDebugThis) {Log("1.10.4");}
					for (TiXmlNode* node3 = node2->FirstChild(); node3; node3 = node3->NextSibling())
					{
						if (string(node3->Value()) == string("Layer"))
						{
							int layer = 0;
							TiXmlElement* elem = node3->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("level"))
								{
									if (string(attr->Value()) == string("BACKGROUND"))
										layer = GUI_LAYER_BACKGROUND;
									else if (string(attr->Value()) == string("BORDER"))
										layer = GUI_LAYER_BORDER;
									else if (string(attr->Value()) == string("ARTWORK"))
										layer = GUI_LAYER_ARTWORK;
									else if (string(attr->Value()) == string("OVERLAY"))
										layer = GUI_LAYER_OVERLAY;
									else if (string(attr->Value()) == string("HIGHLIGHT"))
										layer = GUI_LAYER_HIGHLIGHT;
								}
							}

							for (TiXmlNode* node4 = node3->FirstChild(); node4; node4 = node4->NextSibling())
							{
								if (string(node4->Value()) == string("Texture"))
								{
									XML::ParseTexture(node4, frame, layer);
								}
								else if (string(node4->Value()) == string("FontString"))
								{
									XML::ParseString(node4, frame, layer);
								}
							}
						}
					}
				}
				else if (string(node2->Value()) == string("Backdrop"))
				{
					XML::ParseBackdrop(node2, frame);
				}
				else if (string(node2->Value()) == string("HitRectInsets"))
				{
					TiXmlNode* node3 = node2->FirstChild();
					if (node3)
					{
						if (string(node3->Value()) == string("AbsInset"))
						{
							TiXmlElement* elem = node3->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("left"))
								{
									frame->iHitInsL = atoi(attr->Value());
								}
								if (string(attr->Name()) == string("right"))
								{
									frame->iHitInsR = atoi(attr->Value());
								}
								if (string(attr->Name()) == string("top"))
								{
									frame->iHitInsT = atoi(attr->Value());
								}
								if (string(attr->Name()) == string("bottom"))
								{
									frame->iHitInsB = atoi(attr->Value());
								}
							}
						}
					}
				}

				// Special elements for the status bar
				if (frame->iType == GUI_OBJECT_TYPE_STATUSBAR)
				{
					if (string(node2->Value()) == string("BarTexture"))
					{
						XML::ParseTexture(node2, frame, GUI_LAYER_BACKGROUND, GUI_OBJECT_TYPE_TSTATUSBAR);
					}
					else if (string(node2->Value()) == string("BarColor"))
					{
						if (barTexFound)
						{
							float r = 1.0f; float g = 1.0f; float b = 1.0f; float al = 1.0f;
							TiXmlElement* elem = node2->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("r"))
									r = atof(attr->Value());
								else if (string(attr->Name()) == string("g"))
									g = atof(attr->Value());
								else if (string(attr->Name()) == string("b"))
									b = atof(attr->Value());
								else if (string(attr->Name()) == string("a"))
									al = atof(attr->Value());
							}

							GUIArt* a = frame->lArtList[frame->sName + "BarTexture"];
							a->dwColor = ARGB(255*al, 255*r, 255*g, 255*b);
							a->mSprite->SetColor(a->dwColor);
						}
					}
				}

				// Special elements for the edit box
				if (frame->iType == GUI_OBJECT_TYPE_EDITBOX)
				{
					if (string(node2->Value()) == string("FontString"))
					{
						XML::ParseString(node2, frame, GUI_LAYER_SPECIALHIGH, GUI_OBJECT_TYPE_FEDITBOX);
					}
					else if (string(node2->Value()) == string("TextInsets"))
					{
						TiXmlElement* elem = node2->ToElement();
						for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
						{
							if (string(attr->Name()) == string("left"))
							{
								frame->iEBInsL = atoi(attr->Value());
							}
							if (string(attr->Name()) == string("right"))
							{
								frame->iEBInsR = atoi(attr->Value());
							}
							if (string(attr->Name()) == string("top"))
							{
								frame->iEBInsT = atoi(attr->Value());
							}
							if (string(attr->Name()) == string("bottom"))
							{
								frame->iEBInsB = atoi(attr->Value());
							}
						}
					}
					else if (string(node2->Value()) == string("HighlightColor"))
					{

					}
				}

				// Special elements for the scrolling message frame
				if (frame->iType == GUI_OBJECT_TYPE_SMSGFRAME)
				{
					if (string(node2->Value()) == string("FontString"))
					{
						XML::ParseString(node2, frame, GUI_LAYER_SPECIALHIGH, GUI_OBJECT_TYPE_FSMSGFRAME);
					}
					else if (string(node2->Value()) == string("TextInsets"))
					{
						TiXmlElement* elem = node2->ToElement();
						for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
						{
							if (string(attr->Name()) == string("left"))
							{
								frame->iSMFInsL = atoi(attr->Value());
							}
							if (string(attr->Name()) == string("right"))
							{
								frame->iSMFInsR = atoi(attr->Value());
							}
							if (string(attr->Name()) == string("top"))
							{
								frame->iSMFInsT = atoi(attr->Value());
							}
							if (string(attr->Name()) == string("bottom"))
							{
								frame->iSMFInsB = atoi(attr->Value());
							}
						}
					}
				}

				// Special elements for buttons
				if (frame->iType == GUI_OBJECT_TYPE_BUTTON)
				{
					if (string(node2->Value()) == string("NormalTexture"))
					{
						XML::ParseTexture(node2, frame, GUI_LAYER_BACKGROUND, GUI_OBJECT_TYPE_TNBUTTON);
					}
					else if (string(node2->Value()) == string("PushedTexture"))
					{
						XML::ParseTexture(node2, frame, GUI_LAYER_BACKGROUND, GUI_OBJECT_TYPE_TPBUTTON);
					}
					else if (string(node2->Value()) == string("DisabledTexture"))
					{
						XML::ParseTexture(node2, frame, GUI_LAYER_BACKGROUND, GUI_OBJECT_TYPE_TDBUTTON);
					}
					else if (string(node2->Value()) == string("HighlightTexture"))
					{
						XML::ParseTexture(node2, frame, GUI_LAYER_HIGHLIGHT, GUI_OBJECT_TYPE_THBUTTON);
					}
					else if (string(node2->Value()) == string("NormalText"))
					{
						XML::ParseString(node2, frame, GUI_LAYER_SPECIALHIGH, GUI_OBJECT_TYPE_FNBUTTON);
					}
					else if (string(node2->Value()) == string("HighlightText"))
					{
						XML::ParseString(node2, frame, GUI_LAYER_SPECIALHIGH, GUI_OBJECT_TYPE_FHBUTTON);
					}
					else if (string(node2->Value()) == string("DisabledText"))
					{
						XML::ParseString(node2, frame, GUI_LAYER_SPECIALHIGH, GUI_OBJECT_TYPE_FDBUTTON);
					}
					else if (string(node2->Value()) == string("PushedTextOffset"))
					{
						TiXmlElement* elem = node2->ToElement();
						for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
						{
							if (string(attr->Name()) == string("x"))
							{
								frame->iPushTxtOffX = atoi(attr->Value());
							}
							else if (string(attr->Name()) == string("y"))
							{
								frame->iPushTxtOffY = atoi(attr->Value());
							}
						}
					}
				}
			}

			if (bDebugThis) {Log("1.11");}

			// If the frame is not virtual, we register it in lua
			if (!virt)
			{
				string exec;
				if (frame->iType == GUI_OBJECT_TYPE_STATUSBAR)
					exec = frame->sName + " = StatusBar(\"" + frame->sName + "\");";
				else if (frame->iType == GUI_OBJECT_TYPE_EDITBOX)
					exec = frame->sName + " = EditBox(\"" + frame->sName + "\");";
				else if (frame->iType == GUI_OBJECT_TYPE_SMSGFRAME)
					exec = frame->sName + " = ScrollingMessageFrame(\"" + frame->sName + "\");";
				else if (frame->iType == GUI_OBJECT_TYPE_BUTTON)
					exec = frame->sName + " = Button(\"" + frame->sName + "\");";
				else
					exec = frame->sName + " = Frame(\"" + frame->sName + "\");";

				luaL_dostring(mSceneMgr->luaVM, exec.c_str());
			}

			// We set unprovided parameters
			if (frame->mParent != NULL)
			{
				if (frame->fW < 0)
					frame->fW = frame->mParent->fW;
				if (frame->fH < 0)
					frame->fH = frame->mParent->fH;
			}
			else
			{
				if (frame->fW < 0)
					frame->fW = mGFXMgr->iSWidth;
				if (frame->fH < 0)
					frame->fH = mGFXMgr->iSHeight;
			}

			if (bDebugThis) {Log("1.12");}

			if ( (frame->iType == GUI_OBJECT_TYPE_EDITBOX) && (!frame->bVirt) )
			{
				frame->bEnableMouse = true;

				if (frame->mCaptionFont != NULL)
				{
					Anchor a;
					a.mParent = frame;
					a.sParentName = frame->sName;
					a.fX = frame->iEBInsL;
					a.fY = -frame->iEBInsT;

					frame->mCaptionFont->lAnchorList[0] = a;

					frame->mCaptionFont->fW = frame->fW - frame->iEBInsL - frame->iEBInsT;
					frame->mCaptionFont->mText.fW = frame->mCaptionFont->fW;
					frame->mCaptionFont->fH = frame->fH - frame->iEBInsT - frame->iEBInsB;

					frame->fCarretScale = frame->mCaptionFont->mText.iFntSize/16.0f;
					frame->fCarretX = 1*frame->fCarretScale+frame->iEBInsL;
					frame->fCarretY = 15*frame->fCarretScale+frame->iEBInsT;
				}
				else
				{
					frame->fCarretScale = 1.0f;
					frame->fCarretX = 1+frame->iEBInsL;
					frame->fCarretY = 15+frame->iEBInsT;
				}
			}

			if (frame->iType == GUI_OBJECT_TYPE_SMSGFRAME)
			{
				frame->iOldBottomLine = frame->iMaxLines;
				frame->iBottomLine = frame->iMaxLines;
			}

			if (frame->iType == GUI_OBJECT_TYPE_BUTTON)
			{
				frame->bEnableMouse = true;

				if (frame->mTexNormal == NULL)
					frame->bButtonTextureReady = false;
				else
				{
					frame->bButtonTextureReady = true;
					if (frame->mTexPushed == NULL)
						frame->mTexPushed = frame->mTexNormal;
					if (frame->mTexDisabled == NULL)
						frame->mTexDisabled = frame->mTexNormal;
					if (frame->mTexHighlight == NULL)
						frame->mTexHighlight = frame->mTexNormal;
				}

				if (frame->mFontNormal == NULL)
					frame->bButtonFontReady = false;
				else
				{
					frame->bButtonFontReady = true;
					if (frame->mFontHighlight == NULL)
						frame->mFontHighlight = frame->mFontNormal;
					if (frame->mFontDisabled == NULL)
						frame->mFontDisabled = frame->mFontNormal;
				}

				if ( (frame->mTexNormal == NULL) && (frame->mFontNormal == NULL) )
					frame->bReady = false;
			}

			/*if ( (!frame->bVirt) && (frame->lAnchorList.size() == 0) )
			{
				frame->lAnchorList[0].parent = parent;
				frame->lAnchorList[0].parent_name = "$parent";
			}*/
		}

		if (!newFrame && frame)
            delete frame;
	}
	if (debugXML) {Log("2");}
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_global.h"

#include "wowrl_xml.h"

using namespace std;

extern GFXManager* mGFXMgr;
extern HGE* hge;
extern bool debugXML;

void XML::ParseBackdrop( TiXmlNode* node, GUIElement* parent )
{
	/* [#] This function parses a Backdrop object in an XML file.
	/* A Backdrop must be contained in a Frame.
	*/
	if (debugXML) {Log("9");}
	Backdrop bd;
	bd.sBgFile = "";
	bd.sEdgeFile = "";
	bd.bTile = false;
	bd.fEdgeSize = -1.0f;
	bd.fTileSize = -1.0f;
	bd.fInsL = 0.0f;
	bd.fInsR = 0.0f;
	bd.fInsT = 0.0f;
	bd.fInsB = 0.0f;
	bd.dwEdgeColor = ARGB(255, 255, 255, 255);
	bd.dwBgColor = ARGB(255, 255, 255, 255);
	bd.bBgReadyC = false;

	TiXmlElement* elem = node->ToElement();
	for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
	{
		if (string(attr->Name()) == string("bgFile"))
		{
			bd.sBgFile = attr->Value();
		}
		if (string(attr->Name()) == string("edgeFile"))
		{
			bd.sEdgeFile = attr->Value();
		}
		if (string(attr->Name()) == string("tile"))
		{
			bd.bTile = ToBool((char*)attr->Value());
		}
	}

	for (TiXmlNode* node2 = node->FirstChild(); node2; node2 = node2->NextSibling())
	{
		if (string(node2->Value()) == string("EdgeSize"))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsValue"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("val"))
						{
							bd.fEdgeSize = atoi(attr->Value());
						}
					}
				}
			}
		}
		if (string(node2->Value()) == string("TileSize"))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsValue"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("val"))
						{
							bd.fTileSize = atoi(attr->Value());
						}
					}
				}
			}
		}
		if (string(node2->Value()) == string("BackgroundInsets"))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsInset"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("left"))
						{
							bd.fInsL = atoi(attr->Value());
						}
						if (string(attr->Name()) == string("right"))
						{
							bd.fInsR = atoi(attr->Value());
						}
						if (string(attr->Name()) == string("top"))
						{
							bd.fInsT = atoi(attr->Value());
						}
						if (string(attr->Name()) == string("bottom"))
						{
							bd.fInsB = atoi(attr->Value());
						}
					}
				}
			}
		}
	}

	// Load edges
	if ( (bd.sEdgeFile != "") && (!parent->bVirt) )
	{
		HTEXTURE tex1 = mGFXMgr->LoadTexture(bd.sEdgeFile, false);
		float size = (int)floor(hge->Texture_GetWidth(tex1, true)/8.0f);
		bd.mEdgeL = new hgeSprite(tex1, 0, 0, size, size);
		bd.mEdgeR = new hgeSprite(tex1, size, 0, size, size);
		bd.mEdgeT = new hgeSprite(tex1, 2*size, 0, size, size);
		bd.mEdgeB = new hgeSprite(tex1, 3*size, 0, size, size);
		bd.mCornerTL = new hgeSprite(tex1, 4*size, 0, size, size);
		bd.mCornerTR = new hgeSprite(tex1, 5*size, 0, size, size);
		bd.mCornerBL = new hgeSprite(tex1, 6*size, 0, size, size);
		bd.mCornerBR = new hgeSprite(tex1, 7*size, 0, size, size);
		bd.fEdgeOriginalSize = size;
		bd.bEdgeReady = true;
	}
	else
		bd.bEdgeReady = false;

	// Load background
	if ( (bd.sBgFile != "") && (!parent->bVirt) )
	{
		HTEXTURE tex2;
		tex2 = mGFXMgr->LoadTexture(bd.sBgFile, false);

		bd.fBgW = hge->Texture_GetWidth(tex2, true);
		bd.fBgH = hge->Texture_GetHeight(tex2, true);

		if (bd.bTile)
			bd.mBackground = new hgeSprite(tex2, 0, 0, parent->fW-bd.fInsL-bd.fInsR, parent->fH-bd.fInsT-bd.fInsB);
		else
			bd.mBackground = new hgeSprite(tex2, 0, 0, bd.fBgW, bd.fBgH);

		bd.bBgReady = true;
	}
	else
		bd.bBgReady = false;

	if (!parent->bVirt)
	{
		bd.mTarget = hge->Target_Create(ToInt(parent->fW), ToInt(parent->fH), false);
		bd.mSpr = new hgeSprite(hge->Target_GetTexture(bd.mTarget), 0, 0, ToInt(parent->fW), ToInt(parent->fH));
	}
	else
	{
	    bd.mTarget = 0;
		bd.mSpr = NULL;
	}

	parent->mBackdrop = bd;
	parent->bUseBackdrop = true;

	if (debugXML) {Log("10");}
}

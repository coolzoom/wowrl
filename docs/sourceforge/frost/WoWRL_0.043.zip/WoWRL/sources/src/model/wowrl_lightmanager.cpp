/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           LightManager source          */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the LightManager class.            */
/*       The LightManager takes care of   */
/*  Light creation and storage.           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"

#include "wowrl_lightmanager.h"
#include "wowrl_modelmanager.h"
#include "wowrl_gfxmanager.h"

extern GFXManager* mGFXMgr;
extern ModelManager* mModelMgr;
extern HGE *hge;

using namespace std;

LightManager::LightManager()
{
    iLightNbr = 0;
}

LightManager::~LightManager()
{
}

LightManager* LightManager::mLightMgr = NULL;

LightManager* LightManager::GetSingleton()
{
	if (mLightMgr == NULL)
		mLightMgr = new LightManager;
	return mLightMgr;
}

int LightManager::AddPointLight(float x, float y, float z, float range, DWORD color)
{
    D3DLIGHT9 light;

    ZeroMemory(&light, sizeof(light));
    light.Type = D3DLIGHT_POINT;
    light.Diffuse.r = GETR(color)/255.0f;
    light.Diffuse.g = GETG(color)/255.0f;
    light.Diffuse.b = GETB(color)/255.0f;
    light.Diffuse.a = GETA(color)/255.0f;
    light.Range = range;
    light.Attenuation0 = 0.0f;
    light.Attenuation1 = 0.125f;
    light.Attenuation2 = 0.0f;

    D3DVECTOR vecPosition = {x, y, z};
    light.Position = vecPosition;

    iLightNbr++;

    lLightList.push_back(light);

    return iLightNbr;
}

vector<D3DLIGHT9> LightManager::GetLights( Vector3 pos )
{
    multimap<float, D3DLIGHT9> tmpList;
    vector<D3DLIGHT9>::iterator iterLight = lLightList.begin();
    for (iterLight = lLightList.begin(); iterLight != lLightList.end(); iterLight++)
    {
        float dist = Dist(pos, Vector3(iterLight->Position.x, iterLight->Position.y, iterLight->Position.z));
        tmpList.insert(make_pair(dist, *iterLight));
    }

    vector<D3DLIGHT9> nLightList;
    multimap<float, D3DLIGHT9>::iterator iterTmp = tmpList.begin();
    for (int i = 0; i < tmpList.size(); i++, iterTmp++)
    {
        nLightList.push_back(iterTmp->second);
    }

    for (int i = tmpList.size(); i < 4; i++)
    {
        D3DLIGHT9 l;
        l.Type = (D3DLIGHTTYPE)0;
        nLightList.push_back(l);
    }

    return nLightList;
}

Vector3 LightManager::PointDiffuse(Vector3 VertPos, Vector3 VertNorm, Vector3 LightPos,
                           Vector3 LightColor, Vector3 LightAttenuation, float LightRange)
{
	Vector3 LightDir = LightPos - VertPos;
	float Dist = LightDir.GetLength();
	if (Dist < LightRange)
	{
		float DistAttn = SaturateFloat(1 / (LightAttenuation.x +
									   LightAttenuation.y * Dist +
									   LightAttenuation.z * Dist * Dist));

		float AngleAttn = SaturateFloat(Vector3::DotProduct(&VertNorm, &LightDir));

		return LightColor * DistAttn * AngleAttn;
	}
	else
		return Vector3(0, 0, 0);
}

Vector3 LightManager::GetAmbient()
{
    return vAmb;
}

void LightManager::SetAmbient( Vector3 nAmb )
{
    vAmb = nAmb;
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Model source              */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Model class.                   */
/*       Models are loaded from M2 files  */
/*  and used to render characters, items, */
/*  doodads, ...                          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"

#include "wowrl_modelstructs.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_timemanager.h"
#include "wowrl_global.h"
#include "wowrl_model.h"
#include "wowrl_animmanager.h"
#include "wowrl_modelmanager.h"

using namespace std;

extern GFXManager* mGFXMgr;
extern TimeManager* mTimeMgr;
extern ModelManager* mModelMgr;
extern HGE *hge;
extern bool debugAnim;

bool bDebugLoader = false;

Mesh::Mesh()
{
    lVertexList = NULL;
    iVertexNbr = 0;
    lBoneList = NULL;
    bIsCopy = false;
    bShown = true;
    //bLastShown = false;
    bIsBody = true;
    mTex = 0;
}

Mesh::Mesh(const Mesh &m)
{
    bIsCopy = true;
    iID = m.iID;
    iGID = m.iGID;
    bShown = m.bShown;
    mTex = m.mTex;
    lBoneIDToRIDMap = lBoneIDToRIDMap;

    iVertexNbr = m.iVertexNbr;
    lVertexList = m.lVertexList;

    iBoneNbr = m.iBoneNbr;
    lBoneList = m.lBoneList;
}
Mesh::~Mesh()
{
    if (!bIsCopy)
    {
        if (lVertexList)
            delete[] lVertexList;

        if (lBoneList)
            delete[] lBoneList;
    }
}

void FixCoordSystem(float *pos)
{
    float opos[3];
    opos[0] = pos[0];
    opos[1] = pos[1];
    opos[2] = pos[2];
    pos[0] = opos[0];
    pos[1] = opos[2];
    pos[2] = -opos[1];
}

bool IsAnimated(char* buffer, ModelHeader header)
{
    /* Note : Copy/Pasted from WoWModelViewer */

    // see if we have any animated bones
    ModelBoneDef *bo = (ModelBoneDef*)(buffer + header.ofsBones);

    bool animGeometry = false;
    bool animBones = false;
    bool ind = false;

    ModelVertex *verts = (ModelVertex*)(buffer + header.ofsVertices);
    for (int i = 0; i < header.nVertices && !animGeometry; i++)
    {
        for (int b = 0; b < 4; b++)
        {
            if (verts[i].weights[b] > 0)
            {
                ModelBoneDef &bb = bo[verts[i].bones[b]];
                if (bb.translation.type || bb.rotation.type || bb.scaling.type || (bb.flags&8))
                {
                    if (bb.flags & 8)
                    {
                        // if we have billboarding, the model will need per-instance animation
                        ind = true;
                    }
                    animGeometry = true;
                    break;
                }
            }
        }
    }

    if (animGeometry)
        animBones = true;
    else
    {
        for (int i = 0; i < header.nBones; i++)
        {
            ModelBoneDef &bb = bo[i];
            if (bb.translation.type || bb.rotation.type || bb.scaling.type)
            {
                animBones = true;
                break;
            }
        }
    }

    bool animTextures = header.nTexAnims > 0;

    bool animMisc = header.nCameras > 0          || // why waste time, pretty much all models with cameras need animation
                    header.nLights > 0           || // same here
                    header.nParticleEmitters > 0 ||
                    header.nRibbonEmitters > 0;

    if (animMisc)
        animBones = true;

    // animated colors
    if (header.nColors)
    {
        ModelColorDef *cols = (ModelColorDef*)(buffer + header.ofsColors);
        for (int i = 0; i < header.nColors; i++)
        {
            if (cols[i].color.type != 0 || cols[i].opacity.type != 0)
            {
                animMisc = true;
                break;
            }
        }
    }

    // animated opacity
    if (header.nTransparency && !animMisc)
    {
        ModelTransDef *trs = (ModelTransDef*)(buffer + header.ofsTransparency);
        for (int i = 0; i < header.nTransparency; i++)
        {
            if (trs[i].trans.type != 0)
            {
                animMisc = true;
                break;
            }
        }
    }

    // guess not...
    return (animGeometry || animTextures || animMisc);

    /* Note : End of the Copy/Pasted code */
}

Model::~Model()
{
    if (mAnimMgr) delete mAnimMgr;
    if (lMeshList)
    {
        for (int i = 0; i < iMeshNbr; i++)
            delete lMeshList[i];
        delete[] lMeshList;
    }
    if (!bIsCopy)
    {
        if (lBoneList)
        {
            for (int i = 0; i < iBoneNbr; i++)
                delete lBoneList[i];
            delete[] lBoneList;
        }
        if (lBaseBoneList)
            delete[] lBaseBoneList;
    }
    if (mUpdateTimer) delete mUpdateTimer;
    if (mSprite) delete mSprite;
    if (mRTarget) hge->Target_Free(mRTarget);
}

Model::Model(const Model &m)
{
    bIsCopy = true;
    mParent = NULL;

    if (m.mAnimMgr != NULL)
    {
        mAnimMgr = new AnimManager(*m.mAnimMgr);
        mAnimMgr->SetParent(this);
    }
    else
        mAnimMgr = NULL;

    iMeshNbr = m.iMeshNbr;
    if (iMeshNbr > 0)
    {
        lMeshList = new Mesh*[iMeshNbr];
        for (int i = 0; i < iMeshNbr; i++)
            lMeshList[i] = new Mesh(*(m.lMeshList[i]));
    }
    else
        lMeshList = NULL;

    iBoneNbr = m.iBoneNbr;
    if (iBoneNbr > 0)
    {
        lBoneList = new Bone*[iBoneNbr];
        for (int i = 0; i < iBoneNbr; i++)
            lBoneList[i] = new Bone(*(m.lBoneList[i]));
    }
    else
        lBoneList = NULL;

    iBaseBoneNbr = m.iBaseBoneNbr;
    lBaseBoneList = m.lBaseBoneList;

    bShown = m.bShown;
    bAnimated = m.bAnimated;
    SetPosition(Vector3(0,0,0));
    SetOrientation(Vector3(0,0,0));
    SetScale(Vector3(1,1,1));
    bUpdateWMat = true;

    vBBoxMin = m.vBBoxMin;
    vBBoxMax = m.vBBoxMax;

    mUpdateTimer = new PeriodicTimer(MODEL_UPDATE_TIME, TIMER_START_FIRST, true);

    iRTSize = m.iRTSize;
    mRTarget = hge->Target_Create(iRTSize, iRTSize, true);
    mSprite = new hgeSprite(hge->Target_GetTexture(mRTarget), 0, 0, iRTSize, iRTSize);
    mSprite->SetHotSpot(iRTSize/2, iRTSize/2);

    float zoom = 2.5f*256/iRTSize;
    D3DXMatrixOrthoLH(&mProj,
                      zoom,
                      zoom,
                      1.0f,
                      50.0f);

    bUpdateBBoxes = true;

    mBodyTex = m.mBodyTex;
}

Model::Model(string file)
{
    mUpdateTimer = NULL;
    mAnimMgr = NULL;
    lMeshList = NULL;
    lBoneList = NULL;
    lBaseBoneList = NULL;
    bIsCopy = false;
    mRTarget = 0;
    mSprite = NULL;
    mParent = NULL;
    iRTSize = 256;
    mBodyTex = 0;

    vBBoxMin = Vector3(999,999,999); // Big value that will be replaced
    vBBoxMax = Vector3(-999,-999,-999); // Same here

    fstream f;
    f.open(file.c_str(), ios::in);

    f.seekg(0, ios::end);
    int length = f.tellg();
    f.seekg(0, ios::beg);

    if (f.eof() || (length < sizeof(ModelHeader)))
    {
        Log("# Error # : Unable to load model: \"%s\"", file.c_str());
        f.close();
        return;
    }

    char* buffer = new char[length];
    f.read(buffer,length);
    f.close();

    // Parse the header
    ModelHeader header;
    memcpy(&header, buffer, sizeof(ModelHeader));

    // Error check
    if (header.id[0] != 'M' && header.id[1] != 'D' && header.id[2] != '2' && header.id[3] != '0')
    {
        Log("# Error# : Invalid model: \"%s\"! May be corrupted.", file.c_str());
        f.close();
        return;
    }

    if (header.version[0] != 4 || header.version[1] != 1 || header.version[2] != 0 || header.version[3] != 0)
    {
        Log("# Error # : Incorrect version for model \"%s\"!\nOnly supporting models from 2.0.1 or newer client.", file.c_str());
        f.close();
        return;
    }

    if (bDebugLoader) Log("Loading model: %s", (buffer+header.nameOfs));

    // Get vertices
    if (bDebugLoader) Log("  Vertice : %d", header.nVertices);
    ModelVertex* origVertices = (ModelVertex*)(buffer + header.ofsVertices);
    Vertex* vertices = new Vertex[header.nVertices];

    for (int i = 0; i < header.nVertices; i++)
    {
        FixCoordSystem(origVertices[i].pos);
        FixCoordSystem(origVertices[i].normal);

        // Set the data for our vertices
        vertices[i].fX = origVertices[i].pos[0];
        vertices[i].fY = origVertices[i].pos[1];
        vertices[i].fZ = origVertices[i].pos[2];
        /*vertices[i].fNX = origVertices[i].normal[0];
        vertices[i].fNY = origVertices[i].normal[1];
        vertices[i].fNZ = origVertices[i].normal[2];*/
        vertices[i].fU = origVertices[i].texcoords[0];
        vertices[i].fV = origVertices[i].texcoords[1];
        vertices[i].fBone[0] = origVertices[i].bones[0];
        vertices[i].fBone[1] = origVertices[i].bones[1];
        vertices[i].fBone[2] = origVertices[i].bones[2];
        vertices[i].fBone[3] = origVertices[i].bones[3];
        vertices[i].fWeight[0] = origVertices[i].weights[0]/255.0f;
        vertices[i].fWeight[1] = origVertices[i].weights[1]/255.0f;
        vertices[i].fWeight[2] = origVertices[i].weights[2]/255.0f;
        vertices[i].fWeight[3] = origVertices[i].weights[3]/255.0f;
        //vertices[i].dwColor = ARGB(255,255,255,255);

        // Calculate bounding box
        Vector3 vVert(vertices[i].fX, vertices[i].fY, vertices[i].fZ);
        vBBoxMin = Vector3::Min(&vBBoxMin, &vVert);
        vBBoxMax = Vector3::Max(&vBBoxMax, &vVert);
    }

    //Log("(%f, %f, %f), (%f, %f, %f)", vBBoxMin.x, vBBoxMin.y, vBBoxMin.z, vBBoxMax.x, vBBoxMax.y, vBBoxMax.z);

    vBBoxMin *= 0.5f; // ??
    vBBoxMax *= 0.5f; // ??

    // Get textures
    if (bDebugLoader) Log("  Textures : %d", header.nTextures);
    vector<LPDIRECT3DTEXTURE9> lTexList;
    ModelTextureDef *texdef = (ModelTextureDef*)(buffer + header.ofsTextures);
    uint16 *textures = (uint16*)(buffer + header.ofsTexLookup);

    if (header.nTextures)
    {
        for (int i = 0; i < header.nTextures; i++)
        {
            if (texdef[i].type == 0)
            {
                char texname[256];
                strncpy(texname, (const char*)buffer + texdef[i].nameOfs, texdef[i].nameLen);
                texname[texdef[i].nameLen] = 0;
                string path(texname);
                path = "Textures\\" + path;
                if (FixTextureName(&path))
                {
                    if (bDebugLoader) Log(path.c_str());
                    LPDIRECT3DTEXTURE9 tex = (LPDIRECT3DTEXTURE9)mGFXMgr->LoadTexture(path);
                    lTexList.push_back(tex);
                }
                else
                {
                    Log("# Error # : Can't load texture \"%s\"", path.c_str());
                    lTexList.push_back(0);
                }
            }
            else
                lTexList.push_back(0);
        }
    }

    ModelView *view = (ModelView*)(buffer + header.ofsViews);

    // Worst LOD
    int v = 0;
    // Best LOD
    //int v = header.nViews-1;

    uint16 *indexLookup = (uint16*)(buffer + view[v].ofsIndex);
    uint16 *triangles = (uint16*)(buffer + view[v].ofsTris);
    uint16 *indices = new uint16[view[v].nTris];
    for (int i = 0; i < view[v].nTris; i++)
    {
        indices[i] = indexLookup[triangles[i]];
    }

    // Get submeshes
    iMeshNbr = view[v].nSub;
    if (iMeshNbr > 0)
    {
        lMeshList = new Mesh*[iMeshNbr];

        if (bDebugLoader) Log("  Submeshes : %d", view[v].nSub);
        ModelSubMesh *sms = (ModelSubMesh*)(buffer + view[v].ofsSub);
        for (int i = 0; i < view[v].nSub; i++)
        {
            Mesh* m = lMeshList[i] = new Mesh();
            m->iID = sms[i].id;
            //Log("[%d] %d", i, m->iID);
            m->iGID = mModelMgr->iMeshNbr;
            m->iVertexNbr = sms[i].nTris;

            m->lVertexList = new Vertex[m->iVertexNbr];

            for (int j = 0; j < m->iVertexNbr; j++)
            {
                m->lVertexList[j] = vertices[indices[sms[i].ofsTris+j]];
            }

            mModelMgr->iMeshNbr++;
        }

        // Apply textures
        ModelTexUnit *texUnit = (ModelTexUnit*)(buffer + view[v].ofsTex);
        for (int i = 0; i < view[v].nTex; i++)
        {
            Mesh* m = lMeshList[texUnit[i].op];
            m->mTex = lTexList[textures[texUnit[i].textureid]];
        }
    }
    else
        lMeshList = NULL;

    // Get animation info, if necessary
    if (IsAnimated(buffer, header))
    {
        bAnimated = true;
        /*uint32 *globalseq = (uint32*)(buffer + header.ofsGlobalSequences);
        for (int i = 0; i < header.nGlobalSequences; i++)
        {
            Log("%d", globalseq[i]);
        }*/

        // Get animations

        if (bDebugLoader) Log("  Animations : %d", header.nAnimations);
        AnimSequence* lAnimList = new AnimSequence[header.nAnimations];
        ModelAnimation *anim = (ModelAnimation*)(buffer + header.ofsAnimations);
        for (int i = 0; i < header.nAnimations; i++)
        {
            AnimSequence* as = &lAnimList[i];
            as->iID = anim[i].animID;
            as->iRID = i;
            as->iStart = anim[i].timeStart;
            as->iEnd = anim[i].timeEnd;
            as->iLoop = anim[i].loopType;
            int next = as->iNextAnim = anim[i].next;
            as->iNextNbr = 0;
            as->vBBoxMin = Vector3(anim[i].boxA[0], anim[i].boxA[2], anim[i].boxA[1]);
            as->vBBoxMax = Vector3(anim[i].boxB[0], anim[i].boxB[2], anim[i].boxB[1]);

            as->vBBoxMin *= 0.5f;
            as->vBBoxMax *= 0.5f;

            while (next != -1)
            {
                as->iNextNbr++;
                next = anim[next].next;
            }

            if (bDebugLoader) Log("    %d, %d, %d, %d", as->iID, as->iStart, as->iEnd, as->iLoop);
        }

        lBoneList = new Bone*[header.nBones];
        iBoneNbr = header.nBones;

        // Get bones
        if (bDebugLoader) Log("  Bones : %d", header.nBones);
        ModelBoneDef *bones = (ModelBoneDef*)(buffer + header.ofsBones);
        for (int i = 0; i < header.nBones; i++)
        {
            Bone* b = lBoneList[i] = new Bone();
            b->iID = i;
            b->iSequence = bones[i].animid;
            b->iParent = bones[i].parent;
            b->fX = bones[i].pivot[0];
            b->fY = bones[i].pivot[2];
            b->fZ = -bones[i].pivot[1];

            if (bDebugLoader) Log("%d, %d, %f, %f, %f", bones[i].animid, bones[i].parent, bones[i].pivot[0], bones[i].pivot[2], -bones[i].pivot[1]);

            // Translation
            b->mTranslate = new Anim();
            b->mTranslate->Load(ANIM_TYPE_TRANSLATE, buffer, &bones[i].translation, lAnimList, header.nAnimations);

            // Rotation
            b->mRotate = new Anim();
            b->mRotate->Load(ANIM_TYPE_ROTATE, buffer, &bones[i].rotation, lAnimList, header.nAnimations);

            // Scale
            b->mScale = new Anim();
            b->mScale->Load(ANIM_TYPE_SCALE, buffer, &bones[i].scaling, lAnimList, header.nAnimations);

            if (!b->mTranslate->bUsed && !b->mRotate->bUsed && !b->mScale->bUsed)
                b->bAnimated = false;
            else
                b->bAnimated = true;
        }

        // Create child links :
        // Count the number of childs for each bone
        for (int i = 0; i != iBoneNbr; i++)
        {
            Bone* child = lBoneList[i];
            if (child->iParent != -1)
            {
                lBoneList[child->iParent]->iChildNbr++;
            }
        }
        // Create the table
        for (int i = 0; i != iBoneNbr; i++)
        {
            Bone* parent = lBoneList[i];
            if (parent->iChildNbr > 0)
            {
                parent->lChildList = new int[parent->iChildNbr];
                parent->iChildNbr = 0; // This one will be used for counting just above
            }
            else
                parent->lChildList = NULL;
        }
        // Then at last, register childs
        for (int i = 0; i != iBoneNbr; i++)
        {
            Bone* child = lBoneList[i];
            if (child->iParent != -1)
            {
                Bone* parent = lBoneList[child->iParent];
                parent->iChildNbr++;
                parent->lChildList[parent->iChildNbr-1] = i;
            }
        }

        // Set vertex links
        for (int g = 0; g != iMeshNbr; g++)
        {
            Mesh* m = lMeshList[g];

            int bCount = 0;
            // For each mesh of this model,
            // We first get the number of different bones and
            // store them in the ID conversion map
            for (int h = 0; h != m->iVertexNbr; h++)
            {
                // For each vertex of this submesh,
                Vertex* v = &m->lVertexList[h];
                for (int j = 0; j < 4; j++)
                {
                    // And for each bone linked to this vertex (if any),
                    if (m->lBoneIDToRIDMap.find((int)v->fBone[j]) == m->lBoneIDToRIDMap.end())
                    {
                        // Add this bone to the ID map
                        m->lBoneIDToRIDMap[(int)v->fBone[j]] = bCount;
                        //m->lBoneList[bCount].push_back(lBoneList[(int)v->fBone[j]].iID);
                        bCount++;
                    }

                    // Change the vertex's bone ID to a relative one
                    v->fBone[j] = m->lBoneIDToRIDMap[(int)v->fBone[j]];
                }
            }

            // Then build the local bone list
            m->iBoneNbr = bCount;
            m->lBoneList = new int[m->iBoneNbr];
            map<int, int>::iterator iterID;
            for (iterID = m->lBoneIDToRIDMap.begin(); iterID != m->lBoneIDToRIDMap.end(); iterID++)
            {
                m->lBoneList[iterID->second] = iterID->first;
            }
        }

        // Register highest parent bones
        iBaseBoneNbr = 0;
        for (int i = 0; i != iBoneNbr; i++)
        {
            if (lBoneList[i]->iParent == -1)
                iBaseBoneNbr++;
        }
        lBaseBoneList = new int[iBaseBoneNbr];
        int j = 0;
        for (int i = 0; i != iBoneNbr; i++)
        {
            if (lBoneList[i]->iParent == -1)
            {
                lBaseBoneList[j] = i;
                j++;
            }
        }

        // Create the animation manager
        mAnimMgr = new AnimManager(this, lAnimList, header.nAnimations);

        //delete[] lAnimList;
    }
    else
    {
        bAnimated = false;
        lBoneList = NULL;
    }

    bShown = true;
    SetPosition(Vector3(0,0,0));
    SetOrientation(Vector3(0,0,0));
    SetScale(Vector3(1,1,1));
    bUpdateWMat = true;

    delete[] vertices;
    delete[] indices;
    delete[] buffer;

    if (bDebugLoader) Log("Model loaded !");
}

void Model::Render()
{
    if (bShown)
    {
        if (bAnimated)
        {
            mAnimMgr->Update(mTimeMgr->GetDelta());
        }

        double time = mUpdateTimer->GetElapsed();
        if (mUpdateTimer->Ticks())
        {
            hge->Gfx_BeginScene(mRTarget, true);
            hge->Gfx_Clear(ARGB(0,0,0,0));

            if (bUpdateWMat)
            {
                mWorld = mScale*mRot*mPos;
                bUpdateWMat = false;
            }

            if (bUpdateBBoxes)
            {
                UpdateBBox();
                bUpdateBBoxes = false;
            }

            mGFXMgr->SetWorldMatrix(mWorld);
            mGFXMgr->SetProjectionMatrix(mProj);

            // Send World*View*Proj matrix, plus lights' properties to the shaders
            mGFXMgr->UpdateVertexShader(this);

            for (int i = 0; i < iMeshNbr; i++)
            {
                Mesh* m = lMeshList[i];
                if (m->bShown)
                {
                    if (bAnimated)
                    {
                        // Send bone matrices to the vertex shader
                        int bNbr = 0;
                        D3DXMATRIX** tmp = mAnimMgr->GetMeshMatrices(m, &bNbr);

                        if (bNbr != 0)
                            mGFXMgr->mVSConstantTable->SetMatrixPointerArray(
                                mGFXMgr->mDxDevice,
                                mGFXMgr->mVSCBoneMat,
                                (const D3DXMATRIX**)tmp,
                                bNbr
                            );

                        delete[] tmp;
                    }

                    mGFXMgr->SetTexture(m->mTex);
                    mGFXMgr->mDxDevice->DrawPrimitive(D3DPT_TRIANGLELIST, m->iVertexOff, m->iVertexNbr/3);
                }
            }

            hge->Gfx_EndScene();

            //mAnimMgr->bNewFrame = true;
        }
    }
}

hgeSprite* Model::GetSprite()
{
    return mSprite;
}

HTARGET Model::GetRTarget()
{
    return mRTarget;
}

void Model::SetSubMeshTexture( int iSubMeshID, std::string sFile )
{
    if (iSubMeshID < iMeshNbr)
    {
        Mesh* m = lMeshList[iSubMeshID];
        LPDIRECT3DTEXTURE9 tex = 0;

        if (FixTextureName(&sFile))
            tex = (LPDIRECT3DTEXTURE9)mGFXMgr->LoadTexture(sFile);
        else
            Log("# Error # : Can't load texture \"%s\"", sFile.c_str());

        m->mTex = tex;
    }
}

void Model::SetSubMeshTexture( int iSubMeshID, HTEXTURE tex )
{
    if (iSubMeshID < iMeshNbr)
    {
        Mesh* m = lMeshList[iSubMeshID];
        m->mTex = (LPDIRECT3DTEXTURE9)tex;
    }
}

void Model::ApplySkin(string sFile)
{
    LPDIRECT3DTEXTURE9 tex = 0;
    if (FixTextureName(&sFile))
        tex = (LPDIRECT3DTEXTURE9)mGFXMgr->LoadTexture(sFile);
    else
        Log("# Error # : Can't load texture \"%s\"", sFile.c_str());

    for (int i = 0; i < iMeshNbr; i++)
    {
        Mesh* m = lMeshList[i];
        if (m->bIsBody)
            m->mTex = tex;
    }
}

void Model::Show( int iSubMeshID )
{
    // If -1, show the complete model
    if (iSubMeshID <= -1)
    {
        if (!bShown)
        {
            // If the model was hidden, show it
            bShown = true;
        }
        else
        {
            // If the model was already shown, force show all submeshes
            for (int i = 0; i < iMeshNbr; i++)
                lMeshList[i]->bShown = true;
        }

        mModelMgr->UpdateVertexList();
    }
    else if (iSubMeshID < iMeshNbr)
    {
        if (bShown == false)
        {
            // If the model was previously hidden, hide every submesh
            for (int i = 0; i < iMeshNbr; i++)
                lMeshList[i]->bShown = false;

            bShown = true;
        }

        // And display this one anyway
        if (!lMeshList[iSubMeshID]->bShown)
        {
            lMeshList[iSubMeshID]->bShown = true;
            mModelMgr->UpdateVertexList();
        }
    }
}

void Model::Hide( int iSubMeshID )
{
    // If -1, hide the complete model
    if (iSubMeshID <= -1)
    {
        if (bShown)
        {
            // If the model was previously shown, hide it
            bShown = false;
        }
        else
        {
            // If the model was already hidden, force hide all submeshes
            for (int i = 0; i < iMeshNbr; i++)
                lMeshList[i]->bShown = false;
        }
        mModelMgr->UpdateVertexList();
    }
    else if (iSubMeshID < iMeshNbr)
    {
        if (lMeshList[iSubMeshID]->bShown)
        {
            lMeshList[iSubMeshID]->bShown = false;
            mModelMgr->UpdateVertexList();
        }
    }
}

bool Model::Hidden()
{
    return !bShown;
}

int Model::GetSubMeshID(int category, int variation)
{
    static int iPrevID = -1;
    static int iLastCV = -1;

    int ID;
    if (category == MODEL_SUBMCAT_BODY)
        ID = 0;
    else
    {
        if (variation < 1) variation = 1;
        ID = category*100+variation;
    }

    if (iLastCV != ID)
    {
        iPrevID = -1;
        iLastCV = ID;
    }

    int i = iPrevID+1;
    iPrevID = -1;

    while (i < iMeshNbr)
    {
        if (ID == lMeshList[i]->iID)
        {
            iPrevID = i;
            break;
        }
        i++;
    }

    return iPrevID;
}

void Model::SetPosition( Vector3 nPos )
{
    vPos = nPos;

    D3DXMatrixTranslation(&mPos, vPos.x, vPos.y, vPos.z);
    bUpdateWMat = true;
}

Vector3 Model::GetPosition()
{
    return vPos;
}

void Model::SetOrientation( Vector3 nOrient )
{
    vOrient = nOrient;

    D3DXMATRIX matRotateX;
    D3DXMatrixRotationX(&matRotateX, vOrient.x);
    D3DXMATRIX matRotateY;
    D3DXMatrixRotationY(&matRotateY, vOrient.y);
    D3DXMATRIX matRotateZ;
    D3DXMatrixRotationZ(&matRotateZ, vOrient.z);

    mRot = matRotateX*matRotateZ*matRotateY;
    bUpdateWMat = true;
    bUpdateBBoxes = true;
}

Vector3 Model::GetOrientation()
{
    return vOrient;
}

void Model::SetScale( Vector3 nScale )
{
    vScale = nScale;

    D3DXMatrixScaling(&mScale, vScale.x, vScale.y, vScale.z);
    bUpdateWMat = true;
    bUpdateBBoxes = true;
}

Vector3 Model::GetScale()
{
    return vScale;
}

Point DXVECTORToPoint(D3DXVECTOR3* v)
{
    return Point(v->x, v->y);
}

void Model::UpdateBBox()
{
    // Project bounding box to screen
    D3DXVECTOR3 points[8];
    points[0] = vBBoxMin.GetDXVector();
    points[1] = D3DXVECTOR3(vBBoxMin.x, vBBoxMin.y, vBBoxMax.z);
    points[2] = D3DXVECTOR3(vBBoxMax.x, vBBoxMin.y, vBBoxMax.z);
    points[3] = D3DXVECTOR3(vBBoxMax.x, vBBoxMin.y, vBBoxMin.z);
    points[4] = vBBoxMax.GetDXVector();
    points[5] = D3DXVECTOR3(vBBoxMax.x, vBBoxMax.y, vBBoxMin.z);
    points[6] = D3DXVECTOR3(vBBoxMin.x, vBBoxMax.y, vBBoxMin.z);
    points[7] = D3DXVECTOR3(vBBoxMin.x, vBBoxMax.y, vBBoxMax.z);

    D3DVIEWPORT9 vp;
    mGFXMgr->mDxDevice->GetViewport(&vp);
    //vp.Width = vp.Height = iRTSize;

    for (int i = 0; i < 8; i++)
        D3DXVec3Project(&points[i], &points[i], &vp, &mProj, &mGFXMgr->mViewMat, &mWorld);

    // Build Parallelograms
    // Lower base
    Parallelogram p;
    p.mP[0] = DXVECTORToPoint(&points[0]);
    p.mP[1] = DXVECTORToPoint(&points[1]);
    p.mP[2] = DXVECTORToPoint(&points[2]);
    p.mP[3] = DXVECTORToPoint(&points[3]);
    lBBoxeList[0] = p;

    // Higher base
    p.mP[0] = DXVECTORToPoint(&points[4]);
    p.mP[1] = DXVECTORToPoint(&points[5]);
    p.mP[2] = DXVECTORToPoint(&points[6]);
    p.mP[3] = DXVECTORToPoint(&points[7]);
    lBBoxeList[1] = p;

    // Left side
    p.mP[0] = DXVECTORToPoint(&points[1]);
    p.mP[1] = DXVECTORToPoint(&points[2]);
    p.mP[2] = DXVECTORToPoint(&points[4]);
    p.mP[3] = DXVECTORToPoint(&points[7]);
    lBBoxeList[2] = p;

    // Right side
    p.mP[0] = DXVECTORToPoint(&points[0]);
    p.mP[1] = DXVECTORToPoint(&points[6]);
    p.mP[2] = DXVECTORToPoint(&points[5]);
    p.mP[3] = DXVECTORToPoint(&points[3]);
    lBBoxeList[3] = p;

    // Front side
    p.mP[0] = DXVECTORToPoint(&points[2]);
    p.mP[1] = DXVECTORToPoint(&points[3]);
    p.mP[2] = DXVECTORToPoint(&points[5]);
    p.mP[3] = DXVECTORToPoint(&points[4]);
    lBBoxeList[4] = p;

    // Back side
    p.mP[0] = DXVECTORToPoint(&points[0]);
    p.mP[1] = DXVECTORToPoint(&points[1]);
    p.mP[2] = DXVECTORToPoint(&points[7]);
    p.mP[3] = DXVECTORToPoint(&points[6]);
    lBBoxeList[5] = p;
}

Parallelogram RectToParallelogram(hgeRect* rect)
{
    Parallelogram p;
    p.mP[0] = Point(rect->x1, rect->y1);
    p.mP[1] = Point(rect->x2, rect->y1);
    p.mP[2] = Point(rect->x2, rect->y2);
    p.mP[4] = Point(rect->x1, rect->y2);

    return p;
}

bool Test(Point* p, Parallelogram* P)
{
    bool between1 = false;
    Point diff1 = P->mP[1]-P->mP[0];
    if (diff1.fX == 0)
    {
        float coef1 = diff1.fX/diff1.fY;
        float off1 = P->mP[0].fX - P->mP[0].fY*coef1;
        float off2 = P->mP[2].fX - P->mP[2].fY*coef1;
        between1 = (p->fY*coef1+max(off1,off2) > p->fX) && (p->fX > p->fY*coef1+min(off1,off2));
    }
    else
    {
        float coef1 = diff1.fY/diff1.fX;
        float off1 = P->mP[0].fY - P->mP[0].fX*coef1;
        float off2 = P->mP[2].fY - P->mP[2].fX*coef1;
        between1 = (p->fX*coef1+max(off1,off2) > p->fY) && (p->fY > p->fX*coef1+min(off1,off2));
    }

    bool between2 = false;
    Point diff3 = P->mP[2]-P->mP[1];
    if (diff3.fX == 0)
    {
        float coef3 = diff3.fX/diff3.fY;
        float off3 = P->mP[0].fX - P->mP[0].fY*coef3;
        float off4 = P->mP[2].fX - P->mP[2].fY*coef3;
        between2 = (p->fY*coef3+max(off3,off4) > p->fX) && (p->fX > p->fY*coef3+min(off3,off4));
    }
    else
    {
        float coef3 = diff3.fY/diff3.fX;
        float off3 = P->mP[1].fY - P->mP[1].fX*coef3;
        float off4 = P->mP[3].fY - P->mP[3].fX*coef3;
        between2 = (p->fX*coef3+max(off3,off4) > p->fY) && (p->fY > p->fX*coef3+min(off3,off4));
    }

    return (between1 && between2);
}

bool Test(Parallelogram* p1, Parallelogram* p2)
{
    bool inter = false;
    for (int i = 0; (i < 4) && !inter; i++)
    {
        inter = Test(&p1->mP[i], p2);
        if (!inter)
            inter = Test(&p2->mP[i], p1);
    }
    return inter;
}

bool Model::Intersect(hgeRect* rect)
{
    Parallelogram p = RectToParallelogram(rect);
    bool inter = false;
    for (int i = 0; i < 6; i++)
    {
        if (Test(&lBBoxeList[i], &p))
        {
            inter = true;
            break;
        }
    }

    return inter;
}

bool Model::TestPoint(float fMX, float fMY)
{
    Point p(fMX, fMY);
    bool inter = false;
    for (int i = 0; i < 6; i++)
    {
        if (Test(&p, &lBBoxeList[i]))
        {
            inter = true;
            break;
        }
    }

    return inter;
}

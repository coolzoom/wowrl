/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include <math.h>
#include "wowrl_vectors.h"

#include "wowrl_gfxmanager.h"

extern GFXManager* mGFXMgr;

Vector3 Vector3::Interpolate(float r, Vector3 v2)
{
    return (*this)*(1.0f-r) + v2*r;
}

// Linear interpolation
Vector4 Vector4::InterpolateL(float r, Vector4 v2)
{
    return (*this)*(1.0f-r) + v2*r;
}

// More accurate version
Vector4 Vector4::InterpolateL2(float r, Vector4 v2)
{
    // This prevents wrong interpolation direction
    float dot = (*this)*v2;
    if (dot < 0)
        v2 *= -1;

    // Linear interpolation
    Vector4 v = (*this)*(1.0f-r) + v2*r;

    // Normalization is needed if the difference between the
    // two quaternions is important.
    v.Normalize();
    return v;
}

// Spherical interpolation
Vector4 Vector4::InterpolateS(float r, Vector4 v2)
{
    Vector4 v1 = (*this);
    float dot = v1*v2;

    if (fabs(dot) > 0.9995f)
    {
        return this->InterpolateL(r, v2);
    }

    if (dot < 0)
        v2 *= -1;

    float a = acosf(dot)*r;
    Vector4 v = (v2 - v1*dot);
    v.Normalize();

    return v1*cosf(a) + v*sinf(a);
}

void D3DXMatrixViewport(D3DXMATRIX* mat)
{
    D3DVIEWPORT9 vp;
    mGFXMgr->mDxDevice->GetViewport(&vp);
    mat->_12 = mat->_13 = mat->_14 = mat->_21 = mat->_23 = mat->_24 =
    mat->_31 = mat->_32 = mat->_34 = 0;
    mat->_44 = 1;
    mat->_11 = vp.Width/2;
    mat->_22 = -vp.Height/2;
    mat->_33 = vp.MaxZ - vp.MinZ;
    mat->_41 = vp.X + vp.Width/2;
    mat->_42 = vp.Y + vp.Height/2;
    mat->_43 = vp.MinZ;
}

void D3DXMatrixInterpolateL(D3DXMATRIX* mat, D3DXMATRIX* m1, D3DXMATRIX* m2, float fCoef)
{
    mat->_11 = m1->_11*(1-fCoef) + m2->_11*fCoef;
    mat->_12 = m1->_12*(1-fCoef) + m2->_12*fCoef;
    mat->_13 = m1->_13*(1-fCoef) + m2->_13*fCoef;
    mat->_14 = m1->_14*(1-fCoef) + m2->_14*fCoef;

    mat->_21 = m1->_21*(1-fCoef) + m2->_21*fCoef;
    mat->_22 = m1->_22*(1-fCoef) + m2->_22*fCoef;
    mat->_23 = m1->_23*(1-fCoef) + m2->_23*fCoef;
    mat->_24 = m1->_24*(1-fCoef) + m2->_24*fCoef;

    mat->_31 = m1->_31*(1-fCoef) + m2->_31*fCoef;
    mat->_32 = m1->_32*(1-fCoef) + m2->_32*fCoef;
    mat->_33 = m1->_33*(1-fCoef) + m2->_33*fCoef;
    mat->_34 = m1->_34*(1-fCoef) + m2->_34*fCoef;

    mat->_41 = m1->_41*(1-fCoef) + m2->_41*fCoef;
    mat->_42 = m1->_42*(1-fCoef) + m2->_42*fCoef;
    mat->_43 = m1->_43*(1-fCoef) + m2->_43*fCoef;
    mat->_44 = m1->_44*(1-fCoef) + m2->_44*fCoef;
}

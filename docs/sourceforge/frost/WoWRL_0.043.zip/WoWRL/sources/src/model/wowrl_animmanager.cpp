/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           AnimManager source           */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the AnimManager class.             */
/*       The AnimManager takes care of a  */
/*  Model animations. That is : update,   */
/*  play, pause, select, ...              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"

#include "wowrl_animmanager.h"
#include "wowrl_modelstructs.h"
#include "wowrl_unit.h"

#define ANIMATION_TRANSITION_TIME 100.0f // Transition time in milisecond

using namespace std;

extern HGE *hge;
extern TimeManager *mTimeMgr;

Anim::Anim()
{
    bUsed = false;
    bIsCopy = false;
    bTDataBuilt = false;
    mFirstData = NULL;
    mSecondData = NULL;
    mTSecondData = NULL;
    lTimes = NULL;
    lData = NULL;
    lInfo = NULL;

    iOldTSequence = -1;
}

Anim::Anim(const Anim &a)
{
    bUsed = a.bUsed;
    bIsCopy = true;
    bTDataBuilt = false;
    mFirstData = NULL;
    mSecondData = NULL;
    mTSecondData = NULL;

    iOldTSequence = -1;

    if (bUsed)
    {
        iInterpolation = a.iInterpolation;
        iType = a.iType;
        iActualUpID = a.iActualUpID;
        iFirstTime = a.iFirstTime;
        iSecondTime = a.iSecondTime;

        iTimeNbr = a.iTimeNbr;
        lTimes = a.lTimes;
        lData = a.lData;

        iSequenceNbr = a.iSequenceNbr;

        lInfo = a.lInfo;
    }
}

Anim::~Anim()
{
    if (bUsed && !bIsCopy)
    {
        if (lTimes) delete[] lTimes;
        if (lData) delete[] lData;
        if (lInfo) delete[] lInfo;
    }
}

Bone::Bone()
{
    D3DXMatrixIdentity(&mMat);
    lChildList = NULL;
    bRoot = false;
    bUpperBody = false;
    bUnknown = false;
    iChildNbr = 0;
    iLastUpdated = 0;
    iLastTime = -1;
    fLastCoef = -1.0f;
}

Bone::Bone(const Bone &b)
{
    iID = b.iID;
    iSequence = b.iSequence;
    iParent = b.iParent;
    bAnimated = b.bAnimated;
    bRoot = b.bRoot;
    bUpperBody = b.bUpperBody;
    bUnknown = b.bUnknown;
    fX = b.fX;
    fY = b.fY;
    fZ = b.fZ;
    mTranslate = b.mTranslate;
    mRotate = b.mRotate;
    mScale = b.mScale;
    iChildNbr = b.iChildNbr;
    if (iChildNbr > 0)
    {
        lChildList = new int[iChildNbr];
        memcpy(lChildList, b.lChildList, iChildNbr*sizeof(int));
    }
    else
        lChildList = NULL;

    if (b.mTranslate)
        mTranslate = new Anim(*b.mTranslate);
    else
        mTranslate = NULL;

    if (b.mRotate)
        mRotate = new Anim(*b.mRotate);
    else
        mRotate = NULL;

    if (b.mScale)
        mScale = new Anim(*b.mScale);
    else
        mScale = NULL;

    D3DXMatrixIdentity(&mMat);

    iLastUpdated = 0;
    iLastTime = -1;
    fLastCoef = -1.0f;
}

Bone::~Bone()
{
    if (lChildList) delete[] lChildList;
    if (mTranslate) delete mTranslate;
    if (mRotate) delete mRotate;
    if (mScale) delete mScale;
}

AnimManager::AnimManager(Model* m, AnimSequence* asList, int animNbr)
{
    mParent = m;
    mActualAnim = NULL;
    mOldAnim = NULL;
    bTransition = false;
    bPaused = true;
    bPauseAfter = false;
    bNewFrame = true;

    /*for (int i = 0; i < animNbr; i++)
    {
        lAnimList.insert(make_pair(asList[i].iID, asList[i]));
    }*/
    lAnimList = asList;
    iAnimNbr = animNbr;

    iTime = 0;
    iTrueTime = 0;
    iUpdatedBones = 0;
    iLastUpdatedBones = 0;
    iLastBaseBone = 0;
    iLastBoneChild = 0;
    iBoneToUpdate = 0;
}

AnimManager::AnimManager(const AnimManager &mgr)
{
    mParent = mgr.mParent;
    mActualAnim = NULL;
    mOldAnim = NULL;

    bTransition = false;
    bPaused = mgr.bPaused;
    bPauseAfter = mgr.bPauseAfter;
    lAnimList = mgr.lAnimList;
    iAnimNbr = mgr.iAnimNbr;
    if (iAnimNbr > 0)
    {
        lAnimList = new AnimSequence[iAnimNbr];
        memcpy(lAnimList, mgr.lAnimList, iAnimNbr*sizeof(AnimSequence));
    }
    else
        lAnimList = NULL;

    iTime = mgr.iTime;
    iTrueTime = mgr.iTime;
    iUpdatedBones = 0;
    iLastUpdatedBones = 0;
    iLastBaseBone = 0;
    iLastBoneChild = 0;
    iBoneToUpdate = 0;
    bNewFrame = true;
}

AnimManager::~AnimManager()
{
    if (lAnimList) {delete[] lAnimList; lAnimList = NULL;}
}

void AnimManager::SetParent(Model* m)
{
    mParent = m;
}

AnimSequence* AnimManager::GetAnim(AnimID ID)
{
    if (ID == ANIM_NONE)
        return mActualAnim;
    else
    {
        AnimSequence* a = NULL;
        for (int i = 0; i < iAnimNbr; i++)
        {
            if (lAnimList[i].iID == ID)
            {
                a = &lAnimList[i];
                break;
            }
        }
        return a;
    }
}

void AnimManager::RandomAnim()
{
    if (mRefAnim != NULL)
    {
        mOldAnim = mActualAnim;
        mActualAnim = mRefAnim;
        if (mRefAnim->iNextNbr != 0)
        {
            if (!mParent->GetParent()->bEmote)
            {
                // 8 times out of 10, the base animation is used.
                // Variations are used 2 times out of 10.
                if (hge->Random_Int(0, 100) > 80)
                {
                    int a = hge->Random_Int(1, mRefAnim->iNextNbr);
                    for (int i = 0; i < a; i++)
                    {
                        mActualAnim = &lAnimList[mActualAnim->iNextAnim];
                    }
                }
            }
            else
            {
                int a = hge->Random_Int(0, mRefAnim->iNextNbr);
                for (int i = 0; i < a; i++)
                {
                    mActualAnim = &lAnimList[mActualAnim->iNextAnim];
                }
            }
        }
        iTrueTime = iTime = mActualAnim->iStart;
    }

    if ( (mOldAnim != NULL) && (mActualAnim != NULL) && (mOldAnim != mActualAnim) )
    {
        bTransition = true;
    }

    if (!bTransition)
    {
        for (int i = 0; i < mParent->iBaseBoneNbr; i++)
        {
            // Update every bone for this animation
            mParent->lBoneList[mParent->lBaseBoneList[i]]->Update(mParent, iTime, mActualAnim->iRID, true);
        }
    }
}

void AnimManager::SetAnim(AnimID a, bool pauseAfter)
{
    if (a == ANIM_NONE)
    {
        iTime = 0;
        iTrueTime = 0;
        mActualAnim = NULL;
        mRefAnim = NULL;
    }
    else
    {
        bool bChange = true;
        if (mActualAnim != NULL)
        {
            if (mActualAnim->iID == a)
                bChange = false;
        }

        if (bChange)
        {
            mRefAnim = NULL;

            for (int i = 0; i < iAnimNbr; i++)
            {
                if (lAnimList[i].iID == a)
                {
                    mRefAnim = &lAnimList[i];
                    break;
                }
            }

            RandomAnim();
        }
    }

    if (mActualAnim != NULL)
    {
        mParent->vBBoxMin = mActualAnim->vBBoxMin;
        mParent->vBBoxMax = mActualAnim->vBBoxMax;
    }

    bPauseAfter = pauseAfter;
}

void AnimManager::Play()
{
    if (bPaused)
        bPaused = false;
}

void AnimManager::Pause()
{
    if (!bPaused)
        bPaused = true;
}

void AnimManager::Update( float dt )
{
    if ( !bPaused && (mActualAnim != NULL) )
    {
        if ( (mOldAnim != NULL) && bTransition )
        {
            if (bNewFrame)
            {
                iTime += ToInt(MODEL_UPDATE_TIME*1000.0f);
                iUpdatedBones = 0;
                iLastBaseBone = 0;
                bNewFrame = false;
            }

            if (iTrueTime+ToInt(dt*1000.0f) < iTime)
                iBoneToUpdate = ToInt((mParent->iBoneNbr/MODEL_UPDATE_TIME)*dt);
            else
            {
                iBoneToUpdate = mParent->iBoneNbr-iUpdatedBones;
                bNewFrame = true;
            }

            float fCoef = (iTime-mActualAnim->iStart)/ANIMATION_TRANSITION_TIME;
            if (fCoef <= 1.0f)
            {
                // Interpolate between the two animation sequences
                for (int i = iLastBaseBone; i < mParent->iBaseBoneNbr; i++)
                {
                    // Update every bone
                    if (!mParent->lBoneList[mParent->lBaseBoneList[i]]->UpdateT(mParent, fCoef, mActualAnim->iRID))
                    {
                        iLastBaseBone = i;
                        break;
                    }
                }

                iUpdatedBones += iLastUpdatedBones;
                iLastUpdatedBones = 0;

                // Update the timer
                if (dt > 0.1f)
                    dt = 0.1f;
                iTrueTime += (int)(dt*1000.0f);
            }
            else
            {
                bTransition = false;
                iTrueTime = iTime = mActualAnim->iStart;
                for (int i = 0; i < mParent->iBaseBoneNbr; i++)
                {
                    // Update every bone for this animation
                    mParent->lBoneList[mParent->lBaseBoneList[i]]->Update(mParent, iTime, mActualAnim->iRID, true);
                }
            }
        }
        else
        {
            // Just animate the model
            if ( (iTime >= mActualAnim->iStart) && (iTime < mActualAnim->iEnd) )
            {
                if (bNewFrame)
                {
                    iTime += ToInt(MODEL_UPDATE_TIME*1000.0f);
                    iUpdatedBones = 0;
                    iLastBaseBone = 0;
                    bNewFrame = false;
                }

                if (iTrueTime+ToInt(dt*1000.0f) < iTime)
                    iBoneToUpdate = ToInt((mParent->iBoneNbr/MODEL_UPDATE_TIME)*dt);
                else
                {
                    iBoneToUpdate = mParent->iBoneNbr-iUpdatedBones;
                    bNewFrame = true;
                }

                for (int i = iLastBaseBone; i < mParent->iBaseBoneNbr; i++)
                {
                    // Update every bone for this animation
                    if (!mParent->lBoneList[mParent->lBaseBoneList[i]]->Update(mParent, iTime, mActualAnim->iRID))
                    {
                        iLastBaseBone = i;
                        break;
                    }
                }

                iUpdatedBones += iLastUpdatedBones;
                iLastUpdatedBones = 0;

                // Update the timer
                if (dt > 0.1f)
                    dt = 0.1f;
                iTrueTime += (int)(dt*1000.0f);
            }
            else
            {
                // If this animation should be looped, set the timer back to
                // the animation's start, else set no animation.
                if (mActualAnim->iLoop == 0)
                    RandomAnim();
                else
                {
                    iTime = mActualAnim->iEnd;
                    // Update bones one last time before the model pauses
                    for (int i = 0; i < mParent->iBaseBoneNbr; i++)
                    {
                        // Update every bone for this animation
                        mParent->lBoneList[mParent->lBaseBoneList[i]]->Update(mParent, iTime, mActualAnim->iRID, true);
                    }
                    mParent->GetParent()->bEmote = false;

                    if (!bPauseAfter)
                        SetAnim(ANIM_STAND);
                    else
                        Pause();
                }
            }
        }
    }
}

D3DXMATRIX** AnimManager::GetMeshMatrices(Mesh* m, int* bNbr)
{
    D3DXMATRIX** matrices = new D3DXMATRIX*[60];

    for (int i = 0; i < m->iBoneNbr; i++)
    {
        matrices[i] = mParent->lBoneList[m->lBoneList[i]]->GetMatrix();
    }

    (*bNbr) = m->iBoneNbr;

    return matrices;
}

bool Bone::Update( Model* mParent, int iTime, int iSequence, bool forceAll )
{
    if ( (iLastTime != iTime) || forceAll )
    {
        iLastTime = iTime;

        // Apply pivot translation
        D3DXMatrixTranslation(&mMat, -fX, -fY, -fZ);

        D3DXMATRIX m;

        // Apply the scale animation
        if (mScale->GetMatrix(&m, iTime, iSequence))
            mMat *= m;

        // Apply the rotation animation
        if (mRotate->GetMatrix(&m, iTime, iSequence))
            mMat *= m;

        // Apply the translation animation
        if (mTranslate->GetMatrix(&m, iTime, iSequence))
            mMat *= m;

        // Undo the pivot translation
        D3DXMatrixTranslation(&m, fX, fY, fZ);
        mMat *= m;

        if (iParent != -1)
        {
            // If this bone has a parent, apply its matrix
            mMat *= mParent->lBoneList[iParent]->mMat;
        }

        if (!forceAll)
        {
            mParent->mAnimMgr->iLastUpdatedBones++;
            if (mParent->mAnimMgr->iLastUpdatedBones == mParent->mAnimMgr->iBoneToUpdate)
                return false;
        }

        iLastUpdated = 0;
    }

    for (int i = iLastUpdated; i < iChildNbr; i++)
    {
        // Do the same for every child
        if (!mParent->lBoneList[lChildList[i]]->Update(mParent, iTime, iSequence, forceAll))
        {
            iLastUpdated = i;
            return false;
        }
    }

    return true;
}

bool Bone::UpdateT( Model* mParent, float fCoef, int iSequence )
{
    if (fLastCoef != fCoef)
    {
        fLastCoef = fCoef;

        // Apply pivot translation
        D3DXMatrixTranslation(&mMat, -fX, -fY, -fZ);

        D3DXMATRIX m;

        // Apply the scale animation
        if (mScale->GetMatrixT(&m, fCoef, iSequence))
            mMat *= m;

        // Apply the rotation animation
        if (mRotate->GetMatrixT(&m, fCoef, iSequence))
            mMat *= m;

        // Apply the translation animation
        if (mTranslate->GetMatrixT(&m, fCoef, iSequence))
            mMat *= m;

        // Undo the pivot translation
        D3DXMatrixTranslation(&m, fX, fY, fZ);
        mMat *= m;

        if (iParent != -1)
        {
            // If this bone has a parent, apply its matrix
            mMat *= mParent->lBoneList[iParent]->mMat;
        }

        mParent->mAnimMgr->iLastUpdatedBones++;

        iLastUpdated = 0;

        if (mParent->mAnimMgr->iLastUpdatedBones == mParent->mAnimMgr->iBoneToUpdate)
            return false;
    }

    for (int i = iLastUpdated; i < iChildNbr; i++)
    {
        // Do the same for every child
        if (!mParent->lBoneList[lChildList[i]]->UpdateT(mParent, fCoef, iSequence))
        {
            iLastUpdated = i;
            return false;
        }
    }

    return true;
}

bool Anim::GetMatrix( D3DXMATRIX* m, int iTime, int iSequence )
{
    if (bUsed)
    {
        if (bTDataBuilt)
        {
            bTDataBuilt = false;
        }

        if (iTime == lInfo[iSequence].iStartTime)
        {
            // We just started/restarted this animation
            if (iTime == lInfo[iSequence].iLowestTime)
            {
                // This bone is immediatly animated for
                // this sequence :
                // We take its first frame for this
                // sequence (which is the same as the
                // the first frame of the sequence)
                // and the one just after.
                iActualUpID = lInfo[iSequence].iStartID+1;
                iFirstTime = iTime;
                iSecondTime = lTimes[iActualUpID];
                mFirstData = &lData[iActualUpID-1];
                mSecondData = &lData[iActualUpID];
            }
            else
            {
                // This bone is animated a bit later
                // for this sequence :
                // We take its first frame for this
                // sequence and the one just before.
                iActualUpID = lInfo[iSequence].iStartID;
                if (iActualUpID == 0)
                {
                    // There is no data before the first frame
                    iSecondTime = lTimes[iActualUpID];
                    mSecondData = &lData[iActualUpID];
                }
                else
                {
                    iFirstTime = lTimes[iActualUpID-1];
                    iSecondTime = lTimes[iActualUpID];
                    mFirstData = &lData[iActualUpID-1];
                    mSecondData = &lData[iActualUpID];
                }
            }
        }

        if ( (iTime > lInfo[iSequence].iLowestTime) && (iTime < lInfo[iSequence].iHighestTime) )
        {
            // We are in this bone's animation range
            while ( (iTime > iSecondTime) && (iActualUpID != iTimeNbr-1) )
            {
                // Switch to the next frame
                iActualUpID++;

                if (iActualUpID == iTimeNbr)
                {
                    // There is no next frame
                    mFirstData = mSecondData;
                    // We give a little offset to prevent further calculations
                    iSecondTime++;
                }
                mFirstData = mSecondData;
                mSecondData = &lData[iActualUpID];
                iFirstTime = iSecondTime;
                iSecondTime = lTimes[iActualUpID];
            }

            if (iTime > iSecondTime)
            {
                // We reached the end of the keys in the loop, do what's in the elseif
                iActualUpID = iTimeNbr;
                mFirstData = mSecondData;
            }
            // (iTime < iFirstTime) shouldn't happen here.
            // We are between the two frames, that's good
        }
        else if ( (iTime >= lInfo[iSequence].iHighestTime) && (iActualUpID != iTimeNbr) )
        {
            // We should switch to the next frame, but there is none
            iActualUpID = iTimeNbr;
            mFirstData = mSecondData;
        }

        if (iActualUpID == 0)
        {
            // Just use the bone's first frame
            if (iType == ANIM_TYPE_ROTATE)
            {
                mLastData.mQuat = mSecondData->mQuat;
                D3DXMatrixRotationQuaternion(m, &mLastData.mQuat);
            }
            else if (iType == ANIM_TYPE_SCALE)
            {
                mLastData.mVec = mSecondData->mVec;
                D3DXMatrixScaling(m, &mLastData.mVec);
            }
            else if (iType == ANIM_TYPE_TRANSLATE)
            {
                mLastData.mVec = mSecondData->mVec;
                D3DXMatrixTranslation(m, &mLastData.mVec);
            }
        }
        else if (iActualUpID == iTimeNbr)
        {
            // Just use the bone's last frame
            if (iType == ANIM_TYPE_ROTATE)
            {
                mLastData.mQuat = mFirstData->mQuat;
                D3DXMatrixRotationQuaternion(m, &mLastData.mQuat);
            }
            else if (iType == ANIM_TYPE_SCALE)
            {
                mLastData.mVec = mFirstData->mVec;
                D3DXMatrixScaling(m, &mLastData.mVec);
            }
            else if (iType == ANIM_TYPE_TRANSLATE)
            {
                mLastData.mVec = mFirstData->mVec;
                D3DXMatrixTranslation(m, &mLastData.mVec);
            }
        }
        else
        {
            // Interpolate between the two animation data surrounding iTime
            float r = (float)(iTime - iFirstTime)/(float)(iSecondTime - iFirstTime);

            if (iType == ANIM_TYPE_ROTATE)
            {
                mLastData.mQuat= mFirstData->mQuat.InterpolateL(r, mSecondData->mQuat);
                D3DXMatrixRotationQuaternion(m, &mLastData.mQuat);
            }
            else if (iType == ANIM_TYPE_SCALE)
            {
                mLastData.mVec = mFirstData->mVec.Interpolate(r, mSecondData->mVec);
                D3DXMatrixScaling(m, &mLastData.mVec);
            }
            else if (iType == ANIM_TYPE_TRANSLATE)
            {
                mLastData.mVec = mFirstData->mVec.Interpolate(r, mSecondData->mVec);
                D3DXMatrixTranslation(m, &mLastData.mVec);
            }
        }

        return true;
    }

    return false;
}

bool Anim::GetMatrixT( D3DXMATRIX* m, float fCoef, int iSequence )
{
    if (bUsed)
    {
        if ( !bTDataBuilt || (iSequence != iOldTSequence) )
        {
            // Prepare transition
            iOldTSequence = iSequence;
            mTFirstData = mLastData;
            mTSecondData = &lData[lInfo[iSequence].iStartID];
            bTDataBuilt = true;
        }

        if (mTSecondData != NULL)
        {
            if (iType == ANIM_TYPE_ROTATE)
            {
                // Here we use a more accurate interpolation method
                mLastData.mQuat = mTFirstData.mQuat.InterpolateL2(fCoef, mTSecondData->mQuat);
                D3DXMatrixRotationQuaternion(m, &mLastData.mQuat);
            }
            else if (iType == ANIM_TYPE_SCALE)
            {
                mLastData.mVec = mTFirstData.mVec.Interpolate(fCoef, mTSecondData->mVec);
                D3DXMatrixScaling(m, &mLastData.mVec);
            }
            else if (iType == ANIM_TYPE_TRANSLATE)
            {
                mLastData.mVec = mTFirstData.mVec.Interpolate(fCoef, mTSecondData->mVec);
                D3DXMatrixTranslation(m, &mLastData.mVec);
            }
        }

        return true;
    }

    return false;
}

float ShortToFloat( short s )
{
    float f = (s > 0 ? s-32767 : s+32767)/32767.0;
    return f;
}

void Anim::Load(int type, char* buffer, AnimationBlock* anim, AnimSequence* lAnimList, int sequenceNbr)
{
    iType = type;
    iInterpolation = anim->type;
    iTimeNbr = anim->nTimes;
    iSequenceNbr = sequenceNbr;

    if (iTimeNbr != 0)
    {
        bUsed = true;
        lTimes = new int[iTimeNbr];
        lData = new AnimData[iTimeNbr];

        uint32 *times = (uint32*)(buffer + anim->ofsTimes);
        if ( (iType == ANIM_TYPE_SCALE) || (iType == ANIM_TYPE_TRANSLATE) )
        {
            float *values = (float*)(buffer + anim->ofsKeys);

            for (int j = 0; j < anim->nTimes; j++) // nTimes == nKeys
            {
                lTimes[j] = times[j];
                if (iType == ANIM_TYPE_TRANSLATE)
                {
                    // (x, y, z)    =>    (x, z, -y)
                    lData[j].mVec = Vector3(values[j*3], values[j*3+2], -values[j*3+1]);
                }
                else if (iType == ANIM_TYPE_SCALE)
                {
                    // (x, y , z)    =>    (x, z, y)
                    lData[j].mVec = Vector3(values[j*3], values[j*3+2], values[j*3+1]);
                }
            }
        }
        else if (iType == ANIM_TYPE_ROTATE)
        {
            int16 *values = (int16*)(buffer + anim->ofsKeys);

            for (int j = 0; j < anim->nTimes; j++) // nTimes == nKeys
            {
                lTimes[j] = times[j];
                // (x, y, z, w)    =>    (x, z, -y, w)
                lData[j].mQuat = Vector4(
                    ShortToFloat(values[j*4]),
                    ShortToFloat(values[j*4+2]),
                    -ShortToFloat(values[j*4+1]),
                    ShortToFloat(values[j*4+3])
                );
            }
        }

        lInfo = new SequenceInfo[iSequenceNbr];
        for (int j = 0; j < iSequenceNbr; j++)
        {
            lInfo[j].iStartTime = lAnimList[j].iStart;
            lInfo[j].iEndTime = lAnimList[j].iEnd;
            lInfo[j].iLowestTime = -1;
            lInfo[j].iHighestTime = 0;
            for (int k = 0; (k < iTimeNbr) && !lInfo[j].iHighestTime ; k++)
            {
                if ((lTimes[k] >= lAnimList[j].iStart) &&
                    (lInfo[j].iLowestTime == -1))
                {
                    lInfo[j].iLowestTime = lTimes[k];
                    lInfo[j].iStartID = k;
                }
                if (lTimes[k] > lAnimList[j].iEnd)
                {
                    if (k != 0)
                    {
                        lInfo[j].iHighestTime = lTimes[k-1];
                    }
                }
            }
            if (lInfo[j].iLowestTime == -1)
            {
                // This animation doens't contain the sequence starting time,
                // use the last one
                lInfo[j].iLowestTime = lTimes[iTimeNbr-1];
                lInfo[j].iStartID = iTimeNbr-1;
            }
            if (lInfo[j].iHighestTime == 0)
            {
                // This animation doens't contain the sequence ending time,
                // use the last one
                lInfo[j].iHighestTime = lTimes[iTimeNbr-1];
            }
        }
    }
}

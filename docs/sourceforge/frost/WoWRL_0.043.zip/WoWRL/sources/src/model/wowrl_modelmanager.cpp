/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           ModelManager source          */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the ModelManager class.            */
/*       The ModelManager takes care of   */
/*  Model creation, destruction, render,  */
/*  storage, ...                          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"

#include "wowrl_modelmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_lua.h"
#include "wowrl_global.h"

using namespace std;

extern HGE* hge;
extern GUIManager* mGUIMgr;
extern GFXManager* mGFXMgr;

ModelManager::ModelManager()
{
    lVertexList = NULL;
    iVertexNbr = 0;
    iModelNbr = 0;
    iMeshNbr = 0;
}

ModelManager::~ModelManager()
{
    map<string, Model*>::iterator iterModel;
    for (iterModel = lBaseModelList.begin(); iterModel != lBaseModelList.end(); iterModel++)
        delete iterModel->second;

    mModelMgr = NULL;
}

ModelManager* ModelManager::mModelMgr = NULL;

ModelManager* ModelManager::GetSingleton()
{
	if (mModelMgr == NULL)
		mModelMgr = new ModelManager;
	return mModelMgr;
}

Model* ModelManager::CopyModel(Model* m)
{
    Model* model = new Model(*m);
    model->iID = iModelNbr;
    lModelList[model->iID] = model;
    iModelNbr++;

    if (!model->Hidden())
        mModelMgr->UpdateVertexList();

    return model;
}

void ModelManager::RemoveModel(Model* m)
{
    if (lModelList.find(m->iID) != lModelList.end())
    {
        lModelList.erase(lModelList.find(m->iID));
        mModelMgr->UpdateVertexList();
    }
}

Model* ModelManager::LoadModel(string file)
{
    if (lBaseModelList.find(file) == lBaseModelList.end())
    {
        pair<map<string, Model*>::iterator, bool> i;
        i = lBaseModelList.insert(make_pair(file, new Model(file)));
        return i.first->second;
    }
    else
        return lBaseModelList[file];
}

Model* ModelManager::LoadModelTable(lua_State* luaVM, string name)
{
    lua_getglobal(luaVM, "Models");
    lua_getfield(luaVM, -1, name.c_str());

    if (lua_istable(luaVM, -1))
    {
        string file = LUA::GetFieldString("file");
        if (file != "")
        {
            Model* m;
            m = LoadModel(file);

            int iType = LUA::GetFieldInt("type", false, MODEL_TYPE_DOODAD);
            if (iType == MODEL_TYPE_CHARACTER)
            {
                string skin = LUA::GetFieldString("skin", false, "");
                if (FixTextureName(&skin))
                {
                    m->mBodyTex = mGFXMgr->LoadTexture(skin);
                }
                else
                    Log("# Error # : Can't load texture \"%s\"", skin.c_str());
            }

            lua_pop(luaVM, 2);
            return m;
        }
        else
        {
            lua_pop(luaVM, 2);
            Log("# Error # : No file specified for model \"%s\"", name.c_str());
            return NULL;
        }
    }
    else
    {
        lua_pop(luaVM, 2);
        Log("# Error # : Can't find \"%s\" in the model table", name.c_str());
        return NULL;
    }
}

bool ModelManager::ParseModelsDyn(lua_State* luaVM, int state1, int state2, bool* finished, float filling)
{
    static vector<string> lFileList;

    if (state1 == 1)
    {
        Log("Parsing Tables/model_table.lua...");

        int error = luaL_dofile(luaVM, "Tables/model_table.lua");
        if (error) LUA::LogL(luaVM);

        lua_getglobal(luaVM, "Models");
        for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
        {
            if (!lua_isnil(luaVM, -1))
            {
                if (LUA::GetFieldBool("preload", false, false))
                {
                    string file = LUA::GetFieldString("file");
                    if (file != "")
                    {
                        lFileList.push_back(file);
                    }
                }
            }
        }

        lua_pop(luaVM, 1);

        *finished = false;
		return true;
    }
    else if (state1 == 2)
    {
        mGUIMgr->mLoadingBar.fFilling += filling/lFileList.size();

        if (state2 == lFileList.size())
        {
            Log("Parsing Tables/model_table.lua : done.");
            *finished = true;
            return true;
        }

        string file = lFileList[state2];
	    if (FileExists(file))
            LoadModel(file);

        *finished = false;
        return false;
    }
}

void ModelManager::UpdateVertexList(bool rebuild)
{
    if (!rebuild)
    {
        bRebuildVB = true;
    }
    else if (bRebuildVB)
    {
        iVertexNbr = 0;
        map<int, Mesh*> lMeshLookup;
        vector<Mesh*> lMeshList;

        map<int, Model*>::iterator iterModel;
        for (iterModel = lModelList.begin(); iterModel != lModelList.end(); iterModel++)
        {
            Model* mo = iterModel->second;
            if (!mo->Hidden())
            {
                for (int i = 0; i < mo->iMeshNbr; i++)
                {
                    Mesh* me = mo->lMeshList[i];
                    if (me->bShown)
                    {
                        if (lMeshLookup.find(me->iGID) == lMeshLookup.end())
                        {
                            me->iVertexOff = iVertexNbr;
                            iVertexNbr += me->iVertexNbr;
                            lMeshLookup[me->iGID] = me;
                            lMeshList.push_back(me);
                        }
                        else
                        {
                            me->iVertexOff = lMeshLookup[me->iGID]->iVertexOff;
                        }
                    }
                }
            }
        }

        if (iVertexNbr > 0)
        {
            int iVXOff = 0;
            lVertexList = new Vertex[iVertexNbr];
            vector<Mesh*>::iterator iterMesh;
            for (iterMesh = lMeshList.begin(); iterMesh != lMeshList.end(); iterMesh++)
            {
                Mesh* me = *iterMesh;
                memcpy(&(lVertexList[iVXOff]), me->lVertexList, me->iVertexNbr*sizeof(Vertex));
                iVXOff += me->iVertexNbr;
            }
        }

        mGFXMgr->UpdateVertexBuffer();

        iVertexNbr = 0;

        bRebuildVB = false;
    }
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_global.h"
#include "wowrl_lua.h"
#include "wowrl_scenemanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_timemanager.h"

using namespace std;

extern SceneManager *mSceneMgr;
extern InputManager *mInputMgr;
extern GFXManager *mGFXMgr;
extern TimeManager *mTimeMgr;
extern HGE *hge;

int l_Gfx_UpdateAnimation( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"Gfx_updateAnimation\" (one expected : anim name)");
	}
	if (!lua_isstring(luaVM, 1))
		LUA::PrintError("Argument of Gfx_updateAnimation must be a string (anim name)");
	mGFXMgr->lLuaAnimList[lua_tostring(luaVM, 1)]->Update(mTimeMgr->GetDelta());

	return 0;
}

int l_Gfx_RenderAnimation( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 6)
	{
		LUA::PrintError("Too few arguments in \"Gfx_renderAnimation\" (6 expected : anim name, x, y, angle, horizontal scale, vertical scale)");
	}
	if (!lua_isstring(luaVM, 1))
		LUA::PrintError("Argument 1 of Gfx_renderAnimation must be a string (anim name)");
	if (!lua_isnumber(luaVM, 2))
		LUA::PrintError("Argument 2 of Gfx_renderAnimation must be a number (x)");
	if (!lua_isnumber(luaVM, 3))
		LUA::PrintError("Argument 3 of Gfx_renderAnimation must be a number (y)");
	if (!lua_isnumber(luaVM, 4))
		LUA::PrintError("Argument 4 of Gfx_renderAnimation must be a number (angle)");
	if (!lua_isnumber(luaVM, 5))
		LUA::PrintError("Argument 5 of Gfx_renderAnimation must be a number (horizontal scale)");
	if (!lua_isnumber(luaVM, 6))
		LUA::PrintError("Argument 6 of Gfx_renderAnimation must be a number (vertical scale)");
	hgeAnimation* a = mGFXMgr->lLuaAnimList[lua_tostring(luaVM, 1)];
	a->RenderEx
	(
		lua_tonumber(luaVM, 2),
		lua_tonumber(luaVM, 3),
		lua_tonumber(luaVM, 4),
		lua_tonumber(luaVM, 5),
		lua_tonumber(luaVM, 6)
	);

	return 0;
}

int l_Gfx_CreatePSys( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		LUA::PrintError("Too few arguments in \"Gfx_createPSys\" (3 expected : psys name, file, sprite)");
	}
	if (!lua_isstring(luaVM, 1))
		LUA::PrintError("Argument 1 of Gfx_createPSys must be a string (psys name)");
	if (!lua_isstring(luaVM, 2))
		LUA::PrintError("Argument 2 of Gfx_createPSys must be a string (file)");
	if (!lua_isstring(luaVM, 3))
		LUA::PrintError("Argument 3 of Gfx_createPSys must be a string (sprite)");

	hgeSprite* spr = mGFXMgr->lLuaSpriteList[lua_tostring(luaVM, 3)];
	mGFXMgr->lLuaPSysList[lua_tostring(luaVM, 1)] = mGFXMgr->CreatePSys(lua_tostring(luaVM, 2), spr);

	lua_pushstring(luaVM, lua_tostring(luaVM, 1));
	return 1;
}

int l_Gfx_UpdatePSys( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"Gfx_updatePSys\" (one expected : psys name)");
	}
	if (!lua_isstring(luaVM, 1))
		LUA::PrintError("Argument of Gfx_updatePSys must be a string (psys name)");

	mGFXMgr->lLuaPSysList[lua_tostring(luaVM, 1)]->Update(mTimeMgr->GetDelta());

	return 0;
}

int l_Gfx_RenderPSys( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		LUA::PrintError("Too few arguments in \"Gfx_renderPSys\" (3 expected : psys name, x, y)");
	}
	if (!lua_isstring(luaVM, 1))
		LUA::PrintError("Argument 1 of Gfx_renderPSys must be a string (psys name)");
	if (!lua_isnumber(luaVM, 2))
		LUA::PrintError("Argument 2 of Gfx_renderPSys must be a number (x)");
	if (!lua_isnumber(luaVM, 3))
		LUA::PrintError("Argument 3 of Gfx_renderPSys must be a number (y)");

	hgeParticleSystem* psys = mGFXMgr->lLuaPSysList[lua_tostring(luaVM, 1)];
	psys->MoveTo(lua_tonumber(luaVM, 2)-mSceneMgr->fGX, lua_tonumber(luaVM, 3)-mSceneMgr->fGY);
	psys->Transpose(mSceneMgr->fGX, mSceneMgr->fGY);
	psys->Render();

	return 0;
}

int l_Gfx_RenderSprite( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 6)
	{
		LUA::PrintError("Too few arguments in \"Gfx_renderSprite\" (6 expected : sprite name, x, y, angle, horizontal scale, vertical scale)");
	}
	if (!lua_isstring(luaVM, 1))
		LUA::PrintError("Argument 1 of Gfx_renderSprite must be a string (sprite name)");
	if (!lua_isnumber(luaVM, 2))
		LUA::PrintError("Argument 2 of Gfx_renderSprite must be a number (x)");
	if (!lua_isnumber(luaVM, 3))
		LUA::PrintError("Argument 3 of Gfx_renderSprite must be a number (y)");
	if (!lua_isnumber(luaVM, 4))
		LUA::PrintError("Argument 4 of Gfx_renderSprite must be a number (angle)");
	if (!lua_isnumber(luaVM, 5))
		LUA::PrintError("Argument 5 of Gfx_renderSprite must be a number (horizontal scale)");
	if (!lua_isnumber(luaVM, 6))
		LUA::PrintError("Argument 6 of Gfx_renderSprite must be a number (vertical scale)");

	hgeSprite* spr = mGFXMgr->lLuaSpriteList[lua_tostring(luaVM, 1)];
	spr->RenderEx
	(
		lua_tonumber(luaVM, 2),
		lua_tonumber(luaVM, 3),
		lua_tonumber(luaVM, 4),
		lua_tonumber(luaVM, 5),
		lua_tonumber(luaVM, 6)
	);

	return 0;
}

int l_Gfx_CreateSprite( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 9)
	{
		LUA::PrintError("Too few arguments in \"Gfx_createSprite\" (9 expected : sprite name, texture file, generate mipmaps, x offset, y offset, width, height, x hot spot, y hot spot)");
		return 0;
	}
	else
	{
		if (!lua_isstring(luaVM, 1))
			LUA::PrintError("Argument 1 of Gfx_createSprite must be a string (sprite name)");

		string sName = lua_tostring(luaVM, 1);
		if (mGFXMgr->lLuaSpriteList.find(sName) != mGFXMgr->lLuaSpriteList.end())
		{
    		LUA::PrintError("A sprite with the name " + sName + " aready exists");
    		lua_pushstring(luaVM, sName.c_str());
    		return 1;
		}

		if (!lua_isstring(luaVM, 2))
			LUA::PrintError("Argument 2 of Gfx_createSprite must be a string (texture file)");
		if (!lua_isboolean(luaVM, 3))
			LUA::PrintError("Argument 3 of Gfx_createSprite must be a bool (generate mipmaps)");
		if (!lua_isnumber(luaVM, 4))
			LUA::PrintError("Argument 4 of Gfx_createSprite must be a number (x offset)");
		if (!lua_isnumber(luaVM, 5))
			LUA::PrintError("Argument 5 of Gfx_createSprite must be a number (y offset)");
		if (!lua_isnumber(luaVM, 8))
			LUA::PrintError("Argument 6 of Gfx_createSprite must be a number (x hot spot)");
		if (!lua_isnumber(luaVM, 9))
			LUA::PrintError("Argument 7 of Gfx_createSprite must be a number (y hot spot)");

		float w, h;
		HTEXTURE tex = mGFXMgr->LoadTexture
		(
			lua_tostring(luaVM, 2),
			lua_toboolean(luaVM, 3)
		);
		if (lua_isnumber(luaVM, 6))
			w = lua_tonumber(luaVM, 6);
		else if (lua_isstring(luaVM, 6))
		{
			if (string(lua_tostring(luaVM, 6)) == "texw")
				w = hge->Texture_GetWidth(tex, true);
			else
				w = 0.0f;
		}
		else
			LUA::PrintError("Argument 6 of Gfx_createSprite must be a number or a string (width)");

		if (lua_isnumber(luaVM, 7))
			h = lua_tonumber(luaVM, 7);
		else if (lua_isstring(luaVM, 7))
		{
			if (string(lua_tostring(luaVM, 7)) == "texh")
				h = hge->Texture_GetHeight(tex, true);
			else
				h = 0.0f;
		}
		else
			LUA::PrintError("Argument 7 of Gfx_createSprite must be a number or a string (height)");

		mGFXMgr->lLuaSpriteList[sName] = mGFXMgr->CreateSprite
		(
			tex,
			lua_tonumber(luaVM, 4),
			lua_tonumber(luaVM, 5),
			w,
			h
		);

		mGFXMgr->lLuaSpriteList[sName]->SetHotSpot(lua_tonumber(luaVM, 8), lua_tonumber(luaVM, 9));

		lua_pushstring(luaVM, sName.c_str());
	}

	return 1;
}

int l_Gfx_CreateAnimation( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 11)
	{
		LUA::PrintError("Too few arguments in \"Gfx_createAnimation\" (11 expected : anim name, texture file, generate mipmaps, frame number, frame per second, x offset, y offset, width, height, x hot spot, y hot spot)");
		return 0;
	}
	else
	{
		if (!lua_isstring(luaVM, 1))
			LUA::PrintError("Argument 1 of Gfx_createAnimation must be a string (anim name)");
		string aName = lua_tostring(luaVM, 1);
		if (mGFXMgr->lLuaAnimList.find(aName) != mGFXMgr->lLuaAnimList.end())
		{
    		LUA::PrintError("An animation with the name " + aName + " aready exists");
    		lua_pushstring(luaVM, aName.c_str());
    		return 1;
		}

		if (!lua_isstring(luaVM, 2))
			LUA::PrintError("Argument 2 of Gfx_createAnimation must be a string (texture file)");
		if (!lua_isboolean(luaVM, 3))
			LUA::PrintError("Argument 3 of Gfx_createAnimation must be a bool (generate mipmaps)");
		if (!lua_isnumber(luaVM, 4))
			LUA::PrintError("Argument 4 of Gfx_createAnimation must be a number (frame number)");
		if (!lua_isnumber(luaVM, 5))
			LUA::PrintError("Argument 5 of Gfx_createAnimation must be a number (frame per second)");
		if (!lua_isnumber(luaVM, 6))
			LUA::PrintError("Argument 6 of Gfx_createAnimation must be a number (x offset)");
		if (!lua_isnumber(luaVM, 7))
			LUA::PrintError("Argument 7 of Gfx_createAnimation must be a number (y offset)");
		if (!lua_isnumber(luaVM, 8))
			LUA::PrintError("Argument 8 of Gfx_createAnimation must be a number (width)");
		if (!lua_isnumber(luaVM, 9))
			LUA::PrintError("Argument 9 of Gfx_createAnimation must be a number (height)");
		if (!lua_isnumber(luaVM, 10))
			LUA::PrintError("Argument 10 of Gfx_createAnimation must be a number (x hot spot)");
		if (!lua_isnumber(luaVM, 11))
			LUA::PrintError("Argument 11 of Gfx_createAnimation must be a number (y hot spot)");

		HTEXTURE tex = mGFXMgr->LoadTexture
		(
			lua_tostring(luaVM, 2),
			lua_toboolean(luaVM, 3)
		);
		mGFXMgr->lLuaAnimList[aName] = mGFXMgr->CreateAnimation
		(
			tex,
			(int)lua_tonumber(luaVM, 4),
			lua_tonumber(luaVM, 5),
			lua_tonumber(luaVM, 6),
			lua_tonumber(luaVM, 7),
			lua_tonumber(luaVM, 8),
			lua_tonumber(luaVM, 9)
		);

		mGFXMgr->lLuaAnimList[aName]->SetHotSpot(lua_tonumber(luaVM, 10), lua_tonumber(luaVM, 11));
		lua_pushstring(luaVM, aName.c_str());
	}

	return 1;
}

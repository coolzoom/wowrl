/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               Lua source               */
/*                                        */
/*  ## : This file contains two things :  */
/*    - a lua interface for frequently    */
/*      used function combination.        */
/*    - the lua glues, to call the progs' */
/*      functions inside lua scripts.     */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_luaglues.h"

#include "wowrl_global.h"
#include "wowrl_scenemanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_timemanager.h"
#include "wowrl_gui.h"

#include <sstream>

using namespace std;

extern SceneManager *mSceneMgr;
extern GUIManager *mGUIMgr;
extern InputManager *mInputMgr;
extern TimeManager *mTimeMgr;
extern HGE *hge;

void LUA::RegisterAll( lua_State* luaVM )
{
	// [#] This function registers all the LUA methods and LUNAR classes.
	lua_register(luaVM, "Log", LUA::LogL);
	lua_register(luaVM, "RandomInt", l_RandomInt);
	lua_register(luaVM, "RandomFloat", l_RandomFloat);
	lua_register(luaVM, "StrReplace", l_StrReplace);
	lua_register(luaVM, "StrCapitalStart", l_StrCapitalStart);
	lua_register(luaVM, "GetDelta", l_GetDelta);
	lua_register(luaVM, "GetLeadingUnit", l_GetLeadingUnit);
	lua_register(luaVM, "GetLocale", l_GetLocale);
	lua_register(luaVM, "GetLocalizedString", l_GetLocalizedString);
	lua_register(luaVM, "GetTime", l_GetTime);
	lua_register(luaVM, "GetTimeOfTheDay", l_GetTimeOfTheDay);
	lua_register(luaVM, "GetGlobal", l_GetGlobal);
	lua_register(luaVM, "GetMousePos", l_GetMousePos);
	lua_register(luaVM, "GetMouseGPos", l_GetMouseGPos);
	lua_register(luaVM, "RunScript", l_DoString);

	lua_register(luaVM, "Gfx_createSprite", l_Gfx_CreateSprite);
	lua_register(luaVM, "Gfx_renderSprite", l_Gfx_RenderSprite);
 	lua_register(luaVM, "Gfx_createAnimation", l_Gfx_CreateAnimation);
 	lua_register(luaVM, "Gfx_updateAnimation", l_Gfx_UpdateAnimation);
 	lua_register(luaVM, "Gfx_renderAnimation", l_Gfx_RenderAnimation);
 	lua_register(luaVM, "Gfx_createPSys", l_Gfx_CreatePSys);
 	lua_register(luaVM, "Gfx_updatePSys", l_Gfx_UpdatePSys);
 	lua_register(luaVM, "Gfx_renderPSys", l_Gfx_RenderPSys);

 	lua_register(luaVM, "GUI_createElement", l_GUI_CreateElement);

    lua_register(luaVM, "UnitName", l_Unit_Name);
 	lua_register(luaVM, "UnitSpawn", l_Unit_Spawn);
 	lua_register(luaVM, "UnitAddEffect", l_Unit_AddEffect);
 	lua_register(luaVM, "UnitSetHostile", l_Unit_SetHostile);
 	lua_register(luaVM, "UnitSetMaxHP", l_Unit_SetMaxHP);
 	lua_register(luaVM, "UnitSetAggroRange", l_Unit_SetAggroRange);
 	lua_register(luaVM, "UnitSetTarget", l_Unit_SetTarget);
	lua_register(luaVM, "UnitSetX", l_Unit_SetX);
	lua_register(luaVM, "UnitSetY", l_Unit_SetY);
	lua_register(luaVM, "UnitIsHostile", l_Unit_IsHostile);
	lua_register(luaVM, "UnitIsDead", l_Unit_IsDead);
	lua_register(luaVM, "UnitIsTargetInRange", l_Unit_IsTargetInRange);
	lua_register(luaVM, "UnitTarget", l_Unit_GetTarget);
	lua_register(luaVM, "UnitX", l_Unit_GetX);
	lua_register(luaVM, "UnitY", l_Unit_GetY);
	lua_register(luaVM, "UnitLevel", l_Unit_GetLevel);
	lua_register(luaVM, "UnitHealth", l_Unit_GetHealth);
	lua_register(luaVM, "UnitMana", l_Unit_GetMana);
	lua_register(luaVM, "UnitHealthMax", l_Unit_GetMaxHealth);
	lua_register(luaVM, "UnitManaMax", l_Unit_GetMaxMana);
	lua_register(luaVM, "UnitPowerType", l_Unit_GetPowerType);
	lua_register(luaVM, "UnitAddItem", l_Unit_AddItem);
	lua_register(luaVM, "UnitGetActionTexture", l_Unit_GetActionTexture);
	lua_register(luaVM, "UnitGetActionInfo", l_Unit_GetActionInfo);
	lua_register(luaVM, "UnitIsActionInRange", l_Unit_IsActionInRange);
	lua_register(luaVM, "UnitIsUsableAction", l_Unit_IsUsableAction);
	lua_register(luaVM, "UnitCastSpell", l_Unit_CastSpell);
	lua_register(luaVM, "UnitCastSpellIndirect", l_Unit_CastSpellIndirect);
	lua_register(luaVM, "UnitIsCasting", l_Unit_IsCasting);
	lua_register(luaVM, "UnitCastingInfo", l_Unit_CastingInfo);
	lua_register(luaVM, "UnitSpellInfo", l_Unit_GetSpellInfo);
	lua_register(luaVM, "UnitSetAttacking", l_Unit_SetAttacking);
	lua_register(luaVM, "UnitSetHealing", l_Unit_SetHealing);
	lua_register(luaVM, "UnitSetResurrecting", l_Unit_SetResurrecting);
	lua_register(luaVM, "UnitDamage", l_Unit_Damage);
	lua_register(luaVM, "UnitHeal", l_Unit_Heal);
	lua_register(luaVM, "UnitRes", l_Unit_Res);
	lua_register(luaVM, "UnitAddBuff", l_Unit_AddBuff);
	lua_register(luaVM, "UnitGetBuffs", l_Unit_GetBuffs);
	lua_register(luaVM, "UnitShowSubMesh", l_Unit_ShowSubMesh);
	lua_register(luaVM, "UnitEmote", l_Unit_Emote);
	lua_register(luaVM, "UnitSetAnim", l_Unit_SetAnim);

	Lunar<GUI::UIObject>::Register(luaVM);
	Lunar<GUI::Region>::Register(luaVM);
	Lunar<GUI::Frame>::Register(luaVM);
	Lunar<GUI::StatusBar>::Register(luaVM);
	Lunar<GUI::EditBox>::Register(luaVM);
	Lunar<GUI::ScrollingMessageFrame>::Register(luaVM);
	Lunar<GUI::Button>::Register(luaVM);
	Lunar<GUI::LayeredRegion>::Register(luaVM);
	Lunar<GUI::Texture>::Register(luaVM);
	Lunar<GUI::FontString>::Register(luaVM);

	lua_newtable(luaVM);
	lua_setglobal(luaVM, "Functions");
}

// Modified openlibs function to load my own libs
const luaL_Reg lualibs[] = {
	{"", luaopen_base},
	{LUA_LOADLIBNAME, luaopen_package},
	{LUA_TABLIBNAME, luaopen_table},
	{LUA_IOLIBNAME, luaopen_io},
	{LUA_OSLIBNAME, luaopen_os},
	{LUA_MSTRLIBNAME, LUA::OpenString}, // Modified string lib
	{LUA_MATHLIBNAME, luaopen_math},
	{LUA_DBLIBNAME, luaopen_debug},
	{NULL, NULL}
};
void LUA::OpenLibs(lua_State* luaVM)
{
	const luaL_Reg *lib = lualibs;
	for ( ; lib->func; lib++)
	{
		lua_pushcfunction(luaVM, lib->func);
		lua_pushstring(luaVM, lib->name);
		lua_call(luaVM, 1, 0);
	}
}

string mlua_ConcTable(lua_State* luaVM, string table )
{
	/* [#] This function converts a LUA table into a formated string. It is used
	/* to save the content of the table in the SavedVariables.
	*/
	string s = "";
	s += "tbl = \"" + table + "\";\n";
	s += "temp = \"\";\n";
	s += "for k, v in pairs (" + table + ") do\n";
	s += "local s, t;\n";
	s += "if (type(k) == \"number\") then\ns = k;\nend\n";
	s += "if (type(k) == \"string\") then\ns = \"\\\"\"..k..\"\\\"\";\nend\n";

	s += "if (type(v) == \"number\") then\nt = v;\nend\n";
	s += "if (type(v) == \"string\") then\nt = \"\\\"\"..v..\"\\\"\";\nend\n";
	s += "if (type(v) == \"boolean\") then\nif v then\nt = \"'true'\";\nelse\nt = \"'false'\";\nend\nend\n";
	s += "if (type(v) == \"table\") then\n";
	s += "t = \"'table'\";\nsendString(s..\" \"..t..\" \");\nconcTable(temp, tbl..\"[\"..s..\"]\");\n";
	s += "else\n";
	s += "sendString(s..\" \"..t..\" \");\n";
	s += "end\n";
	s += "end\n";
	s += "sendString(\"'end' \");\n";

	luaL_dostring(luaVM, s.c_str());

	return mSceneMgr->sTmpString;
}

void LUA::PrintError( string error )
{
	lua_Debug d;
	lua_getstack(mSceneMgr->luaVM, 1, &d);
	lua_getinfo(mSceneMgr->luaVM, "Sl" , &d);
	string debugStr = string(d.short_src) + ", line " + ToString(d.currentline)
				+ string(" : ") + error;
	lua_pushstring(mSceneMgr->luaVM, debugStr.c_str());
	LUA::LogL(mSceneMgr->luaVM);
}

void LUA::Print( string str )
{
	lua_pushstring(mSceneMgr->luaVM, str.c_str());
	LUA::LogL(mSceneMgr->luaVM);
}

/* [#] The following functions are shortcuts to the LUA C API. They are very
/* usefull when dealing with tables, and allow default values.
*/
int LUA::GetGlobalInt( string name, bool critical, int defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			LUA::Print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isnumber(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		LUA::Print("\"" + name + "\" is expected to be a number");
		return defaultValue;
	}
	else
	{
		int i = (int)lua_tonumber(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return i;
	}
}

float LUA::GetGlobalFloat( string name, bool critical, float defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			LUA::Print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isnumber(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		LUA::Print("\"" + name + "\" is expected to be a number");
		return defaultValue;
	}
	else
	{
		float f = lua_tonumber(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return f;
	}
}

string LUA::GetGlobalString( string name, bool critical, string defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			LUA::Print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isstring(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		LUA::Print("\"" + name + "\" is expected to be a string");
		return defaultValue;
	}
	else
	{
		string s = lua_tostring(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return s;
	}
}

bool LUA::GetGlobalBool( string name, bool critical, bool defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			LUA::Print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isboolean(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		LUA::Print("\"" + name + "\" is expected to be a bool");
		return defaultValue;
	}
	else
	{
		bool b = lua_toboolean(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return b;
	}
}

int LUA::GetFieldInt( string name, bool critical, int defaultValue, bool setValue, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_getfield(luaVM, -1, name.c_str());
	if (lua_isnil(luaVM, -1))
	{
		lua_pop(luaVM, 1);
		if (critical)
			LUA::Print("Missing " + name + " attribute");
		else if (setValue)
		{
			LUA::SetFieldInt(name, defaultValue, luaVM);
			return defaultValue;
		}
		else
			return defaultValue;
	}
	else if (!lua_isnumber(luaVM, -1))
	{
		LUA::Print("Field is expected to be a number");
		lua_pop(luaVM, 1);
	}
	else
	{
		int i = (int)lua_tonumber(luaVM, -1);
		lua_pop(luaVM, 1);
		return i;
	}
}

float LUA::GetFieldFloat( string name, bool critical, float defaultValue, bool setValue, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_getfield(luaVM, -1, name.c_str());
	if (lua_isnil(luaVM, -1))
	{
		lua_pop(luaVM, 1);
		if (critical)
			LUA::Print("Missing " + name + " attribute");
		else if (setValue)
		{
			LUA::SetFieldFloat(name, defaultValue, luaVM);
			return defaultValue;
		}
		else
			return defaultValue;
	}
	else if (!lua_isnumber(luaVM, -1))
	{
		LUA::Print("Field is expected to be a number");
		lua_pop(luaVM, 1);
	}
	else
	{
		float f = lua_tonumber(luaVM, -1);
		lua_pop(luaVM, 1);
		return f;
	}
}

string LUA::GetFieldString( string name, bool critical, string defaultValue, bool setValue, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_getfield(luaVM, -1, name.c_str());
	if (lua_isnil(luaVM, -1))
	{
		lua_pop(luaVM, 1);
		if (critical)
			LUA::Print("Missing " + name + " attribute");
		else if (setValue)
		{
			LUA::SetFieldString(name, defaultValue, luaVM);
			return defaultValue;
		}
		else
			return defaultValue;
	}
	else if (!lua_isstring(luaVM, -1))
	{
		LUA::Print("Field is expected to be a string");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		string str = lua_tostring(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return str;
	}
}

bool LUA::GetFieldBool( string name, bool critical, bool defaultValue, bool setValue, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_getfield(luaVM, -1, name.c_str());
	if (lua_isnil(luaVM, -1))
	{
		lua_pop(luaVM, 1);
		if (critical)
			LUA::Print("Missing " + name + " attribute");
		else if (setValue)
		{
			LUA::SetFieldBool(name, defaultValue, luaVM);
			return defaultValue;
		}
		else
			return defaultValue;
	}
	else if (!lua_isboolean(luaVM, -1))
	{
		LUA::Print("Field is expected to be a bool");
		lua_pop(luaVM, 1);
	}
	else
	{
		bool b = lua_toboolean(luaVM, -1);
		lua_pop(luaVM, 1);
		return b;
	}
}

void LUA::SetFieldInt( string name, int value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushstring(luaVM, name.c_str());
	lua_pushnumber(luaVM, value);
	lua_settable(luaVM, -3);
}

void LUA::SetFieldFloat( string name, float value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushstring(luaVM, name.c_str());
	lua_pushnumber(luaVM, value);
	lua_settable(luaVM, -3);
}

void LUA::SetFieldString( string name, string value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushstring(luaVM, name.c_str());
	lua_pushstring(luaVM, value.c_str());
	lua_settable(luaVM, -3);
}

void LUA::SetFieldBool( string name, bool value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushstring(luaVM, name.c_str());
	lua_pushboolean(luaVM, value);
	lua_settable(luaVM, -3);
}

void LUA::SetIFieldInt( int id, int value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushnumber(luaVM, id);
	lua_pushnumber(luaVM, value);
	lua_settable(luaVM, -3);
}

void LUA::SetIFieldFloat( int id, float value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushnumber(luaVM, id);
	lua_pushnumber(luaVM, value);
	lua_settable(luaVM, -3);
}

void LUA::SetIFieldString( int id, string value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushnumber(luaVM, id);
	lua_pushstring(luaVM, value.c_str());
	lua_settable(luaVM, -3);
}

void LUA::SetIFieldBool( int id, bool value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushnumber(luaVM, id);
	lua_pushboolean(luaVM, value);
	lua_settable(luaVM, -3);
}

/* [#] The following functions are called "glues". They aren't used in C++ but
/* in the LUA environnement. To get a description of what they do, you can refer
/* to :
/*              http://www.fWowwiki.com/World_of_Warcraft_API
/*
/* They aren't all described there, but the most complexe ones are. Their use is,
/* in many case, obvious. So I won't make a description for each : it would be
/* redundant.
*/

int l_SendString( lua_State* luaVM )
{
	mSceneMgr->sTmpString += lua_tostring(luaVM, 1);

	return 0;
}

int l_ConcTable( lua_State* luaVM )
{
	string t = lua_tostring(luaVM, 1);
	string s = mlua_ConcTable(luaVM, lua_tostring(luaVM, 2));
	s = t+s;
	lua_pushstring(luaVM, s.c_str());

	return 1;
}

int LUA::LogL( lua_State* luaVM )
{
	if (!lua_isstring(luaVM, -1))
		LUA::PrintError("Argument of LogPrint must be a string (caption)");
	else
		Log("# LUA : %s", lua_tostring(luaVM, -1));

	return 0;
}

int l_RandomInt( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"randomInt\" (2 expected : low, high)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of RandomInt must be a number (low)");
		error++;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 2 of RandomInt must be a number (high)");
		error++;
	}

	if (error == 0)
	{
		int low = ToInt(lua_tonumber(luaVM, 1));
		int high = ToInt(lua_tonumber(luaVM, 2));
		int rand = hge->Random_Int(low, high);
		lua_pushnumber(luaVM, rand);
	}

	return 1;
}

int l_RandomFloat( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"RandomFloat\" (2 expected : low, high)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of RandomFloat must be a number (low)");
		error++;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 2 of RandomFloat must be a number (high)");
		error++;
	}

	if (error == 0)
	{
		float low = lua_tonumber(luaVM, 1);
		float high = lua_tonumber(luaVM, 2);
		float rand = hge->Random_Float(low, high);
		lua_pushnumber(luaVM, rand);
	}

	return 1;
}

int l_StrReplace( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		LUA::PrintError("Too few arguments in \"StrReplace\" (3 expected : base string, pattern, replacement)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of StrReplace must be a string (base string)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of StrReplace must be a string (pattern)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of StrReplace must be a string (replacement)");
		error++;
	}

	if (error == 0)
	{
		string base = lua_tostring(luaVM, 1);
		int i = StrReplace(&base, lua_tostring(luaVM, 2), lua_tostring(luaVM, 3));
		lua_pushstring(luaVM, base.c_str());
		lua_pushnumber(luaVM, i);
	}

	return 2;
}

int l_StrCapitalStart( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"StrCapitalStart\" (one expected : base string)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		LUA::PrintError("Argument of StrCapitalStart must be a string (base string)");
		error++;
	}

	if (error == 0)
	{
		lua_pushstring(luaVM, StrCapitalStart(lua_tostring(luaVM, 1), true).c_str());
	}

	return 1;
}

int l_GetDelta( lua_State* luaVM )
{
	lua_pushnumber(luaVM, mTimeMgr->GetDelta());

	return 1;
}

int l_GetLocale( lua_State* luaVM )
{
	lua_pushstring(luaVM, mSceneMgr->sLocale.c_str());

	return 1;
}

int l_GetLocalizedString( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"GetLocalizedString\" (one expected : string id)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		LUA::PrintError("Argument of GetLocalizedString must be a string (string id)");
		error++;
	}

	if (error == 0)
	{
		lua_pushstring(luaVM, mSceneMgr->tStrTable->GetString(lua_tostring(luaVM, 1)));
	}

	return 1;
}

int l_GetTime( lua_State* luaVM )
{
	lua_pushnumber(luaVM, mTimeMgr->GetTime());

	return 1;
}

int l_GetTimeOfTheDay( lua_State* luaVM )
{
	lua_pushnumber(luaVM, mTimeMgr->GetHour());
	lua_pushnumber(luaVM, mTimeMgr->GetMinutes());
	lua_pushnumber(luaVM, mTimeMgr->GetSeconds());

	return 3;
}

int l_GetGlobal( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"GetGlobal\" (one expected : variable name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		LUA::PrintError("Argument of GetGlobal must be a string (variable name)");
		error++;
	}

	if (error == 0)
	{
		lua_getglobal(luaVM, lua_tostring(luaVM, 1));
	}
	return 1;
}

int l_GetMousePos( lua_State* luaVM )
{
	lua_pushnumber(luaVM, mInputMgr->fMX);
	lua_pushnumber(luaVM, mInputMgr->fMY);
	return 2;
}

int l_GetMouseGPos( lua_State* luaVM )
{
	lua_pushnumber(luaVM, mInputMgr->fGMX);
	lua_pushnumber(luaVM, mInputMgr->fGMY);
	return 2;
}

int l_GUI_CreateElement( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"GUI_createElement\" (one expected : element name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		LUA::PrintError("Argument of GUI_createElement must be a string (element name)");
		error++;
	}

	if (error == 0)
	{
		if (mGUIMgr->lGuiList.find(lua_tostring(luaVM, 1)) == mGUIMgr->lGuiList.end())
		{
			string name = lua_tostring(luaVM, 1);
			if (name != "")
			{
				mGUIMgr->lGuiList[name] = new GUIElement();
			}
		}

		lua_pushstring(luaVM, lua_tostring(luaVM, 1));
		return 1;
	}
	else
		return 0;
}

int l_DoString( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"DoString\" (one expected : string)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		LUA::PrintError("Argument of DoString must be a string");
		error++;
	}

	if (error == 0)
	{
		int error = luaL_dostring(luaVM, lua_tostring(luaVM, 1));
		if (error) LUA::LogL(luaVM);
	}

	return 0;
}

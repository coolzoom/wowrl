/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_lua.h"
#include "wowrl_unitmanager.h"
#include "wowrl_scenemanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_timemanager.h"
#include "wowrl_model.h"
#include "wowrl_unit.h"

using namespace std;

extern SceneManager *mSceneMgr;
extern UnitManager *mUnitMgr;
extern GUIManager *mGUIMgr;
extern GFXManager *mGFXMgr;
extern TimeManager *mTimeMgr;
extern HGE *hge;

int l_GetLeadingUnit( lua_State* luaVM )
{
	if (mUnitMgr->mLeadingUnit != NULL)
		lua_pushnumber(luaVM, mUnitMgr->mLeadingUnit->GetID());
	else
		lua_pushnil(luaVM);

	return 1;
}

int l_Unit_Spawn( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 8)
	{
		LUA::PrintError("Too few arguments in \"UnitSpawn\" (8 expected : unit name, x, y, level, race, gender, class, speed)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitSpawn must be a number (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitSpawn must be a number (x)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of UnitSpawn must be a number (y)");
		error++;
	}
	if (!lua_isnumber(luaVM, 4))
	{
		LUA::PrintError("Argument 4 of UnitSpawn must be a number (level)");
		error++;
	}
	if (!lua_isstring(luaVM, 5))
	{
		LUA::PrintError("Argument 5 of UnitSpawn must be a string (race)");
		error++;
	}
	if (!lua_isnumber(luaVM, 6))
	{
		LUA::PrintError("Argument 6 of UnitSpawn must be a number (gender)");
		error++;
	}
	if (!lua_isstring(luaVM, 7))
	{
		LUA::PrintError("Argument 7 of UnitSpawn must be a string (class)");
		error++;
	}
	if (!lua_isnumber(luaVM, 8))
	{
		LUA::PrintError("Argument 8 of UnitSpawn must be a number (speed)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->CreateUnit
		(
			lua_tostring(luaVM, 1),
			lua_tonumber(luaVM, 2),
			lua_tonumber(luaVM, 3),
			(int)lua_tonumber(luaVM, 4),
			mUnitMgr->GetRace(lua_tostring(luaVM, 5)),
			(int)lua_tonumber(luaVM, 6),
			mUnitMgr->GetClass(lua_tostring(luaVM, 7)),
			lua_tonumber(luaVM, 8)
		);
		mGFXMgr->ForceUpdate();
		lua_pushnumber(luaVM, u->GetID());
	}
	else
        lua_pushnil(luaVM);

	return 1;
}

int l_Unit_AddEffect( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitAddEffect\" (2 expected : unit id, effect name)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitAddEffect must be a number (unit id)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitAddEffect must be a string (effect name)");
		error++;
	}

	if (error == 0)
	{
        Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            string fx = lua_tostring(luaVM, 2);
            if (mGFXMgr->lFXList.find(fx) == mGFXMgr->lFXList.end())
                Log("# ERROR # : Unknown effect \"%s\"", fx.c_str());
            else
                u->AddEffect(fx);
        }
	}
	return 0;
}

int l_Unit_SetHostile( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitSetHostile\" (2 expected : unit id, hostile)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitSetHostile must be a number (unit id)");
		error++;
	}
	if (!lua_isboolean(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitSetHostile must be a bool (hostile)");
		error++;
	}

	if (error == 0)
	{
        Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
            u->SetHostile(lua_toboolean(luaVM, 2));
	}
	return 0;
}

int l_Unit_SetMaxHP( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		LUA::PrintError("Too few arguments in \"UnitSetMaxHP\" (3 expected : unit id, hp, fill to max)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitSetMaxHP must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitSetMaxHP must be a number (hp)");
		error++;
	}
	if (!lua_isboolean(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of UnitSetMaxHP must be a bool (fill to max)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
            u->SetMaxHealth(lua_tonumber(luaVM, 2), lua_toboolean(luaVM, 3));
	}
	return 0;
}

int l_Unit_SetAggroRange( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitSetAggroRange\" (2 expected : unit id, aggro range)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitSetAggroRange must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitSetAggroRange must be a number (aggro range)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
            u->SetAggroRange(lua_tonumber(luaVM, 2));
	}
	return 0;
}

int l_Unit_GetMaxMana( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitMaxMana\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitMaxMana must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            float mana = u->GetMaxMana();
            lua_pushnumber(luaVM, mana);
        }
        else
            lua_pushnil(luaVM);
	}
	else
        lua_pushnil(luaVM);

	return 1;
}

int l_Unit_GetMaxHealth( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitMaxHealth\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitMaxHealth must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            float mhealth = u->GetMaxHealth();
            lua_pushnumber(luaVM, mhealth);
        }
        else
            lua_pushnumber(luaVM, 1);
	}

	return 1;
}

int l_Unit_GetMana( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitMana\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitMana must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            float mana = u->GetMana();
            lua_pushnumber(luaVM, mana);
        }
        else
            lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_GetLevel( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitLevel\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitLevel must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            int lvl = u->GetLevel();
            lua_pushnumber(luaVM, lvl);
        }
        else
            lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_GetHealth( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitHealth\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitHealth must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            float health = u->GetHealth();
            lua_pushnumber(luaVM, health);
        }
        else
            lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_GetPowerType( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitPowerType\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitPowerType must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            int p = u->GetPowerType();
            lua_pushnumber(luaVM, p);
        }
        else
            lua_pushnil(luaVM);
	}
	return 1;
}

int l_Unit_GetY( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitY\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitY must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            float y = u->GetGY();
            lua_pushnumber(luaVM, y);
        }
        else
            lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_GetX( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitX\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitX must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            float x = u->GetGX();
            lua_pushnumber(luaVM, x);
        }
        else
            lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_GetTarget( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitTarget\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitTarget must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            Unit* t = u->GetTarget();
            if (t != NULL)
            {
                string str = t->GetName().c_str();
                lua_pushstring(luaVM, str.c_str());
            }
            else
                lua_pushnil(luaVM);
        }
        else
            lua_pushnil(luaVM);
	}
	return 1;
}

int l_Unit_IsTargetInRange( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitIsTargetInRange\" (2 expected : unit id, spell name)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitIsTargetInRange must be a number (unit id)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitIsTargetInRange must be a string (spell name)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            string sname = lua_tostring(luaVM, 2);
            if (sname != "")
            {
                Spell* s = &mUnitMgr->lSpellList[sname];
                if (s->sName != "")
                {
                    bool r = u->IsTargetInRange(s);
                    lua_pushboolean(luaVM, r);
                }
                else
                    lua_pushboolean(luaVM, false);
            }
        }
        else
            lua_pushboolean(luaVM, false);
	}
	return 1;
}

int l_Unit_IsDead( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitIsDead\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitIsDead must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            bool d = u->IsDead();
            lua_pushboolean(luaVM, d);
        }
        else
            lua_pushboolean(luaVM, false);
	}
	return 1;
}

int l_Unit_IsHostile( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitIsHostile\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitIsHostile must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            bool h = u->IsHostile();
            lua_pushboolean(luaVM, h);
        }
        else
            lua_pushboolean(luaVM, false);
	}
	return 1;
}

int l_Unit_SetTarget( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitSetTarget\" (2 expected : unit id, target id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitSetTarget must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitSetTarget must be a number (target id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
            u->Target(mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 2))));

	}

	return 0;
}

int l_Unit_SetX( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitSetX\" (2 expected : unit id, x)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitSetX must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitSetX must be a number (x)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
            u->SetX(lua_tonumber(luaVM, 2));
	}

	return 0;
}

int l_Unit_SetY( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitSetY\" (2 expected : unit id, y)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitSetY must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitSetY must be a number (y)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
            u->SetY(lua_tonumber(luaVM, 2));
	}

	return 0;
}

int l_Unit_AddItem( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitAddItem\" (2 expected : unit id, item id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitAddItem must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitAddItem must be a number (item id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
	}
	return 0;
}

int l_Unit_GetActionTexture( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitGetActionTexture\" (2 expected : unit id, action id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitGetActionTexture must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitGetActionTexture must be a number (action id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            int i = ToInt(lua_tonumber(luaVM, 2));
            if ( (i <= 120) && (i >= 0) )
            {
                ActionButton ab = u->GetABList()[i];
                if (ab.mSpell != NULL)
                {
                    if (ab.iType == GUI_CASTBUTTON_SPELL)
                    {
                        lua_getglobal(luaVM, "Spells");
                        lua_getfield(luaVM, -1, ab.mSpell->sName.c_str());
                        lua_getfield(luaVM, -1, "icon");
                        //lua_pushstring(luaVM, ab.mSpell->sIconPath.c_str());
                    }
                    else if (ab.iType == GUI_CASTBUTTON_STOP)
                        lua_pushstring(luaVM, "Icons/Stop.png");
                    else
                        lua_pushstring(luaVM, "");
                }
                else
                    lua_pushstring(luaVM, "");
            }
            else
                lua_pushstring(luaVM, "");
        }
        else
            lua_pushstring(luaVM, "");
	}
	else
		lua_pushstring(luaVM, "");

	return 1;
}

int l_Unit_GetActionInfo( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitGetActionInfo\" (2 expected : unit id, action id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitGetActionInfo must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitGetActionInfo must be a number (action id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            int i = ToInt(lua_tonumber(luaVM, 2));
            if ( (i <= 120) && (i >= 0) )
            {
                ActionButton ab = u->GetABList()[i];
                if (ab.mSpell != NULL)
                {
                    if (ab.iType == GUI_CASTBUTTON_SPELL)
                    {
                        lua_pushstring(luaVM, "spell");
                    }
                    else if (ab.iType == GUI_CASTBUTTON_STOP)
                        lua_pushstring(luaVM, "stop");
                    else
                        lua_pushstring(luaVM, "");
                }
                else
                    lua_pushstring(luaVM, "");

            }
            else
                lua_pushstring(luaVM, "");
        }
        else
            lua_pushstring(luaVM, "");
	}
	else
		lua_pushstring(luaVM, "");

	return 1;
}

int l_Unit_IsActionInRange( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitIsActionInRange\" (2 expected : unit id, action id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitIsActionInRange must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitIsActionInRange must be a number (action id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            Unit* t = u->GetTarget();
            if (t != NULL)
            {
                int i = ToInt(lua_tonumber(luaVM, 2));
                if ( (i <= 120) && (i >= 0) )
                {
                    ActionButton ab = u->GetABList()[i];
                    if (ab.iType == GUI_CASTBUTTON_SPELL)
                    {
                        if (ab.mSpell != NULL)
                        {
                            lua_pushnumber(luaVM, u->IsTargetInRange(ab.mSpell));
                        }
                        else
                            lua_pushnil(luaVM);
                    }
                    else
                        lua_pushnil(luaVM);
                }
                else
                    lua_pushnil(luaVM);
            }
            else
                lua_pushnil(luaVM);
        }
        else
            lua_pushnil(luaVM);
	}
	else
		lua_pushnil(luaVM);

	return 1;
}

int l_Unit_IsUsableAction( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitIsUsableAction\" (2 expected : unit id, action id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitIsUsableAction must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitIsUsableAction must be a number (action id)");
		error++;
	}

	if (error == 0)
	{
	    error = 1;
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            int i = ToInt(lua_tonumber(luaVM, 2));
            if ( (i <= 120) && (i >= 0) )
            {
                ActionButton ab = u->GetABList()[i];
                if (ab.iType == GUI_CASTBUTTON_SPELL)
                {
                    if (ab.mSpell != NULL)
                    {
                        string reason;
                        lua_pushnumber(luaVM, u->IsCastable(ab.mSpell, &reason, true));
                        if (reason == "error_out_of_mana")
                            lua_pushnumber(luaVM, 1);
                        else
                            lua_pushnumber(luaVM, 0);

                        if (reason == "error_gcd")
                        {
                            lua_pushnumber(luaVM, 1);
                            lua_pushnumber(luaVM, u->GetGCD());
                        }
                        else
                        {
                            lua_pushnumber(luaVM, 0);
                            lua_pushnumber(luaVM, 0);
                        }
                        error = 0;
                    }
                }
            }
        }
	}

	if (error)
	{
		lua_pushnil(luaVM);
		lua_pushnil(luaVM);
		lua_pushnil(luaVM);
		lua_pushnil(luaVM);
	}

	return 4;
}

int l_Unit_CastSpell( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitCastSpell\" (3 expected : unit id, spell id, spell book)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitCastSpell must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitCastSpell must be a number (spell id)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of UnitCastSpell must be a string (spell book)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            ActionButton* ab = &u->GetABList()[ToInt(lua_tonumber(luaVM, 2))];
            Spell* s = ab->mSpell;
            if (s != NULL)
            {
                Unit* t = u->GetTarget();
                if (t != NULL)
                {
                    if (ab->iType == GUI_CASTBUTTON_SPELL)
                    {
                        string reason;
                        if (u->IsCastable(s, &reason))
                        {
                            u->Stop();
                            if (s->bSelfOnly)
                                u->Incant(s, u);
                            else
                                u->Incant(s, t);
                        }
                        else
                            mGUIMgr->AddErrorMessage(u->GetName() + " : " + mSceneMgr->tStrTable->GetString(reason.c_str()));
                    }
                    else if (ab->iType == GUI_CASTBUTTON_STOP)
                    {
                        u->Stop();
                    }
                }
                else
                {
                    if (ab->iType == GUI_CASTBUTTON_SPELL)
                    {
                        string reason;
                        if (u->IsCastable(s, &reason, true, true))
                        {
                            mUnitMgr->mCastedButton = ab;
                            mUnitMgr->mCasterUnit = u;

                            if (!s->bSelfOnly)
                                mUnitMgr->bCastingSpell = true;

                            if (s->bSelfOnly)
                            {
                                u->Stop();
                                u->Incant(s, u);
                            }
                            else
                                mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action_imp");
                        }
                        else
                            mGUIMgr->AddErrorMessage(u->GetName() + " : " + mSceneMgr->tStrTable->GetString(reason.c_str()));
                    }
                    else if (ab->iType == GUI_CASTBUTTON_STOP)
                    {
                        u->Stop();
                    }
                }
            }
        }
	}

	return 0;
}

int l_Unit_CastSpellIndirect( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitCastSpellIndirect\" (3 expected : unit id, spell id, spell book)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitCastSpellIndirect must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitCastSpellIndirect must be a number (spell id)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of UnitCastSpellIndirect must be a string (spell book)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
            ActionButton* ab = &u->GetABList()[ToInt(lua_tonumber(luaVM, 2))];
            Spell* s = ab->mSpell;
            if (s != NULL)
            {
                if (ab->iType == GUI_CASTBUTTON_SPELL)
                {
                    string reason;
                    if (u->IsCastable(s, &reason, true, true))
                    {
                        mUnitMgr->mCastedButton = ab;
                        mUnitMgr->mCasterUnit = u;

                        if (!s->bSelfOnly)
                            mUnitMgr->bCastingSpell = true;

                        if (s->bSelfOnly)
                        {
                            u->Stop();
                            u->Incant(s, u);
                        }
                        else
                            mGUIMgr->mCursor = mGUIMgr->SwitchCursor("normal_action_imp");
                    }
                    else
                        mGUIMgr->AddErrorMessage(u->GetName() + " : " + mSceneMgr->tStrTable->GetString(reason.c_str()));
                }
                else if (ab->iType == GUI_CASTBUTTON_STOP)
                {
                    u->Stop();
                }
            }
        }
	}

	return 0;
}

int l_Unit_IsCasting( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitIsCasting\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitIsCasting must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
        Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
        if (u != NULL)
        {
			if(u->IsCasting())
			{
				if (!u->GetSpell()->bChanneled)
				{
					lua_pushstring(luaVM, "SPELL");
				}
				else
				{
					lua_pushstring(luaVM, "CHANNELED");
				}
			}
			else
				lua_pushstring(luaVM, "");
		}
		else
			lua_pushstring(luaVM, "");
	}
	else
		lua_pushstring(luaVM, "");

	return 1;
}

int l_Unit_CastingInfo( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitCastingInfo\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitCastingInfo must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
			if (u->IsCasting())
			{
				Spell* s = u->GetSpell();
				lua_getglobal(luaVM, "Spells");
				lua_getfield(luaVM, -1, s->sName.c_str());
				if (lua_istable(luaVM, -1))
				{
					lua_pushstring(luaVM, s->sName.c_str());
					lua_getfield(luaVM, -2, "rank");
					int iRank = ToInt(lua_tonumber(luaVM, -1));
					lua_pop(luaVM, 1); // rank key
					if (iRank != -1)
						lua_pushstring(luaVM, string(string(mSceneMgr->tStrTable->GetString("gui_cb_rank")) + string(" ") + ToString(iRank)).c_str());
					else
						lua_pushstring(luaVM, "");
					lua_getfield(luaVM, -3, "display_name");
					char* sDispName = (char*)lua_tostring(luaVM, -1);
					lua_pop(luaVM, 1); // display_name key
					lua_pushstring(luaVM, mSceneMgr->tStrTable->GetString(sDispName));
					lua_getfield(luaVM, -4, "icon");
					lua_pushnumber(luaVM, (mTimeMgr->GetTime()-u->GetActionState()*s->fCastTime)*1000);
					lua_pushnumber(luaVM, (mTimeMgr->GetTime()+(1-u->GetActionState())*s->fCastTime)*1000);
				}
				else
				{
					for (int i = 0; i < 6; i++)
						lua_pushnil(luaVM);
				}
			}
			else
			{
				for (int i = 0; i < 6; i++)
					lua_pushnil(luaVM);
			}
		}
		else
		{
			for (int i = 0; i < 6; i++)
				lua_pushnil(luaVM);
		}
	}
	else
	{
		for (int i = 0; i < 6; i++)
			lua_pushnil(luaVM);
	}

	return 6;
}

int l_Unit_GetSpellInfo( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		LUA::PrintError("Too few arguments in \"UnitSpellInfo\" (2 expected : unit id, spell id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitSpellInfo must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitSpellInfo must be a number (spell id)");
		error++;
	}

	if (error == 0)
	{
	    Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
            int spellID = ToInt(lua_tonumber(luaVM, 2));
            if ( (spellID >= 0) && (spellID <= 120) )
            {
				ActionButton* ab = &u->GetABList()[spellID];
				if (ab != NULL)
				{
					Spell* s = ab->mSpell;
					if (s != NULL)
					{
						lua_getglobal(luaVM, "Spells");
						lua_getfield(luaVM, -1, s->sName.c_str());
					}
					else
						lua_pushnil(luaVM);
				}
				else
					lua_pushnil(luaVM);
            }
            else
                lua_pushnil(luaVM);
		}
		else
            lua_pushnil(luaVM);
	}
	else
		lua_pushnil(luaVM);

	return 1;
}

int l_Unit_SetAttacking( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitSetAttacking\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitSetAttacking must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
			u->bAttacking = true;
			mUnitMgr->lAttackerList[u->GetID()] = u;
			mUnitMgr->lActingList[u->GetID()] = u;
		}
	}

	return 0;
}

int l_Unit_SetHealing( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitSetHealing\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitSetHealing must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
			u->bHealing = true;
			mUnitMgr->lHealerList[u->GetID()] = u;
			mUnitMgr->lActingList[u->GetID()] = u;
		}
	}

	return 0;
}

int l_Unit_SetResurrecting( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitSetResurrecting\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitSetResurrecting must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
			u->bResurrecting = true;
			mUnitMgr->lReserList[u->GetID()] = u;
			mUnitMgr->lActingList[u->GetID()] = u;
		}
	}

	return 0;
}

int l_Unit_Damage( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 6)
	{
		LUA::PrintError("Too few arguments in \"UnitDamage\" (6 expected : unit id, caster name, spell name, damages, generate aggro, scrolling text)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitDamage must be a number (unit id)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitDamage must be a string (caster name)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of UnitDamage must be a string (spell name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 4))
	{
		LUA::PrintError("Argument 4 of UnitDamage must be a number (dammages)");
		error++;
	}
	if (!lua_isboolean(luaVM, 5))
	{
		LUA::PrintError("Argument 5 of UnitDamage must be a bool (generate aggro)");
		error++;
	}
	if (!lua_isboolean(luaVM, 6))
	{
		LUA::PrintError("Argument 6 of UnitDamage must be a bool (scrolling text)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
			Unit* c = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 2)));
            if (c != NULL)
            {
                string sname = lua_tostring(luaVM, 3);
				if (mUnitMgr->lSpellList.find(sname) != mUnitMgr->lSpellList.end())
				{
					Spell* s = &mUnitMgr->lSpellList[sname];
					int value = ToInt(lua_tonumber(luaVM, 4));
					u->Damage(s, c, value, lua_toboolean(luaVM, 5));

					int type;
					if (s->iSchool == SPELL_SCHOOL_NONE)
						type = GUI_SCRTXT_TYPE_PHYSICAL;
					else
						type = GUI_SCRTXT_TYPE_SPELL;

					if (lua_toboolean(luaVM, 6))
						mGUIMgr->AddScrollingText(u, type, ToString(value));
				}
			}
		}
	}

	return 0;
}

int l_Unit_Heal( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 5)
	{
		LUA::PrintError("Too few arguments in \"UnitHeal\" (5 expected : unit id, caster name, healings, generate aggro, scrolling text)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitHeal must be a number (unit id)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitHeal must be a string (caster name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of UnitHeal must be a number (healings)");
		error++;
	}
	if (!lua_isboolean(luaVM, 4))
	{
		LUA::PrintError("Argument 4 of UnitHeal must be a bool (generate aggro)");
		error++;
	}
	if (!lua_isboolean(luaVM, 5))
	{
		LUA::PrintError("Argument 5 of UnitHeal must be a bool (scrolling text)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
			Unit* c = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 2)));
            if (c != NULL)
            {
				int value = ToInt(lua_tonumber(luaVM, 3));
				u->Heal(c, value, lua_toboolean(luaVM, 4));
				if (lua_toboolean(luaVM, 5))
					mGUIMgr->AddScrollingText(u, GUI_SCRTXT_TYPE_HEAL, ToString(value));
			}
		}
	}

	return 0;
}

int l_Unit_Res( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 4)
	{
		LUA::PrintError("Too few arguments in \"UnitRes\" (4 expected : unit id, caster name, health gained, mana gained)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitRes must be a number (unit id)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitRes must be a string (caster name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of UnitRes must be a number (health gained)");
		error++;
	}
	if (!lua_isnumber(luaVM, 4))
	{
		LUA::PrintError("Argument 4 of UnitRes must be a number (mana gained)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
			Unit* c = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 2)));
            if (c != NULL)
            {
				int health = ToInt(lua_tonumber(luaVM, 3));
				int mana = ToInt(lua_tonumber(luaVM, 4));
				u->Res(health, mana, c);
			}
		}
	}

	return 0;
}

int l_Unit_AddBuff( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		LUA::PrintError("Too few arguments in \"UnitAddBuff\" (3 expected : unit id, caster name, buff)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitAddBuff must be a number (unit id)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitAddBuff must be a string (caster name)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of UnitAddBuff must be a string (buff)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
			Unit* c = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 2)));
            if (c != NULL)
            {
				u->AddBuff(lua_tostring(luaVM, 3));
			}
		}
	}

	return 0;
}

int l_Unit_GetBuffs( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitGetBuffs\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitGetBuff must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
			multimap<float, Buff*> buffList = u->GetBuffList();
			lua_settop(luaVM, 0);
			lua_pushnumber(luaVM, buffList.size());

			lua_newtable(luaVM);
			multimap<float, Buff*>::iterator iterBuff;
			int i = 1;
			for (iterBuff = buffList.begin(); iterBuff != buffList.end(); iterBuff++)
			{
				Buff* b = iterBuff->second;

				lua_getglobal(luaVM, "Buffs");
				lua_getfield(luaVM, -1, b->sName.c_str());
				//lua_getfield(luaVM, "icon");
				if (lua_istable(luaVM, -1))
				{
					string iconF = LUA::GetFieldString("icon", luaVM);
					lua_pop(luaVM, 2);

					lua_createtable(luaVM, 0, 2);
					LUA::SetFieldFloat("time_remaining", b->mBuff->fDuration - b->fLife, luaVM);
					LUA::SetFieldInt("count", b->iCount, luaVM);
					//LUA::SetFieldString("icon", b->mBuff->sIconFile, luaVM);
					LUA::SetFieldString("icon", iconF.c_str(), luaVM);
					lua_rawseti(luaVM, -2, i);
					i++;
				}
				else
				{
					Log("# Error # : unknown buff \"%s\"", b->sName.c_str());
					lua_pop(luaVM, 2);
				}
			}
		}
	}

	return 2;
}

int l_Unit_ShowSubMesh( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		LUA::PrintError("Too few arguments in \"UnitShowSubMesh\" (3 expected : unit id, submesh id, shown)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitShowSubMesh must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		LUA::PrintError("Argument 2 of UnitShowSubMesh must be a number (submesh id)");
		error++;
	}
	if (!lua_isboolean(luaVM, 3))
	{
		LUA::PrintError("Argument 3 of UnitShowSubMesh must be a bool (shown)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
			Model* m = u->GetModel();
			if (m != NULL)
			{
			    bool show = lua_toboolean(luaVM, 3);
			    if (show)
			    {
                    m->Show((int)lua_tonumber(luaVM, 2));
			    }
			    else
			    {
			        m->Hide((int)lua_tonumber(luaVM, 2));
			    }
			}
		}
	}

	return 0;
}

int l_Unit_Name( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitName\" (one expected : unit id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument of UnitName must be a number (unit id)");
		error++;
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
			lua_pushstring(luaVM, u->GetName().c_str());
		}
		else
            lua_pushnil(luaVM);
	}
	else
        lua_pushnil(luaVM);

	return 1;
}

int l_Unit_Emote( lua_State* luaVM )
{
    int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitEmote\" (2 expected : unit id, emote name)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitEmote must be a number (unit id)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
	    LUA::PrintError("Argument 2 of UnitEmote must be a string (emote name)");
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
			if (!u->IsActing())
			{
			    string sEmote = lua_tostring(luaVM, 2);
			    int    iEmote = -1;

			    if (sEmote == "DANCE")
                    iEmote = ANIM_EMOTE_DANCE;
                else if (sEmote == "BOW")
                    iEmote = ANIM_EMOTE_BOW;
                else if (sEmote == "TALK")
                    iEmote = ANIM_EMOTE_TALK;
                else if (sEmote == "LAUGH")
                    iEmote = ANIM_EMOTE_LAUGH;
                else if (sEmote == "KNEEL")
                    iEmote = ANIM_EMOTE_KNEEL;
                else if (sEmote == "KISS")
                    iEmote = ANIM_EMOTE_KISS;
                else if (sEmote == "CRY")
                    iEmote = ANIM_EMOTE_CRY;
                else if (sEmote == "APPLAUD")
                    iEmote = ANIM_EMOTE_APPLAUD;

                if (iEmote != -1)
                {
                    u->SetAnimState((AnimID)iEmote);
                    u->bEmote = true;
                }
			}
		}
	}

    return 0;
}

int l_Unit_SetAnim( lua_State* luaVM )
{
    int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		LUA::PrintError("Too few arguments in \"UnitSetAnim\" (2 expected : unit id, anim id)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		LUA::PrintError("Argument 1 of UnitSetAnim must be a number (unit id)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
	    LUA::PrintError("Argument 2 of UnitSetAnim must be a number (anim id)");
	}

	if (error == 0)
	{
		Unit* u = mUnitMgr->GetUnitByID(ToInt(lua_tonumber(luaVM, 1)));
		if (u != NULL)
		{
            u->SetAnimState((AnimID)ToInt(lua_tonumber(luaVM, 2)));
            u->bEmote = true;
		}
	}

    return 0;
}

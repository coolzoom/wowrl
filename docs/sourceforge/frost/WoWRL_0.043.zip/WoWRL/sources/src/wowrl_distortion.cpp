/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Distortion source            */
/*                                        */
/*  ## : Contains all the functions that  */
/*  are related to distortion.            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge/hge.h"
#include "hge/hgesprite.h"
#include "hge/hgevector.h"

#include "wowrl_point.h"
#include "wowrl_global.h"
#include "wowrl_zonemanager.h"
#include "wowrl_structs.h"

extern HGE *hge;
extern ZoneManager *mZoneMgr;

float GetPointDistortion( int x, int y )
{
	/* [#] This function returns the distortion of a point. It is no longer used.
	*/

    float distortion;
	BGPart* part = mZoneMgr->mActualZone.GetBGPart(x, y);
	if (part != NULL)
	{
        if (part->bDistData)
        {
            x -= ToInt(part->fX);
            y -= ToInt(part->fY);
            int colorIndex = ToInt(y*mZoneMgr->mActualZone.iPartSize + x);
            if ( (colorIndex >= 0) && (colorIndex < ToInt(mZoneMgr->mActualZone.iPartSize*mZoneMgr->mActualZone.iPartSize+mZoneMgr->mActualZone.iPartSize)) )
            {
                // Distortion is read on the BLUE chanel
                distortion = GETB(part->mDist[colorIndex]);
            }
            else
                distortion = 0.0f;
        }
        else
            distortion = 0.0f;
	}
	else
        distortion = 0.0f;

    return distortion/255.0f;
}

float GetPointShadow( int x, int y )
{
	/* [#] This function returns the intensity of the shadow at the given coordi-
	/* nates.
	*/

    float shadow;
	BGPart* part = mZoneMgr->mActualZone.GetBGPart(x, y);
	if (part != NULL)
	{
        if (part->bDistData)
        {
            x -= ToInt(part->fX);
            y -= ToInt(part->fY);
            int colorIndex = ToInt(y*mZoneMgr->mActualZone.iPartSize + x);
            if ( (colorIndex >= 0) && (colorIndex < ToInt(mZoneMgr->mActualZone.iPartSize*mZoneMgr->mActualZone.iPartSize+mZoneMgr->mActualZone.iPartSize)) )
            {
                // Shadow is read on the GREEN chanel
                return GETG(part->mDist[colorIndex]);
            }
        }
	}

    return 0.0f;
}

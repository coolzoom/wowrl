/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Inventory header            */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Inventory class.               */
/*       An inventory is used to store    */
/*  items received by a unit.             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_inventory.h"
#include "wowrl_global.h"

extern HGE *hge;

Inventory::Inventory()
{
	parent = NULL;
}

void Inventory::Render(float x, float y)
{
	/*int row = ToInt(floor(Rac2(size)));
	w = row*41 + 8+8;
	h = ceil((float)size/row)*41 + 8+28;

	hge->System_SetState(HGE_TEXTUREFILTER, false);
	cornerBottom->SetFlip(true, false, true);
	cornerBottom->Render(x-32, y);
	borderHorizontalBottom->RenderStretch(x-32, y-32, x-w+32, y);
	cornerBottom->SetFlip(false, false, true);
	cornerBottom->Render(x-w, y);
	borderVertical->SetFlip(false, false, true);
	borderVertical->RenderStretch(x-w, y-32, x-w+32, y-h+32);
	borderVertical->SetFlip(true, false, true);
	borderVertical->RenderStretch(x-32, y-32, x, y-h+32);
	cornerTop->SetFlip(true, false, true);
	cornerTop->Render(x-32, y-h);
	cornerTop->SetFlip(false, false, true);
	cornerTop->Render(x-w, y-h);
	borderHorizontalTop->RenderStretch(x-32, y-h, x-w+32, y-h+32);
	background->RenderStretch(x-32, y-32, x-w+32, y-h+32);
	hge->System_SetState(HGE_TEXTUREFILTER, true);

	font->printf(x-w+10, y-h+8, HGETEXT_LEFT, title.c_str());

	closeButton->Render(x-28, y-h+10);

	float bx = x-w+8;
	float by = y-h+28;
	for (int i=1; i <= size; i++)
	{
		if (items.count(i) == 1)
		{
			items[i].icon->RenderEx(bx, by, 0.0f, 0.714f);
		}
		emptySlot->Render(bx, by);
		bx += 41;
		if (bx >= x-8)
		{
			bx = x-w+8;
			by += 41;
		}
	}*/
}

bool Inventory::addItem(Item item)
{
	/*if (items.size() != size)
	{
		for (int i=1; i <= size; i++)
		{
			if (items.count(i) == 0)
			{
				items[i] = item;
				return true;
			}
		}
	}*/

	return false;
}

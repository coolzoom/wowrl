/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Profiler source             */
/*                                        */
/*  ## : A class that manages code        */
/*  profiling.                            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_timemanager.h"

#include <time.h>

using namespace std;

extern HGE* hge;

TimeManager::TimeManager()
{
	QueryPerformanceFrequency(&liFreq);
	bProfiled = false;
	bProfiling = false;
	dStart = dLast = GetTime();
	dProfileTime = 0.0f;
	iFPS = 0;
	fDelta = 0.05f;
}

TimeManager::~TimeManager()
{
	mTimeMgr = NULL;
}

TimeManager* TimeManager::mTimeMgr = NULL;

TimeManager* TimeManager::GetSingleton()
{
	if (mTimeMgr == NULL)
		mTimeMgr = new TimeManager;
	return mTimeMgr;
}

void TimeManager::Update()
{
	QueryPerformanceCounter(&liTs);
	fDelta = (double)(liTs.QuadPart-liOs.QuadPart)/(double)liFreq.QuadPart;
	liOs = liTs;

	// Update FPS
	static float timer = 0.0f;
	static int   frameRateCount = 0;
	static int   frameCount = 0;
	timer -= fDelta;
	frameCount++;

	if (fDelta <= 0.001f)
		frameRateCount += 1000;
	else
		frameRateCount += (int)(1/fDelta);

	if (timer < 0.0f)
	{
		iFPS = frameRateCount/frameCount;
		frameRateCount = 0;
		frameCount = 0;
		timer = 1.0f;

		iAvgFPS += iFPS;
		dFrameNbr++;
	}
}

double TimeManager::GetDelta()
{
	if (fDelta > 0.001f)
		return fDelta;
	else
	{
		if (iFPS != 0)
			return 1.0f/(double)iFPS;
		else
			return 0.0f;
	}
}

int TimeManager::GetFPS()
{
	return iFPS;
}

int TimeManager::GetAverageFPS()
{
    return iAvgFPS/(int)dFrameNbr;
}

//returns the current tick count in seconds
double TimeManager::GetTime()
{
	QueryPerformanceCounter(&liTs);
	return (double)liTs.QuadPart/(double)liFreq.QuadPart;
}

string TimeManager::GetPlayTime()
{
    double time = GetTime()-dStart;
    int hours = (int)floor(time/3600);
    time -= hours*3600;
    int minutes = (int)floor((time)/60);
    time -= minutes*60;
    int seconds = (int)floor(time);
    time -= seconds;
    int miliseconds = (int)floor(time*1000);

    string s = "[";
    s += ToString(hours, 2) + ":";
    s += ToString(minutes, 2) + ":";
    s += ToString(seconds, 2) + ":";
    s += ToString(miliseconds, 3) + "]";

    return s;
}

Profiler* TimeManager::GetProfiler(int group, std::string name, bool autoPrint)
{
	if (bProfiling == true)
	{
		bProfiled = true;

		if (lProfilerList.find(name) == lProfilerList.end())
		{
			Profiler p(group, name, autoPrint);
			lProfilerList.insert(make_pair(name, p));
		}

		return &lProfilerList.find(name)->second;
	}
	else
		return NULL;
}

Profiler::Profiler(int g, string n, bool keep)
{
	sName = n;
	iGroup = g;
	iCallNbr = 0;
	iZeroTimings = 0;
	dTotalTime = 0.0f;
	dLowestTime = -1.0f;
	dHighestTime = -1.0f;
	bKeepRecords = keep;
}

Chrono::Chrono(Profiler* p, bool start)
{
    if (start)
    {
        if (p != NULL)
            dStart = TimeManager::GetSingleton()->GetTime();
        bStopped = false;
    }
    else
    {
        bStopped = true;
    }
    mParent = p;
    dCumul = 0.0f;
}

void Chrono::Start()
{
    if (bStopped)
    {
        if (mParent != NULL)
        {
            dStart = TimeManager::GetSingleton()->GetTime();
        }
        bStopped = false;
    }
}

void Chrono::Stop(bool pause)
{
    if (!bStopped)
    {
        if (mParent != NULL)
        {
            double time = TimeManager::GetSingleton()->GetTime() - dStart;
            dCumul += time;
            if (!pause)
            {
                mParent->AddTiming(dCumul);
                dCumul = 0.0f;
            }
        }
        bStopped = true;
    }
}

double Chrono::GetTime()
{
	return TimeManager::GetSingleton()->GetTime() - dStart;
}

Chrono::~Chrono()
{
	if ( (mParent != NULL) && (!bStopped) )
	{
		double time = TimeManager::GetSingleton()->GetTime() - dStart;
		dCumul += time;
		mParent->AddTiming(dCumul);
	}
}

void Profiler::AddTiming(double time)
{
	iCallNbr++;

	if (time*1000 < 0.001f)
        iZeroTimings++;
    else
    {
        if ( (dLowestTime == -1.0f) || (time < dLowestTime) )
            dLowestTime = time;
        if ( (dHighestTime == -1.0f) || (time > dHighestTime) )
            dHighestTime = time;

        dTotalTime += time;

        if (bKeepRecords)
            lRecordList.push_back(time);
    }
}

void Profiler::SetKeepRecords(bool keep)
{
	bKeepRecords = keep;
}

void Profiler::PrintProfile(double profileTime)
{
	Log("  - %s :", sName.c_str());
	Log("     - call number : %d (%d not timed)", iCallNbr, iZeroTimings);
	if (iCallNbr != 0)
    {
        Log("     - total time : %f s (%.4f%% of total)", dTotalTime, 100*dTotalTime/profileTime);
        Log("     - average time : %f ms", 1000*dTotalTime/(iCallNbr-iZeroTimings));
        Log("     - highest time : %f ms", 1000*dHighestTime);
        Log("     - lowest time : %f ms", 1000*dLowestTime);
        if (bKeepRecords)
        {
            Log("     - listing records :");
            int i = 1;
            vector<double>::iterator iter;
            for (iter = lRecordList.begin(); iter != lRecordList.end(); iter++)
            {
                Log("        [%d] : %f ms", i, (*iter)*1000);
                i++;
            }
        }
	}
}

void TimeManager::SetProfiling(bool prof)
{
	// Update total profiling time
	if (prof && !bProfiling)
		dLast = GetTime();
	else if (!prof && bProfiling)
		dProfileTime = GetTime()-dLast;

	bProfiling = prof;
}

void TimeManager::Print(int group)
{
	if (bProfiled)
	{
		if (bProfiling)
		{
			dProfileTime = GetTime()-dLast;
			bProfiling = false;
		}

        Log("|t\n");
		if (group == -1)
			Log("# Profiling info : %f s of profiling", dProfileTime);
		else
			Log("# Profiling info for group [%d] : %f s of profiling", group, dProfileTime);
		map<string, Profiler>::iterator iter;
		for (iter = lProfilerList.begin(); iter != lProfilerList.end(); iter++)
		{
			Profiler* p = &iter->second;
			if ( (p->GetGroup() == group) || (group == -1) )
				p->PrintProfile(dProfileTime);
		}
		Log("# end.");
	}
}

int TimeManager::GetYear()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_year + 1900;
}

int TimeManager::GetMonth()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_mon + 1;
}

int TimeManager::GetDayName()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_wday + 1;
}

int TimeManager::GetDay()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_mday;
}

int TimeManager::GetHour()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_hour;
}

int TimeManager::GetMinutes()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_min;
}

int TimeManager::GetSeconds()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_sec;
}


/*****************************************************************/
/* # PeriodicTimer :                                             */
/* ------------------------------------------------------------- */
/*   This class is useful if you need a timer that automaticaly  */
/* resets itself every X seconds.                                */
/*****************************************************************/

PeriodicTimer::PeriodicTimer( double period, int start, bool tickFirst )
{
	dPeriod = period;
	if (tickFirst) dElapsed = period;
	else dElapsed = 0.0f;
	iStart = start;
	bPaused = true;
	if (iStart == TIMER_START_NOW) Start();
}

// Returns the time elapsed since last reset.
double PeriodicTimer::GetElapsed()
{
	if (!bPaused)
		return dElapsed + TimeManager::GetSingleton()->GetTime() - dStart;
	else
		return dElapsed;
}

// Returns true when the period is reached.
bool PeriodicTimer::Ticks()
{
    if (iStart == TIMER_START_FIRST)
    {
        iStart = -1;
        Start();
    }

	if (!bPaused)
	{
		if ((dElapsed + TimeManager::GetSingleton()->GetTime() - dStart) >= dPeriod)
		{
			Zero();
			return true;
		}
		else
			return false;
	}
	else
	{
		if (dElapsed >= dPeriod)
			return true;
		else
			return false;
	}
}

// Stops and reset the timer.
void PeriodicTimer::Stop()
{
	dElapsed = 0;
	bPaused = true;
}

// Starts the timer. Can be automatically called in the constructor.
void PeriodicTimer::Start()
{
	if (bPaused)
	{
		dStart = TimeManager::GetSingleton()->GetTime();
		bPaused = false;
	}
}

// Stops the timer, but keeps the time elapsed.
void PeriodicTimer::Pause()
{
	if (!bPaused)
	{
		dElapsed += TimeManager::GetSingleton()->GetTime() - dStart;
		bPaused = true;
	}
}

// Resets the timer, but doesn't stop it.
void PeriodicTimer::Zero()
{
	dElapsed = 0;
	dStart = TimeManager::GetSingleton()->GetTime();
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Node source               */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Node class.                    */
/*       The Node is only used for the    */
/*  pathfinding function. Its use may be  */
/*  extended later on.                    */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_global.h"
#include "wowrl_point.h"

#include "wowrl_node.h"

Node::Node() : fX(0.0f), fY(0.0f),
               fF(0.0f),
               fG(0),
               bClosed(false),
               bOpened(false),
               bWalkable(false),
               bUseless(false)
{
	mParent = NULL;
}

Node::~Node()
{
    fX = 0.0f; fY = 0.0f;
    fF = 0.0f;
    fG = 0;
    mParent = NULL;
    bClosed = false;
    bOpened = false;
    bWalkable = false;
    bUseless = false;
}


void Node::Set( float nx, float ny, Node* nparent=0, float nf=0, float ng=0 )
{
	fX = nx;
	fY = ny;
	mParent = nparent;
	fF = nf;
	fG = ng;
}

Point Node::GetPoint()
{
	Point p;
	p.fX = fX;
	p.fY = fY;
	return p;
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_unit.h"
#include "wowrl_global.h"
#include "wowrl_scenemanager.h"

using namespace std;

extern SceneManager *mSceneMgr;

string Unit::ParseString( string s )
{
	StrReplace(&s, "[unit]", sName);
	if (mTarget != NULL)
	{
		StrReplace(&s, "[target]", mTarget->GetName());
		StrReplace(&s, "[target ]", mTarget->GetName() + " ");
	}
	else
	{
		StrReplace(&s, "[target]", "");
		StrReplace(&s, "[target ]", "");
	}

	return s;
}

string Unit::ParseStringAttack( string s, Unit* c, Spell* spell, int value )
{
	StrReplace(&s, "[unit]", sName);

	if (mTarget != NULL)
	{
		StrReplace(&s, "[target]", mTarget->GetName());
		StrReplace(&s, "[target ]", mTarget->GetName() + " ");
	}
	else
	{
		StrReplace(&s, "[target]", "");
		StrReplace(&s, "[target ]", "");
	}

	if (c != NULL)
	{
		StrReplace(&s, "[caster]", c->GetName());
		StrReplace(&s, "[caster ]", c->GetName() + " ");
	}
	else
	{
		StrReplace(&s, "[caster]", "");
		StrReplace(&s, "[caster ]", "");
	}

	if (value > 0)
	{
		StrReplace(&s, "[value]", ToString(value));
		StrReplace(&s, "[value ]", ToString(value) + " ");
	}
	else
	{
		StrReplace(&s, "[value]", "");
		StrReplace(&s, "[value ]", "");
	}

	if (spell != NULL)
	{
		StrReplace(&s, "[cspell]", spell->sName);
		StrReplace(&s, "[cspell ]", spell->sName + " ");

		string school = "";
		if (spell->iSchool == SPELL_SCHOOL_HOLY)
			school = mSceneMgr->tStrTable->GetString("school_holy");
		else if (spell->iSchool == SPELL_SCHOOL_FROST)
			school = mSceneMgr->tStrTable->GetString("school_frost");
		else if (spell->iSchool == SPELL_SCHOOL_FIRE)
			school = mSceneMgr->tStrTable->GetString("school_fire");
		else if (spell->iSchool == SPELL_SCHOOL_NATURE)
			school = mSceneMgr->tStrTable->GetString("school_nature");
		else if (spell->iSchool == SPELL_SCHOOL_SHADOW)
			school = mSceneMgr->tStrTable->GetString("school_shadow");
		else if (spell->iSchool == SPELL_SCHOOL_ARCANE)
			school = mSceneMgr->tStrTable->GetString("school_arcane");
		StrReplace(&s, "[school]", school);
		StrReplace(&s, "[school ]", school + " ");
	}
	else
	{
		StrReplace(&s, "[cspell]", "");
		StrReplace(&s, "[cspell ]", "");
	}

	return s;
}

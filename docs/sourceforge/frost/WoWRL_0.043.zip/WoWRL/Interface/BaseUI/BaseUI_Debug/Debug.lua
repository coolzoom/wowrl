
SLASH_DEBUG1 = "/debug";
SLASH_DEBUG2 = "/d";

SlashCmdList["DEBUG"] = function(msg)
	if (Debug:IsShown()) then
		Debug:Hide();
	else
		Debug:Show();
	end
end

---------
function BUI_DebugEB_OnEnterPressed(show)
---------
	local u = tonumber(DebugNameEB:GetText());
	if (u ~= nil) then
		local id = tonumber(this:GetText());
		if (id ~= nil) then
			UnitShowSubMesh(u, id, show);
		end
	end
	this:SetText("");
end

---------
function BUI_DebugButton_OnClick()
---------
	if (UNIT ~= nil) then
		DebugNameEB:SetText(UNIT);
	end
end


local buttonNumber = 0;

---------
function BUI_ActionBar_OnUpdate()
---------
	if (UNIT == nil) then
		this.Buttons:Hide();
	else
		this.Buttons:Show();
	end
end

---------
function BUI_AButton_OnLoad()
---------
	this.number = buttonNumber;
	this.spellID = buttonNumber;
	this.oldIcon = "";
	this.lastUnit = nil;
	this.empty = true;
	
	buttonNumber = buttonNumber+1;
end

---------
function BUI_AButton_OnUpdate()
---------
	if (UNIT ~= nil) then
		-- Update icon texture
		if (UNIT ~= this.lastUnit) then
			local iconFile = UnitGetActionTexture(UNIT, this.number);
			if (iconFile ~= this.oldIcon) then
				if (iconFile == "") then
					this.empty = true;
				else
					this.empty = false;
				end
				local backdropTable = this:GetBackdrop();
				backdropTable.bgFile = iconFile;
				this:SetBackdrop(backdropTable);
				this.oldIcon = iconFile;
			end
			this.lastUnit = UNIT;
		end
		
		-- Update icon color, red if out of range, grey is not usable, 
		-- blue if not enough mana/rage/energy.
		if not(this.empty) then
			local inRange = UnitIsActionInRange(UNIT, this.number);

			if ( (inRange == 1) or (inRange == nil) ) then
				local usable, enoughMana, cooldown, left = UnitIsUsableAction(UNIT, this.number);
				
				if ( (usable == 1) or (usable == nil) ) then
					this:SetBackdropColor(1,1,1,1);
				elseif (enoughMana == 1) then
					this:SetBackdropColor(0,0,1,1);
				else
					this:SetBackdropColor(0.3,0.3,0.3,1);
				end
			else
				this:SetBackdropColor(1,0,0,1);
			end
		else
			this:SetBackdropColor(0.2,0.2,0.2,0.6);
		end
	end
end

---------
function BUI_AButton_OnMouseUp()
---------
	if not(this.empty) then
		if (arg1 == "LeftButton") then
			UnitCastSpell(UNIT, this.spellID, "spell");
		elseif (arg1 == "RightButton") then
			UnitCastSpellIndirect(UNIT, this.spellID, "spell");
		end
	end
end

---------
function BUI_AButton_OnEnter()
---------
	if not(this.empty) then
		local info = UnitGetActionInfo(UNIT, this.number);
		if (info == "spell") then
			ChangeToolTipContent = true;
			AskingForTooltip = AskingForTooltip+1;
			NewContent = {
				["type"] = "spell";
				["content"] = UnitSpellInfo(UNIT, this.spellID);
			};
		elseif (info == "stop") then
			ChangeToolTipContent = true;
			AskingForTooltip = AskingForTooltip+1;
			NewContent = {
				["type"] = "stop";
			};
		elseif (info == "item") then
			ChangeToolTipContent = true;
			AskingForTooltip = AskingForTooltip+1;
		end
	end
end

---------
function BUI_AButton_OnLeave()
---------
	if not(this.empty) then
		AskingForTooltip = AskingForTooltip-1;
		ChangeToolTipContent = true;
	end
end


---------
function BUI_UF_OnUpdate()
---------
	if (UNIT ~= nil) then
		-- Unit name and level
		UnitFrameName:SetText(UnitName(UNIT));
		if (UnitIsHostile(UNIT)) then
			UnitFrameName:SetTextColor(1,0,0);
		else
			UnitFrameName:SetTextColor(0,1,0);
		end
		
		UnitFrameLevel:SetText(UnitLevel(UNIT));

		local UNIT_HEALTH = UnitHealth(UNIT);
		local UNIT_MAXHEALTH = UnitHealthMax(UNIT);
		local UNIT_MANA = UnitMana(UNIT);
		local UNIT_MAXMANA = UnitManaMax(UNIT);
	
		if (UnitIsDead(UNIT)) then
			-- Manage the health and mana bars
			UnitFrameHealthBar:SetValue(0);
			UnitFrameHealthBarBg:SetStatusBarColor(0.5, 0.5, 0.5, 0.7);
			UnitFrameHealthBarBg:SetMinMaxValues(0, UNIT_MAXHEALTH);
			UnitFrameHealthBarBg:SetValue(UNIT_MAXHEALTH);
			
			UnitFrameManaBar:SetValue(0);
			UnitFrameManaBarBg:SetStatusBarColor(0.5, 0.5, 0.5, 0.7);
			UnitFrameManaBarBg:SetMinMaxValues(0, UNIT_MAXMANA);
			UnitFrameManaBarBg:SetValue(UNIT_MAXMANA);
			
			UnitFrameHealthBarValues:SetText("0 / "..UNIT_MAXHEALTH);
			UnitFrameHealthPercent:SetText(UNITFRAME_DEAD);
			
			UnitFrameManaBarValues:SetText("0 / "..UNIT_MAXMANA);
			UnitFrameManaPercent:SetText(UNITFRAME_DEAD);
		else
			-- Manage the health and mana bars
			local color = {
				["r"] = 1;
				["g"] = 1;
				["b"] = 0;
			}
			if (UNIT_HEALTH/UNIT_MAXHEALTH >= 0.5) then
				color.g = 1;
				color.r = (1-UNIT_HEALTH/UNIT_MAXHEALTH)*2;
			else
				color.r = 1;
				color.g = (UNIT_HEALTH/UNIT_MAXHEALTH)*2;
			end
			UnitFrameHealthBar:SetStatusBarColor(color.r, color.g, color.b, 1.0);
			UnitFrameHealthBar:SetMinMaxValues(0, UNIT_MAXHEALTH);
			UnitFrameHealthBar:SetValue(UNIT_HEALTH);
			UnitFrameHealthBarBg:SetStatusBarColor(color.r, color.g, color.b, 0.25);
			UnitFrameHealthBarBg:SetMinMaxValues(0, UNIT_MAXHEALTH);
			UnitFrameHealthBarBg:SetValue(UNIT_MAXHEALTH);
			
			local UNIT_POWERTYPE = UnitPowerType(UNIT);
			if (UNIT_POWERTYPE == 0) then -- Mana, blue
				color.r = 0; color.g = 0; color.b = 1;
			elseif (UNIT_POWERTYPE == 1) then -- Rage, red
				color.r = 1; color.g = 0; color.b = 0;
			elseif (UNIT_POWERTYPE == 2) then -- Focus, orange
				color.r = 1; color.g = 0.5; color.b = 0;
			elseif (UNIT_POWERTYPE == 3) then -- Energy, yellow
				color.r = 1; color.g = 1; color.b = 0;
			else -- Happiness ?
				color.r = 1; color.g = 1; color.b = 1;
			end
			UnitFrameManaBar:SetStatusBarColor(color.r, color.g, color.b, 1.0);
			UnitFrameManaBar:SetMinMaxValues(0, UNIT_MAXMANA);
			UnitFrameManaBar:SetValue(UNIT_MANA);
			UnitFrameManaBarBg:SetStatusBarColor(color.r, color.g, color.b, 0.25);
			UnitFrameManaBarBg:SetMinMaxValues(0, UNIT_MAXMANA);
			UnitFrameManaBarBg:SetValue(UNIT_MAXMANA);
			
			-- Unit health and mana/energy/rage percentages/values			
			UnitFrameHealthBarValues:SetText(UNIT_HEALTH.." / "..UNIT_MAXHEALTH);
			local healthPercent = string.format("%.0f", 100*UNIT_HEALTH/UNIT_MAXHEALTH);
			UnitFrameHealthPercent:SetText(healthPercent.."%%");
			
			UnitFrameManaBarValues:SetText(UNIT_MANA.." / "..UNIT_MAXMANA);
			local manaPercent = string.format("%.0f", 100*UNIT_MANA/UNIT_MAXMANA);
			UnitFrameManaPercent:SetText(manaPercent.."%%");
		end
		
		UnitFrame:Show();
	else
		UnitFrame:Hide();
	end
end

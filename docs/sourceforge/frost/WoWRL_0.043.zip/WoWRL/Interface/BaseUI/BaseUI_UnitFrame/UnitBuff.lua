local old_buffs = nil;

---------
function BUI_UnitBuff_OnUpdate()
---------
	if (UNIT ~= nil) then
		local buffNbr, buffs = UnitGetBuffs(UNIT);
		if (old_buffs ~= buffs) then
			if (buffNbr ~= 0) then
				for i=1, buffNbr do
					local BuffFrame = GetGlobal("UnitBuffB"..i)
					local buff = buffs[i];
					if (buff ~= nil) then
						-- Change backdrop background
						local backdropTable = BuffFrame.Icon:GetBackdrop();
						backdropTable.bgFile = buff.icon;
						BuffFrame.Icon:SetBackdrop(backdropTable);
						-- Set duration
						BuffFrame.remaining = buff.time_remaining;
						BuffFrame.DurationText:SetText(TimeToString(BuffFrame.remaining));
						-- Set count
						if (buff.count > 1) then
							BuffFrame.Icon.CountText:SetText(tostring(buff.count));
							BuffFrame.Icon.CountText:Show();
						else
							BuffFrame.Icon.CountText:Hide();
						end
						BuffFrame:Show();
					end
				end
			end
			for i=buffNbr+1, 10 do
				local BuffFrame = GetGlobal("UnitBuffB"..i)
				BuffFrame:Hide();
			end
		end
		old_buffs = buffs;
	else
		if (old_buffs ~= nil) then
			for i=1, 10 do
				local BuffFrame = GetGlobal("UnitBuffB"..i)
				BuffFrame:Hide();
			end
		end
	end
end

---------
function TimeToString(time)
---------
	if (time >= 3600) then
		-- Format : [hour]h[min]
		local h = math.floor(time/3600);
		local m = math.floor(time/60-h*60);
		local hs = tostring(h);
		local ms;
		if (m < 10) then
			ms = "0"..tostring(m);
		else
			ms = tostring(m);
		end
		return hs.."h"..ms;
	elseif (time >= 60) then
		-- Format : [min]h[sec]
		local m = math.floor(time/60);
		local s = math.floor(time-m*60);
		local ms = tostring(m);
		local ss;
		if (s < 10) then
			ss = "0"..tostring(s);
		else
			ss = tostring(s);
		end
		return ms.."m"..ss;
	else
		-- Format : [sec]s
		local s = math.floor(time);
		return ss.."s";
	end
end


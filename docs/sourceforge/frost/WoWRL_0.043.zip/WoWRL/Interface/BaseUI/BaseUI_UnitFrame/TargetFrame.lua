
---------
function BUI_TF_OnUpdate()
---------
	if (TARGET ~= nil) and (UNIT ~= nil) then
		-- Target name and level
		TargetFrameName:SetText(UnitName(TARGET));
		if (UnitIsHostile(TARGET)) then
			TargetFrameName:SetTextColor(1,0,0);
		else
			TargetFrameName:SetTextColor(0,1,0);
		end
		
		TargetFrameLevel:SetText(UnitLevel(TARGET));

		local TARGET_HEALTH = UnitHealth(TARGET);
		local TARGET_MAXHEALTH = UnitHealthMax(TARGET);
		local TARGET_MANA = UnitMana(TARGET);
		local TARGET_MAXMANA = UnitManaMax(TARGET);
		
		if (UnitIsDead(TARGET)) then
			-- Manage the health and mana bars
			TargetFrameHealthBar:SetValue(0);
			TargetFrameHealthBarBg:SetStatusBarColor(0.5, 0.5, 0.5, 0.7);
			TargetFrameHealthBarBg:SetMinMaxValues(0, TARGET_MAXHEALTH);
			TargetFrameHealthBarBg:SetValue(TARGET_MAXHEALTH);
			
			TargetFrameManaBar:SetValue(0);
			TargetFrameManaBarBg:SetStatusBarColor(0.5, 0.5, 0.5, 0.7);
			TargetFrameManaBarBg:SetMinMaxValues(0, TARGET_MAXMANA);
			TargetFrameManaBarBg:SetValue(TARGET_MAXMANA);
			
			TargetFrameHealthBarValues:SetText("0 / "..TARGET_MAXHEALTH);
			TargetFrameHealthPercent:SetText(UNITFRAME_DEAD);
			
			TargetFrameManaBarValues:SetText("0 / "..TARGET_MAXMANA);
			TargetFrameManaPercent:SetText(UNITFRAME_DEAD);
		else
			-- Manage the health and mana bars
			local color = {
				["r"] = 1;
				["g"] = 1;
				["b"] = 0;
			}
			if (TARGET_HEALTH/TARGET_MAXHEALTH >= 0.5) then
				color.g = 1;
				color.r = (1-TARGET_HEALTH/TARGET_MAXHEALTH)*2;
			else
				color.r = 1;
				color.g = (TARGET_HEALTH/TARGET_MAXHEALTH)*2;
			end
			TargetFrameHealthBar:SetStatusBarColor(color.r, color.g, color.b, 1.0);
			TargetFrameHealthBar:SetMinMaxValues(0, TARGET_MAXHEALTH);
			TargetFrameHealthBar:SetValue(TARGET_HEALTH);
			TargetFrameHealthBarBg:SetStatusBarColor(color.r, color.g, color.b, 0.25);
			TargetFrameHealthBarBg:SetMinMaxValues(0, TARGET_MAXHEALTH);
			TargetFrameHealthBarBg:SetValue(TARGET_MAXHEALTH);
			
			local TARGET_POWERTYPE = UnitPowerType(TARGET);
			if (TARGET_POWERTYPE == 0) then -- Mana, blue
				color.r = 0; color.g = 0; color.b = 1;
			elseif (TARGET_POWERTYPE == 1) then -- Rage, red
				color.r = 1; color.g = 0; color.b = 0;
			elseif (TARGET_POWERTYPE == 2) then -- Focus, orange
				color.r = 1; color.g = 0.5; color.b = 0;
			elseif (TARGET_POWERTYPE == 3) then -- Energy, yellow
				color.r = 1; color.g = 1; color.b = 0;
			else -- Happiness ?
				color.r = 1; color.g = 1; color.b = 1;
			end
			TargetFrameManaBar:SetStatusBarColor(color.r, color.g, color.b, 1.0);
			TargetFrameManaBar:SetMinMaxValues(0, TARGET_MAXMANA);
			TargetFrameManaBar:SetValue(TARGET_MANA);
			TargetFrameManaBarBg:SetStatusBarColor(color.r, color.g, color.b, 0.25);
			TargetFrameManaBarBg:SetMinMaxValues(0, TARGET_MAXMANA);
			TargetFrameManaBarBg:SetValue(TARGET_MAXMANA);
			
			-- Target name, health and mana/energy/rage percentages/values
			TargetFrameHealthBarValues:SetText(TARGET_HEALTH.." / "..TARGET_MAXHEALTH);
			local healthPercent = string.format("%.0f", 100*TARGET_HEALTH/TARGET_MAXHEALTH);
			TargetFrameHealthPercent:SetText(healthPercent.."%%");
			
			TargetFrameManaBarValues:SetText(TARGET_MANA.." / "..TARGET_MAXMANA);
			local manaPercent = string.format("%.0f", 100*TARGET_MANA/TARGET_MAXMANA);
			TargetFrameManaPercent:SetText(manaPercent.."%%");
		end
		
		TargetFrame:Show();
	else
		TargetFrame:Hide();
	end
end

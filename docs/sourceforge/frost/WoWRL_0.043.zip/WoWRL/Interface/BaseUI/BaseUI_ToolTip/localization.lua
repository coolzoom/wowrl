
if ( GetLocale() == "frFR" ) then
	
	-- FRANCAIS
	TT_SPELL_RANK = "Rang [rank]";
	TT_SPELL_COST = "[cost_type] : [cost]";
	TT_SPELL_OFMAX = "[cost_percent]%% du maximum";
	TT_SPELL_CASTTIME = "[cast_time] sec d'incantation";
	TT_SPELL_INSTANT = "Instantan�";
	TT_SPELL_RANGE = "port�e de [range] m";

else

	-- ENGLISH, default
	TT_SPELL_RANK = "Rank [rank]";
	TT_SPELL_COST = "[cost] [cost_type]";
	TT_SPELL_OFMAX = "[cost_percent]%% of maximum";
	TT_SPELL_CASTTIME = "[cast_time] sec. cast";
	TT_SPELL_INSTANT = "Instant";
	TT_SPELL_RANGE = "[range] yd range";
	
end

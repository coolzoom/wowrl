SLASH_HELP1 = "/help";

SlashCmdList["HELP"] = function(msg)
	if (HelpScreen:IsShown()) then
		HelpScreen:Hide();
	else
		HelpScreen:Show();
	end
end

---------
function BUI_HelpPageBox_OnEnterPressed()
---------
	local text = this:GetText();
	if (text == "0") then
		HelpScreenHelpString:SetText(HELPSCREEN_MENU);
	elseif (text == "1") then
		HelpScreenHelpString:SetText(HELPSCREEN_SELMOV);
	end
end

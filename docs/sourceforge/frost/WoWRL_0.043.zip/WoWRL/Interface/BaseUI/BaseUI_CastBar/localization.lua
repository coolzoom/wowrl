
if ( GetLocale() == "frFR" ) then
	
	-- FRANCAIS

else

	-- ENGLISH, default

end

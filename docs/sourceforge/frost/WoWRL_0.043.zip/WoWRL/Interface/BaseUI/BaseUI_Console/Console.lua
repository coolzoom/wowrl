SLASH_CONSOLE1 = "/console";
SLASH_CONSOLE2 = "/c";

SlashCmdList["CONSOLE"] = function(msg)
	if (Console:IsShown()) then
		Console:Hide();
	else
		Console:Show();
	end
end

---------
function BUI_ConsoleExecButton_OnClick()
---------
	RunScript(ConsoleEditBox:GetText());
end

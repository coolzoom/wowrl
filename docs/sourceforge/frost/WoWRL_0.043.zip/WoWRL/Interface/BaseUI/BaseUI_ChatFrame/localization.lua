
if ( GetLocale() == "frFR" ) then
	
	-- FRANCAIS
	CHATFRAME_WELCOME_MSG = " - WoWRL v.|cffff00000.043|r - \n|cffffdc00Bienvenue en Azeroth ! Tapez /help pour afficher de l'aide. Appuyez sur T pour �crire.";

else

	-- ENGLISH, default
	CHATFRAME_WELCOME_MSG = " - WoWRL v.|cffff00000.043|r - \n|cffffdc00Welcome to Azeroth ! Type /help to bring the help screen. Press T to write.";
	
end

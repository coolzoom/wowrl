-- Localized emotes slash commands
-- English emotes are available to all languages.

if ( GetLocale() == "frFR" ) then
	SLASH_APPLAUD4 = "/applaudir";
	SLASH_BOW2     = "/courbette";
	SLASH_CRY2     = "/pleurer";
	SLASH_DANCE2   = "/dancer";
	SLASH_KNEEL2   = "/genou";
	SLASH_KISS3    = "/bisou";
	SLASH_KISS4    = "/embrasser";
	SLASH_LAUGH3   = "/rire";
	SLASH_LAUGH4   = "/mdr";
	SLASH_TALK2    = "/parler";
end

SLASH_APPLAUD1 = "/applaud";
SLASH_APPLAUD2 = "/applause";
SLASH_APPLAUD3 = "/bravo";
SLASH_BOW1     = "/bow";
SLASH_CRY1     = "/cry";
SLASH_DANCE1   = "/dance";
SLASH_KNEEL1   = "/kneel";
SLASH_KISS1    = "/kiss";
SLASH_KISS2    = "/blow";
SLASH_LAUGH1   = "/laugh";
SLASH_LAUGH2   = "/lol";
SLASH_TALK1    = "/talk";

function Emote(emote)
	if (UNIT ~= nil) then
		UnitEmote(UNIT, emote);
	end
end

SlashCmdList["APPLAUD"] = function(msg)
	Emote("APPLAUD");
end

SlashCmdList["BOW"] = function(msg)
	Emote("BOW");
end

SlashCmdList["CRY"] = function(msg)
	Emote("CRY");
end

SlashCmdList["DANCE"] = function(msg)
	Emote("DANCE");
end

SlashCmdList["KNEEL"] = function(msg)
	Emote("KNEEL");
end

SlashCmdList["KISS"] = function(msg)
	Emote("KISS");
end

SlashCmdList["LAUGH"] = function(msg)
	Emote("LAUGH");
end

SlashCmdList["TALK"] = function(msg)
	Emote("TALK");
end

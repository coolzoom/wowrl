
	/* ###################################### */
	/* ###   WoW Raid Leader, by Kalith   ### */
	/* ###################################### */
	/*                                        */
	/* Powered by :                           */
	/* Haaf's Game Engine 1.7                 */
	/* Copyright (C) 2003-2007, Relish Games  */
	/* hge.relishgames.com                    */
	/*                                        */
	/*                  README                */
	/*                                        */
	/******************************************/

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of
    the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program; if not, write to the Free
    Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
    Boston, MA 02110-1301 USA.


## Important :
Data pack is not needed anymore : you've just downloaded all that
is requiered to play. Enjoy !


## What is done so far :

 - Classic RTS unit manipulation (selection, orders, ...)
 - Collision detection and pathfinding (with a precalculated
   waypoint system in combination with real time pathfinding).
 - Animated sprites.
 - Almost everything is dynamic and easily modifiable thanks to
   lua and xml files.
 - Special effects.
 - Offensive (no DOT), resurrection and heal (no HOT) spells.
 - Basic stats implemented (stamina, intellect and spirit), others
   are to come shortly.
 - Range checking.
 - In combat flag.
 - Aggro range : if a friendly unit enters the aggro range
   of a hostile unit, the hostile one will attack the other until
   death. If the friendly unit escapes (out of range), the
   hostile unit will try to get in range again and attack. If it
   succeed in killing its target, the hostile unit goes back where
   it was before the aggro.
 - Inflicting damage to a hostile unit (or healing a friendly unit that
   is in a hostile's aggro list) increases threat. The unit with the
   highest threat in the list is targeted. Note that you generate less
   threat is you're not targeted (10% less in melee range and 30%
   elsewhere). Every hostile unit has its own threat list, but friendly
   ones don't : it's all up to you to choose which enemy to kill first.
 - Complex AddOn management (like in WoW). The WoWRL API is different
   from the one used in WoW. The goal is to make WoW's AddOns work with
   WoWRL with the least modifications possible.


## To Do :

# Gameplay :
 - Add patrols
 - Implement the specialisation system
 - Add gears (boots, rings, ...)
 - Allow selection and casting from the target and unit frames
 - Add pets for hunters and warlocks
 - Allow heal and damage over time
 - Add keybindings
 - Add a new zone (Orgrimmar or Ironforge) in which the player could :
 -- decide where he wants to go (which instance)
 -- manage the guild (recruitment)
 -- buy things in the auction house
 -- ...

# GUI :
 - Add a raid frame (display the health of all units in the raid)
 - Add a resurection monitor
 - Add a main tanks frame
 - Add a config screen
 - Add a main menu

# Graphics and game engine :
 - Allow zoning
 - Add waypoints to reduce the time spent calculating large paths
 - Add fog of war (?)
 - Render animations for all other classes, races, creatures, spells,
   add all the spells in the ini files, add all the lvl 60 dungeons of WoW.


## Settings :

See config.ini to edit them.
Resolution suported :
 - 1024 / 768 and higher (lower resolutions work, but they may not be good to play).


## Game controls :

#------------------------------##-----------------------------------------------------------#
|                 [Left click] || Select a unit (or deselect)                               |
#------------------------------||-----------------------------------------------------------#
|         [Shift + Left click] || Select/deselect the unit under the mouse without          |
|                              || loosing the old selection.                                |
#------------------------------||-----------------------------------------------------------#
|       [Control + Left click] || Select all the available units of the same class.         |
#------------------------------||-----------------------------------------------------------#
|         [Dragged left click] || Draw a selection square.                                  |
#------------------------------||-----------------------------------------------------------#
| [Shift + Dragged left click] || Draw a selection square without loosing the old selection.|
#------------------------------||-----------------------------------------------------------#
|                [Right click] || Order all selected units to go near where you             |
|                              || clicked or to attack a hostile unit.                      |
#------------------------------||-----------------------------------------------------------#
|      [Control + Right click] || Force all selected units to go exactly where you clicked. |
#------------------------------||-----------------------------------------------------------#
|          [Alt + Right click] || Make all selected units target the unit under the         |
|                              || pointer.                                                  |
#------------------------------||-----------------------------------------------------------#
|                      [Pause] || Pause the game.                                           |
#------------------------------||-----------------------------------------------------------#
|                     [Delete] || Kill all selected units.                                  |
#------------------------------||-----------------------------------------------------------#
|                          [S] || Hide/show status bars.                                    |
#------------------------------||-----------------------------------------------------------#
|                  [Shift + S] || Hide/show enemies' status bars.                           |
#------------------------------||-----------------------------------------------------------#
|                     [Escape] || Exit the game.                                            |
#------------------------------##-----------------------------------------------------------#

## Debug, fun controls :

#------------------------------##-----------------------------------------------------------#
|             [1,2,3 (numpad)] || Spawn a mage at the mouse position (2 spawns a hunter,    |
|                              || 3 a priest).                                              |
#------------------------------||-----------------------------------------------------------#
|                          [C] || Puts all selected units in combat.                        |
#------------------------------||-----------------------------------------------------------#
|                          [H] || Make all selected units hostile.                          |
#------------------------------##-----------------------------------------------------------#
|                          [R] || Reloads the UI.                                           |
#------------------------------##-----------------------------------------------------------#


## Good to know :

 - Almost all the graphics of the game are extracted from World
of Warcraft and are the property of Blizzard. Please do not use
them unless you own the game.
 - For those interested, backgrounds are extracted with WoW
mapview and sprites are extracted with WoW modelview. See
http://www.wowmodelviewer.org/ for more infos.
 - The keyhandler has been written by suliman from the HGE forums.
 - HGE is a powerfull and flexible 2D game engine. It used to be
a shareware, but it is now released as a freeware. So great
thanks to Haaf and his team !
 - This program is released under the GPL license. See gnu.txt
for more details.
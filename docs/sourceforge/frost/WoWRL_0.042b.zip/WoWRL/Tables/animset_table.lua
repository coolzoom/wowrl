-- Characters' animation sets database

AnimSets = {
	["mage"] = {
	    ["scale"] = 1.00;
	    ["shadow_scale"] = 0.70;
		["status_bar_size"] = 45;
		["status_bar_y_offset"] = 62;
		["states"] = {
			[1] = {
			    ["name"] = "stand";
			    ["sub_animations"] = {
			        [0] = Gfx_createAnimation(
			                    "mage_stand_0",
			                    "Animations/mage/mage_stand_1.png",
			                    false, 32, 16, 0, 0, 46, 59, 16, 48
						  );
					[1] = Gfx_createAnimation(
			                    "mage_stand_1",
			                    "Animations/mage/mage_stand_1.png",
			                    false, 32, 16, 460, 118, 46, 59, 16, 49
						  );
					[2] = Gfx_createAnimation(
			                    "mage_stand_2",
			                    "Animations/mage/mage_stand_2.png",
			                    false, 32, 16, 0, 0, 55, 56, 25, 46
						  );
					[3] = Gfx_createAnimation(
			                    "mage_stand_3",
			                    "Animations/mage/mage_stand_2.png",
			                    false, 32, 16, 275, 168, 55, 56, 27, 45
						  );
					[4] = Gfx_createAnimation(
			                    "mage_stand_4",
			                    "Animations/mage/mage_stand_3.png",
			                    false, 32, 16, 0, 0, 43, 63, 30, 43
						  );
					[5] = Gfx_createAnimation(
			                    "mage_stand_5",
			                    "Animations/mage/mage_stand_3.png",
			                    false, 32, 16, 430, 126, 43, 63, 30, 44
						  );
					[6] = Gfx_createAnimation(
			                    "mage_stand_6",
			                    "Animations/mage/mage_stand_4.png",
			                    false, 32, 16, 0, 0, 59, 61, 30, 49
						  );
					[7] = Gfx_createAnimation(
			                    "mage_stand_7",
			                    "Animations/mage/mage_stand_4.png",
			                    false, 32, 16, 0, 244, 59, 61, 29, 50
						  );
			    },
			},
			[2] = {
			    ["name"] = "walk";
			    ["sub_animations"] = {
			        [0] = Gfx_createAnimation(
			                    "mage_walk_0",
			                    "Animations/mage/mage_walk_1.png",
			                    false, 16, 20, 0, 0, 82, 86, 42, 64
						  );
					[1] = Gfx_createAnimation(
			                    "mage_walk_1",
			                    "Animations/mage/mage_walk_1.png",
			                    false, 16, 20, 328, 86, 82, 86, 44, 62
						  );
					[2] = Gfx_createAnimation(
			                    "mage_walk_2",
			                    "Animations/mage/mage_walk_1.png",
			                    false, 16, 20, 656, 172, 82, 86, 43, 58
						  );
					[3] = Gfx_createAnimation(
			                    "mage_walk_3",
			                    "Animations/mage/mage_walk_1.png",
			                    false, 16, 20, 0, 344, 82, 86, 42, 58
						  );
					[4] = Gfx_createAnimation(
			                    "mage_walk_4",
			                    "Animations/mage/mage_walk_2.png",
			                    false, 16, 20, 0, 0, 78, 76, 41, 54
						  );
					[5] = Gfx_createAnimation(
			                    "mage_walk_5",
			                    "Animations/mage/mage_walk_2.png",
			                    false, 16, 20, 234, 76, 78, 76, 35, 56
						  );
					[6] = Gfx_createAnimation(
			                    "mage_walk_6",
			                    "Animations/mage/mage_walk_2.png",
			                    false, 16, 20, 468, 152, 78, 76, 36, 56
						  );
					[7] = Gfx_createAnimation(
			                    "mage_walk_7",
			                    "Animations/mage/mage_walk_2.png",
			                    false, 16, 20, 702, 228, 78, 76, 38, 58
						  );
			    },
			},
			[3] = {
			    ["name"] = "attack";
			    ["loop"] = false;
			    ["sub_animations"] = {
			        [0] = Gfx_createAnimation(
			                    "mage_attack_0",
			                    "Animations/mage/mage_attack_1.png",
			                    false, 16, 16, 0, 0, 61, 71, 33, 56
						  );
					[1] = Gfx_createAnimation(
			                    "mage_attack_1",
			                    "Animations/mage/mage_attack_1.png",
			                    false, 16, 16, 0, 71, 61, 71, 33, 56
						  );
					[2] = Gfx_createAnimation(
			                    "mage_attack_2",
			                    "Animations/mage/mage_attack_1.png",
			                    false, 16, 16, 0, 142, 61, 71, 33, 56
						  );
					[3] = Gfx_createAnimation(
			                    "mage_attack_3",
			                    "Animations/mage/mage_attack_1.png",
			                    false, 16, 16, 0, 213, 61, 71, 33, 56
						  );
					[4] = Gfx_createAnimation(
			                    "mage_attack_4",
			                    "Animations/mage/mage_attack_2.png",
			                    false, 16, 16, 0, 0, 56, 68, 23, 51
						  );
					[5] = Gfx_createAnimation(
			                    "mage_attack_5",
			                    "Animations/mage/mage_attack_2.png",
			                    false, 16, 16, 896, 0, 56, 68, 24, 51
						  );
					[6] = Gfx_createAnimation(
			                    "mage_attack_6",
			                    "Animations/mage/mage_attack_2.png",
			                    false, 16, 16, 784, 68, 56, 68, 23, 48
						  );
					[7] = Gfx_createAnimation(
			                    "mage_attack_7",
			                    "Animations/mage/mage_attack_2.png",
			                    false, 16, 16, 672, 136, 56, 68, 22, 50
						  );
			    },
			},
			[4] = {
			    ["name"] = "prepare_attack";
			    ["sub_animations"] = {
			        [0] = Gfx_createAnimation(
			                    "mage_prepare_attack_0",
			                    "Animations/mage/mage_prepare_attack_1.png",
			                    false, 16, 13, 0, 0, 55, 64, 25, 49
						  );
					[1] = Gfx_createAnimation(
			                    "mage_prepare_attack_1",
			                    "Animations/mage/mage_prepare_attack_1.png",
			                    false, 16, 13, 385, 64, 55, 64, 25, 48
						  );
					[2] = Gfx_createAnimation(
			                    "mage_prepare_attack_2",
			                    "Animations/mage/mage_prepare_attack_1.png",
			                    false, 16, 13, 275, 192, 55, 64, 25, 49
						  );
					[3] = Gfx_createAnimation(
			                    "mage_prepare_attack_3",
			                    "Animations/mage/mage_prepare_attack_1.png",
			                    false, 16, 13, 165, 320, 55, 64, 25, 49
						  );
					[4] = Gfx_createAnimation(
			                    "mage_prepare_attack_4",
			                    "Animations/mage/mage_prepare_attack_2.png",
			                    false, 16, 13, 0, 0, 52, 65, 29, 50
						  );
					[5] = Gfx_createAnimation(
			                    "mage_prepare_attack_5",
			                    "Animations/mage/mage_prepare_attack_2.png",
			                    false, 16, 13, 832, 0, 52, 65, 30, 50
						  );
					[6] = Gfx_createAnimation(
			                    "mage_prepare_attack_6",
			                    "Animations/mage/mage_prepare_attack_2.png",
			                    false, 16, 13, 676, 65, 52, 65, 29, 47
						  );
					[7] = Gfx_createAnimation(
			                    "mage_prepare_attack_7",
			                    "Animations/mage/mage_prepare_attack_2.png",
			                    false, 16, 13, 520, 130, 52, 65, 28, 49
						  );
			    },
			},
			[5] = {
			    ["name"] = "death";
			    ["loop"] = false;
			    ["sub_animations"] = {
			        [0] = Gfx_createAnimation(
			                    "mage_death_0",
			                    "Animations/mage/mage_death_1.png",
			                    false, 32, 13, 0, 0, 74, 89, 31, 57
						  );
					[1] = Gfx_createAnimation(
			                    "mage_death_1",
			                    "Animations/mage/mage_death_1.png",
			                    false, 32, 13, 444, 178, 74, 89, 35, 63
						  );
					[2] = Gfx_createAnimation(
			                    "mage_death_2",
			                    "Animations/mage/mage_death_2.png",
			                    false, 32, 13, 0, 0, 97, 85, 55, 50
						  );
					[3] = Gfx_createAnimation(
			                    "mage_death_3",
			                    "Animations/mage/mage_death_2.png",
			                    false, 32, 13, 194, 258, 97, 85, 54, 46
						  );
					[4] = Gfx_createAnimation(
			                    "mage_death_4",
			                    "Animations/mage/mage_death_3.png",
			                    false, 32, 13, 0, 0, 82, 93, 46, 46
						  );
					[5] = Gfx_createAnimation(
			                    "mage_death_5",
			                    "Animations/mage/mage_death_3.png",
			                    false, 32, 13, 656, 186, 82, 93, 42, 43
						  );
					[6] = Gfx_createAnimation(
			                    "mage_death_6",
			                    "Animations/mage/mage_death_4.png",
			                    false, 32, 13, 0, 0, 95, 78, 38, 41
						  );
					[7] = Gfx_createAnimation(
			                    "mage_death_7",
			                    "Animations/mage/mage_death_4.png",
			                    false, 32, 13, 190, 234, 95, 78, 45, 49
						  );
			    },
			},
		},
	},
	["hunter"] = {
	    ["scale"] = 1.20;
	    ["shadow_scale"] = 0.80;
		["status_bar_size"] = 60;
		["status_bar_y_offset"] = 60;
		["states"] = {
			[1] = {
			    ["name"] = "stand";
			    ["sub_animations"] = {
			        [0] = Gfx_createAnimation(
			                    "hunter_stand_0",
			                    "Animations/hunter/hunter_stand_1.png",
			                    false, 32, 16, 0, 0, 56, 82, 27, 66
						  );
					[1] = Gfx_createAnimation(
			                    "hunter_stand_1",
			                    "Animations/hunter/hunter_stand_1.png",
			                    false, 32, 16, 784, 82, 56, 82, 28, 64
						  );
					[2] = Gfx_createAnimation(
			                    "hunter_stand_2",
			                    "Animations/hunter/hunter_stand_2.png",
			                    false, 32, 16, 0, 0, 54, 78, 29, 64
						  );
					[3] = Gfx_createAnimation(
			                    "hunter_stand_3",
			                    "Animations/hunter/hunter_stand_2.png",
			                    false, 32, 16, 756, 78, 54, 78, 28, 66
						  );
					[4] = Gfx_createAnimation(
			                    "hunter_stand_4",
			                    "Animations/hunter/hunter_stand_3.png",
			                    false, 32, 16, 0, 0, 58, 72, 28, 59
						  );
					[5] = Gfx_createAnimation(
			                    "hunter_stand_5",
			                    "Animations/hunter/hunter_stand_3.png",
			                    false, 32, 16, 870, 72, 58, 72, 29, 59
						  );
					[6] = Gfx_createAnimation(
			                    "hunter_stand_6",
			                    "Animations/hunter/hunter_stand_4.png",
			                    false, 32, 16, 0, 0, 57, 81, 26, 62
						  );
					[7] = Gfx_createAnimation(
			                    "hunter_stand_7",
			                    "Animations/hunter/hunter_stand_4.png",
			                    false, 32, 16, 855, 81, 57, 81, 23, 63
						  );
			    },
			},
			[2] = {
			    ["name"] = "walk";
			    ["sub_animations"] = {
			        [0] = Gfx_createAnimation(
			                    "hunter_walk_0",
			                    "Animations/hunter/hunter_walk_1.png",
			                    false, 16, 20, 0, 0, 86, 82, 45, 64
						  );
					[1] = Gfx_createAnimation(
			                    "hunter_walk_1",
			                    "Animations/hunter/hunter_walk_1.png",
			                    false, 16, 20, 430, 82, 86, 82, 47, 62
						  );
					[2] = Gfx_createAnimation(
			                    "hunter_walk_2",
			                    "Animations/hunter/hunter_walk_1.png",
			                    false, 16, 20, 860, 164, 86, 82, 47, 59
						  );
					[3] = Gfx_createAnimation(
			                    "hunter_walk_3",
			                    "Animations/hunter/hunter_walk_1.png",
			                    false, 16, 20, 344, 328, 86, 82, 46, 61
						  );
					[4] = Gfx_createAnimation(
			                    "hunter_walk_4",
			                    "Animations/hunter/hunter_walk_2.png",
			                    false, 16, 20, 0, 0, 90, 85, 39, 60
						  );
					[5] = Gfx_createAnimation(
			                    "hunter_walk_5",
			                    "Animations/hunter/hunter_walk_2.png",
			                    false, 16, 20, 450, 85, 90, 85, 39, 60
						  );
					[6] = Gfx_createAnimation(
			                    "hunter_walk_6",
			                    "Animations/hunter/hunter_walk_2.png",
			                    false, 16, 20, 900, 170, 90, 85, 37, 61
						  );
					[7] = Gfx_createAnimation(
			                    "hunter_walk_7",
			                    "Animations/hunter/hunter_walk_2.png",
			                    false, 16, 20, 360, 340, 90, 85, 37, 66
						  );
			    },
			},
			[3] = {
			    ["name"] = "attack";
			    ["loop"] = false;
			    ["sub_animations"] = {
			        [0] = Gfx_createAnimation(
			                    "hunter_attack_0",
			                    "Animations/hunter/hunter_attack_1.png",
			                    false, 32, 20, 0, 0, 58, 84, 29, 64
						  );
					[1] = Gfx_createAnimation(
			                    "hunter_attack_1",
			                    "Animations/hunter/hunter_attack_1.png",
			                    false, 32, 20, 870, 84, 58, 84, 29, 59
						  );
					[2] = Gfx_createAnimation(
			                    "hunter_attack_2",
			                    "Animations/hunter/hunter_attack_2.png",
			                    false, 32, 20, 0, 0, 71, 77, 41, 62
						  );
					[3] = Gfx_createAnimation(
			                    "hunter_attack_3",
			                    "Animations/hunter/hunter_attack_2.png",
			                    false, 32, 20, 284, 154, 71, 77, 35, 61
						  );
					[4] = Gfx_createAnimation(
			                    "hunter_attack_4",
			                    "Animations/hunter/hunter_attack_3.png",
			                    false, 32, 20, 0, 0, 57, 72, 28, 60
						  );
					[5] = Gfx_createAnimation(
			                    "hunter_attack_5",
			                    "Animations/hunter/hunter_attack_3.png",
			                    false, 32, 20, 855, 72, 57, 72, 29, 59
						  );
					[6] = Gfx_createAnimation(
			                    "hunter_attack_6",
			                    "Animations/hunter/hunter_attack_4.png",
			                    false, 32, 20, 0, 0, 71, 76, 33, 62
						  );
					[7] = Gfx_createAnimation(
			                    "hunter_attack_7",
			                    "Animations/hunter/hunter_attack_4.png",
			                    false, 32, 20, 284, 152, 71, 76, 30, 62
						  );
			    },
			},
			[4] = {
			    ["name"] = "prepare_attack";
			    ["sub_animations"] = {
			        [0] = Gfx_createAnimation(
			                    "hunter_prepare_attack_0",
			                    "Animations/hunter/hunter_prepare_attack_1.png",
			                    false, 32, 20, 0, 0, 58, 84, 28, 65
						  );
					[1] = Gfx_createAnimation(
			                    "hunter_prepare_attack_1",
			                    "Animations/hunter/hunter_prepare_attack_1.png",
			                    false, 32, 20, 870, 84, 58, 84, 28, 60
						  );
					[2] = Gfx_createAnimation(
			                    "hunter_prepare_attack_2",
			                    "Animations/hunter/hunter_prepare_attack_2.png",
			                    false, 32, 20, 0, 0, 69, 76, 41, 61
						  );
					[3] = Gfx_createAnimation(
			                    "hunter_prepare_attack_3",
			                    "Animations/hunter/hunter_prepare_attack_2.png",
			                    false, 32, 20, 276, 152, 69, 76, 35, 60
						  );
					[4] = Gfx_createAnimation(
			                    "hunter_prepare_attack_4",
			                    "Animations/hunter/hunter_prepare_attack_3.png",
			                    false, 32, 20, 0, 0, 60, 70, 30, 57
						  );
					[5] = Gfx_createAnimation(
			                    "hunter_prepare_attack_5",
			                    "Animations/hunter/hunter_prepare_attack_3.png",
			                    false, 32, 20, 900, 70, 60, 70, 31, 56
						  );
					[6] = Gfx_createAnimation(
			                    "hunter_prepare_attack_6",
			                    "Animations/hunter/hunter_prepare_attack_4.png",
			                    false, 32, 20, 0, 0, 72, 77, 33, 63
						  );
					[7] = Gfx_createAnimation(
			                    "hunter_prepare_attack_7",
			                    "Animations/hunter/hunter_prepare_attack_4.png",
			                    false, 32, 20, 288, 154, 72, 77, 30, 63
						  );
			    },
			},
			[5] = {
			    ["name"] = "death";
       			["loop"] = false;
			    ["sub_animations"] = {
			        [0] = Gfx_createAnimation(
			                    "hunter_death_0",
			                    "Animations/hunter/hunter_death_1.png",
			                    false, 16, 13, 0, 0, 84, 80, 30, 60
						  );
					[1] = Gfx_createAnimation(
			                    "hunter_death_1",
			                    "Animations/hunter/hunter_death_2.png",
			                    false, 16, 13, 0, 0, 79, 81, 47, 60
						  );
					[2] = Gfx_createAnimation(
			                    "hunter_death_2",
			                    "Animations/hunter/hunter_death_3.png",
			                    false, 16, 13, 0, 0, 100, 81, 63, 64
						  );
					[3] = Gfx_createAnimation(
			                    "hunter_death_3",
			                    "Animations/hunter/hunter_death_4.png",
			                    false, 16, 13, 0, 0, 103, 106, 68, 66
						  );
					[4] = Gfx_createAnimation(
			                    "hunter_death_4",
			                    "Animations/hunter/hunter_death_5.png",
			                    false, 16, 13, 0, 0, 96, 118, 65, 62
						  );
					[5] = Gfx_createAnimation(
			                    "hunter_death_5",
			                    "Animations/hunter/hunter_death_6.png",
			                    false, 16, 13, 0, 0, 78, 123, 32, 61
						  );
					[6] = Gfx_createAnimation(
			                    "hunter_death_6",
			                    "Animations/hunter/hunter_death_7.png",
			                    false, 16, 13, 0, 0, 104, 113, 32, 62
						  );
					[7] = Gfx_createAnimation(
			                    "hunter_death_7",
			                    "Animations/hunter/hunter_death_8.png",
			                    false, 16, 13, 0, 0, 102, 79, 33, 62
						  );
			    },
			},
		},
	},
}
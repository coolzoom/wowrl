-- Item database

Items = {
	[8952] = {
		["display_name"] = "item_8952_name";
		["description"] = "item_8952_desc";
		["icon"] = "Icons/INV_Misc_Food_15.png";
		["type"] = 7;
		["quality"] = 1;
		["binds"] = 0;
		["requieres_lvl"] = 45;
		["unique"] = 0;
		["charges"] = 1;
		["sellable"] = true;
		["price"] = 4000;
	},
}
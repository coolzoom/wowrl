-- Buffs database

Buffs = {
	["chilling_armor_rk1"] = {
		["display_name"] = "buff_chilling_armor_name";
		["description"] = "buff_chilling_armor_desc";
		["duration"] = 1800;
		["icon"] = "Icons/Spell_Frost_ChillingArmor.png"
	},
}
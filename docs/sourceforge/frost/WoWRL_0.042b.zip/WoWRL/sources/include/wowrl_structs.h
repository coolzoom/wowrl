/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Structures header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_STRUCTS_H
#define WOWRL_STRUCTS_H

#include "wowrl.h"

struct RGB
{
	float R;
	float G;
	float B;
};

struct FormatedString
{
	float       fX, fY;
	DWORD       dColor;
	std::string sStr;

	FormatedString()
	{
		dColor = ARGB(255, 255, 255, 255);
		fX = 0;
		fY = 0;
	}
};

struct FormatedText
{
	std::list<FormatedString> lFStr;
	hgeFont*    fnt;
	int         fntSize;
	DWORD       color;
	int         align;
	float       tracking;
	bool        box;
	float       w, h;
	std::string sStr;
	std::string sBaseStr;
	bool        shadow;
	int         outline;
	float       sox, soy;
	DWORD       scolor;

	FormatedText()
	{
		color = ARGB(255, 255, 255, 255);
		scolor = ARGB(255, 0, 0, 0);
		fnt = NULL;
	}
};

struct SBuff
{
	std::string name;
	std::string display_name;
	std::string description;
	float       duration;
	int         max_count;
	hgeSprite*  icon;
	std::string icon_file;

	SBuff()
	{
		name = "";
	}
};

struct Buff
{
	std::string name;
	SBuff* buff;
	int count;
	float life;
};

struct Spell
{
	std::string name;
	std::string display_name;
	std::string description;
	bool		loaded;
	int         rank;
	float       cast_time;
	float       cost;
	float       costp;
	std::string cost_type;
	float       range;
	bool        self_only;
	float       crits;
	bool        in_combat;
	bool		puts_in_combat;
	bool        loop;
	SBuff*      buff;
	int         school;
	bool        cast_fx;
	std::string cast_effect;
	bool        attack_fx;
	std::string attack_effect;
	hgeSprite*  icon;
	std::string iconPath;
	int         dmg_min;
	int         dmg_max;
	int			add_dmg;
	int         heal_min;
	int         heal_max;
	int			add_heal;
	float		duration;
	int         health_recovered;
	int         mana_recovered;
	bool		proj;
	float		proj_speed;
	bool		channeled;
	int			target;
	bool        melee;

	std::string OnCastBegin;
	std::string OnCasted;
	std::string OnImpact;
	std::string OnUpdate;

	Spell()
	{
		name = "";
		loaded = false;
	}

};

struct CSpell
{
	Spell* spell;
	int    cost;
	int    lvl;
};

struct Specialisation
{
	std::string name;
	std::string displayName;
	std::string role;
	Spell*      defaultSpell;
};

struct Cursor
{
	std::string   name;
	bool          animated;
	float         rot;
	hgeSprite*    sprite;
	hgeAnimation* anim;
};

struct Class
{
	std::string     name;
	std::string     display_name;
	int             id;
	float           scale;
	float           shadow_scale;
	float           status_bar_size;
	float           status_bar_y_offset;
	hgeSprite*      icon;
	std::string     anim_set;
	Specialisation* defaultSpec;
	float           health_gained_per_spirit;
	float           health_gained_per_tick;
	float           mana_gained_per_spirit;
	float           mana_gained_per_tick;
	int             power_type;
	float           regen_health_in_combat;
	float           regen_mana_in_combat;

	std::map<std::string, CSpell>         spell;
	std::map<std::string, Specialisation> spec;
};

struct Animation
{
    hgeAnimation* state[8];
};

struct AnimatedEffect
{
	float         fade_in;
	float         fade_out;
	int           type;
	float         scale;
	hgeAnimation* state[8];
	hgeAnimation* anim;
};

struct ParticleEffect
{
	hgeParticleSystem* psys;
	float              delay;
};

struct SEffect
{
	std::string    name;
	int            type;
	float          life;
	float          offset_x;
	float          offset_y;
	AnimatedEffect afx;
	ParticleEffect pfx;
};

struct PAnim
{
	std::string name;
	std::map<std::string, Animation> animation;
};

struct ActionButton
{
	bool        clickable;
	std::string reason;
	int         type;
	Spell*      spell;
	Item*       item;
};

struct BFont
{
	std::string name;
	std::map<int, hgeFont*> subFont;
};

struct Object
{
	int   type;
	void* ptr;
};

struct ScrollingText
{
	Unit*       parent;
	float       x, y;
	int         type;
	std::string value;
	float       lifeTime;
	DWORD		color;
};

struct ErrorText
{
	std::string caption;
	float       alpha;
	float       lifeTime;
};

struct BGPart
{
	int        i;
	float      x, y;
	float      w, h;
	hgeSprite* bg;
	bool       distData;
	DWORD*     dist;
	DWORD      globalDist;
};

struct Waypoint
{
	float       x, y;
	float       size;
	std::string name;
	std::multimap<float, Waypoint*> childs;

	// Temporary attributes used for pathfinding
	bool useless;
	bool opened;
	bool closed;
	float g;
	Waypoint* parent;
};

struct AddOn
{
	std::string name;
	std::string version;
	float UIVersion;
	std::string author;

	bool enabled;
	bool loaded;

	std::string folder;

	std::vector<std::string> files;
	std::vector<std::string> saved;

	AddOn()
	{
		enabled = true;
		loaded = false;
	}
};

#endif

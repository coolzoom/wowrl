/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          Scene manager header          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_SCENEMANAGER_H
#define WOWRL_SCENEMANAGER_H

#include "wowrl.h"
#include "wowrl_structs.h"
#include "wowrl_inventory.h"

class SceneManager
{
public :

	static SceneManager* getSingleton();
	void Update();

	// Global variables
	float gx, gy;
	float dx, dy;
	float dgx, dgy;
	int   gameState;
	bool  gamePaused;
	float gameVersion;
	int   loaderState;
	bool  jumpToNextState;

	// Scene variables
	bool panning;
	bool mouseOverPlayField;

	hgeRect* screenLRect;
	hgeRect* screenTRect;
	hgeRect* screenRRect;
	hgeRect* screenBRect;

	// Lua parser
	lua_State*  luaVM;
	// Used to communicate with LUA
	std::string tmpString;

	// String manipulation
	void                        replaceSpellValues( std::string*, Spell* );
	std::vector<FormatedString> createSpellInfos ( Spell* );
	hgeStringTable*				strTable;

	// Tables
	std::string locale;

	// Items
	Item parseItem( int item_id );

    // Pathfinding management
    void                   requestWPPath( Unit* );
    void                   buildWPPaths();
    void                   requestPath( Unit* );
    void                   buildPaths();
    void                   requestDirectPath( Unit* );
    void                   buildDirectPaths();
    std::map<float, Unit*> requestWPList;
    std::map<float, Unit*> requestList;
    std::map<float, Unit*> requestDList;

	// Game constants
	float aspectRatio;
	float regenTimer;
	float inCombatTimer;
	int   maxComputedPaths;

	// Lists
    std::map<int, Item> itemList;

protected :

	SceneManager();

private:

	static SceneManager* mSceneMgr;
	bool debugParser;

	hgeRect*    bgRect;
	bool        screenLInt;
	bool        screenTInt;
	bool        screenRInt;
	bool        screenBInt;
	float       fPanSpeed;

};

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Effect header             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_EFFECT_H
#define WOWRL_EFFECT_H

#include "wowrl.h"

class Effect
{
public :

	Effect()
	{
		anim = NULL;
		psys = NULL;
	}

	std::string name;
	int type;
	bool ended;
	float life;
	float lifeTimer;
	hgeAnimation* anim;
	int rot;
	float fade_in;
	float fade_out;
	bool fade;
	bool faded_in;
	bool faded_out;
	float fadeTimer;
	float scale;
	hgeParticleSystem* psys;
	float offset_x;
	float offset_y;
	float delay;

	void Render(float x, float y);
	void RenderEx(float x, float y, float angle, float v_scale, float h_scale = 0.0f);
	void SetColor(DWORD col);
	void Play();
	void Stop();
	void Update(float dt);

private :

};

#endif

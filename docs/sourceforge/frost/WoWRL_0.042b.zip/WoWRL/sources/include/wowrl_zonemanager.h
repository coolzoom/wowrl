/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           ZoneManager header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_ZONEMANAGER_H
#define WOWRL_ZONEMANAGER_H

#include "wowrl.h"
#include "wowrl_zone.h"

class ZoneManager
{
public :

	static ZoneManager* getSingleton();

	float bgx, bgy;

	// Zones
	bool parseZoneDyn( lua_State*, int, int, bool*, float );
	void deleteDoodads();
	Zone actualZone;

protected :

	ZoneManager();

private:

	static ZoneManager* mZoneMgr;

	bool debugParser;

};

#endif

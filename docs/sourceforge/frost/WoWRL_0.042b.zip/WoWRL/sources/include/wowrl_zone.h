/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Zone header               */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_ZONE_H
#define WOWRL_ZONE_H

#include "wowrl.h"
#include "wowrl_structs.h"
#include "wowrl_zone.h"
#include "wowrl_doodad.h"

class Zone
{
public :

    /*Zone();
    ~Zone();*/

    std::string name;
	float distortion_scale_max;
	float distortion_scale_min;
	float distortion_vscale_max;
	float distortion_vscale_min;
	float distortion_angle_max;
	float distortion_angle_min;
	std::map<std::string, Doodad> doodadList;
	std::map<std::string, Waypoint> wPntList;
	int w;
	int h;
	int tw;
	int th;
	float respawnTime;
	std::map<std::string, float> respawn;

	BGPart* getBGPart(float, float);
	void deleteSelf();

	std::map<float, BGPart> parts;
	int partSize;

private :

};

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            GFXManager header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_GFXMANAGER_H
#define WOWRL_GFXMANAGER_H

#include "wowrl.h"

class GFXManager
{
public :

	static GFXManager* getSingleton();

	hgeRect*          scrRect;
	int				  sWidth, sHeight;
	IDirect3DDevice9* mDxDevice;
	HTARGET           tMainTarget;
	hgeSprite*        sprMainSprite;

	// Textures
	HTEXTURE loadTexture( std::string, bool mipmaps = false );
	void     freeTextures();

	// Sprites
	hgeSprite* createSprite( HTEXTURE tex, float x, float y, float w, float h, bool GUI = false );
	hgeSprite* createSprite( hgeSprite*, bool GUI = false );
	void       deleteSprites();

	// Animations
	hgeAnimation* createAnimation( HTEXTURE tex, int frames, float fps, float x, float y, float w, float h );
	void          deleteAnimations();
	bool          parseAnimationsDyn( lua_State*, int, int, bool*, float );

	// PSys
	hgeParticleSystem* createPSys( std::string file,  hgeSprite* spr );
	void               deletePSys();

	// Rects
	hgeRect* createRect( float x1, float y2, float x2, float y2 );
	void     deleteRects();

    // Effects
    void parseEffects( lua_State* );

    // System
	hgeSprite* pixel;

	// Z sorted object list for rendering
	void                     buildRenderList();
	void                     forceUpdate();
	std::map<float, Object>  zSortedList;
	std::map<float, Unit*>   zSortedUnitList;
	std::map<float, Doodad*> renderInTopList;


	// Lists
	std::map<std::string, HTEXTURE> 	 textureList;
	std::map<std::string, PAnim> 		 pAnimList;
    std::map<std::string, SEffect>       FXList;
    std::vector<hgeSprite*>				 spriteList;
    std::vector<hgeAnimation*>			 animList;
    std::vector<hgeParticleSystem*>      psysList;
    std::vector<hgeRect*>				 rectList;

    std::map<std::string, hgeSprite*>	      mlua_spriteList;
    std::map<std::string, hgeAnimation*>      mlua_animList;
    std::map<std::string, hgeParticleSystem*> mlua_psysList;
    std::map<std::string, hgeRect*>		      mlua_rectList;

protected :

	GFXManager();

private:

	static GFXManager* mGFXMgr;

	bool debugParser;
	bool debugRenderList;
	bool mForceUpdate;

};

#endif

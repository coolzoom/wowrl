/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Lua header                */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_LUA_H
#define WOWRL_LUA_H

#include "wowrl.h"
#include <string>

std::string mlua_concTable( std::string table );

void mlua_print( std::string str );
void mlua_printError( std::string error );

int mlua_getGlobalInt( std::string name, bool critical = true, int defaultValue = 0 );
float mlua_getGlobalFloat( std::string name, bool critical = true, float defaultValue = 0.0f );
std::string mlua_getGlobalString( std::string name, bool critical = true, std::string defaultValue = "" );
bool mlua_getGlobalBool( std::string name, bool critical = true, bool defaultValue = false );

int mlua_getFieldInt( std::string name, bool critical = true, int defaultValue = 0, bool setValue = false, lua_State* luaVM = NULL );
float mlua_getFieldFloat( std::string name, bool critical = true, float defaultValue = 0.0f, bool setValue = false, lua_State* luaVM = NULL );
std::string mlua_getFieldString( std::string name, bool critical = true, std::string defaultValue = "", bool setValue = false, lua_State* luaVM = NULL );
bool mlua_getFieldBool( std::string name, bool critical = true, bool defaultValue = false, bool setValue = false, lua_State* luaVM = NULL );

void mlua_setFieldInt( std::string name, int value, lua_State* luaVM = NULL );
void mlua_setFieldFloat( std::string name, float value, lua_State* luaVM = NULL );
void mlua_setFieldString( std::string name, std::string value, lua_State* luaVM = NULL );
void mlua_setFieldBool( std::string name, bool value, lua_State* luaVM = NULL );

void mlua_setIFieldInt( int id, int value, lua_State* luaVM = NULL );
void mlua_setIFieldFloat( int id, float value, lua_State* luaVM = NULL );
void mlua_setIFieldString( int id, std::string value, lua_State* luaVM = NULL );
void mlua_setIFieldBool( int id, bool value, lua_State* luaVM = NULL );

void mlua_registerAll( lua_State* luaVM );

// Glue, but also used direcly in C++
int l_sendString( lua_State* luaVM );
int l_concTable( lua_State* luaVM );
int l_logPrint( lua_State* luaVM );
// Edited string lib
#define LUA_MSTRLIBNAME	"string"
int mluaopen_string( lua_State* luaVM );
void mluaL_openlibs( lua_State* luaVM );

#endif

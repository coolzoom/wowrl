/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             CastBar header             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_LOADINGBAR_H
#define WOWRL_LOADINGBAR_H

#include "wowrl.h"
#include "wowrl_structs.h"
#include "wowrl_unit.h"

class LoadingBar
{
public :

	LoadingBar()
	{
		captionFnt = NULL;
	}

    float filling;
	std::string state;
	std::string caption;
	Spell* spell;
	hgeSprite* border;
	hgeSprite* spark;
	hgeSprite* gauge_active;
	hgeSprite* gauge_error;
	hgeSprite* gauge_finish;
	hgeSprite* background;
	Unit* parent;

	void initialize();
	void Render();

private :

	hgeFont* captionFnt;
};

#endif

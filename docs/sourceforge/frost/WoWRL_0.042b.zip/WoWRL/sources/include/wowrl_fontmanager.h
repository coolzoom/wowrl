/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Font manager header          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_FONTMANAGER_H
#define WOWRL_FONTMANAGER_H

//#include "wowrl.h"
#include "hge/hgefont.h"

#include <map>
#include <string>
#include <vector>

class FontManager
{
public :

	static FontManager* getSingleton();

    hgeFont* getFont(bool file, std::string szFontName, int nSize, bool bBold, bool bItalic);
    void deleteFonts();

    hgeFont* systemFont;

protected :

	FontManager();

private:

	static FontManager* mFontMgr;
	std::map<std::string, hgeFont*> fntList;
	std::map<std::string, std::string> fntPathName;
	std::vector<std::string> ttfList;
};

#endif

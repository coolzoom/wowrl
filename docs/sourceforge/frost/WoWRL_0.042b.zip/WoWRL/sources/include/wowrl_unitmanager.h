/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           UnitManager header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_UNITMANAGER_H
#define WOWRL_UNITMANAGER_H

#include "wowrl.h"
#include "wowrl_unit.h"

class UnitManager
{
public :

	static UnitManager* getSingleton();

	// Casting
	ActionButton* castedButton;
	bool          castingSpell;
	Unit*         casterUnit;
	Unit*         targetUnit;
	bool          selected;
	bool          orderGiven;
	bool          castable;

	// Tables
	int             getBaseHealth( int, Class* );
	int             getBaseMana( int, Class* );
	int             getXPNeeded( int );
	hgeStringTable*	lvl_healthTable;
	hgeStringTable*	lvl_manaTable;
	hgeStringTable* lvl_xp_neededTable;

    // Classes
    bool   parseClassesDyn( lua_State*, int, bool*, float );
	Class* getClass( std::string );

	// Spells and buffs
	Spell*   parseSpell( lua_State*, std::string spell_name, bool regLUA );
    SBuff*   parseBuff( lua_State*, std::string buff_name );
	hgeFont* buffDurationFont;

	// Units
	//  # functions
    Unit* createUnit( std::string, float, float, int, Class*, float );
    Unit* getUnitByName( std::string );
    void  deselectAll();
    void  deleteUnits();
    Unit* leadingUnit;
    Unit* lastOvering;
    Unit* newOvering;
    float pSpeed; // Unit default movement speed;

    // Projectiles
    void       createProjectile( Spell*, Unit*, Unit* );
	hgeSprite* particle;

	// Lists
	std::map<std::string, Unit>  unitList;
	std::map<std::string, Unit*> orderList;
	std::map<std::string, Unit*> hostileList;
	std::map<std::string, Unit*> selectedList;
	std::map<std::string, Unit*> tempSelectedList;
	std::map<std::string, Unit*> actingList;
	std::map<std::string, Unit*> attackerList;
	std::map<std::string, Unit*> healerList;
	std::map<std::string, Unit*> reserList;
	std::map<std::string, Unit*> deadList;

	std::map<std::string, Spell>	  spellList;
	std::map<std::string, SBuff>	  buffList;
	std::map<std::string, Class> 	  classList;
	std::map<std::string, Projectile> projectileList;

protected :

	UnitManager();

private:

	static UnitManager* mUnitMgr;
	bool debugParser;

};

#endif

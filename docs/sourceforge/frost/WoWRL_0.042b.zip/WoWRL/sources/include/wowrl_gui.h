/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               GUI header               */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_GUI_H
#define WOWRL_GUI_H

#include "wowrl.h"
#include "wowrl_guimanager.h"
#include "wowrl_structs.h"
#include "wowrl_lua.h"

struct Anchor
{
	int         anchorPt;
	int         relativePt;
	GUIBase*    parent;
	std::string parent_name;
	float       x, y;

	Anchor()
	{
		x = 0.0f;
		y = 0.0f;
		parent = NULL;
		parent_name = "";
		anchorPt = GUI_ANCHOR_TOPLEFT;
   		relativePt = GUI_ANCHOR_TOPLEFT;
	}
};

struct Backdrop
{
	bool tile;
	float edgeSize;
	float tileSize;
	float insL;
	float insR;
	float insT;
	float insB;

	float bgW;
	float bgH;
	float edgeOriginalSize;

	std::string bgFile;
	std::string edgeFile;

	DWORD edgeColor;
	DWORD bgColor;

	bool edgeReady;
	hgeSprite* edgeL;
	hgeSprite* edgeR;
	hgeSprite* edgeT;
	hgeSprite* edgeB;
	hgeSprite* cornerTL;
	hgeSprite* cornerTR;
	hgeSprite* cornerBL;
	hgeSprite* cornerBR;
	bool bgReady;
	hgeSprite* background;
	bool bgReadyC;
	//hgeQuad    backgroundC;

	// Cache
	HTARGET    target;
    hgeSprite* spr;
};

struct OnFunc
{
	int         iType;
	bool        bFuncDefined;
	int         iFuncId;
};

class GUIBase
{
public :

	float getX( bool relative = false );
    float getY( bool relative = false );
    bool  IsVisible();

    void _init();
    GUIBase* getHighestVirtParent();

	std::string name;
	std::string sname;
	std::string vname;
	int         type;
	bool        virt;
	bool        ready;
	float       x, y;
	float       w, h;
	float       alpha;
	bool        hidden;

	std::map<int, Anchor> anchors;
	Anchor* banchor;
	std::map<std::string, GUIBase*> parentList;

	GUIElement*    parent;
	std::string parent_name;
};

class GUIArt : public GUIBase
{
public :

	int id;

	hgeSprite*     sprite;
	hgeAnimation*  anim;
	FormatedText   text;

	int   layer;
	float scale;
	float vscale;
	float angle;
	bool  box;
	DWORD color;
	int   blend;

	float ax, ay;

	std::string file;

	GUIArt() : GUIBase()
	{
		sprite = NULL;
		anim = NULL;
		parent = NULL;
		parent_name = "";
		name = "";
		vname = "";
		hidden = false;
		box = false;
		ready = false;
		color = ARGB(255, 255, 255, 255);
		x = 0.0f;
		y = 0.0f;
		layer = 0;
		angle = 0.0f;
		scale = 1.0f;
		vscale = 1.0f;
		banchor = NULL;
	}

	void Render();
};

class GUIElement : public GUIBase
{
public :

    void Render(bool);

    GUIElement();

	void deleteMe();

	void CheckInput(float, float, int, int);

	void On(int, Event* event = NULL);
	void SetOnFunction(int, int);

    void copyVirt(GUIElement*);

    int  GetChildLevel();

    void UpdateCarret();

    std::map<std::string, GUIElement*> childs;
    std::map<std::string, GUIElement>  vchilds;
    bool 							   child;

    std::map<std::string, GUIArt> arts;

	// Parameters
    float gx, gy;
    bool  lastOn;
    bool  registeredForDrag;
    bool  enableMouse;
    bool  baseUI;
    int   frameStrata;
    bool  rebuildList;

    int iHitInsL;
    int iHitInsR;
    int iHitInsT;
    int iHitInsB;

    std::map<int, OnFunc> funcList;
    std::map<int, bool>   lRegEvents;

	// Cache
    HTARGET    target;
    hgeSprite* spr;
    bool       rebuildCache;
    bool       rebuildBackdrop;
    void       _rebuildCache( bool child = false );
	bool       recreateCache;
	float      fLD, fRD;
	float      fTD, fBD;
	void       AdjustCache( bool adjustParent = true );

    void _print(int);
    void _init();

    // Backdrop
    Backdrop backdrop;
    bool     useBackdrop;

    // Status bar specific variables
    float       value;
    float       min_value;
    float       max_value;
    float       base_width;
    GUIArt*     barTexture;
    std::string barTextureName;

    // Edit box specific variables
    std::string sEBText;
    int         letters;
    int         historyLines;
    int         EBinsL, EBinsR, EBinsT, EBinsB;
    float       blinkSpeed;
    float       carretTimer;
    int         carretPos;
    int         iSubStrStart;
    int         iSubStrLength;
    float       carretX, carretY, carretScale;
    bool        showCarret;
    bool        numeric;
    bool        password;
    bool        multiLine;
    bool        ignoreArrows;
    bool        autoFocus;
    GUIArt*     captionFont;
    std::string captionFontName;

    // Scrolling message frame specific variables
    int   maxLines;
    int   actualLine;
    int   bottomLine;
    int   oldBottomLine;
    float fadeDuration;
    float displayDuration;
    bool  fade;
    int   SMFinsL, SMFinsR, SMFinsT, SMFinsB;
    bool  bAtTop;
    bool  bAtBottom;

    // Button specific variables
    GUIArt*     texNormal;
    GUIArt*     texPushed;
    GUIArt*     texDisabled;
    GUIArt*     texHighlight;
    GUIArt*     fontNormal;
    GUIArt*     fontHighlight;
    GUIArt*     fontDisabled;
    int         iPushTxtOffX;
    int         iPushTxtOffY;
    bool        bMouseDown;
    bool        bButtonDisabled;
    bool        bButtonFontReady;
    bool        bButtonTextureReady;
    std::string sButtonText;
    int         iButtonState;

private :

    std::multimap<int, GUIElement*> sortedGUIList;
};

class l_UIObject
{
public :

	static const char className[];
	static Lunar<l_UIObject>::RegType methods[];

	/**/ int GetAlpha(lua_State*) {}
	/**/ int GetObjectType(lua_State*) {}
	/**/ int IsObjectType(lua_State*) {}
	/**/ int SetAlpha(lua_State*) {}

	int getDataTable(lua_State *L) {
		lua_getref(L, ref);
		return 1;
    }

	l_UIObject(lua_State* luaVM) {
		lua_newtable(luaVM);
		ref = luaL_ref(luaVM, LUA_REGISTRYINDEX);
		l = luaVM;
	}

	~l_UIObject() {
		luaL_unref(l, LUA_REGISTRYINDEX, ref);
	}

protected :

	std::string name;
	lua_State*  l;
    int         ref;
};

class l_Region : public l_UIObject
{
public :

	static const char className[];
	static Lunar<l_Region>::RegType methods[];

	int GetName(lua_State*);

	int GetBottom(lua_State*);
	int GetCenter(lua_State*);
	int GetHeight(lua_State*);
	int GetLeft(lua_State*);
	/**/ int GetNumPoint(lua_State*) {}
	int GetParent(lua_State*);
	int GetPoint(lua_State*);
	int GetRight(lua_State*);
	int GetTop(lua_State*);
	int GetWidth(lua_State*);
	int Hide(lua_State*);
	int IsShown(lua_State*);
	int IsVisible(lua_State*);
	/**/ int SetAllPoints(lua_State*) {}
	int SetHeight(lua_State*);
	/**/ int SetParent(lua_State*) {}
	int SetPoint(lua_State*);
	int SetWidth(lua_State*);
	int Show(lua_State*);

	l_Region(lua_State* luaVM) : l_UIObject(luaVM) {ebase=NULL; rbase=NULL; abase=NULL;}

protected :

	GUIBase*    rbase;
	GUIElement* ebase;
	GUIArt*     abase;
};

class l_Frame : public l_Region
{
public :

	static const char className[];
	static Lunar<l_Frame>::RegType methods[];

	/**/ int CreateFontString(lua_State*) {}
	/**/ int CreateTexture(lua_State*) {}
	/**/ int CreateTitleRegion(lua_State*) {}
	/**/ int DisableDrawLayer(lua_State*) {}
	/**/ int EnableDrawLayer(lua_State*) {}
	/**/ int EnableKeyboard(lua_State*) {}
	/**/ int EnableMouse(lua_State*) {}
	/**/ int EnableMouseWheel(lua_State*) {}
	int GetBackdrop(lua_State*);
	/**/ int GetBackdropBorderColor(lua_State*) {}
	/**/ int GetBackdropColor(lua_State*) {}
	/**/ int GetChildren(lua_State*) {}
	/**/ int GetEffectiveAlpha(lua_State*) {}
	/**/ int GetEffectiveScale(lua_State*) {}
	/**/ int GetFrameLevel(lua_State*) {}
	/**/ int GetFrameStrata(lua_State*) {}
	/**/ int GetFrameType(lua_State*) {}
	/**/ int GetHitRectInsets(lua_State*) {}
	/**/ int GetID(lua_State*) {}
	/**/ int GetMaxResize(lua_State*) {}
	/**/ int GetMinResize(lua_State*) {}
	/**/ int GetNumChildren(lua_State*) {}
	/**/ int GetNumRegions(lua_State*) {}
	/**/ int GetScale(lua_State*) {}
	/**/ int GetScript(lua_State*) {}
	/**/ int GetTitleRegion(lua_State*) {}
	/**/ int HasScript(lua_State*) {}
	/**/ int HookScript(lua_State*) {}
	/**/ int IsClampedtoScreen(lua_State*) {}
	/**/ int IsFrameType(lua_State*) {}
	/**/ int IsKeyboardEnabled(lua_State*) {}
	/**/ int IsMouseEnabled(lua_State*) {}
	/**/ int IsMouseWheelEnabled(lua_State*) {}
	/**/ int IsMovable(lua_State*) {}
	/**/ int IsResizable(lua_State*) {}
	/**/ int IsTopLevel(lua_State*) {}
	/**/ int IsUserPlaced(lua_State*) {}
	/**/ int Lower(lua_State*) {}
	/**/ int Raise(lua_State*) {}
	/**/ int RegisterAllEvents(lua_State*) {}
	int RegisterEvent(lua_State*);
	/**/ int RegisterForDrag(lua_State*) {}
	int SetBackdrop(lua_State*);
	/**/ int SetBackdropBorderColor(lua_State*) {}
	int SetBackdropColor(lua_State*);
	/**/ int SetClampedToScreen(lua_State*) {}
	/**/ int SetFrameLevel(lua_State*) {}
	/**/ int SetFrameStrata(lua_State*) {}
	/**/ int SetHitRectInsets(lua_State*) {}
	/**/ int SetID(lua_State*) {}
	/**/ int SetMaxResize(lua_State*) {}
	/**/ int SetMinResize(lua_State*) {}
	/**/ int SetMovable(lua_State*) {}
	/**/ int SetResizable(lua_State*) {}
	/**/ int SetScale(lua_State*) {}
	/**/ int SetScript(lua_State*) {}
	/**/ int SetTopLevel(lua_State*) {}
	/**/ int SetUserPlaced(lua_State*) {}
	/**/ int StartMoving(lua_State*) {}
	/**/ int StartSizing(lua_State*) {}
	/**/ int StopMovingOrSizing(lua_State*) {}
	int UnregisterAllEvents(lua_State*);
	int UnregisterEvent(lua_State*);

	int _init(lua_State*);

	l_Frame(lua_State*);

protected :

	GUIElement* base;
};

class l_StatusBar : public l_Frame
{
public :

	static const char className[];
	static Lunar<l_StatusBar>::RegType methods[];

	/**/ int GetMinMaxValues(lua_State*) {}
	/**/ int GetOrientation(lua_State*) {}
	/**/ int GetStatusBarColor(lua_State*) {}
	/**/ int GetStatusBarTexture(lua_State*) {}
	/**/ int GetValue(lua_State*) {}
	int SetMinMaxValues(lua_State*);
	/**/ int SetOrientation(lua_State*) {}
	int SetStatusBarColor(lua_State*);
	/**/ int SetStatusBarTexture(lua_State*) {}
	int SetValue(lua_State*);

	l_StatusBar(lua_State*);
};

class l_EditBox : public l_Frame
{
public :

	static const char className[];
	static Lunar<l_EditBox>::RegType methods[];

	/**/ int AddHistoryLine(lua_State*) {}
	int ClearFocus(lua_State*);
	/**/ int GetAltArrowKeyMode(lua_State*) {}
	/**/ int GetBlinkSpeed(lua_State*) {}
	/**/ int GetHistoryLines(lua_State*) {}
	/**/ int GetInputLanguage(lua_State*) {}
	/**/ int GetMaxBytes(lua_State*) {}
	/**/ int GetMaxLetters(lua_State*) {}
	/**/ int GetNumLetters(lua_State*) {}
	/**/ int GetNumber(lua_State*) {}
	int GetText(lua_State*);
	/**/ int GetTextInsets(lua_State*) {}
	/**/ int HighlithtText(lua_State*) {}
	/**/ int Insert(lua_State*) {}
	/**/ int IsAutoFocus(lua_State*) {}
	/**/ int IsMultiLine(lua_State*) {}
	/**/ int IsNumeric(lua_State*) {}
	/**/ int IsPassword(lua_State*) {}
	/**/ int SetAltArrowKeyMode(lua_State*) {}
	/**/ int SetAutoFocus(lua_State*) {}
	/**/ int SetBlinkSpeed(lua_State*) {}
	int SetFocus(lua_State*);
	/**/ int SetHistoryLines(lua_State*) {}
	/**/ int SetMaxBytes(lua_State*) {}
	/**/ int SetMaxLetters(lua_State*) {}
	/**/ int SetMultiLine(lua_State*) {}
	/**/ int SetNumber(lua_State*) {}
	/**/ int SetNumeric(lua_State*) {}
	/**/ int SetPassword(lua_State*) {}
	int SetText(lua_State*);
	/**/ int SetTextInsets(lua_State*) {}
	/**/ int ToggleInputLanguage(lua_State*) {}


	l_EditBox(lua_State*);
};

class l_ScrollingMessageFrame : public l_Frame
{
public :

	static const char className[];
	static Lunar<l_ScrollingMessageFrame>::RegType methods[];

	int AddMessage(lua_State*);
	int AtBottom(lua_State*);
	int AtTop(lua_State*);
	/**/ int Clear(lua_State*) {}
	/**/ int GetCurrentLine(lua_State*) {}
	/**/ int GetCurrentScroll(lua_State*) {}
	/**/ int GetFadeDuration(lua_State*) {}
	/**/ int GetFading(lua_State*) {}
	/**/ int GetMaxLines(lua_State*) {}
	/**/ int GetNumLinesDisplayed(lua_State*) {}
	/**/ int GetNumMessages(lua_State*) {}
	/**/ int GetTimeVisible(lua_State*) {}
	/**/ int PageDown(lua_State*) {}
	/**/ int PageUp(lua_State*) {}
	int ScrollDown(lua_State*);
	int ScrollToBottom(lua_State*);
	int ScrollToTop(lua_State*);
	int ScrollUp(lua_State*);
	/**/ int SetFadeDuration(lua_State*) {}
	/**/ int SetFading(lua_State*) {}
	/**/ int SetMaxLines(lua_State*) {}
	/**/ int SetScrollFromBottom(lua_State*) {}
	/**/ int SetTimeVisible(lua_State*) {}
	/**/ int UpdateColorByID(lua_State*) {}

	l_ScrollingMessageFrame(lua_State*);
};

class l_Button : public l_Frame
{
public :

	static const char className[];
	static Lunar<l_Button>::RegType methods[];

	/**/ int Click(lua_State*) {}
	int Disable(lua_State*);
	int Enable(lua_State*);
	int GetButtonState(lua_State*);
	/**/ int GetDisabledFontObject(lua_State*) {}
	/**/ int GetDisabledTextColor(lua_State*) {}
	/**/ int GetDisabledTexture(lua_State*) {}
	/**/ int GetFont(lua_State*) {}
	/**/ int GetFontString(lua_State*) {}
	/**/ int GetHighlightFontObject(lua_State*) {}
	/**/ int GetHighlightTextColor(lua_State*) {}
	/**/ int GetHighlightTexture(lua_State*) {}
	/**/ int GetNormalTexture(lua_State*) {}
	/**/ int GetPushedTextOffset(lua_State*) {}
	/**/ int GetPushedTexture(lua_State*) {}
	/**/ int GetText(lua_State*) {}
	/**/ int GetTextColor(lua_State*) {}
	/**/ int GetTextFontObject(lua_State*) {}
	/**/ int GetTextHeight(lua_State*) {}
	/**/ int GetTextWidth(lua_State*) {}
	int IsEnabled(lua_State*);
	/**/ int LockHighlight(lua_State*) {}
	/**/ int RegisterForClicks(lua_State*) {}
	/**/ int SetButtonState(lua_State*) {}
	/**/ int SetDisabledFontObject(lua_State*) {}
	/**/ int SetDisabledTextColor(lua_State*) {}
	/**/ int SetDisabledTexture(lua_State*) {}
	/**/ int SetFont(lua_State*) {}
	/**/ int SetFontString(lua_State*) {}
	/**/ int SetHighlightFontObject(lua_State*) {}
	/**/ int SetHighlightTextColor(lua_State*) {}
	/**/ int SetHighlightTexture(lua_State*) {}
	/**/ int SetNormalTexture(lua_State*) {}
	/**/ int SetPushedTextOffset(lua_State*) {}
	/**/ int SetPushedTexture(lua_State*) {}
	/**/ int SetText(lua_State*) {}
	/**/ int SetTextColor(lua_State*) {}
	/**/ int SetTextFontObject(lua_State*) {}
	/**/ int UnlockHighlight(lua_State*) {}

	l_Button(lua_State*);
};

class l_LayeredRegion : public l_Region
{
public :

	static const char className[];
	static Lunar<l_LayeredRegion>::RegType methods[];

	/**/ int GetDrawLayer(lua_State*) {}
	/**/ int SetDrawLayer(lua_State*) {}

	int _init(lua_State*);

	l_LayeredRegion(lua_State* luaVM) : l_Region(luaVM) {base=NULL;}

protected :

	std::string pname;
	GUIArt* base;
};

class l_Texture : public l_LayeredRegion
{
public :

	static const char className[];
	static Lunar<l_Texture>::RegType methods[];

	/**/ int GetBlendMode(lua_State*) {}
	/**/ int GetTexCoord(lua_State*) {}
	/**/ int GetTexCoordModifiesRect(lua_State*) {}
	/**/ int GetTexture(lua_State*) {}
	/**/ int GetVertexColor(lua_State*) {}
	/**/ int GetDesaturated(lua_State*) {}
	/**/ int SetBlendMode(lua_State*) {}
	/**/ int SetDesaturated(lua_State*) {}
	/**/ int SetGradient(lua_State*) {}
	/**/ int SetGradientAlpha(lua_State*) {}
	int SetTexCoord(lua_State*);
	/**/ int SetTexCoordModifiesRect(lua_State*) {}
	int SetTexture(lua_State*);
	int SetVertexColor(lua_State*);

	l_Texture(lua_State*);

protected :
};

class l_FontString : public l_LayeredRegion
{
public :

	static const char className[];
	static Lunar<l_FontString>::RegType methods[];

	// Inherits from FontInstance
	/**/ int GetFont(lua_State*) {}
	/**/ int GetFontObject(lua_State*) {}
	/**/ int GetJustifyH(lua_State*) {}
	/**/ int GetJustifyV(lua_State*) {}
	/**/ int GetShadowColor(lua_State*) {}
	/**/ int GetShadowOffset(lua_State*) {}
	/**/ int GetSpacing(lua_State*) {}
	/**/ int GetTextColor(lua_State*) {}
	int SetFont(lua_State*);
	/**/ int SetFontObject(lua_State*) {}
	/**/ int SetJustifyH(lua_State*) {}
	/**/ int SetJustifyV(lua_State*) {}
	/**/ int SetShadowColor(lua_State*) {}
	/**/ int SetShadowOffset(lua_State*) {}
	/**/ int SetSpacing(lua_State*) {}
	int SetTextColor(lua_State*);

	/**/ int CanNonSpaceWrap(lua_State*) {}
	int GetStringWidth(lua_State*);
	/**/ int GetText(lua_State*) {}
	/**/ int SetAlphaGradient(lua_State*) {}
	/**/ int SetNonSpaceWrap(lua_State*) {}
	int SetText(lua_State*);
	/**/ int SetTextHeight(lua_State*) {}

	l_FontString(lua_State*);

protected :
};

#endif

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           GUIManager header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_GUIMANAGER_H
#define WOWRL_GUIMANAGER_H

#include "wowrl.h"
#include "wowrl_structs.h"
#include "wowrl_loadingbar.h"
#include "wowrl_selectionsquare.h"

#define ARG_TYPE_INTEGER 0
#define ARG_TYPE_FLOAT   1
#define ARG_TYPE_STRING  2

struct Argument
{
	int iType;
	int vInt;
	float vFloat;
	std::string vString;

	Argument()
	{
		iType = -1;
	}

	Argument(int type, int value)
	{
		iType = type;
		vInt = value;
	}

	Argument(int type, float value)
	{
		iType = type;
		vFloat = value;
	}

	Argument(int type, std::string value)
	{
		iType = type;
		vString = value;
	}
};

struct Event
{
	int iID;
	bool bCumulable;
	std::string sName;
	int iArgNbr;
	Argument arg[9];
};

class GUIManager
{
public :

	static GUIManager* getSingleton();
	void initValues();

	// Fonts
	hgeFont* defaultFont;

	// Cursors
	void    parseCursors(lua_State*);
	Cursor* switchCursor(std::string);
	Cursor* cursor;

	// Scrolling combat text
	void       addScrollingText( Unit*, int, std::string );
	void       updateScrollingTexts();
	void       renderScrollingTexts();
	hgeFont*   scrollingTextFont;
	// StatusBar
    void       createStatusBar( Unit* );
	hgeSprite* statusB_bg_left;
	hgeSprite* statusB_bg_middle;
	hgeSprite* statusB_bg_right;
	hgeSprite* statusB_dead_bg_left;
	hgeSprite* statusB_dead_bg_middle;
	hgeSprite* statusB_dead_bg_right;
	hgeSprite* statusB_gauge;
	// TargetLinks
	hgeQuad    targetLink1;
	hgeQuad    targetLink2;
	float      targetLinkTimer;
	DWORD      targetLinkColorF1;
	DWORD      targetLinkColorF2;
	DWORD      targetLinkColorF3;
	DWORD      targetLinkColorE1;
	DWORD      targetLinkColorE2;
	DWORD      targetLinkColorE3;
	// SelectionSquare
	SelectionSquare selSquare;
	// Base UI
	hgeSprite* selectionCircle;
	hgeSprite* deathCircle;
	hgeSprite* hostileCircle;
	hgeSprite* p_shadow;
	hgeSprite* orderCircle;
	hgeSprite* selectionSquare;
	hgeSprite* selectionSquareLeftBorder;
	hgeSprite* selectionSquareTopBorder;
	hgeSprite* selectionSquareRightBorder;
	hgeSprite* selectionSquareBottomBorder;
	hgeSprite* loadingBackground;
	hgeSprite* carret;
	LoadingBar mLoadingBar;

	// GUI management
	void        parseUI( std::string );
	void        loadAddOn( lua_State*, std::string, std::string );
	void        loadUI( lua_State* );
	void        closeUI( lua_State* );
	lua_State*  reLoadUI( lua_State* );
	void        updateUI();
	void        RegisterFunc( GUIElement*, int, std::string );
	bool        rebuildGUIList;
	std::string lScriptsStr;
	int         iFuncCount;

	// Event list
	Event mActualEvent;
	std::vector<Event> lEvents;
	void FireEvent(Event);
	std::map<int, std::string> lEventNToS;
	std::map<std::string, int> lEventSToN;
	void RegisterEvents();
	int ToEventNbr( std::string );
	std::string ToEventName( int );

	// FormatedText
	FormatedText ParseFormatedText( FormatedText );

	// Error messages
	void     addErrorMessage( std::string );
	void     updateErrorTexts();
	hgeFont* errorFont;

	// Edit box
	bool  HasFocus( GUIElement* );
	void  RequestFocus( GUIElement* );
	void  LooseFocus( GUIElement* );
	Point GetCarretPos( GUIElement*, bool );
	Point GetCarretPos( int, hgeFont*, float, float, std::string );
	void  PlaceCarret( GUIElement*, float, float );
	void  UpdateCarretPos( GUIElement* );
	void  UpdateEditBox();

	// Scrolling message frame
	void UpdateScrollingMsgFrame( GUIElement* );

	// GUI lists
	std::map<std::string, GUIElement> guiList;
	std::multimap<int, GUIElement*>   sortedGUIList;
	std::map<std::string, GUIElement> templateList;
	std::map<std::string, GUIBase*>   parentList;
	std::map<std::string, AddOn>      addOnList;
	std::map<std::string, Cursor> 	  cursorList;
	std::map<std::string, StatusBar>  statusBarList;
	std::multimap<int, GUIElement*>   sortedEditBoxList;

	std::vector<ErrorText>               errorTextList;
	std::map<std::string, ScrollingText> scrollingTextList;
	std::vector<hgeSprite*>              GUIspriteList;

	// GUI constants
	float loadingBarX, loadingBarY;
	float scrollingTextMaxLife;
	float scrollingTextSpeed;
	bool  scrollingTextFade;
	bool  showStatusBars;
	bool  showEnemiesStatusBars;
	float errorTextsDuration;
	float errorTextsFadeDelay;

protected :

	GUIManager();

private:

	static GUIManager* mGUIMgr;

	GUIElement* focus;
	bool        newFocus;

};


#endif

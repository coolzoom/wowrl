/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          InputManager header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_INPUTMANAGER_H
#define WOWRL_INPUTMANAGER_H

#include "hge/hge.h"
//#include "hge/hgerect.h"
#include <string>

class InputManager
{
public:

	static InputManager* getSingleton();

	// Variables
	float       mx, my;
	float       gmx, gmy;
	float       dmx, dmy;
	double      dt;
	int         mLState, mRState;
	std::string mouseButton;
	bool        lastDragged;
	bool        ctrlPressed;
	bool        shiftPressed;
	bool        altPressed;

	// Time
	double GetTime();
	double GetDelta();
	int    GetFPS();

	// Basic input
	void  GetMousePos();
	char  GetChar(bool, bool force = false);
	bool  GetKey(bool force = false);
	bool  KeyIsDown(int, bool force = false);
	bool  KeyIsDownLong(int, bool force = false);
	bool  KeyIsPressed(int, bool force = false);
	bool  KeyIsReleased(int, bool force = false);
	bool  KeyIsDoubleClicked(int, bool force = false);
	void  Update();

	// Parameters
	void SetDoubleclickTime(float);
	void SetGlobalDisplacement(float, float);
	void SetFocus(bool);

protected:

	InputManager();

private:

	static InputManager *mInputMgr;

	LARGE_INTEGER freq, ts, os;

	float doubleclickTime;
	float doubleclickDelay[3];
	float key_delay[256];
	bool  key_long[256];
	bool  key_buf[256];
	bool  key_buf_old[256];

	float old_mx, old_my;
	float gx, gy;

	int iFPS;

	bool focus;
	bool key;
};

#endif

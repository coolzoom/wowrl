/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*        SelectionSquare header          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_SELECTIONSQUARE_H
#define WOWRL_SELECTIONSQUARE_H

#include "wowrl.h"

class SelectionSquare
{
public :
	SelectionSquare();

	bool IsActive();
	void Update();
	void Render();

private :
	bool     active;
	hgeRect* rect;
	bool     renderBG;
	float    x, y;
	float    w, h;

	hgeQuad bg;
	hgeQuad border;
};



#endif

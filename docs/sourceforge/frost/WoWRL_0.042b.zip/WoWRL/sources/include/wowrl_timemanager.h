/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             Profiler header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_PROFILER_H
#define WOWRL_PROFILER_H

#include <map>
#include <string>
#include <vector>
#include <windows.h>

class Profiler
{
public:
	Profiler(int, std::string, bool);

	void AddTiming(double);
	void PrintProfile(double);
	void SetKeepRecords(bool);
	int  GetGroup() { return group; }

private:
	std::string name;
	int         group;
	double      startTime;
	double      totalTime;
	double      highestTime;
	double      lowestTime;
	int         callNbr;
	bool        keepRecords;

	std::vector<double> records;
};

class Chrono
{
public:
	Chrono(Profiler*);
	~Chrono();

	double GetTime();
	void   Stop();

private:
	Profiler* parent;
	double    start;
	bool      stopped;
};

class PeriodicTimer
{
public:
	PeriodicTimer(double, bool, bool);

	double GetElapsed();
	bool   Ticks();
	void   Stop();
	void   Start();
	void   Pause();
	void   Zero();

private:

	double elapsed;
	double start;
	double period;
	bool   paused;
};

class TimeManager
{
public:
	static TimeManager* getSingleton();

	double    GetTime();
	int       GetYear();
	int       GetMonth();
	int       GetDayName();
	int       GetDay();
	int       GetHour();
	int       GetMinutes();
	int       GetSeconds();

	// Profiling functions
	void      SetProfiling(bool);
	bool      IsProfiling() { return profiling; }
	Profiler* GetProfiler(int, std::string, bool);
	void      Print(int group = -1);

protected:
	TimeManager();

private:
	static TimeManager* mTimeMgr;

	bool profiled;
	bool profiling;

	LARGE_INTEGER freq, ts;
	double last;
	double profileTime;
	std::map<std::string, Profiler> profilerList;
};

/****** PROFILING GROUPS ******/
/* [1] : pathfinding          */
/* [2] : unit                 */
/* [3] : GUI parsing          */
/* [4] : GUI drawing          */
/* [5] : data parsing         */
/* [6] : render order         */
/* [7] : scene manager        */
/* [8] : frame func           */
/* [0] : other                */
/******************************/

#endif

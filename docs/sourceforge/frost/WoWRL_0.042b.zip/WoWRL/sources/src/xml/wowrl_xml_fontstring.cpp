/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_scenemanager.h"
#include "wowrl_fontmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_global.h"

#include "wowrl_xml.h"

using namespace std;

extern SceneManager* mSceneMgr;
extern FontManager* mFontMgr;
extern GUIManager* mGUIMgr;
extern HGE* hge;
extern bool debugXML;

void mxml_parseString( TiXmlNode* node, GUIElement* parent, int layer, int type )
{
	/* [#] This function parses a FontString object in an XML file. A FontString
	/* is basicaly a tool to display some text. You can display as many lines as
	/* you want, except if a text box is defined. A FontString object must be
	/* contained in a Frame (or one of its derivation).
	*/
	bool debugThis = false;
	if (debugXML) {hge->System_Log("5");}
	if (debugThis) hge->System_Log("0");
	GUIArt a;
	a.name = "";
	a.layer = layer;
	a.parent = parent;
	a.virt = parent->virt;
	a.type = type;
	a.w = parent->w;
	a.h = parent->h;
	FormatedText text;
	text.fntSize = 16;
	text.shadow = false;
	text.outline = 0;
	text.align = HGETEXT_LEFT | HGETEXT_TOP;
	text.sStr = "";
	text.w = parent->w;
	text.h = parent->h;
	float space = 0.0f;
	int size = 0;
	string font = "";
	if (debugThis) hge->System_Log("0.");

	TiXmlElement* elem = node->ToElement();
	for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
	{
		if (debugThis) hge->System_Log("1.1 : %s", attr->Name());
		if (string(attr->Name()) == string("name"))
		{
			a.name = attr->Value();
		}
		else if (string(attr->Name()) == string("font"))
		{
			font = attr->Value();
		}
		else if (string(attr->Name()) == string("outline"))
		{
			if (string(attr->Value()) == string("THIN"))
				text.outline = 1;
			else if (string(attr->Value()) == string("NORMAL"))
				text.outline = 2;
			else if (string(attr->Value()) == string("THICK"))
				text.outline = 3;
		}
		else if ((string(attr->Name()) == string("text")) &&
			     (type != GUI_OBJECT_TYPE_FEDITBOX) &&
		         (type != GUI_OBJECT_TYPE_FSMSGFRAME))
			text.sStr = attr->Value();
		else if ((string(attr->Name()) == string("justifyH")) &&
		         (type != GUI_OBJECT_TYPE_FSMSGFRAME))
		{
			if (string(attr->Value()) == string("LEFT"))
				text.align = HGETEXT_LEFT | HGETEXT_TOP;
			else if (string(attr->Value()) == string("CENTER"))
				text.align = HGETEXT_CENTER | HGETEXT_TOP;
			else if (string(attr->Value()) == string("RIGHT"))
				text.align = HGETEXT_RIGHT | HGETEXT_TOP;
		}
		else if (string(attr->Name()) == string("spacing"))
			space = atof(attr->Value());
	}

	for (TiXmlNode* node2 = node->FirstChild(); node2; node2 = node2->NextSibling())
	{
		if (debugThis) hge->System_Log("1.2 : %s", node2->Value());
		if ((string(node2->Value()) == string("Size")) &&
			(type != GUI_OBJECT_TYPE_FEDITBOX) &&
			(type != GUI_OBJECT_TYPE_FSMSGFRAME))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsDimension"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("x"))
						{
							a.w = atof(attr->Value());
							text.w = a.w;
						}
						else if (string(attr->Name()) == string("y"))
						{
							a.h = atof(attr->Value());
							text.h = a.h;
						}
					}
				}
			}
		}
		else if ((string(node2->Value()) == string("Anchors")) &&
		         (type != GUI_OBJECT_TYPE_FEDITBOX) &&
		         (type != GUI_OBJECT_TYPE_FSMSGFRAME))
		{
			mxml_parseAnchor(node2, &a);
		}
		else if (string(node2->Value()) == string("FontHeight"))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsValue"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("val"))
						{
							text.fntSize = atoi(attr->Value());
						}
					}
				}
			}
		}
		else if (string(node2->Value()) == string("Color"))
		{
			float r, g, b = 0.0f;
			float al = 255.0f;
			TiXmlElement* elem = node2->ToElement();
			for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
			{
				if (string(attr->Name()) == string("r"))
					r = 255.0f*atof(attr->Value());
				else if (string(attr->Name()) == string("g"))
					g = 255.0f*atof(attr->Value());
				else if (string(attr->Name()) == string("b"))
					b = 255.0f*atof(attr->Value());
				else if (string(attr->Name()) == string("a"))
					al = 255.0f*atof(attr->Value());
			}
			text.color = ARGB(al, r, g, b);
		}
		else if (string(node2->Value()) == string("Shadow"))
		{
			text.shadow = true;
			for (TiXmlNode* node3 = node2->FirstChild(); node3; node3 = node3->NextSibling())
			{
				if (string(node3->Value()) == string("Offset"))
				{
					TiXmlNode* node4 = node3->FirstChild();
					if (node4)
					{
						if (string(node4->Value()) == string("AbsDimension"))
						{
							TiXmlElement* elem = node4->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("x"))
								{
									text.sox = atof(attr->Value());
								}
								else if (string(attr->Name()) == string("y"))
								{
									text.soy = atof(attr->Value());
								}
							}
						}
					}
				}
				else if (string(node3->Value()) == string("Color"))
				{
					float r, g, b = 0.0f;
					float al = 255.0f;
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("r"))
							r = 255.0f*atof(attr->Value());
						else if (string(attr->Name()) == string("g"))
							g = 255.0f*atof(attr->Value());
						else if (string(attr->Name()) == string("b"))
							b = 255.0f*atof(attr->Value());
						else if (string(attr->Name()) == string("a"))
							al = 255.0f*atof(attr->Value());
					}
					text.scolor = ARGB(al, r, g, b);
				}
			}
		}
	}

	if (debugThis) hge->System_Log("2");

	a.text = text;

	if (a.type == GUI_OBJECT_TYPE_FEDITBOX)
		a.name = "$parent_EBText";
	else if (a.type == GUI_OBJECT_TYPE_FSMSGFRAME)
		a.name = "$parent_MSGText";
	else if (a.type == GUI_OBJECT_TYPE_FNBUTTON)
	{
		a.name = "$parent_NormalText";
		a.hidden = false;
		a.text.sStr = parent->sButtonText;
	}
	else if (a.type == GUI_OBJECT_TYPE_FHBUTTON)
	{
		a.name = "$parent_HighlightText";
		a.hidden = true;
		a.text.sStr = parent->sButtonText;
	}
	else if (a.type == GUI_OBJECT_TYPE_FDBUTTON)
	{
		a.name = "$parent_DisabledText";
		a.hidden = true;
		a.text.sStr = parent->sButtonText;
	}

	if (a.name != "")
	{
		// Default anchor
		/*if (a.anchors.size() == 0)
		{
			a.anchors[0].parent = parent;
			a.anchors[0].parent_name = "$parent";
		}*/

		if (debugThis) hge->System_Log("3");
		// Update name
		a.sname = a.name;
		if (!parent->virt)
		{
			int i = a.name.find("$parent");
			if (i != a.name.npos)
			{
				a.name = a.name.erase(i, 7);
				a.sname = a.name;
				a.name.insert(i, parent->name);
			}
		}
		else
		{
			a.vname = a.name;
			int i = a.vname.find("$parent");
			if (i != a.vname.npos)
			{
				a.vname = a.vname.erase(i, 7);
				a.vname.insert(i, parent->vname);
			}
		}

		if (debugThis) hge->System_Log("4 %s, %d", font.c_str(), text.fntSize);

		hgeFont* tmpFnt = NULL;
		if (font != "")
			tmpFnt = mFontMgr->getFont(true, font, text.fntSize, false, false);

		a.text.fnt = tmpFnt;
		a.text.tracking = space;

		if (tmpFnt != NULL)
			a.ready = true;
		else
			a.ready = false;

		if (debugThis) hge->System_Log("5");

		if (!parent->virt)
		{
			if (a.type == GUI_OBJECT_TYPE_FONTSTRING)
			{
				if (debugThis) hge->System_Log("6.1");
				a.text = mGUIMgr->ParseFormatedText(a.text);

				string exec = a.name + " = FontString(\"" + parent->name + "\", \"" + a.name + "\");";
				luaL_dostring(mSceneMgr->luaVM, exec.c_str());

				if (mGUIMgr->parentList.find(a.name) == mGUIMgr->parentList.end())
				{
					parent->arts[a.name] = a;
					mGUIMgr->parentList[a.name] = &parent->arts[a.name];
					if (parent->arts[a.name].anchors.size() == 0)
					{
						parent->arts[a.name].anchors[0].parent = parent;
						parent->arts[a.name].anchors[0].parent_name = "$parent";
					}
				}
				else
				{
					hge->System_Log("# XML Error # : an object with the name %s already exists", a.name.c_str());
				}
				if (debugThis) hge->System_Log("6.2");
			}
			else if (a.type == GUI_OBJECT_TYPE_FSMSGFRAME)
			{
				parent->ready = true;
				if (debugThis) hge->System_Log("7.1");
				a.h = a.text.fntSize;
				a.hidden = true;
				a.text.sStr = "<empty>";
				a.text = mGUIMgr->ParseFormatedText(a.text);
				for (int i = 1; i <= parent->maxLines; i++)
				{
					a.name = "Msg" + toString(i);

					parent->arts[a.name] = a;
				}
				if (debugThis) hge->System_Log("7.2");
			}
			else if (a.type == GUI_OBJECT_TYPE_FEDITBOX)
			{
				if (debugThis) hge->System_Log("8.1");
				a.text = mGUIMgr->ParseFormatedText(a.text);
				parent->arts[a.name] = a;
				parent->captionFont = &parent->arts[a.name];
				if (debugThis) hge->System_Log("8.2");
			}
			else if (a.type == GUI_OBJECT_TYPE_FNBUTTON)
			{
				if (a.anchors.size() == 0)
				{
					a.anchors[0].parent = parent;
					a.anchors[0].parent_name = "$parent";
				}
				a.text = mGUIMgr->ParseFormatedText(a.text);
				parent->arts[a.name] = a;
				parent->fontNormal = &parent->arts[a.name];
			}
			else if (a.type == GUI_OBJECT_TYPE_FHBUTTON)
			{
				if (a.anchors.size() == 0)
				{
					a.anchors[0].parent = parent;
					a.anchors[0].parent_name = "$parent";
				}
				a.text = mGUIMgr->ParseFormatedText(a.text);
				parent->arts[a.name] = a;
				parent->fontHighlight = &parent->arts[a.name];
			}
			else if (a.type == GUI_OBJECT_TYPE_FDBUTTON)
			{
				if (a.anchors.size() == 0)
				{
					a.anchors[0].parent = parent;
					a.anchors[0].parent_name = "$parent";
				}
				a.text = mGUIMgr->ParseFormatedText(a.text);
				parent->arts[a.name] = a;
				parent->fontDisabled = &parent->arts[a.name];
			}
		}
		else
		{
			if (debugThis) hge->System_Log("9");
			GUIBase* hparent = parent->getHighestVirtParent();
			if (hparent->parentList.find(a.vname) == hparent->parentList.end())
			{
				if (type == GUI_OBJECT_TYPE_FEDITBOX)
				{
					parent->captionFontName = a.name;
				}
				parent->arts[a.name] = a;
				hparent->parentList[a.vname] = &parent->arts[a.name];
			}
			else
			{
				hge->System_Log("# XML Error # : a template object with the name %s already exists", a.vname.c_str());
			}
			if (debugThis) hge->System_Log("10");
		}
	}
	if (debugXML) {hge->System_Log("6");}
}

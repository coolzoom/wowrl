/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_global.h"

#include "wowrl_xml.h"

using namespace std;

extern GFXManager* mGFXMgr;
extern HGE* hge;
extern bool debugXML;

void mxml_parseBackdrop( TiXmlNode* node, GUIElement* parent )
{
	/* [#] This function parses a Backdrop object in an XML file.
	/* A Backdrop must be contained in a Frame.
	*/
	if (debugXML) {hge->System_Log("9");}
	Backdrop bd;
	bd.bgFile = "";
	bd.edgeFile = "";
	bd.tile = false;
	bd.edgeSize = -1.0f;
	bd.tileSize = -1.0f;
	bd.insL = 0.0f;
	bd.insR = 0.0f;
	bd.insT = 0.0f;
	bd.insB = 0.0f;
	bd.edgeColor = ARGB(255, 255, 255, 255);
	bd.bgColor = ARGB(255, 255, 255, 255);
	bd.bgReadyC = false;
	//bd.backgroundC.tex = 0;
	//bd.backgroundC.blend = BLEND_DEFAULT;

	TiXmlElement* elem = node->ToElement();
	for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
	{
		if (string(attr->Name()) == string("bgFile"))
		{
			bd.bgFile = attr->Value();
		}
		if (string(attr->Name()) == string("edgeFile"))
		{
			bd.edgeFile = attr->Value();
		}
		if (string(attr->Name()) == string("tile"))
		{
			bd.tile = toBool((char*)attr->Value());
		}
	}

	for (TiXmlNode* node2 = node->FirstChild(); node2; node2 = node2->NextSibling())
	{
		if (string(node2->Value()) == string("EdgeSize"))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsValue"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("val"))
						{
							bd.edgeSize = atoi(attr->Value());
						}
					}
				}
			}
		}
		if (string(node2->Value()) == string("TileSize"))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsValue"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("val"))
						{
							bd.tileSize = atoi(attr->Value());
						}
					}
				}
			}
		}
		if (string(node2->Value()) == string("BackgroundInsets"))
		{
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsInset"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("left"))
						{
							bd.insL = atoi(attr->Value());
						}
						if (string(attr->Name()) == string("right"))
						{
							bd.insR = atoi(attr->Value());
						}
						if (string(attr->Name()) == string("top"))
						{
							bd.insT = atoi(attr->Value());
						}
						if (string(attr->Name()) == string("bottom"))
						{
							bd.insB = atoi(attr->Value());
						}
					}
				}
			}
		}
	}

	// Load edges
	if ( (bd.edgeFile != "") && (!parent->virt) )
	{
		HTEXTURE tex1 = mGFXMgr->loadTexture(bd.edgeFile, false);
		float size = (int)floor(hge->Texture_GetWidth(tex1, true)/8.0f);
		bd.edgeL = new hgeSprite(tex1, 0, 0, size, size);
		bd.edgeR = new hgeSprite(tex1, size, 0, size, size);
		bd.edgeT = new hgeSprite(tex1, 2*size, 0, size, size);
		bd.edgeB = new hgeSprite(tex1, 3*size, 0, size, size);
		bd.cornerTL = new hgeSprite(tex1, 4*size, 0, size, size);
		bd.cornerTR = new hgeSprite(tex1, 5*size, 0, size, size);
		bd.cornerBL = new hgeSprite(tex1, 6*size, 0, size, size);
		bd.cornerBR = new hgeSprite(tex1, 7*size, 0, size, size);
		bd.edgeOriginalSize = size;
		bd.edgeReady = true;
	}
	else
		bd.edgeReady = false;

	// Load background
	if ( (bd.bgFile != "") && (!parent->virt) )
	{
		HTEXTURE tex2;
		tex2 = mGFXMgr->loadTexture(bd.bgFile, false);

		bd.bgW = hge->Texture_GetWidth(tex2, true);
		bd.bgH = hge->Texture_GetHeight(tex2, true);

		if (bd.tile)
			bd.background = new hgeSprite(tex2, 0, 0, parent->w-bd.insL-bd.insR, parent->h-bd.insT-bd.insB);
		else
			bd.background = new hgeSprite(tex2, 0, 0, bd.bgW, bd.bgH);

		bd.bgReady = true;
	}
	else
		bd.bgReady = false;

	if (!parent->virt)
	{
		bd.target = hge->Target_Create(toInt(parent->w), toInt(parent->h), false);
		bd.spr = new hgeSprite(hge->Target_GetTexture(bd.target), 0, 0, toInt(parent->w), toInt(parent->h));
	}

	parent->backdrop = bd;
	parent->useBackdrop = true;

	if (debugXML) {hge->System_Log("10");}
}

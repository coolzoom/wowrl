/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_scenemanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_global.h"

#include "wowrl_xml.h"

using namespace std;

extern SceneManager* mSceneMgr;
extern GFXManager* mGFXMgr;
extern GUIManager* mGUIMgr;
extern HGE* hge;
extern bool debugXML;

void mxml_parseTexture( TiXmlNode* node, GUIElement* parent, int layer, int type )
{
	/* [#] This function parses a Texture object in an XML file. A Texture is
	/* the most important part of the GUI. It is used to display bitmap files
	/* on the screen. A Texture object must be contained in a Frame (or one of
	/* its derivation).
	*/
	bool debugThis = false;
	if (debugXML) {hge->System_Log("3");}
	GUIArt a;
	a.layer = layer;
	a.parent_name = parent->name;
	a.parent = parent;
	a.virt = parent->virt;
	a.type = type;
	/*a.w = parent->w;
	a.h = parent->h;*/
	a.w = -1;
	a.h = -1;
	HTEXTURE tex;
	int blend = BLEND_DEFAULT;
	float sx = 0.0f; float sy = 0.0f; float sw = 0.0f; float sh = 0.0f;
	float x1 = 0.0f; float y1 = 0.0f; float x2 = 1.0f; float y2 = 1.0f;
	float r = 1.0f; float g = 1.0f; float b = 1.0f; float al = 1.0f;
	bool fileFound = false;

	TiXmlElement* elem = node->ToElement();
	for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
	{
		if (string(attr->Name()) == string("name"))
		{
			if (debugThis) {hge->System_Log("3.1");}
			a.name = attr->Value();
			a.sname = a.name;
			if (!parent->virt)
			{
				int i = a.name.find("$parent");
				if (i != a.name.npos)
				{
					a.name = a.name.erase(i, 7);
					a.sname = a.name;
					a.name.insert(i, parent->name);
				}
			}
			else
			{
				a.vname = a.name;
				int i = a.vname.find("$parent");
				if (i != a.vname.npos)
				{
					a.vname = a.vname.erase(i, 7);
					a.vname.insert(i, parent->vname);
				}
			}
		}
		else if (string(attr->Name()) == string("file"))
		{
			if (debugThis) {hge->System_Log("3.2");}
			a.file = attr->Value();
			tex = mGFXMgr->loadTexture(a.file, false);
			fileFound = true;
		}
		else if (string(attr->Name()) == string("alphaMode"))
		{
			if (debugThis) {hge->System_Log("3.3");}
			if (string(attr->Value()) == string("DISABLE"))
				blend = BLEND_DEFAULT;
			else if (string(attr->Value()) == string("BLEND"))
				blend = BLEND_DEFAULT;
			else if (string(attr->Value()) == string("ALPHAKEY"))
				blend = BLEND_DEFAULT;
			else if (string(attr->Value()) == string("ADD"))
				blend = (BLEND_COLORMUL | BLEND_ALPHAADD | BLEND_NOZWRITE);
			else if (string(attr->Value()) == string("MOD"))
				blend = BLEND_DEFAULT;
		}
	}

	for (TiXmlNode* node2 = node->FirstChild(); node2; node2 = node2->NextSibling())
	{
		if (string(node2->Value()) == string("Size"))
		{
			if (debugThis) {hge->System_Log("3.4");}
			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("AbsDimension"))
				{
					TiXmlElement* elem = node3->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("x"))
						{
							a.w = atof(attr->Value());
						}
						else if (string(attr->Name()) == string("y"))
						{
							a.h = atof(attr->Value());
						}
					}
				}
			}
		}
		else if ( (type == GUI_OBJECT_TYPE_TEXTURE) && (string(node2->Value()) == string("Anchors")) )
		{
			if (debugThis) {hge->System_Log("3.4");}
			mxml_parseAnchor(node2, &a);
		}
		else if (string(node2->Value()) == string("TexCoords"))
		{
			if (debugThis) {hge->System_Log("3.5");}
			TiXmlElement* elem = node2->ToElement();
			for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
			{
				if (string(attr->Name()) == string("left"))
					x1 = atof(attr->Value());
				else if (string(attr->Name()) == string("right"))
					x2 = atof(attr->Value());
				else if (string(attr->Name()) == string("top"))
					y1 = atof(attr->Value());
				else if (string(attr->Name()) == string("bottom"))
					y2 = atof(attr->Value());
			}
		}
		else if ( (type == GUI_OBJECT_TYPE_TEXTURE) && (string(node2->Value()) == string("Color")) )
		{
			if (debugThis) {hge->System_Log("3.6");}
			TiXmlElement* elem = node2->ToElement();
			for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
			{
				if (string(attr->Name()) == string("r"))
					r = atof(attr->Value());
				else if (string(attr->Name()) == string("g"))
					g = atof(attr->Value());
				else if (string(attr->Name()) == string("b"))
					b = atof(attr->Value());
				else if (string(attr->Name()) == string("a"))
					al = atof(attr->Value());
			}
		}
		else if ( (type == GUI_OBJECT_TYPE_TEXTURE) && (string(node2->Value()) == string("Gradient")) )
		{
		}
	}

	if (a.type == GUI_OBJECT_TYPE_TNBUTTON)
	{
		a.name = parent->name + "_NormalTexture";
		a.hidden = false;
	}
	else if (a.type == GUI_OBJECT_TYPE_THBUTTON)
	{
		a.name = parent->name + "_HighlightTexture";
		a.hidden = true;
	}
	else if (a.type == GUI_OBJECT_TYPE_TDBUTTON)
	{
		a.name = parent->name + "_DisabledTexture";
		a.hidden = true;
	}
	else if (a.type == GUI_OBJECT_TYPE_TPBUTTON)
	{
		a.name = parent->name + "_PushedTexture";
		a.hidden = true;
	}

	if (a.name != "")
	{
		// Default anchor
		/*if (a.anchors.size() == 0)
		{
			a.anchors[0].parent = parent;
			a.anchors[0].parent_name = "$parent";
		}*/

		if (fileFound)
		{
			if (debugThis) {hge->System_Log("3.7");}
			float tw = hge->Texture_GetWidth(tex, true);
			float th = hge->Texture_GetHeight(tex, true);
			sx = tw*x1;
			sy = th*y1;
			sw = tw*(x2-x1);
			sh = th*(y2-y1);

			if (a.w == -1) a.w = sw;
			if (a.h == -1) a.h = sh;

			if (type == GUI_OBJECT_TYPE_TSTATUSBAR)
				parent->base_width = sw;

			a.scale = a.w/sw;
			a.vscale = a.h/sh;

			a.sprite = mGFXMgr->createSprite(tex, sx, sy, sw, sh, true);
			a.blend = blend;
			a.color = ARGB(255*al, 255*r, 255*g, 255*b);
			a.sprite->SetBlendMode(BLEND_COLORMUL | a.blend | BLEND_NOZWRITE);
			a.sprite->SetColor(a.color);
			a.ready = true;
		}

		if (!parent->virt)
		{
			if (debugThis) {hge->System_Log("3.9");}
			if (a.type == GUI_OBJECT_TYPE_TNBUTTON)
			{
				if (a.anchors.size() == 0)
				{
					a.anchors[0].parent = parent;
					a.anchors[0].parent_name = "$parent";
				}
				parent->arts[a.name] = a;
				parent->texNormal = &parent->arts[a.name];
			}
			else if (a.type == GUI_OBJECT_TYPE_THBUTTON)
			{
				if (a.anchors.size() == 0)
				{
					a.anchors[0].parent = parent;
					a.anchors[0].parent_name = "$parent";
				}
				parent->arts[a.name] = a;
				parent->texHighlight = &parent->arts[a.name];
			}
			else if (a.type == GUI_OBJECT_TYPE_TDBUTTON)
			{
				if (a.anchors.size() == 0)
				{
					a.anchors[0].parent = parent;
					a.anchors[0].parent_name = "$parent";
				}
				parent->arts[a.name] = a;
				parent->texDisabled = &parent->arts[a.name];
			}
			else if (a.type == GUI_OBJECT_TYPE_TPBUTTON)
			{
				if (a.anchors.size() == 0)
				{
					a.anchors[0].parent = parent;
					a.anchors[0].parent_name = "$parent";
				}
				parent->arts[a.name] = a;
				parent->texPushed = &parent->arts[a.name];
			}
			else if (mGUIMgr->parentList.find(a.name) == mGUIMgr->parentList.end())
			{
				if (debugThis) {hge->System_Log("3.8");}
				string exec = a.name + " = Texture(\"" + parent->name + "\", \"" + a.name + "\");";
				luaL_dostring(mSceneMgr->luaVM, exec.c_str());
				if (debugThis) {hge->System_Log("3.8.");}

				parent->arts[a.name] = a;
				if (type == GUI_OBJECT_TYPE_TSTATUSBAR)
					parent->barTexture = &parent->arts[a.name];
				mGUIMgr->parentList[a.name] = &parent->arts[a.name];
				if (parent->arts[a.name].anchors.size() == 0)
				{
					parent->arts[a.name].anchors[0].parent = parent;
					parent->arts[a.name].anchors[0].parent_name = "$parent";
				}
			}
			else
			{
				hge->System_Log("# XML Error # : an object with the name %s already exists", a.name.c_str());
			}
		}
		else
		{
			if (debugThis) {hge->System_Log("3.10");}
			GUIBase* hparent = parent->getHighestVirtParent();
			if (hparent->parentList.find(a.vname) == hparent->parentList.end())
			{
				if (type == GUI_OBJECT_TYPE_TSTATUSBAR)
				{
					parent->barTextureName = a.name;
				}
				parent->arts[a.name] = a;
				hparent->parentList[a.vname] = &parent->arts[a.name];
				if (parent->arts[a.name].anchors.size() == 0)
				{
					parent->arts[a.name].anchors[0].parent = parent;
					parent->arts[a.name].anchors[0].parent_name = "$parent";
				}
			}
			else
			{
				hge->System_Log("# XML Error # : a template object with the name %s already exists", a.vname.c_str());
			}
		}
	}
	if (debugXML) {hge->System_Log("4");}
}

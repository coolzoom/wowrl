/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_scenemanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_global.h"

#include "wowrl_xml.h"

using namespace std;

extern SceneManager* mSceneMgr;
extern GUIManager* mGUIMgr;
extern GFXManager* mGFXMgr;
extern HGE* hge;
extern bool debugXML;

void mxml_parseFrame( TiXmlNode* node, GUIElement* parent, int type )
{
	/* [#] This very long function parses a Frame object in an XML file. The Frame
	/* is the base of the GUI. It is a container in which you can put as many
	/* objects as you want, would it be other Frames, Textures, ...
	/* [#] Be carefull when setting a Frame's size : every child which is too large
	/* will not be rendered completely (or even not at all).
	/* [#] The Frame object has some derivations :
	/*    - The StatusBar can do whatever a Frame can do, plus it has a special
	/*      texture which adjust itself its parameters to fit the provded filling
	/*      value.
	/*    - The EditBox, which is basicaly a place where the user can input some
	/*      text that you get and use in your AddOn.
	*/
	bool debugThis = false;
	if (debugXML) {hge->System_Log("1");}
	if (node->ToElement())
	{
		GUIElement g;
		GUIElement* frame;
		g.parent = parent;
		g.type = type;
		string inherits = "";
		string pname = "";
		bool hidden = false;
		bool hiddenD = false;
		bool virt = false;
		bool newFrame = true;
		bool barTexFound = false;
		if (type == GUI_OBJECT_TYPE_SMSGFRAME)
			g.ready = false;

		// We get the frame's attributes
		TiXmlElement* elem = node->ToElement();
		for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
		{
			if (string(attr->Name()) == string("name"))
			{
				if (debugThis) {hge->System_Log("1.1");}
				g.name = attr->Value();
				g.sname = g.name;
			}
			else if (string(attr->Name()) == string("hidden"))
			{
				if (debugThis) {hge->System_Log("1.2");}
				if (string(attr->Value()) == string("true"))
					hidden = true;

				hiddenD = true;
			}
			else if (string(attr->Name()) == string("parent"))
			{
				if (debugThis) {hge->System_Log("1.3");}
				pname = attr->Value();
			}
			else if (string(attr->Name()) == string("virtual"))
			{
				virt = toBool((char*)attr->Value());
			}
			else if (string(attr->Name()) == string("inherits"))
			{
				if ((mGUIMgr->templateList.find(attr->Value()) != mGUIMgr->templateList.end()))
				{
					inherits = attr->Value();
				}
				else
				{
					newFrame = false;
					hge->System_Log("# XML Error # : unknown template %s", attr->Value());
				}
			}
			else if (string(attr->Name()) == string("frameStrata"))
			{
				if (string(attr->Value()) == string("TOOLTIP"))
					g.frameStrata = GUI_STRATA_TOOLTIP;
				else if (string(attr->Value()) == string("FULLSCREEN_DIALOG"))
					g.frameStrata = GUI_STRATA_FULLSCREEN_DIALOG;
				else if (string(attr->Value()) == string("FULLSCREEN"))
					g.frameStrata = GUI_STRATA_FULLSCREEN;
				else if (string(attr->Value()) == string("DIALOG"))
					g.frameStrata = GUI_STRATA_DIALOG;
				else if (string(attr->Value()) == string("HIGH"))
					g.frameStrata = GUI_STRATA_HIGH;
				else if (string(attr->Value()) == string("MEDIUM"))
					g.frameStrata = GUI_STRATA_MEDIUM;
				else if (string(attr->Value()) == string("LOW"))
					g.frameStrata = GUI_STRATA_LOW;
				else if (string(attr->Value()) == string("BACKGROUND"))
					g.frameStrata = GUI_STRATA_BACKGROUND;
			}
			else if (string(attr->Name()) == string("movable"))
			{
			}
			else if (string(attr->Name()) == string("enableMouse"))
			{
				g.enableMouse = toBool((char*)attr->Value());
			}
			else if (string(attr->Name()) == string("toplevel"))
			{
			}
			else if (string(attr->Name()) == string("clampedToScreen"))
			{
			}

			// EditBox specific attributes
			if (type == GUI_OBJECT_TYPE_EDITBOX)
			{
				if (string(attr->Name()) == string("letters"))
				{
					g.letters = toInt(attr->Value());
				}
				if (string(attr->Name()) == string("historyLines"))
				{
					g.historyLines = toInt(attr->Value());
				}
				else if (string(attr->Name()) == string("blinkSpeed"))
				{
					g.blinkSpeed = atof(attr->Value());
				}
				else if (string(attr->Name()) == string("numeric"))
				{
					g.numeric = toBool((char*)attr->Value());
				}
				else if (string(attr->Name()) == string("password"))
				{
					g.password = toBool((char*)attr->Value());
				}
				else if (string(attr->Name()) == string("multiLine"))
				{
					g.multiLine = toBool((char*)attr->Value());
				}
				else if (string(attr->Name()) == string("ignoreArrows"))
				{
					g.ignoreArrows = toBool((char*)attr->Value());
				}
				else if (string(attr->Name()) == string("autoFocus"))
				{
					g.autoFocus = toBool((char*)attr->Value());
				}
			}

			// ScrollingMessageFrame specific attributes
			if (type == GUI_OBJECT_TYPE_SMSGFRAME)
			{
				if (string(attr->Name()) == string("maxLines"))
				{
					g.maxLines = toInt(attr->Value());
				}
				if (string(attr->Name()) == string("fade"))
				{
					g.fade = toBool((char*)attr->Value());
				}
				if (string(attr->Name()) == string("fadeDuration"))
				{
					g.fadeDuration = atof(attr->Value());
				}
				if (string(attr->Name()) == string("displayDuration"))
				{
					g.displayDuration = atof(attr->Value());
				}
			}

			// Button specific attributes
			if (type == GUI_OBJECT_TYPE_BUTTON)
			{
				if (string(attr->Name()) == string("text"))
				{
					g.sButtonText = attr->Value();
				}
			}
		}
		if (newFrame)
		{
			if (g.name == "")
			{
				newFrame = false;
				hge->System_Log("# XML Error # : a frame must have a name");
			}
		}

		if (newFrame)
		{
			if (debugThis) {hge->System_Log("1.4");}
			if (parent != NULL)
			{
				// A virtual frame can't be contained into a non virtual one
				if (parent->virt)
					virt = true;
				else if (virt)
					newFrame = false;
			}
			if (debugThis) {hge->System_Log("1.5");}
			if (pname != "")
			{
				// We make sure that all references to other frames are valid
				if (!virt)
				{
					int i = pname.find("$parent");
					if (i != pname.npos)
					{
						pname = pname.erase(i, 7);
						if (parent != NULL)
							pname.insert(i, parent->name);
					}
					if (mGUIMgr->guiList.find(pname) != mGUIMgr->guiList.end())
					{
						g.parent_name = pname;
					}
					else
					{
						newFrame = false;
						hge->System_Log("# XML Error # : unknown parent frame %s", pname.c_str());
					}
				}
				else
				{
					string pvname = pname;
					int i = pvname.find("$parent");
					if (i != pvname.npos)
					{
						pvname = pvname.erase(i, 7);
						if (parent != NULL)
							pvname.insert(i, parent->vname);
					}
					GUIBase* hparent = parent->getHighestVirtParent();
					if ( (hparent->parentList.find(pvname) != hparent->parentList.end()) ||
						(mGUIMgr->templateList.find(pvname) != mGUIMgr->templateList.end()) )
					{
						g.parent_name = pname;
					}
					else
					{
						newFrame = false;
						hge->System_Log("# XML Error # : unknown template frame %s", pvname.c_str());
					}
				}
			}
			if (debugThis) {hge->System_Log("1.6");}
		}

		if (newFrame)
		{
			// Then we make sure that the name given to that frame is unique
			if (debugThis) {hge->System_Log("1.7");}
			if (!virt)
			{
				if (parent == NULL)
				{
					if (g.parent_name != "")
					{
						g.parent = &mGUIMgr->guiList[g.parent_name];
						parent = g.parent;
					}
				}
				else
				{
					g.parent = parent;
				}
			}
			else
			{
				if (parent != NULL)
				{
					g.parent = parent;
				}
			}

			if (debugThis) {hge->System_Log("1.8");}
			if (virt)
			{
				g.virt = true;

				if (parent == NULL)
				{
					int i = g.name.find("$parent");
					if (i != g.name.npos)
						g.name = g.name.erase(i, 7);

					g.vname = g.name;

					if (mGUIMgr->templateList.find(g.name) == mGUIMgr->templateList.end())
					{
						mGUIMgr->templateList[g.name] = g;
						frame = &mGUIMgr->templateList[g.name];
					}
					else
					{
						newFrame = false;
						hge->System_Log("# XML Error # : a template with the name %s already exists", g.name.c_str());
					}
				}
				else
				{
					g.vname = g.name;
					int i = g.vname.find("$parent");
					if (i != g.vname.npos)
					{
						g.vname = g.vname.erase(i, 7);
						g.vname.insert(i, parent->vname);
					}

					GUIBase* hparent = parent->getHighestVirtParent();
					if (hparent->parentList.find(g.vname) == hparent->parentList.end())
					{
						g.child = true;
						parent->vchilds[g.vname] = g;
						hparent->parentList[g.vname] = frame = &parent->vchilds[g.vname];
					}
					else
					{
						newFrame = false;
						hge->System_Log("# XML Error # : a template object with the name %s already exists", g.vname.c_str());
					}
				}
			}
			else
			{
				g.sname = g.name;
				int i = g.name.find("$parent");
				if (i != g.name.npos)
				{
					g.name = g.name.erase(i, 7);
					g.sname = g.name;
					if (parent != NULL)
						g.name.insert(i, parent->name);
				}

				if (mGUIMgr->parentList.find(g.name) == mGUIMgr->parentList.end())
				{
					if (parent == NULL)
					{
						mGUIMgr->guiList[g.name] = g;
						frame = &mGUIMgr->guiList[g.name];
						mGUIMgr->parentList[g.name] = frame;

					}
					else
					{
						g.child = true;
						mGUIMgr->guiList[g.name] = g;
						frame = &mGUIMgr->guiList[g.name];
						parent->childs[g.name] = frame;
						mGUIMgr->parentList[g.name] = frame;
					}
				}
				else
				{
					newFrame = false;
					hge->System_Log("# XML Error # : an object with the name %s already exists", g.name.c_str());
				}
			}
			if (debugThis) {hge->System_Log("1.8.");}
		}

		if (newFrame)
		{
			// Debug: print the frame's name
			if (debugThis)
			{
				if (!virt)
					hge->System_Log("1.9 %s", frame->name.c_str());
				else
					hge->System_Log("1.9 %s", frame->vname.c_str());
			}

			// We apply inheritance, copying the base frame's parameter to our new one
			if (inherits != "")
			{
				GUIElement* inh = &mGUIMgr->templateList[inherits];

				if ((inh->type == GUI_OBJECT_TYPE_FRAME) ||
				    (frame->type == inh->type))
				{
					if (!frame->virt)
					{
						if (debugThis) {hge->System_Log("1.9.1");}
						inh->copyVirt(frame);
						if (debugThis) {hge->System_Log("1.9.2");}
					}
					else
					{
						if (debugThis) {hge->System_Log("1.9.3");}
						frame->hidden = inh->hidden;
						frame->w = inh->w;
						frame->h = inh->h;
						frame->alpha = inh->alpha;

						frame->funcList = inh->funcList;

						frame->childs = inh->childs;
						frame->arts = inh->arts;
						frame->anchors = inh->anchors;

	// TODO (Corentin#1#): Attributes must be overwritten only if not defined.
						// Status bar
						if (inh->type == GUI_OBJECT_TYPE_STATUSBAR)
						{
							frame->value = inh->value;
							frame->min_value = inh->min_value;
							frame->max_value = inh->max_value;
							frame->base_width = inh->base_width;
							frame->barTextureName = inh->barTextureName;
						}

						// Edit box
						if (inh->type == GUI_OBJECT_TYPE_EDITBOX)
						{
							frame->letters = inh->letters;
							frame->historyLines = inh->historyLines;
							frame->blinkSpeed = inh->blinkSpeed;
							frame->numeric = inh->numeric;
							frame->password = inh->password;
							frame->multiLine = inh->multiLine;
							frame->ignoreArrows = inh->ignoreArrows;
							frame->autoFocus = inh->autoFocus;
							frame->captionFontName = inh->captionFontName;
						}

						frame->useBackdrop = inh->useBackdrop;
						if (frame->useBackdrop)
							frame->backdrop = inh->backdrop;

						if (debugThis) {hge->System_Log("1.9.4");}
					}
				}
				else
					hge->System_Log("# XML Error # : wrong parent type for inheritance in %s", frame->name.c_str());
			}

			if (debugThis) {hge->System_Log("1.10");}

			if (hiddenD)
				frame->hidden = hidden;

			// Then we get this frame's elements
			for (TiXmlNode* node2 = node->FirstChild(); node2; node2 = node2->NextSibling())
			{
				if (string(node2->Value()) == string("Scripts"))
				{
					if (debugThis) {hge->System_Log("1.10.1");}
					for (TiXmlNode* node3 = node2->FirstChild(); node3; node3 = node3->NextSibling())
					{
						// Frame handlers
						if (string(node3->Value()) == string("OnLoad"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_LOAD, node4->Value());
						}
						else if (string(node3->Value()) == string("OnEnter"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_ENTER, node4->Value());
						}
						else if (string(node3->Value()) == string("OnLeave"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_LEAVE, node4->Value());
						}
						else if (string(node3->Value()) == string("OnDragStart"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_DRAGSTART, node4->Value());
						}
						else if (string(node3->Value()) == string("OnReceiveDrag"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_RECEIVEDRAG, node4->Value());
						}
						else if (string(node3->Value()) == string("OnUpdate"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_UPDATE, node4->Value());
						}
						else if (string(node3->Value()) == string("OnMouseUp"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_MOUSEUP, node4->Value());
						}
						else if (string(node3->Value()) == string("OnMouseDown"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_MOUSEDOWN, node4->Value());
						}
						else if (string(node3->Value()) == string("OnKeyUp"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_KEYUP, node4->Value());
						}
						else if (string(node3->Value()) == string("OnKeyDown"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_KEYDOWN, node4->Value());
						}
						else if (string(node3->Value()) == string("OnHide"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_HIDE, node4->Value());
						}
						else if (string(node3->Value()) == string("OnShow"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_SHOW, node4->Value());
						}
						else if (string(node3->Value()) == string("OnEvent"))
						{
							TiXmlNode* node4 = node3->FirstChild();
							if (node4)
								mGUIMgr->RegisterFunc(frame, GUI_FUNC_EVENT, node4->Value());
						}

						// EditBox specific handlers
						if (frame->type == GUI_OBJECT_TYPE_EDITBOX)
						{
							if (string(node3->Value()) == string("OnChar"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_CHAR, node4->Value());
							}
							else if (string(node3->Value()) == string("OnEnterPressed"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_ENTERPRESSED, node4->Value());
							}
							else if (string(node3->Value()) == string("OnSpacePressed"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_SPACEPRESSED, node4->Value());
							}
							else if (string(node3->Value()) == string("OnTabPressed"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_TABPRESSED, node4->Value());
							}
							else if (string(node3->Value()) == string("OnEscapePressed"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_ESCAPEPRESSED, node4->Value());
							}
							else if (string(node3->Value()) == string("OnEditFocusGained"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_EDITFOCUSGAINED, node4->Value());
							}
							else if (string(node3->Value()) == string("OnEditFocusLost"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_EDITFOCUSLOST, node4->Value());
							}
						}

						// Button specific handler
						if (frame->type == GUI_OBJECT_TYPE_BUTTON)
						{
							if (string(node3->Value()) == string("OnClick"))
							{
								TiXmlNode* node4 = node3->FirstChild();
								if (node4)
									mGUIMgr->RegisterFunc(frame, GUI_FUNC_CLICK, node4->Value());
							}
						}
					}
				}
				else if (string(node2->Value()) == string("Size"))
				{
					if (debugThis) {hge->System_Log("1.10.2");}
					TiXmlNode* node3 = node2->FirstChild();
					if (node3)
					{
						if (string(node3->Value()) == string("AbsDimension"))
						{
							TiXmlElement* elem = node3->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("x"))
								{
									frame->w = atof(attr->Value());
								}
								else if (string(attr->Name()) == string("y"))
								{
									frame->h = atof(attr->Value());
								}
							}
						}
					}
				}
				else if (string(node2->Value()) == string("Anchors"))
				{
					mxml_parseAnchor(node2, frame);
				}
				else if (string(node2->Value()) == string("Frames"))
				{
					if (debugThis) {hge->System_Log("1.10.3");}
					for (TiXmlNode* node3 = node2->FirstChild(); node3; node3 = node3->NextSibling())
					{
						if (string(node3->Value()) == string("Frame"))
						{
							mxml_parseFrame(node3, frame, GUI_OBJECT_TYPE_FRAME);
						}
						else if (string(node3->Value()) == string("StatusBar"))
						{
							mxml_parseFrame(node3, frame, GUI_OBJECT_TYPE_STATUSBAR);
						}
						else if (string(node3->Value()) == string("EditBox"))
						{
							mxml_parseFrame(node3, frame, GUI_OBJECT_TYPE_EDITBOX);
						}
						else if (string(node3->Value()) == string("ScrollingMessageFrame"))
						{
							mxml_parseFrame(node3, frame, GUI_OBJECT_TYPE_SMSGFRAME);
						}
						else if (string(node3->Value()) == string("Button"))
						{
							mxml_parseFrame(node3, frame, GUI_OBJECT_TYPE_BUTTON);
						}
					}
				}
				else if (string(node2->Value()) == string("Layers"))
				{
					if (debugThis) {hge->System_Log("1.10.4");}
					for (TiXmlNode* node3 = node2->FirstChild(); node3; node3 = node3->NextSibling())
					{
						if (string(node3->Value()) == string("Layer"))
						{
							int layer = 0;
							TiXmlElement* elem = node3->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("level"))
								{
									if (string(attr->Value()) == string("BACKGROUND"))
										layer = GUI_LAYER_BACKGROUND;
									else if (string(attr->Value()) == string("BORDER"))
										layer = GUI_LAYER_BORDER;
									else if (string(attr->Value()) == string("ARTWORK"))
										layer = GUI_LAYER_ARTWORK;
									else if (string(attr->Value()) == string("OVERLAY"))
										layer = GUI_LAYER_OVERLAY;
									else if (string(attr->Value()) == string("HIGHLIGHT"))
										layer = GUI_LAYER_HIGHLIGHT;
								}
							}

							for (TiXmlNode* node4 = node3->FirstChild(); node4; node4 = node4->NextSibling())
							{
								if (string(node4->Value()) == string("Texture"))
								{
									mxml_parseTexture(node4, frame, layer);
								}
								else if (string(node4->Value()) == string("FontString"))
								{
									mxml_parseString(node4, frame, layer);
								}
							}
						}
					}
				}
				else if (string(node2->Value()) == string("Backdrop"))
				{
					mxml_parseBackdrop(node2, frame);
				}
				else if (string(node2->Value()) == string("HitRectInsets"))
				{
					TiXmlNode* node3 = node2->FirstChild();
					if (node3)
					{
						if (string(node3->Value()) == string("AbsInset"))
						{
							TiXmlElement* elem = node3->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("left"))
								{
									frame->iHitInsL = atoi(attr->Value());
								}
								if (string(attr->Name()) == string("right"))
								{
									frame->iHitInsR = atoi(attr->Value());
								}
								if (string(attr->Name()) == string("top"))
								{
									frame->iHitInsT = atoi(attr->Value());
								}
								if (string(attr->Name()) == string("bottom"))
								{
									frame->iHitInsB = atoi(attr->Value());
								}
							}
						}
					}
				}

				// Special elements for the status bar
				if (frame->type == GUI_OBJECT_TYPE_STATUSBAR)
				{
					if (string(node2->Value()) == string("BarTexture"))
					{
						mxml_parseTexture(node2, frame, GUI_LAYER_BACKGROUND, GUI_OBJECT_TYPE_TSTATUSBAR);
					}
					else if (string(node2->Value()) == string("BarColor"))
					{
						if (barTexFound)
						{
							float r = 1.0f; float g = 1.0f; float b = 1.0f; float al = 1.0f;
							TiXmlElement* elem = node2->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("r"))
									r = atof(attr->Value());
								else if (string(attr->Name()) == string("g"))
									g = atof(attr->Value());
								else if (string(attr->Name()) == string("b"))
									b = atof(attr->Value());
								else if (string(attr->Name()) == string("a"))
									al = atof(attr->Value());
							}

							GUIArt* a = &frame->arts[frame->name + "BarTexture"];
							a->color = ARGB(255*al, 255*r, 255*g, 255*b);
							a->sprite->SetColor(a->color);
						}
					}
				}

				// Special elements for the edit box
				if (frame->type == GUI_OBJECT_TYPE_EDITBOX)
				{
					if (string(node2->Value()) == string("FontString"))
					{
						mxml_parseString(node2, frame, GUI_LAYER_SPECIALHIGH, GUI_OBJECT_TYPE_FEDITBOX);
					}
					else if (string(node2->Value()) == string("TextInsets"))
					{
						TiXmlElement* elem = node2->ToElement();
						for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
						{
							if (string(attr->Name()) == string("left"))
							{
								frame->EBinsL = atoi(attr->Value());
							}
							if (string(attr->Name()) == string("right"))
							{
								frame->EBinsR = atoi(attr->Value());
							}
							if (string(attr->Name()) == string("top"))
							{
								frame->EBinsT = atoi(attr->Value());
							}
							if (string(attr->Name()) == string("bottom"))
							{
								frame->EBinsB = atoi(attr->Value());
							}
						}
					}
					else if (string(node2->Value()) == string("HighlightColor"))
					{

					}
				}

				// Special elements for the scrolling message frame
				if (frame->type == GUI_OBJECT_TYPE_SMSGFRAME)
				{
					if (string(node2->Value()) == string("FontString"))
					{
						mxml_parseString(node2, frame, GUI_LAYER_SPECIALHIGH, GUI_OBJECT_TYPE_FSMSGFRAME);
					}
					else if (string(node2->Value()) == string("TextInsets"))
					{
						TiXmlElement* elem = node2->ToElement();
						for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
						{
							if (string(attr->Name()) == string("left"))
							{
								frame->SMFinsL = atoi(attr->Value());
							}
							if (string(attr->Name()) == string("right"))
							{
								frame->SMFinsR = atoi(attr->Value());
							}
							if (string(attr->Name()) == string("top"))
							{
								frame->SMFinsT = atoi(attr->Value());
							}
							if (string(attr->Name()) == string("bottom"))
							{
								frame->SMFinsB = atoi(attr->Value());
							}
						}
					}
				}

				// Special elements for buttons
				if (frame->type == GUI_OBJECT_TYPE_BUTTON)
				{
					if (string(node2->Value()) == string("NormalTexture"))
					{
						mxml_parseTexture(node2, frame, GUI_LAYER_BACKGROUND, GUI_OBJECT_TYPE_TNBUTTON);
					}
					else if (string(node2->Value()) == string("PushedTexture"))
					{
						mxml_parseTexture(node2, frame, GUI_LAYER_BACKGROUND, GUI_OBJECT_TYPE_TPBUTTON);
					}
					else if (string(node2->Value()) == string("DisabledTexture"))
					{
						mxml_parseTexture(node2, frame, GUI_LAYER_BACKGROUND, GUI_OBJECT_TYPE_TDBUTTON);
					}
					else if (string(node2->Value()) == string("HighlightTexture"))
					{
						mxml_parseTexture(node2, frame, GUI_LAYER_HIGHLIGHT, GUI_OBJECT_TYPE_THBUTTON);
					}
					else if (string(node2->Value()) == string("NormalText"))
					{
						mxml_parseString(node2, frame, GUI_LAYER_SPECIALHIGH, GUI_OBJECT_TYPE_FNBUTTON);
					}
					else if (string(node2->Value()) == string("HighlightText"))
					{
						mxml_parseString(node2, frame, GUI_LAYER_SPECIALHIGH, GUI_OBJECT_TYPE_FHBUTTON);
					}
					else if (string(node2->Value()) == string("DisabledText"))
					{
						mxml_parseString(node2, frame, GUI_LAYER_SPECIALHIGH, GUI_OBJECT_TYPE_FDBUTTON);
					}
					else if (string(node2->Value()) == string("PushedTextOffset"))
					{
						TiXmlElement* elem = node2->ToElement();
						for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
						{
							if (string(attr->Name()) == string("x"))
							{
								frame->iPushTxtOffX = atoi(attr->Value());
							}
							else if (string(attr->Name()) == string("y"))
							{
								frame->iPushTxtOffY = atoi(attr->Value());
							}
						}
					}
				}
			}

			if (debugThis) {hge->System_Log("1.11");}

			// If the frame is not virtual, we register it in lua
			if (!virt)
			{
				string exec;
				if (frame->type == GUI_OBJECT_TYPE_STATUSBAR)
					exec = frame->name + " = StatusBar(\"" + frame->name + "\");";
				else if (frame->type == GUI_OBJECT_TYPE_EDITBOX)
					exec = frame->name + " = EditBox(\"" + frame->name + "\");";
				else if (frame->type == GUI_OBJECT_TYPE_SMSGFRAME)
					exec = frame->name + " = ScrollingMessageFrame(\"" + frame->name + "\");";
				else if (frame->type == GUI_OBJECT_TYPE_BUTTON)
					exec = frame->name + " = Button(\"" + frame->name + "\");";
				else
					exec = frame->name + " = Frame(\"" + frame->name + "\");";

				luaL_dostring(mSceneMgr->luaVM, exec.c_str());
			}

			// We set unprovided parameters
			if (frame->parent != NULL)
			{
				if (frame->w < 0)
					frame->w = frame->parent->w;
				if (frame->h < 0)
					frame->h = frame->parent->h;
			}
			else
			{
				if (frame->w < 0)
					frame->w = mGFXMgr->sWidth;
				if (frame->h < 0)
					frame->h = mGFXMgr->sHeight;
			}

			if (debugThis) {hge->System_Log("1.12");}

			if ( (frame->type == GUI_OBJECT_TYPE_EDITBOX) && (!frame->virt) )
			{
				frame->enableMouse = true;

				if (frame->captionFont != NULL)
				{
					Anchor a;
					a.parent = frame;
					a.parent_name = frame->name;
					a.x = frame->EBinsL;
					a.y = -frame->EBinsT;

					frame->captionFont->anchors[0] = a;

					frame->captionFont->w = frame->w - frame->EBinsL - frame->EBinsT;
					frame->captionFont->text.w = frame->captionFont->w;
					frame->captionFont->h = frame->h - frame->EBinsT - frame->EBinsB;

					frame->carretScale = frame->captionFont->text.fntSize/16.0f;
					frame->carretX = 1*frame->carretScale+frame->EBinsL;
					frame->carretY = 15*frame->carretScale+frame->EBinsT;
				}
				else
				{
					frame->carretScale = 1.0f;
					frame->carretX = 1+frame->EBinsL;
					frame->carretY = 15+frame->EBinsT;
				}
			}

			if (frame->type == GUI_OBJECT_TYPE_SMSGFRAME)
			{
				frame->oldBottomLine = frame->maxLines;
				frame->bottomLine = frame->maxLines;
			}

			if (frame->type == GUI_OBJECT_TYPE_BUTTON)
			{
				frame->enableMouse = true;

				if (frame->texNormal == NULL)
					frame->bButtonTextureReady = false;
				else
				{
					frame->bButtonTextureReady = true;
					if (frame->texPushed == NULL)
						frame->texPushed = frame->texNormal;
					if (frame->texDisabled == NULL)
						frame->texDisabled = frame->texNormal;
					if (frame->texHighlight == NULL)
						frame->texHighlight = frame->texNormal;
				}

				if (frame->fontNormal == NULL)
					frame->bButtonFontReady = false;
				else
				{
					frame->bButtonFontReady = true;
					if (frame->fontHighlight == NULL)
						frame->fontHighlight = frame->fontNormal;
					if (frame->fontDisabled == NULL)
						frame->fontDisabled = frame->fontNormal;
				}

				if ( (frame->texNormal == NULL) && (frame->fontNormal == NULL) )
					frame->ready = false;
			}

			/*if ( (!frame->virt) && (frame->anchors.size() == 0) )
			{
				frame->anchors[0].parent = parent;
				frame->anchors[0].parent_name = "$parent";
			}*/
		}
	}
	if (debugXML) {hge->System_Log("2");}
}

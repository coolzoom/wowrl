/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               XML source               */
/*                                        */
/*  ## : This file contains xml related   */
/*  functions.                            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_scenemanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_global.h"

#include "wowrl_xml.h"

using namespace std;

extern SceneManager* mSceneMgr;
extern GFXManager* mGFXMgr;
extern GUIManager* mGUIMgr;
extern HGE* hge;

bool debugXML = false;

void mxml_initUI()
{
	string s = "";
	s += "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n";
	s += "<Ui>\n";
	s += "    <Frame name=\"UIParent\">\n";
	s += "        <Size>\n";
    s += "            <AbsDimension x=\"" + toString(mGFXMgr->sWidth) + "\" y=\"" + toString(mGFXMgr->sHeight) + "\"/>\n";
    s += "        </Size>\n";
	s += "        <Anchors>\n";
	s += "            <Anchor point=\"TOPLEFT\">\n";
	s += "                <Offset>\n";
	s += "                    <AbsDimension x=\"0\" y=\"0\"/>\n";
	s += "                </Offset>\n";
	s += "            </Anchor>\n";
	s += "        </Anchors>\n";
	s += "    <Frame>\n";
	s += "</Ui>\n";

	TiXmlDocument doc;
	doc.Parse(s.c_str());
  	mxml_parseUIFile(NULL, doc);

  	mGUIMgr->guiList["UIParent"].baseUI = true;
}

void mxml_parseUIFile( AddOn* a, TiXmlDocument doc )
{
	/* [#] This function parses an XML UI file.
	/* To be considered as valid, an XML UI file must contain the <Ui> tag in
	/* its root. Everything else wont be parsed.
	*/
	if (debugXML) hge->System_Log("# 0");
	GUIElement* eParent = NULL;
	GUIArt* aParent = NULL;

	if (string(doc.RootElement()->Value()) == string("Ui"))
	{
		for (TiXmlNode* node = doc.RootElement()->FirstChild(); node; node = node->NextSibling())
		{
			if (string(node->Value()) == string("Script"))
			{
				if (node->ToElement())
				{
					TiXmlElement* elem = node->ToElement();
					for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
					{
						if (string(attr->Name()) == string("file"))
						{
							string lFile = a->folder + "/" + attr->Value();
							if (fileExists(lFile))
							{
								int error = luaL_dofile(mSceneMgr->luaVM, lFile.c_str());
								if (error) l_logPrint(mSceneMgr->luaVM);
							}
						}
					}
				}
			}
			else if (string(node->Value()) == string("Frame"))
			{
				mxml_parseFrame(node, NULL, GUI_OBJECT_TYPE_FRAME);
			}
			else if (string(node->Value()) == string("StatusBar"))
			{
				mxml_parseFrame(node, NULL, GUI_OBJECT_TYPE_STATUSBAR);
			}
			else if (string(node->Value()) == string("EditBox"))
			{
				mxml_parseFrame(node, NULL, GUI_OBJECT_TYPE_EDITBOX);
			}
			else if (string(node->Value()) == string("ScrollingMessageFrame"))
			{
				mxml_parseFrame(node, NULL, GUI_OBJECT_TYPE_SMSGFRAME);
			}
			else if (string(node->Value()) == string("Button"))
			{
				mxml_parseFrame(node, NULL, GUI_OBJECT_TYPE_BUTTON);
			}
		}
	}
	else
		hge->System_Log("# XML Error # : invalid root node %s", doc.RootElement()->Value());

	if (debugXML) hge->System_Log("# 0.");
}

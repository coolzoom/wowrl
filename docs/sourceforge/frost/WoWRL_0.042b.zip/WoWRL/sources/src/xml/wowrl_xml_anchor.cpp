/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_guimanager.h"
#include "wowrl_global.h"

#include "wowrl_xml.h"

using namespace std;

extern GUIManager* mGUIMgr;
extern HGE* hge;
extern bool debugXML;

void mxml_parseAnchor( TiXmlNode* node, GUIBase* parent )
{
	/* [#] This function parses an Anchor object in an XML file.
	/* An Anchor must be contained in another object, such as a Frame or a Texture.
	*/
	if (debugXML) {hge->System_Log("7");}
	TiXmlNode* node2 = node->FirstChild();
	if (node2)
	{
		if (string(node2->Value()) == string("Anchor"))
		{
			Anchor a;
			TiXmlElement* elem = node2->ToElement();
			for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
			{
				if (string(attr->Name()) == string("point"))
				{
					if (string(attr->Value()) == string("TOPLEFT"))
						a.anchorPt = GUI_ANCHOR_TOPLEFT;
					else if (string(attr->Value()) == string("TOP"))
						a.anchorPt = GUI_ANCHOR_TOP;
					else if (string(attr->Value()) == string("TOPRIGHT"))
						a.anchorPt = GUI_ANCHOR_TOPRIGHT;
					else if (string(attr->Value()) == string("RIGHT"))
						a.anchorPt = GUI_ANCHOR_RIGHT;
					else if (string(attr->Value()) == string("BOTTOMRIGHT"))
						a.anchorPt = GUI_ANCHOR_BOTTOMRIGHT;
					else if (string(attr->Value()) == string("BOTTOM"))
						a.anchorPt = GUI_ANCHOR_BOTTOM;
					else if (string(attr->Value()) == string("BOTTOMLEFT"))
						a.anchorPt = GUI_ANCHOR_BOTTOMLEFT;
					else if (string(attr->Value()) == string("LEFT"))
						a.anchorPt = GUI_ANCHOR_LEFT;
					else if (string(attr->Value()) == string("CENTER"))
						a.anchorPt = GUI_ANCHOR_CENTER;
				}
				else if (string(attr->Name()) == string("relativeTo"))
				{
					a.parent_name = attr->Value();
				}
				else if (string(attr->Name()) == string("relativePoint"))
				{
					if (string(attr->Value()) == string("TOPLEFT"))
						a.relativePt = GUI_ANCHOR_TOPLEFT;
					else if (string(attr->Value()) == string("TOP"))
						a.relativePt = GUI_ANCHOR_TOP;
					else if (string(attr->Value()) == string("TOPRIGHT"))
						a.relativePt = GUI_ANCHOR_TOPRIGHT;
					else if (string(attr->Value()) == string("RIGHT"))
						a.relativePt = GUI_ANCHOR_RIGHT;
					else if (string(attr->Value()) == string("BOTTOMRIGHT"))
						a.relativePt = GUI_ANCHOR_BOTTOMRIGHT;
					else if (string(attr->Value()) == string("BOTTOM"))
						a.relativePt = GUI_ANCHOR_BOTTOM;
					else if (string(attr->Value()) == string("BOTTOMLEFT"))
						a.relativePt = GUI_ANCHOR_BOTTOMLEFT;
					else if (string(attr->Value()) == string("LEFT"))
						a.relativePt = GUI_ANCHOR_LEFT;
					else if (string(attr->Value()) == string("CENTER"))
						a.relativePt = GUI_ANCHOR_CENTER;
				}
			}

			TiXmlNode* node3 = node2->FirstChild();
			if (node3)
			{
				if (string(node3->Value()) == string("Offset"))
				{
					TiXmlNode* node4 = node3->FirstChild();
					if (node4)
					{
						if (string(node4->Value()) == string("AbsDimension"))
						{
							TiXmlElement* elem = node4->ToElement();
							for (const TiXmlAttribute* attr = elem->FirstAttribute(); attr; attr = attr->Next())
							{
								if (string(attr->Name()) == string("x"))
								{
									a.x = atof(attr->Value());
								}
								else if (string(attr->Name()) == string("y"))
								{
									a.y = atof(attr->Value());
								}
							}
						}
					}
				}
			}

			bool newAnchor = true;

			if (parent->virt)
			{
				if (a.parent_name == "")
				{
					if (parent->parent != NULL)
					{
						a.parent = parent->parent;
						a.parent_name = "$parent";
					}
				}
				else
				{
					if (mGUIMgr->guiList.find(a.parent_name) != mGUIMgr->guiList.end())
					{
						a.parent = &mGUIMgr->guiList[a.parent_name];
					}
					else
					{
						GUIBase* hparent = parent->getHighestVirtParent();
						string tpname = a.parent_name;
						int i = tpname.find("$parent");
						if (i != tpname.npos)
						{
							tpname = tpname.erase(i, 7);
							if (parent->parent != NULL)
								tpname.insert(i, parent->parent->vname);
						}
						if (hparent->parentList.find(tpname) != hparent->parentList.end())
						{
							a.parent = hparent->parentList[tpname];
						}
						else
						{
							newAnchor = false;
							hge->System_Log("# XML Error # : unknown parent %s\n# Listing %s parents :", tpname.c_str(), hparent->vname.c_str());
							map<string, GUIBase*>::iterator iter;
							for (iter = hparent->parentList.begin(); iter != hparent->parentList.end(); iter++)
							{
								hge->System_Log("   - %s", iter->first.c_str());
							}
						}
					}
				}
			}
			else
			{
				if (a.parent_name == "")
				{
					if (parent->parent != NULL)
					{
						a.parent = parent->parent;
						a.parent_name = parent->parent->name;
					}
				}
				else
				{
					int i = a.parent_name.find("$parent");
					if (i != a.parent_name.npos)
					{
						a.parent_name = a.parent_name.erase(i, 7);
						if (parent != NULL)
						{
							if (parent->parent != NULL)
								a.parent_name.insert(i, parent->parent->name);
						}
					}
					/*if (mGUIMgr->guiList.find(a.parent_name) != mGUIMgr->guiList.end())
					{
						a.parent = &mGUIMgr->guiList[a.parent_name];
					}*/
					if (mGUIMgr->parentList.find(a.parent_name) != mGUIMgr->parentList.end())
					{
						a.parent = mGUIMgr->parentList[a.parent_name];
					}
					else
					{
						newAnchor = false;
						hge->System_Log("# XML Error # : unknown parent %s", a.parent_name.c_str());
					}
				}
			}

			parent->anchors[parent->anchors.size()] = a;
		}
	}
	if (debugXML) {hge->System_Log("8");}
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          Scene manager source          */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the SceneManager class.            */
/*       A SceneManager is obviously a    */
/*  class that manages the scene and its  */
/*  components (units, background ...)    */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_global.h"
#include "wowrl_pathfinding.h"
#include "wowrl_lua.h"
#include "wowrl_guimanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_zonemanager.h"

#include "wowrl_scenemanager.h"

extern HGE *hge;
extern GUIManager *mGUIMgr;
extern TimeManager *mTimeMgr;
extern GFXManager *mGFXMgr;
extern InputManager *mInputMgr;
extern ZoneManager *mZoneMgr;

using namespace std;

SceneManager::SceneManager()
{
	loaderState = 0;
	jumpToNextState = false;

	bgRect = new hgeRect();
	fPanSpeed = 500.0f;
	dx = 0.0f; dy = 0.0f;
	dgx = 0.0f; dgy = 0.0f;

	panning = false;
	mouseOverPlayField = true;

	gamePaused = false;

	debugParser = false;
}

SceneManager* SceneManager::mSceneMgr = NULL;

SceneManager* SceneManager::getSingleton()
{
	if (mSceneMgr == NULL)
		mSceneMgr = new SceneManager;
	return mSceneMgr;
}

Item SceneManager::parseItem( int item_id )
{
	if (itemList.find(item_id) == itemList.end())
	{
		if (this->debugParser) hge->System_Log(" Parsing item %d...", item_id);

		lua_getglobal(luaVM, "Items");
		lua_rawgeti(luaVM, -1, item_id);

		Item item;

		item.id = item_id;
		item.display_name = mlua_getFieldString("display_name");
		item.description = mlua_getFieldString("description");
		string icon = mlua_getFieldString("icon", false, "Icons/INV_Misc_QuestionMark.png");
		item.iconPath = icon;
		item.icon = mGFXMgr->createSprite
		(
			mGFXMgr->loadTexture(icon, true),
			5, 5, 56, 56
		);
		item.type = mlua_getFieldInt("type");
		item.quality = mlua_getFieldInt("quality");
		item.binds = mlua_getFieldInt("binds", false, 0);
		item.req_lvl = mlua_getFieldInt("requieres_lvl", false, 0);
		item.unique = mlua_getFieldInt("unique", false, 0);
		item.charges = mlua_getFieldInt("charges", false, -1);
		item.sellable = mlua_getFieldBool("sellable", false, false);
		item.price = mlua_getFieldInt("price");

		item.req_class = -1;
		item.req_skill = "";
		item.req_skill_lvl = 0;
		item.cooldown = 0.0f;
		//item.quest = NULL;
		item.conjured = false;
		item.made_by = "";
		item.container = false;
		item.soulbound = false;
		item.on_equip = NULL;
		item.on_use = NULL;
		item.on_hit = NULL;
		item.on_cast = NULL;
		item.durability_max = 0;
		item.durability_cur = 0;
		item.bonus_stat.clear();
		item.speed = 0.0f;
		item.dmg_min = 0;
		item.dmg_max = 0;
		item.add_dmg_school = 0;
		item.add_dmg_min = 0;
		item.add_dmg_max = 0;

		lua_pop(luaVM, 2);

		itemList[item_id] = item;
		return item;
	}
	else
		return itemList[item_id];
}

void SceneManager::requestWPPath( Unit* u )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->getProfiler(1, "SceneManager::requestWPPath", false);
		Chrono c(prof);
	#endif
	if (u->destPoint == Point(u->getGX(), u->getGY()))
	{
		u->waypointIndice == -1;
		u->orderGiven = true;
		u->following = true;
		vector<Point> path;
		path.push_back(u->destPoint);
		u->path = path;
		if (u->order != MOVEMENT_LEASHING)
			u->order = MOVEMENT_MOVE;
	}
	float index = hge->Timer_GetTime();
	while (this->requestWPList.find(index) != this->requestWPList.end())
	{
		index += 0.001;
	}
	this->requestWPList[index] = u;
	u->placeInWPQueue = index;
}

void SceneManager::buildWPPaths()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->getProfiler(1, "SceneManager::buildWPPaths", false);
		Chrono c(prof);
	#endif
	if (!this->requestWPList.empty())
	{
		int pathBuilded = 0;
		map<float, Unit*>::iterator iter = this->requestWPList.begin();
		while (pathBuilded < maxComputedPaths)
		{
			Unit* u = iter->second;
			if (u->placeInWPQueue == iter->first)
			{
				u->wPath = getWaypoints
				(
					toInt(u->getGX()),
					toInt(u->getGY()),
					toInt(u->destPoint.x),
					toInt(u->destPoint.y)
				);
				u->orderGiven = true;

				pathBuilded++;

				this->requestWPList.erase(iter);
				iter = this->requestWPList.begin();
			}
			if (iter == this->requestWPList.end())
				break;
		}
	}
}

void SceneManager::requestPath( Unit* u )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->getProfiler(1, "SceneManager::requestPath", false);
		Chrono c(prof);
	#endif
	float index = hge->Timer_GetTime();
	while (this->requestList.find(index) != this->requestList.end())
	{
		index += 0.001;
	}
	this->requestList[index] = u;
	u->placeInQueue = index;
	u->pathRequested = true;
	u->pathObtained = false;
}

void SceneManager::buildPaths()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->getProfiler(1, "SceneManager::buildPaths", false);
		Chrono c(prof);
	#endif
	if (!this->requestList.empty())
	{
		int pathBuilded = 0;
		map<float, Unit*>::iterator iter = this->requestList.begin();
		while (pathBuilded < maxComputedPaths)
		{
			Unit* u = iter->second;
			if (u->placeInQueue == iter->first)
			{
				vector<Point>::iterator iter2 = u->wPath.begin();
				for (int i=0; i < u->waypointIndice; i++)
				{
					iter2++;
				}
				if (iter2->size != 0.0f)
				{
					float ySize = iter2->size/1.6f;
					float randomY = hge->Random_Float(-ySize, ySize);
					float randomX = hge->Random_Float(-iter2->size, iter2->size)*sin(randomY/ySize);
					u->path = getShortestPath
					(
						toInt(u->getGX()),
						toInt(u->getGY()),
						toInt(iter2->x+randomX),
						toInt(iter2->y+randomY)
					);
				}
				else
				{
					u->path = getShortestPath
					(
						toInt(u->getGX()),
						toInt(u->getGY()),
						toInt(iter2->x),
						toInt(iter2->y)
					);
				}

				u->pathRequested = false;
				u->pathObtained = true;
				this->requestList.erase(iter);
				iter = this->requestList.begin();
				pathBuilded++;
			}
			if (iter == this->requestList.end())
				break;
		}
	}
}

void SceneManager::requestDirectPath( Unit* u )
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->getProfiler(1, "SceneManager::requestDirectPath", false);
		Chrono c(prof);
	#endif
	float index = hge->Timer_GetTime();
	while (this->requestDList.find(index) != this->requestDList.end())
	{
		index += 0.001;
	}
	this->requestDList[index] = u;
	u->placeInDQueue = index;
	u->pathRequested = true;
	u->pathObtained = false;
}

void SceneManager::buildDirectPaths()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->getProfiler(1, "SceneManager::buildDirectPaths", false);
		Chrono c(prof);
	#endif
	if (!this->requestDList.empty())
	{
		int pathBuilded = 0;
		map<float, Unit*>::iterator iter = this->requestDList.begin();
		while (pathBuilded < maxComputedPaths)
		{
			Unit* u = iter->second;
			if (u->placeInDQueue == iter->first)
			{
				u->path = getShortestPath
				(
					toInt(u->getGX()),
					toInt(u->getGY()),
					toInt(u->destPoint.x),
					toInt(u->destPoint.y)
				);
				u->pathRequested = false;
				u->pathObtained = true;
				this->requestDList.erase(iter);
				iter = this->requestDList.begin();
				pathBuilded++;
			}
			if (iter == this->requestDList.end())
				break;
		}
	}
}

void SceneManager::Update()
{
	// Reset variation
	mSceneMgr->dx = 0;
	mSceneMgr->dy = 0;

	// If the mouse enters a 4 pixel zone around the screen, pan the view in the direction
	// given by the mouse pointer
	bool mouseLInt = screenLRect->TestPoint(mInputMgr->mx, mInputMgr->my);
	bool mouseTInt = screenTRect->TestPoint(mInputMgr->mx, mInputMgr->my);
	bool mouseRInt = screenRRect->TestPoint(mInputMgr->mx, mInputMgr->my);
	bool mouseBInt = screenBRect->TestPoint(mInputMgr->mx, mInputMgr->my);

	if (mouseLInt || mouseTInt || mouseRInt || mouseBInt)
	{
		mGUIMgr->cursor = mGUIMgr->switchCursor("pan");
		mGUIMgr->cursor->rot = -1.0f;
		if (mouseLInt && !(mouseTInt && mouseRInt && mouseBInt))
		{
			mGUIMgr->cursor->rot = M_PI;
			dx = fPanSpeed*mInputMgr->dt;
		}
		if (mouseTInt && !(mouseLInt && mouseRInt && mouseBInt))
		{
			if (mGUIMgr->cursor->rot == -1.0f)
				mGUIMgr->cursor->rot = 3*M_PI_2;
			else
				mGUIMgr->cursor->rot = (mGUIMgr->cursor->rot+3*M_PI_2)/2.0f;
			dy = fPanSpeed*mInputMgr->dt;
		}
		if (mouseRInt && !(mouseLInt && mouseTInt && mouseBInt))
		{
			if (mGUIMgr->cursor->rot == -1.0f)
				mGUIMgr->cursor->rot = 0.0f;
			else
				mGUIMgr->cursor->rot = -M_PI_2/2.0f;
			dx = -fPanSpeed*mInputMgr->dt;
		}
		if (mouseBInt && !(mouseLInt && mouseTInt && mouseRInt))
		{
			if (mGUIMgr->cursor->rot == -1.0f)
				mGUIMgr->cursor->rot = M_PI_2;
			else
				mGUIMgr->cursor->rot = (mGUIMgr->cursor->rot+M_PI_2)/2.0f;
			dy = -fPanSpeed*mInputMgr->dt;
		}
		panning = true;
	}
	else
	{
		if (panning)
		{
			mGUIMgr->cursor = mGUIMgr->switchCursor("normal");
			panning = false;
		}
	}

	gx += dx;
	gy += dy;
	dgx = dx;
	dgy = dy;

	// Detect loss of intersections between screen BBs and the background
	bgRect->x1 = gx;
	bgRect->y1 = gy;
	bgRect->x2 = gx+mZoneMgr->actualZone.w;
	bgRect->y2 = gy+mZoneMgr->actualZone.h;
	screenLInt = bgRect->Intersect(screenLRect);
	screenTInt = bgRect->Intersect(screenTRect);
	screenRInt = bgRect->Intersect(screenRRect);
	screenBInt = bgRect->Intersect(screenBRect);

	// If the background goes away from a screen bounding boxes, discard the previous changes
	if (!screenLInt)
	{
		gx -= dx;
		dx = 0;
	}
	if (!screenTInt)
	{
		gy -= dy;
		dy = 0;
	}
	if (!screenRInt)
	{
		gx -= dx;
		dx = 0;
	}
	if (!screenBInt)
	{
		gy -= dy;
		dy = 0;
	}

	mInputMgr->SetGlobalDisplacement(gx, gy);
}


/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            GFXManager source           */
/*                                        */
/*  ## : This class contains all graphics */
/*  related function and lists.           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_global.h"
#include "wowrl_structs.h"
#include "wowrl_unitmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_zonemanager.h"
#include "wowrl_scenemanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_lua.h"

#include "wowrl_gfxmanager.h"

using namespace std;

extern UnitManager *mUnitMgr;
extern GUIManager *mGUIMgr;
extern ZoneManager *mZoneMgr;
extern SceneManager *mSceneMgr;
extern InputManager *mInputMgr;
extern HGE *hge;

GFXManager::GFXManager()
{
	debugParser = false;
	debugRenderList = false;

	mForceUpdate = true;
}

GFXManager* GFXManager::mGFXMgr = NULL;

GFXManager* GFXManager::getSingleton()
{
	if (mGFXMgr == NULL)
		mGFXMgr = new GFXManager;
	return mGFXMgr;
}

bool GFXManager::parseAnimationsDyn( lua_State *luaVM, int state1, int state2, bool* finished, float filling )
{
	static map<string, Class>::iterator iterC = mUnitMgr->classList.begin();
	static PAnim anim;
	static int anim_nbr = 0;

	if (state1 == 1)
	{
		hge->System_Log("Parsing Tables/animset_table.lua...");
		int error = luaL_dofile(luaVM,"Tables/animset_table.lua");
		if (error) l_logPrint(luaVM);

		lua_getglobal(luaVM, "AnimSets");

		*finished = false;
		return true;
	}
	else
	{
		if (state2 == 0)
		{
			Class* c = &iterC->second;
			if (this->debugParser) hge->System_Log("  Loading %s's animset...", c->name.c_str());
			lua_getfield(luaVM, -1, c->anim_set.c_str());
			c->scale = mlua_getFieldFloat("scale", false, 1.0f);
			c->shadow_scale = mlua_getFieldFloat("shadow_scale", false, 1.0f);
			c->status_bar_size = mlua_getFieldFloat("status_bar_size");
			c->status_bar_y_offset = mlua_getFieldFloat("status_bar_y_offset");

			if (pAnimList.find(c->anim_set) != pAnimList.end())
			{
				lua_pop(luaVM, 1);
				mGUIMgr->mLoadingBar.filling += filling/mUnitMgr->classList.size();
				iterC++;
				if (iterC == mUnitMgr->classList.end())
				{
					hge->System_Log("Parsing Tables/animset_table.lua : done.");
					lua_pop(luaVM, 1);
					*finished = true;
					return true;
				}
				else
				{
					*finished = false;
					return true;
				}
			}

			anim.name = c->anim_set;

			lua_getfield(luaVM, -1, "states");

			anim_nbr = 0;
			for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
			{
				anim_nbr++;
			}

			lua_pushnil(luaVM);

			*finished = false;
			return false;
		}
		else
		{
			if (!lua_next(luaVM, -2))
			{
				pAnimList[iterC->second.anim_set] = anim;
				anim.animation.clear();

				lua_pop(luaVM, 2);

				iterC++;
				if (iterC == mUnitMgr->classList.end())
				{
					hge->System_Log("Parsing Tables/animset_table.lua : done.");
					lua_pop(luaVM, 1);
					*finished = true;
					return true;
				}
				else
				{
					*finished = false;
					return true;
				}
			}

			string a_name = mlua_getFieldString("name");
			if (this->debugParser) hge->System_Log("   Loading state : %s", a_name.c_str());
			bool loop = mlua_getFieldBool("loop", false, true);

			lua_getfield(luaVM, -1, "sub_animations");

			Animation a;
			for (int i=0; i <= 7; i++)
			{
				lua_rawgeti(luaVM, -1, i);
				if (lua_isnil(luaVM, -1))
					mlua_print("Missing subanimation " + toString(i));
				else if (!lua_isstring(luaVM, -1))
					mlua_print("Field is expected to be a string");
				else
				{
					string str = lua_tostring(luaVM, -1);
					a.state[i] = mlua_animList[str];
					if (loop)
						a.state[i]->Play();
					else
					{
						a.state[i]->SetMode(HGEANIM_FWD | HGEANIM_NOLOOP);
						a.state[i]->Play();
					}
				}
				lua_pop(luaVM, 1);
			}

			anim.animation[a_name] = a;

			mGUIMgr->mLoadingBar.filling += (filling/mUnitMgr->classList.size())/anim_nbr;

			lua_pop(luaVM, 2);

			*finished = false;
			return false;
		}
	}
}

void GFXManager::parseEffects( lua_State* luaVM )
{
	hge->System_Log("Parsing Tables/fx_table.lua...");
	int error = luaL_dofile(luaVM, "Tables/fx_table.lua");
	if (error) l_logPrint(luaVM);

	lua_getglobal(luaVM, "Effects");

	for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
	{
		SEffect e;
		e.name = mlua_getFieldString("name");
		e.life = mlua_getFieldFloat("life_duration", false, 0.0f);
		string type = mlua_getFieldString("type");
		e.offset_x = mlua_getFieldFloat("offset_x", false, 0.0f);
		e.offset_y = mlua_getFieldFloat("offset_y", false, 0.0f);
		if (type == "multi_angle_anim")
		{
			e.type = FX_ANIMATED_EFFECT;
			e.afx.type = FX_MULTI_ANGLE_ANIM;
			e.afx.fade_in = mlua_getFieldFloat("fade_in", false, 0.0f);
			e.afx.fade_out = mlua_getFieldFloat("fade_out", false, 0.0f);
			e.afx.scale = mlua_getFieldFloat("scale", false, 1.0f);
			string blend_mode = mlua_getFieldString("blend_mode", false, "");
			bool loop = mlua_getFieldBool("loop", false, true);

			lua_getfield(luaVM, -1, "sub_animations");
			for (int i=0; i <= 7; i++)
			{
				lua_rawgeti(luaVM, -1, i);
				if (lua_isnil(luaVM, -1))
					mlua_print("Missing subanimation " + toString(i));
				else if (!lua_isstring(luaVM, -1))
					mlua_print("Field is expected to be a string");
				else
				{
					string str = lua_tostring(luaVM, -1);
					e.afx.state[i] = mlua_animList[str];
					if (loop)
						e.afx.state[i]->Play();
					else
					{
						e.afx.state[i]->SetMode(HGEANIM_FWD | HGEANIM_NOLOOP);
						e.afx.state[i]->Play();
					}
					if (blend_mode == "add")
						e.afx.state[i]->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHAADD | BLEND_NOZWRITE);
				}
				lua_pop(luaVM, 1);
			}
			lua_pop(luaVM, 1);
		}
		else if (type == "single_angle_anim")
		{
			e.type = FX_ANIMATED_EFFECT;
			e.afx.type = FX_SINGLE_ANGLE_ANIM;
			e.afx.fade_in = mlua_getFieldFloat("fade_in", false, 0.0f);
			e.afx.fade_out = mlua_getFieldFloat("fade_out", false, 0.0f);
			e.afx.scale = mlua_getFieldFloat("scale", false, 1.0f);
			string blend_mode = mlua_getFieldString("blend_mode", false, "");
			bool loop = mlua_getFieldBool("loop", false, true);

			e.afx.anim = mlua_animList[mlua_getFieldString("animation")];
			if (loop)
				e.afx.anim->Play();
			else
			{
				e.afx.anim->SetMode(HGEANIM_FWD | HGEANIM_NOLOOP);
				e.afx.anim->Play();
			}
			if (blend_mode == "add")
				e.afx.anim->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHAADD | BLEND_NOZWRITE);
		}
		else if (type == "psys")
		{
			e.type = FX_PARTICLE_SYSTEM;
			e.pfx.delay = mlua_getFieldFloat("delay", false, 0.0f);
			string blend_mode = mlua_getFieldString("blend_mode", false, "");
			hgeSprite* spr = mlua_spriteList[mlua_getFieldString("sprite")];
			if (blend_mode == "add")
				spr->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHAADD | BLEND_NOZWRITE);
			string file = mlua_getFieldString("file");
			e.pfx.psys = new hgeParticleSystem(file.c_str(), spr);
		}
		else
		{
			hge->System_Log("# Error # : Unknown effect type : \"%s\".", type.c_str());
			continue;
		}

		this->FXList[e.name] = e;
	}

	lua_pop(luaVM, 1);

	hge->System_Log("Parsing Tables/fx_table.lua : done.");
}

void GFXManager::buildRenderList()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->getProfiler(6, "GFXManager::buildRenderList", false);
		Chrono c(prof);
	#endif

	bool debug = false;

	// Update render order every 0.1 sec
	static float timer = 0.0f;
	bool rebuild;

	timer += mInputMgr->dt;
	if (timer >= 0.33f)
	{
		rebuild = true;
		timer = 0.0f;
	}
	else
		rebuild = false;

	if ( (mForceUpdate == true) || (rebuild) )
	{
		debugRenderList = debug;
		zSortedList.clear();
		zSortedUnitList.clear();
		map<string, Unit>::iterator iterUnit;
		for (iterUnit = mUnitMgr->unitList.begin(); iterUnit != mUnitMgr->unitList.end(); iterUnit++)
		{
			Unit *u = &iterUnit->second;
			if (!mSceneMgr->gamePaused)
				u->update();
			else
				u->setBox();
			if (u->getBox()->Intersect(scrRect))
			{
				float z = u->getZ();
				Object obj;
				obj.type = UNIT;
				obj.ptr = u;
				while (this->zSortedList.find(z) != this->zSortedList.end())
				{
					z += 0.01f;
				}
				this->zSortedList[z] = obj;
				this->zSortedUnitList[z] = u;
			}
		}

		map<float, Object> relZList;

		map<string, Doodad>::iterator iterDoodad;
		for (iterDoodad = mZoneMgr->actualZone.doodadList.begin(); iterDoodad != mZoneMgr->actualZone.doodadList.end(); iterDoodad++)
		{
			relZList.clear();
			Doodad *d = &iterDoodad->second;
			if (this->debugRenderList) {hge->System_Log("#Doodad %s :", d->name.c_str());}

			if (d->getBox()->Intersect(scrRect))
			{
				if (d->inTop)
					this->renderInTopList[d->getZ()] = d;
				else
				{
					map<float, Object>::iterator iterZ;
					for (iterZ = this->zSortedList.begin(); iterZ != this->zSortedList.end(); iterZ++)
					{
						// Check every unit or doodad that is in close range
						if (d->intersects(iterZ->second))
						{
							// Get relative Z for each
							float z;
							if (iterZ->second.type == UNIT)
							{
								Unit* tempUnit = static_cast<Unit*>(iterZ->second.ptr);
								if (this->debugRenderList) {hge->System_Log("  %s :", tempUnit->getName().c_str());}
								z = - d->getRelativeDepth(tempUnit->getGPoint());
							}
							else if (iterZ->second.type == DOODAD)
							{
								Doodad* tempDoodad = static_cast<Doodad*>(iterZ->second.ptr);
								if (this->debugRenderList) {hge->System_Log("  %s :", tempDoodad->name.c_str());}
								z = tempDoodad->getRelativeDepth(d->getPoint());
							}

							if (z != 0.0f)
							{
								// A little offset to prevent duplicates
								while (relZList.find(z) != relZList.end())
								{
									z += 0.01f;
								}

								if (this->debugRenderList) {hge->System_Log("   relZ = %f :", z);}

								// ... and store it in a map
								relZList[z] = iterZ->second;
							}
							else
							{
								if (this->debugRenderList) {hge->System_Log("   relZ = 0");}
							}
						}
					}
					float z;
					if (relZList.empty())
					{
						// If the map is empty, then set unit's Z to its global value
						z = d->getZ();
						// ...and add little offset if needed to prevent duplicates
						while (this->zSortedList.find(z) != this->zSortedList.end())
						{
							z += 0.01f;
						}

						if (this->debugRenderList) {hge->System_Log(" relZ is empty : z = %f", z);}
					}
					else
					{
						if (relZList.size() == 1)
						{
							// Else if there is only one object in range, set unit's Z to the
							// object's + the relative Z.
							if (relZList.begin()->second.type == UNIT)
							{
								Unit* tempUnit = static_cast<Unit*>(relZList.begin()->second.ptr);
								if (relZList.begin()->first >= 0.0f)
								{
									if (d->getZ() >= tempUnit->getZ())
										z = d->getZ();
									else
										z = tempUnit->getRZ()+0.01f;
								}
								else if (relZList.begin()->first < 0.0f)
								{
									if (d->getZ() < tempUnit->getZ())
										z = d->getZ();
									else
										z = tempUnit->getRZ()-0.01f;
								}
								if (this->debugRenderList) {hge->System_Log(" relZ contains only one object (%s) : z = %f", tempUnit->getName().c_str(), z);}
							}
							else if (relZList.begin()->second.type == DOODAD)
							{
								Doodad* tempDoodad = static_cast<Doodad*>(relZList.begin()->second.ptr);
								if (relZList.begin()->first >= 0.0f)
								{
									if (d->getZ() >= tempDoodad->getZ())
										z = d->getZ();
									else
										z = tempDoodad->getZ()+0.01f;
								}
								else if (relZList.begin()->first < 0.0f)
								{
									if (d->getZ() < tempDoodad->getZ())
										z = d->getZ();
									else
										z = tempDoodad->getZ()-0.01f;
								}
								if (this->debugRenderList) {hge->System_Log(" relZ contains only one object (%s) : z = %f", tempDoodad->name.c_str(), z);}
							}
						}
						else if (relZList.size() > 1)
						{
							// And if there is more than two objects...
							float z1, z2;
							map<float, Object>::iterator iter0, iter1, iter2, iter3;

							// We get the two objects with the highest and lowest Z value
							float bestZ, worstZ;
							iter0 = relZList.begin();
							if (iter0->second.type == UNIT)
								bestZ = worstZ = static_cast<Unit*>(iter0->second.ptr)->getZ();
							else if (iter0->second.type == DOODAD)
								bestZ = worstZ = static_cast<Doodad*>(iter0->second.ptr)->getZ();
							iter1 = iter2 = iter0;
							for (iter0 = relZList.begin(); iter0 != relZList.end(); iter0++)
							{
								float z;
								if (iter0->second.type == UNIT)
									z = static_cast<Unit*>(iter0->second.ptr)->getZ();
								else if (iter0->second.type == DOODAD)
									z = static_cast<Doodad*>(iter0->second.ptr)->getZ();

								if (z < worstZ)
								{
									worstZ = z;
									iter1 = iter0;
								}
								if (z > bestZ)
								{
									bestZ = z;
									iter2 = iter0;
								}
							}

							iter3 = relZList.upper_bound(0.0f);
							if (this->debugRenderList) {hge->System_Log(" relZ contains more than one object :");}

							if (iter1->first <= 0.0f)
							{
								// There is no positive Z value, set Z to the nearest from zero + relZ
								if (this->debugRenderList) {hge->System_Log("  none of them have a positive relZ,");}
								if (iter1->second.type == UNIT)
								{
									Unit* tempUnit = static_cast<Unit*>(iter1->second.ptr);
									z = tempUnit->getZ()+iter1->first;
									if (this->debugRenderList) {hge->System_Log(" take the latest object (%s) : z = %f+%f = %f", tempUnit->getName().c_str(), tempUnit->getZ(), iter1->first, z);}
								}
								else if (iter1->second.type == DOODAD)
								{
									Doodad* tempDoodad = static_cast<Doodad*>(iter1->second.ptr);
									z = tempDoodad->getZ()+iter1->first*0.01f;
									if (this->debugRenderList) {hge->System_Log(" take the latest object (%s) : z = %f+%f = %f", tempDoodad->name.c_str(), tempDoodad->getZ(), iter1->first*0.01f, z);}
								}
							}
							else if (iter2->first >= 0.0f)
							{
								if (this->debugRenderList) {hge->System_Log(" none of them have a negative relZ");}
								// There is no negative Z value, set Z to the nearest from zero + relZ
								if (iter2->second.type == UNIT)
								{
									Unit* tempUnit = static_cast<Unit*>(iter2->second.ptr);
									z = tempUnit->getZ()+iter2->first;
									if (this->debugRenderList) {hge->System_Log(" take the first object (%s) : z = %f+%f = %f", tempUnit->getName().c_str(), tempUnit->getZ(), iter2->first, z);}
								}
								else if (iter2->second.type == DOODAD)
								{
									Doodad* tempDoodad = static_cast<Doodad*>(iter2->second.ptr);
									z = tempDoodad->getZ()+iter2->first*0.01f;
									if (this->debugRenderList) {hge->System_Log(" take the first object (%s) : z = %f+%f = %f", tempDoodad->name.c_str(), tempDoodad->getZ(), iter2->first*0.01f, z);}
								}
							}
							else
							{
								if (this->debugRenderList) {hge->System_Log(" there are positive and negative relZ");}
								// Else get the average of the two closest from 0
								if (iter3->second.type == UNIT)
								{
									Unit* tempUnit = static_cast<Unit*>(iter3->second.ptr);
									z1 = tempUnit->getZ();
									if (this->debugRenderList) {hge->System_Log("  take the nearest from 0 (%s) : z1 = %f", tempUnit->getName().c_str(), z1);}
								}
								else if (iter3->second.type == DOODAD)
								{
									Doodad* tempDoodad = static_cast<Doodad*>(iter3->second.ptr);
									z1 = tempDoodad->getZ();
									if (this->debugRenderList) {hge->System_Log("  take the nearest from 0 (%s) : z1 = %f", tempDoodad->name.c_str(), z1);}
								}
								iter3--;
								if (iter3->second.type == UNIT)
								{
									Unit* tempUnit = static_cast<Unit*>(iter3->second.ptr);
									z2 = tempUnit->getZ();
									if (this->debugRenderList) {hge->System_Log("  and the one just before (%s) : z2 = %f", tempUnit->getName().c_str(), z2);}
								}
								else if (iter3->second.type == DOODAD)
								{
									Doodad* tempDoodad = static_cast<Doodad*>(iter3->second.ptr);
									z2 = tempDoodad->getZ();
									if (this->debugRenderList) {hge->System_Log("  and the one just before (%s) : z2 = %f", tempDoodad->name.c_str(), z2);}
								}
								z = (z1+z2)/2;
								if (this->debugRenderList) {hge->System_Log(" and get the average between those two : z = %f", z);}
							}
						}
					}
					Object obj;
					obj.type = DOODAD;
					obj.ptr = d;
					// A little offset to prevent duplicates
					while (this->zSortedList.find(z) != this->zSortedList.end())
					{
						z += 0.01f;
					}
					if (this->debugRenderList) {hge->System_Log(" %s : z = %f", d->name.c_str(), z);}
					this->zSortedList[z] = obj;
				}
			}
		}
	}
	else if (!mSceneMgr->gamePaused)
	{
		// Just update all units.
		map<string, Unit>::iterator iterUnit;
		for (iterUnit = mUnitMgr->unitList.begin(); iterUnit != mUnitMgr->unitList.end(); iterUnit++)
		{
			iterUnit->second.update();
		}
	}
	mForceUpdate = false;
}

void GFXManager::forceUpdate()
{
	mForceUpdate = true;
}

HTEXTURE GFXManager::loadTexture( string file, bool mipmaps )
{
	if (textureList.find(file) != textureList.end())
	{
	  	return textureList[file];
	}
	else
	{
		if (file == "") {hge->System_Log("# Error # : can't load texture : missing file name");}
		else
		{
			textureList[file] = hge->Texture_Load(file.c_str(), 0, mipmaps);
			return textureList[file];
		}
	}
}

void GFXManager::freeTextures()
{
	map<string, HTEXTURE>::iterator iterTex;
	for (iterTex = this->textureList.begin(); iterTex != this->textureList.end(); iterTex++)
	{
		hge->Texture_Free(iterTex->second);
	}
}

hgeSprite* GFXManager::createSprite( HTEXTURE tex, float x, float y, float w, float h, bool GUI )
{
	hgeSprite* spr = new hgeSprite(tex, x, y, w, h);
	if (GUI)
		mGUIMgr->GUIspriteList.push_back(spr);
	else
		spriteList.push_back(spr);
	return spr;
}

hgeSprite* GFXManager::createSprite( hgeSprite* base, bool GUI )
{
	hgeSprite* spr = new hgeSprite(*base);
	if (GUI)
		mGUIMgr->GUIspriteList.push_back(spr);
	else
		spriteList.push_back(spr);
	return spr;
}

void GFXManager::deleteSprites()
{
	vector<hgeSprite*>::iterator iter;
	while (!spriteList.empty())
	{
		iter = spriteList.begin();
		delete *iter;
		spriteList.erase(iter);
	}

	hge->Target_Free(mGFXMgr->tMainTarget);
	delete mGFXMgr->sprMainSprite;
	mGFXMgr->sprMainSprite = NULL;
}

hgeAnimation* GFXManager::createAnimation( HTEXTURE tex, int frames, float fps, float x, float y, float w, float h )
{
	hgeAnimation* anim = new hgeAnimation(tex, frames, fps, x, y, w, h);
	animList.push_back(anim);
	return anim;
}

void GFXManager::deleteAnimations()
{
	vector<hgeAnimation*>::iterator iter;
	while (!animList.empty())
	{
		iter = animList.begin();
		delete *iter;
		animList.erase(iter);
	}
}

hgeRect* GFXManager::createRect( float x1, float y1, float x2, float y2 )
{
	hgeRect* rect = new hgeRect(x1, y1, x2, y2);
	rectList.push_back(rect);
	return rect;
}

void GFXManager::deleteRects()
{
	vector<hgeRect*>::iterator iter;
	while (!rectList.empty())
	{
		iter = rectList.begin();
		delete *iter;
		rectList.erase(iter);
	}
}

hgeParticleSystem* GFXManager::createPSys( string file, hgeSprite* spr )
{
	hgeParticleSystem* psys = new hgeParticleSystem(file.c_str(), spr);
	psysList.push_back(psys);
	return psys;
}

void GFXManager::deletePSys()
{
	vector<hgeParticleSystem*>::iterator iter;
	while (!psysList.empty())
	{
		iter = psysList.begin();
		delete *iter;
		psysList.erase(iter);
	}
}

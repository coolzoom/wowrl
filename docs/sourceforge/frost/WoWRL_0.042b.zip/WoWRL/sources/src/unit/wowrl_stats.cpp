/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Stats source              */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Stats class.                   */
/*       Stats are a set of attributes    */
/*  that are given to a unit.             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_stats.h"

void Stats::clear()
{
	armor = 0;
	health = 0;
	mana = 0;
	power_type = 0;
	stamina = 0;
	intellect = 0;
	agility = 0;
	spirit = 0;
	strengh = 0;
	block = 0;

	resist_all = 0;
	resist_frost = 0;
	resist_fire = 0;
	resist_nature = 0;
	resist_shadow = 0;
	resist_arcane = 0;

	spell_power = 0;
	attack_power = 0;
	regen_5s_health = 0;
	regen_5s_mana = 0;
	crit = 0;
	crit_spell = 0;
	hit = 0;
	penetration = 0;
}

Stats Stats::operator+ (Stats s1)
{
	Stats s;
	s.armor = armor + s1.armor;
	if (s.armor < 0) s.armor = 0;
	s.health = health + s1.health;
	if (s.health < 1) s.health = 1;
	if (s.power_type == s1.power_type)
	{
		s.mana = mana + s1.mana;
		if (s.mana < 1) s.mana = 1;
	}
	s.stamina = stamina + s1.stamina;
	if (s.stamina < 0) s.stamina = 0;
	s.intellect = intellect + s1.intellect;
	if (s.intellect < 0) s.intellect = 0;
	s.agility = agility + s1.agility;
	if (s.agility < 0) s.agility = 0;
	s.spirit = spirit + s1.spirit;
	if (s.spirit < 0) s.spirit = 0;
	s.strengh = strengh + s1.strengh;
	if (s.strengh < 0) s.strengh = 0;
	s.block = block + s1.block;
	if (s.block < 0) s.block = 0;

	s.resist_all = resist_all + s1.resist_all;
	if (s.resist_all < 0) s.resist_all = 0;
	s.resist_frost = resist_frost + s1.resist_frost;
	if (s.resist_frost < 0) s.resist_frost = 0;
	s.resist_fire = resist_fire + s1.resist_fire;
	if (s.resist_fire < 0) s.resist_fire = 0;
	s.resist_nature = resist_nature + s1.resist_nature;
	if (s.resist_nature < 0) s.resist_nature = 0;
	s.resist_shadow = resist_shadow + s1.resist_shadow;
	if (s.resist_shadow < 0) s.resist_shadow = 0;
	s.resist_arcane = resist_arcane + s1.resist_arcane;
	if (s.resist_arcane < 0) s.resist_arcane = 0;

	s.spell_power = spell_power + s1.spell_power;
	if (s.spell_power < 0) s.spell_power = 0;
	s.attack_power = attack_power + s1.attack_power;
	if (s.attack_power < 0) s.attack_power = 0;
	s.regen_5s_health = regen_5s_health + s1.regen_5s_health;
	if (s.regen_5s_health < 0) s.regen_5s_health = 0;
	s.regen_5s_mana = regen_5s_mana + s1.regen_5s_mana;
	if (s.regen_5s_mana < 0) s.regen_5s_mana = 0;
	s.crit = crit + s1.crit;
	if (s.crit < 0) s.crit = 0;
	s.crit_spell = crit_spell + s1.crit_spell;
	if (s.crit_spell < 0) s.crit_spell = 0;
	s.hit = hit + s1.hit;
	if (s.hit < 0) s.hit = 0;
	s.penetration = penetration + s1.penetration;
	if (s.penetration < 0) s.penetration = 0;

	return s;
}

Stats Stats::operator- (Stats s1)
{
	Stats s;
	s.armor = armor - s1.armor;
	if (s.armor < 0) s.armor = 0;
	s.health = health - s1.health;
	if (s.health < 1) s.health = 1;
	if (s.power_type == s1.power_type)
	{
		s.mana = mana - s1.mana;
		if (s.mana < 1) s.mana = 1;
	}
	s.stamina = stamina - s1.stamina;
	if (s.stamina < 0) s.stamina = 0;
	s.intellect = intellect - s1.intellect;
	if (s.intellect < 0) s.intellect = 0;
	s.agility = agility - s1.agility;
	if (s.agility < 0) s.agility = 0;
	s.spirit = spirit - s1.spirit;
	if (s.spirit < 0) s.spirit = 0;
	s.strengh = strengh - s1.strengh;
	if (s.strengh < 0) s.strengh = 0;
	s.block = block - s1.block;
	if (s.block < 0) s.block = 0;

	s.resist_all = resist_all - s1.resist_all;
	if (s.resist_all < 0) s.resist_all = 0;
	s.resist_frost = resist_frost - s1.resist_frost;
	if (s.resist_frost < 0) s.resist_frost = 0;
	s.resist_fire = resist_fire - s1.resist_fire;
	if (s.resist_fire < 0) s.resist_fire = 0;
	s.resist_nature = resist_nature - s1.resist_nature;
	if (s.resist_nature < 0) s.resist_nature = 0;
	s.resist_shadow = resist_shadow - s1.resist_shadow;
	if (s.resist_shadow < 0) s.resist_shadow = 0;
	s.resist_arcane = resist_arcane - s1.resist_arcane;
	if (s.resist_arcane < 0) s.resist_arcane = 0;

	s.spell_power = spell_power - s1.spell_power;
	if (s.spell_power < 0) s.spell_power = 0;
	s.attack_power = attack_power - s1.attack_power;
	if (s.attack_power < 0) s.attack_power = 0;
	s.regen_5s_health = regen_5s_health - s1.regen_5s_health;
	if (s.regen_5s_health < 0) s.regen_5s_health = 0;
	s.regen_5s_mana = regen_5s_mana - s1.regen_5s_mana;
	if (s.regen_5s_mana < 0) s.regen_5s_mana = 0;
	s.crit = crit - s1.crit;
	if (s.crit < 0) s.crit = 0;
	s.crit_spell = crit_spell - s1.crit_spell;
	if (s.crit_spell < 0) s.crit_spell = 0;
	s.hit = hit - s1.hit;
	if (s.hit < 0) s.hit = 0;
	s.penetration = penetration - s1.penetration;
	if (s.penetration < 0) s.penetration = 0;
}

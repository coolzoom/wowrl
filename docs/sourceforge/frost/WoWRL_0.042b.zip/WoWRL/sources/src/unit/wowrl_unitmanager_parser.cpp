/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_scenemanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_structs.h"
#include "wowrl_lua.h"

#include "wowrl_unitmanager.h"

using namespace std;

extern SceneManager *mSceneMgr;
extern GUIManager *mGUIMgr;
extern TimeManager *mTimeMgr;
extern GFXManager *mGFXMgr;
extern HGE *hge;

Spell* UnitManager::parseSpell( lua_State* luaVM, string spell_name, bool regLUA = false )
{
	Spell s = spellList[spell_name];

	if (regLUA || !s.loaded)
	{
		if (debugParser && !regLUA) hge->System_Log(" Parsing %s...", spell_name.c_str());

		lua_getglobal(luaVM, "Spells");
		lua_getfield(luaVM, -1, spell_name.c_str());

		s.name = spell_name;
		mlua_setFieldString("name", spell_name.c_str(), luaVM);
		s.display_name = mlua_getFieldString("display_name", true, "", false, luaVM);
		s.description = mlua_getFieldString("description", true, "", false, luaVM);
		s.rank = mlua_getFieldInt("rank", false, -1, true, luaVM);
		s.cast_time = mlua_getFieldFloat("cast_time", false, -1.0f, true, luaVM);
		s.crits = mlua_getFieldFloat("crits", false, 0.0f, true, luaVM);
		s.cost = mlua_getFieldInt("cost", false, 0, true, luaVM);
		s.costp = mlua_getFieldFloat("cost_percent", false, 0.0f, true, luaVM);
		s.cost_type = mlua_getFieldString("cost_type", false, "", true, luaVM);
		if ( s.cost_type != "mana" && s.cost_type != "rage" && s.cost_type != "energy" && (s.cost_type == "" && (s.cost != 0.0f || s.costp != 0.0f)) )
			hge->System_Log("# Error # : wrong cost_type value in %s's (possible values : mana, rage, energy or blank if cost is nul).", spell_name.c_str());
		s.range = mlua_getFieldFloat("range", false, 5.0f, true, luaVM);
		s.self_only = mlua_getFieldBool("self_only", false, false, true, luaVM);
		s.in_combat = mlua_getFieldBool("usable_in_combat", false, true, true, luaVM);
		s.puts_in_combat = mlua_getFieldBool("puts_in_combat", false, true, true, luaVM);
		s.loop = mlua_getFieldBool("loop", false, true, true, luaVM);
		s.school = mlua_getFieldInt("school", false, SPELL_SCHOOL_NONE, true, luaVM);

		s.cast_effect = mlua_getFieldString("cast_effect", false, "", true, luaVM);
		if (s.cast_effect == "")
			s.cast_fx = false;
		else
			s.cast_fx = true;
		s.attack_effect = mlua_getFieldString("attack_effect", false, "", true, luaVM);
		if (s.attack_effect == "")
			s.attack_fx = false;
		else
			s.attack_fx = true;
		string icon_file = mlua_getFieldString("icon", false, "Icons/INV_Misc_QuestionMark.png", true, luaVM);
		s.iconPath = icon_file;
		s.icon = mGFXMgr->createSprite
		(
			mGFXMgr->loadTexture(icon_file, true),
			0, 0, 64, 64, true
		);

		s.proj = mlua_getFieldBool("projectile", false, false, true, luaVM);
		if (s.proj)
			s.proj_speed = mlua_getFieldFloat("projectile_speed", false, 600.0f, true, luaVM);

		s.channeled = mlua_getFieldBool("channeled", false, false, true, luaVM);

		string target = mlua_getFieldString("target", false, "all", true, luaVM);

		if (target == "hostiles")
			s.target = SPELL_TARGET_HOSTILES;
		else if (target == "all")
			s.target = SPELL_TARGET_ALL;
		else if (target == "friends")
			s.target = SPELL_TARGET_FRIENDS;
		else if (target == "deads")
			s.target = SPELL_TARGET_DEADS;
		else if (target == "dead_friends")
			s.target = SPELL_TARGET_DEAD_FRIENDS;
		else if (target == "dead_hostiles")
			s.target = SPELL_TARGET_DEAD_HOSTILES;
		else
		{
			s.target = SPELL_TARGET_HOSTILES;
			hge->System_Log("# Error # : unknown target value \"%s\" in %s.", target.c_str(), spell_name.c_str());
		}

		s.dmg_min = mlua_getFieldInt("damage_min", false, 0, true, luaVM);
		if (s.dmg_min<0) {hge->System_Log("# Warning # : %s's damage_min parameter can't be negative.", spell_name.c_str()); s.dmg_min = 0;}
		s.dmg_max = mlua_getFieldInt("damage_max", false, s.dmg_min, true, luaVM);
		if (s.dmg_max<0) {hge->System_Log("# Warning # : %s's damage_max parameter can't be negative.", spell_name.c_str()); s.dmg_max = 0;}
		if (s.dmg_max<s.dmg_min) {hge->System_Log("# Warning # : %s's damage_max parameter can't be smaller than damage_min.", spell_name.c_str()); s.dmg_max = s.dmg_min;}

		s.heal_min = mlua_getFieldInt("heal_min", false, 0, true, luaVM);
		if (s.heal_min<0) {hge->System_Log("# Warning # : %s's heal_min parameter can't be negative.", spell_name.c_str()); s.heal_min = 0;}
		s.heal_max = mlua_getFieldInt("heal_max", false, s.heal_min, true, luaVM);
		if (s.heal_max<0) {hge->System_Log("# Warning # : %s's heal_max parameter can't be negative.", spell_name.c_str()); s.heal_max = 0;}
		if (s.heal_max<s.heal_min) {hge->System_Log("# Warning # : %s's heal_max parameter can't be smaller than damage_min.", spell_name.c_str()); s.heal_max = s.heal_min;}

		s.health_recovered = mlua_getFieldInt("health_recovered", false, 1, true, luaVM);
		if (s.health_recovered<1) {hge->System_Log("# Warning # : %s's health_recovered parameter can't be smaller than 1.", spell_name.c_str()); s.health_recovered = 1;}
		s.mana_recovered = mlua_getFieldInt("mana_recovered", false, 0, true, luaVM);
		if (s.mana_recovered<0) {hge->System_Log("# Warning # : %s's mana_recovered parameter can't be negative.", spell_name.c_str()); s.mana_recovered = 0;}

		string buff = mlua_getFieldString("buff", false, "", true, luaVM);
		if (buff != "")
			s.buff = parseBuff(luaVM, buff);
		else
			s.buff = NULL;

		lua_getfield(luaVM, -1, "scripts");

		s.OnCastBegin = mlua_getFieldString("OnCastBegin", false, "", true, luaVM);
		s.OnCasted = mlua_getFieldString("OnCasted", false, "", true, luaVM);
		s.OnImpact = mlua_getFieldString("OnImpact", false, "", true, luaVM);
		s.OnUpdate = mlua_getFieldString("OnUpdate", false, "", true, luaVM);

		lua_pop(luaVM, 3);

		spellList[spell_name] = s;

		s.loaded = true;
	}

	return &spellList[spell_name];
}

SBuff* UnitManager::parseBuff( lua_State* luaVM, string buff_name )
{
	if (buffList[buff_name].name == "")
	{
		if (debugParser) hge->System_Log(" Parsing %s...", buff_name.c_str());

		lua_getglobal(luaVM, "Buffs");
		lua_getfield(luaVM, -1, buff_name.c_str());

		SBuff b;
		b.name = buff_name;
		b.display_name = mlua_getFieldString("display_name");
		b.description = mlua_getFieldString("description");
		b.duration = mlua_getFieldFloat("duration", false, -1.0f);
		b.max_count = mlua_getFieldInt("max_count", false, 50);

		b.icon_file = mlua_getFieldString("icon", false, "Icons/INV_Misc_QuestionMark.png");
		b.icon = mGFXMgr->createSprite
		(
			mGFXMgr->loadTexture(b.icon_file, true),
			0, 0, 64, 64
		);

		lua_pop(luaVM, 2);

		buffList[buff_name] = b;
	}

	return &buffList[buff_name];
}

bool UnitManager::parseClassesDyn( lua_State* luaVM, int state1, bool* finished, float filling )
{
	static int class_nbr = 0;

	if (state1 == 1)
	{
		hge->System_Log("Parsing Tables/buff_table.lua...");
		int error = luaL_dofile(mSceneMgr->luaVM, "Tables/buff_table.lua");
		if (error) l_logPrint(mSceneMgr->luaVM);
		hge->System_Log("Parsing Tables/buff_table.lua : done.");
		hge->System_Log("Parsing Tables/spell_scripts_table.lua...");
		error = luaL_dofile(mSceneMgr->luaVM, "Tables/spell_scripts_table.lua");
		if (error) l_logPrint(mSceneMgr->luaVM);
		hge->System_Log("Parsing Tables/spell_scripts_table.lua : done.");
		hge->System_Log("Parsing Tables/spell_table.lua...");
		error = luaL_dofile(mSceneMgr->luaVM, "Tables/spell_table.lua");
		if (error) l_logPrint(mSceneMgr->luaVM);
		hge->System_Log("Parsing Tables/spell_table.lua : done.");
		hge->System_Log("Parsing Tables/item_table.lua...");
		error = luaL_dofile(mSceneMgr->luaVM, "Tables/item_table.lua");
		if (error) l_logPrint(mSceneMgr->luaVM);
		hge->System_Log("Parsing Tables/item_table.lua : done.");
		hge->System_Log("Parsing Tables/class_table.lua...");
		error = luaL_dofile(luaVM, "Tables/class_table.lua");
		if (error) l_logPrint(luaVM);
		int n = lua_gettop(luaVM);
		lua_getglobal(luaVM, "Classes");

		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			class_nbr++;
		}

		lua_pushnil(luaVM);
		*finished = false;
		n = lua_gettop(luaVM);
		return true;
	}
	else if (state1 == 2)
	{
		if (!lua_next(luaVM, -2))
		{
			*finished = false;
			return true;
		}

		Class c;

		c.name = mlua_getFieldString("name");
		c.display_name = mlua_getFieldString("display_name");
		c.id = mlua_getFieldInt("id");
		string icon_file = mlua_getFieldString("icon", false, "Icons/INV_Misc_QuestionMark.png");
		c.icon = mGFXMgr->createSprite(mGFXMgr->loadTexture(icon_file, true), 0, 0, 64, 64);
		c.anim_set = mlua_getFieldString("animset");
		c.health_gained_per_spirit = mlua_getFieldFloat("health_gained_per_spirit", false, 0.0f);
		c.health_gained_per_tick = mlua_getFieldFloat("health_gained_per_tick", false, 0.0f);
		c.mana_gained_per_spirit = mlua_getFieldFloat("mana_gained_per_spirit", false, 0.0f);
		c.mana_gained_per_tick = mlua_getFieldFloat("mana_gained_per_tick", false, 0.0f);
		c.power_type = mlua_getFieldInt("power_type", false, 5);
		c.regen_health_in_combat = mlua_getFieldFloat("regen_health_in_combat", false, 0.0f);
		c.regen_mana_in_combat = mlua_getFieldFloat("regen_mana_in_combat", false, 0.0f);

		lua_getfield(luaVM, -1, "spells");
		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			if (!lua_isnil(luaVM, -1))
			{
				CSpell cs;
				string spell_name = mlua_getFieldString("name");
				cs.spell = parseSpell(luaVM, spell_name);
				cs.cost = mlua_getFieldInt("cost", false, 0);
				cs.lvl = mlua_getFieldInt("available_at_lvl", false, 1);
				c.spell[spell_name] = cs;
			}
		}
		lua_pop(luaVM, 1);

		lua_getfield(luaVM, -1, "talent_trees");
		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			if (!lua_isnil(luaVM, -1))
			{
				Specialisation s;
				s.name = mlua_getFieldString("name");
				s.displayName = mlua_getFieldString("display_name");
				s.role = mlua_getFieldString("role");
				s.defaultSpell = &spellList[mlua_getFieldString("default_spell")];
				c.spec[s.name] = s;
			}
		}
		lua_pop(luaVM, 1);

		classList[c.name] = c;
		classList[c.name].defaultSpec = &classList[c.name].spec[mlua_getFieldString("default_spec")];

		mGUIMgr->mLoadingBar.filling += filling/class_nbr;

		lua_pop(luaVM, 1);
		*finished = false;
		return false;
	}
	else
	{
		lua_pop(luaVM, 1);
		hge->System_Log("Parsing Tables/class_table.lua : done.");
		*finished = true;
		return true;
	}
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           UnitManager source           */
/*                                        */
/*  ## : A class that takes care of       */
/*  units, including movement and various */
/*  updates.                              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_global.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_structs.h"
#include "wowrl_lua.h"
#include "wowrl_projectile.h"

#include "wowrl_unitmanager.h"

using namespace std;

extern TimeManager *mTimeMgr;
extern GFXManager *mGFXMgr;
extern HGE *hge;

UnitManager::UnitManager()
{
	debugParser = false;
	castingSpell = false;
	orderGiven = false;
	selected = false;
	castable = false;

	pSpeed = 150.0f;

	leadingUnit = NULL;
	newOvering = NULL;
	lastOvering = NULL;
	castedButton = NULL;
	casterUnit = NULL;
	targetUnit = NULL;
}

UnitManager* UnitManager::mUnitMgr = NULL;

UnitManager* UnitManager::getSingleton()
{
	if (mUnitMgr == NULL)
		mUnitMgr = new UnitManager;
	return mUnitMgr;
}

void UnitManager::createProjectile( Spell* spell, Unit* target, Unit* origin )
{
	string oname = origin->getName();
	if (projectileList.find(oname) == projectileList.end())
	{
		projectileList[oname] = Projectile(spell, target, origin);
	}
	string fxname = spell->attack_effect;
	projectileList[oname].getPSys()->MoveTo(
		origin->getX()+mGFXMgr->FXList[fxname].offset_x,
		origin->getY()+mGFXMgr->FXList[fxname].offset_y
	);
	projectileList[oname].getPSys()->Stop(true);
	projectileList[oname].getPSys()->Fire();
}

void UnitManager::deleteUnits()
{
	map<string, Unit>::iterator iterUnit;
	for (iterUnit = this->unitList.begin(); iterUnit != this->unitList.end(); iterUnit++)
	{
		iterUnit->second.deleteSelf();
	}
	this->unitList.clear();
}

Unit* UnitManager::createUnit( string name, float x, float y, int lvl, Class* c, float speed )
{
	if (unitList.find(name) != unitList.end())
	{
		hge->System_Log("# Warning # : A unit with the name %s already exists, returning pointer.", name.c_str());
	}
	else
	{
		unitList[name] = Unit(name, x, y, lvl, c, speed);
		unitList[name].setAnimation();
		unitList[name].setBox();
		unitList[name].setStandBox();
		unitList[name].initAB();
	}
	return &unitList[name];
}

Unit* UnitManager::getUnitByName( string name )
{
	if (unitList.find(name) != unitList.end())
	{
		Unit *u = &unitList[name];
		return u;
	}
	else
	{
		return NULL;
	}
}

void UnitManager::deselectAll()
{
	map<string, Unit>::iterator iter;
	for (iter=unitList.begin(); iter !=unitList.end(); iter++)
	{
		iter->second.setSelected(false);
	}
}

Class* UnitManager::getClass( string name )
{
	if (classList.find(name) != classList.end())
	{
		Class *c = &classList[name];
		return c;
	}
	else
	{
		hge->System_Log("# ERROR # : No class found with the name %s", name.c_str());
	}
}

int UnitManager::getBaseHealth( int lvl, Class* c )
{
	string s = c->name + "_" + toString(lvl);
	return toInt(lvl_healthTable->GetString(s.c_str()));
}

int UnitManager::getBaseMana( int lvl, Class* c )
{
	string s = c->name + "_" + toString(lvl);
	return toInt(lvl_manaTable->GetString(s.c_str()));
}

int UnitManager::getXPNeeded( int lvl )
{
	string s = "xp_" + toString(lvl);
	return toInt(lvl_healthTable->GetString(s.c_str()));
}


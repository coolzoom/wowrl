/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               Main source              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_scenemanager.h"
#include "wowrl_fontmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_unitmanager.h"
#include "wowrl_zonemanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_unit.h"
#include "wowrl_projectile.h"
#include "wowrl_point.h"
#include "wowrl_global.h"
#include "wowrl_pathfinding.h"
#include "wowrl_collision.h"
#include "wowrl_distortion.h"
#include "wowrl_doodad.h"
#include "wowrl_statusbar.h"
#include "wowrl_structs.h"
#include "wowrl_lua.h"
#include "wowrl_effect.h"
#include "wowrl_gui.h"

#include <math.h>
#include <string>

using namespace std;

// Global variables
HGE *hge = 0;
SceneManager*   mSceneMgr;
FontManager*    mFontMgr;
GUIManager*     mGUIMgr;
TimeManager*    mTimeMgr;
UnitManager*    mUnitMgr;
ZoneManager*    mZoneMgr;
GFXManager*     mGFXMgr;
InputManager*   mInputMgr;

float timerAlpha;

// Function called by HGE once per frame.
bool FrameFunc()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->getProfiler(8, "FrameFunc", false);
		Chrono c(prof);
	#endif

	if (mInputMgr->shiftPressed)
	{
		if (mInputMgr->KeyIsPressed(HGEK_ESCAPE, true))
			return true;
	}
	else
	{
		if (mInputMgr->KeyIsPressed(HGEK_ESCAPE))
			return true;
	}

	switch (mSceneMgr->gameState)
	{
/********************************/
		case GAME:
/********************************/
		{
			#ifdef PROFILE
				Profiler* prof1 = mTimeMgr->getProfiler(8, "FrameFunc - Inputs", false);
				Chrono c1(prof1);
			#endif

			// Get keys, mouse events, delta time...
			mInputMgr->Update();

			// Update the view
			mSceneMgr->Update();

			if (mInputMgr->KeyIsPressed(HGEK_DELETE))
			{
				// Kill selected
				if (mUnitMgr->selected)
				{
					map<string, Unit*>::iterator iter;
					while (mUnitMgr->selectedList.empty() == false)
					{
						iter = mUnitMgr->selectedList.begin();
						iter->second->die();
					}
					mUnitMgr->selected = false;
				}
			}

			static bool spawned = false;
			static int uNbr=0;

			if (mInputMgr->KeyIsPressed(HGEK_NUMPAD1))
			{
				// Spawn a mage
				if (!spawned)
				{
					uNbr++;
					Unit* u = mUnitMgr->createUnit(
						"Player"+toString(uNbr),
						mInputMgr->gmx, mInputMgr->gmy,
						hge->Random_Int(1,70),
						mUnitMgr->getClass("mage"),
						mUnitMgr->pSpeed
					);
					mGFXMgr->forceUpdate();
					spawned = true;
				}
			}
			else
				spawned = false;

			if (mInputMgr->KeyIsPressed(HGEK_NUMPAD2))
			{
				// Spawn a hunter
				if (!spawned)
				{
					uNbr++;
					Unit* u = mUnitMgr->createUnit(
						"Player"+toString(uNbr),
						mInputMgr->gmx, mInputMgr->gmy,
						hge->Random_Int(1,70),
						mUnitMgr->getClass("hunter"),
						mUnitMgr->pSpeed
					);
					mGFXMgr->forceUpdate();
					spawned = true;
				}
			}
			else
				spawned = false;

			if (mInputMgr->KeyIsPressed(HGEK_NUMPAD3))
			{
				// Spawn a priest
				if (!spawned)
				{
					uNbr++;
					Unit* u = mUnitMgr->createUnit(
						"Player"+toString(uNbr),
						mInputMgr->gmx, mInputMgr->gmy,
						hge->Random_Int(1,70),
						mUnitMgr->getClass("priest"),
						mUnitMgr->pSpeed
					);
					mGFXMgr->forceUpdate();
					spawned = true;
				}
			}
			else
				spawned = false;

			if (mInputMgr->KeyIsPressed(HGEK_C))
			{
				if (mUnitMgr->selected)
				{
					map<string, Unit*>::iterator iter;
					for (iter = mUnitMgr->selectedList.begin(); iter != mUnitMgr->selectedList.end(); iter++)
					{
						if (!iter->second->isDead())
							iter->second->setInCombat();
					}
				}
			}

			if (mInputMgr->KeyIsPressed(HGEK_T))
			{
				int error = luaL_dofile(mSceneMgr->luaVM, "Scripts/test.lua");
				if (error) l_logPrint(mSceneMgr->luaVM);
			}

			if (mInputMgr->KeyIsPressed(HGEK_PAUSE))
				mSceneMgr->gamePaused = !mSceneMgr->gamePaused;

			if (mInputMgr->KeyIsPressed(HGEK_H))
			{
				if (mUnitMgr->selected)
				{
					map<string, Unit*>::iterator iter;
					while (mUnitMgr->selectedList.empty() == false)
					{
						iter = mUnitMgr->selectedList.begin();
						if (!iter->second->isDead())
						{
							iter->second->setHostile(true);
						}
						else
						{
							iter->second->setSelected(false);
						}
					}
					mUnitMgr->selected = false;
				}
			}

			if (mInputMgr->KeyIsPressed(HGEK_S) && mInputMgr->shiftPressed)
			{
				mGUIMgr->showEnemiesStatusBars = !mGUIMgr->showEnemiesStatusBars;
			}
			else if (mInputMgr->KeyIsPressed(HGEK_S))
			{
				mGUIMgr->showStatusBars = !mGUIMgr->showStatusBars;
			}

			if (mInputMgr->KeyIsPressed(HGEK_G))
			{
				map<float, Object>::iterator iter;
				for (iter = mGFXMgr->zSortedList.begin(); iter != mGFXMgr->zSortedList.end(); iter++)
				{
					if (iter->second.type == UNIT)
					{
						Unit *u = static_cast<Unit*>(iter->second.ptr);
						if (u->isSelected())
							hge->System_Log("[%f] %s (S)", iter->first, u->getName().c_str());
						else
							hge->System_Log("[%f] %s", iter->first, u->getName().c_str());
					}
					else if (iter->second.type == DOODAD)
					{
						Doodad *d = static_cast<Doodad*>((*iter).second.ptr);
						hge->System_Log("[%f] %s", iter->first, d->name.c_str());
					}
				}
			}

			if (mInputMgr->KeyIsPressed(HGEK_U))
			{
				hge->System_Log("# GUI # :");
				hge->System_Log(" - AddOns list :");
				map<string, AddOn>::iterator iter1;
				for (iter1 = mGUIMgr->addOnList.begin(); iter1 != mGUIMgr->addOnList.end(); iter1++)
				{
					hge->System_Log("	 - %s (%d)", iter1->second.name.c_str(), iter1->second.enabled);
				}

				hge->System_Log("\n - GUIElement list :");

				map<string, GUIElement>::iterator iter2;
				for (iter2 = mGUIMgr->guiList.begin(); iter2 != mGUIMgr->guiList.end(); iter2++)
				{
					if (!iter2->second.child)
						iter2->second._print(1);
				}
			}

			if (mInputMgr->KeyIsPressed(HGEK_R))
			{
				mSceneMgr->luaVM = mGUIMgr->reLoadUI(mSceneMgr->luaVM);
			}

			if (mInputMgr->KeyIsPressed(HGEK_P))
			{
				mTimeMgr->SetProfiling(true);
			}

			#ifdef PROFILE
				c1.Stop();
			#endif

		/* ---------------------------------------------------- */
		/* Handle clicking : movements                          */
		/* ---------------------------------------------------- */

			#ifdef PROFILE
				Profiler* prof2 = mTimeMgr->getProfiler(8, "FrameFunc - Interpret clicks", false);
				Chrono c2(prof2);
			#endif

			// Parse all units to define wether the mouse is hovering one
			if (mSceneMgr->mouseOverPlayField)
			{
				bool attack = false;
				Unit* target = NULL;
				mUnitMgr->newOvering = NULL;

				map<float, Unit*>::iterator iterUnit;
				for (iterUnit = mGFXMgr->zSortedUnitList.begin(); iterUnit != mGFXMgr->zSortedUnitList.end(); iterUnit++)
				{
					Unit* u = iterUnit->second;
					attack = u->getBox()->TestPoint(mInputMgr->mx, mInputMgr->my);

					if (attack)
					{
						mUnitMgr->newOvering = u;
					}

					if (!u->isDead() && u->isHostile() && mUnitMgr->selected)
					{
						if (attack)
						{
							target = u;
							if (!mSceneMgr->panning)
								mGUIMgr->cursor = mGUIMgr->switchCursor("attack");
							break;
						}
						else
						{
							if (!mSceneMgr->panning)
								mGUIMgr->cursor = mGUIMgr->switchCursor("normal");
						}
					}
					else
						attack = false;
				}

				if ( (mUnitMgr->newOvering != mUnitMgr->lastOvering) &&
					 (!mGUIMgr->selSquare.IsActive()) &&
					 ((mInputMgr->dmx != 0.0f) || (mInputMgr->dmy != 0.0f)) )
				{
					int asking = mlua_getGlobalInt("AskingForTooltip", false);
					lua_pushboolean(mSceneMgr->luaVM, true);
					lua_setglobal(mSceneMgr->luaVM, "ChangeToolTipContent");
					if (mUnitMgr->newOvering != NULL)
					{
						lua_newtable(mSceneMgr->luaVM);
						lua_setglobal(mSceneMgr->luaVM, "NewContent");
						lua_getglobal(mSceneMgr->luaVM, "NewContent");
						mlua_setFieldString("type", "unit");
						mlua_setFieldString("id", mUnitMgr->newOvering->getName());
						lua_pop(mSceneMgr->luaVM, 1);

						if (mUnitMgr->lastOvering == NULL)
						{
							asking++;
							lua_pushnumber(mSceneMgr->luaVM, asking);
							lua_setglobal(mSceneMgr->luaVM, "AskingForTooltip");
						}
					}
					else
					{
						asking--;
						lua_pushnumber(mSceneMgr->luaVM, asking);
						lua_setglobal(mSceneMgr->luaVM, "AskingForTooltip");
					}
					mUnitMgr->lastOvering = mUnitMgr->newOvering;
				}

				if ( (mInputMgr->mRState==2)          &&
				     (mUnitMgr->selected)             &&
				     (!mGUIMgr->selSquare.IsActive()) &&
				     (!mUnitMgr->castingSpell) )
				{
					if (mInputMgr->altPressed) // It's a target order
					{
						map<string, Unit*>::iterator iterSelected;
						for (iterSelected = mUnitMgr->selectedList.begin(); iterSelected != mUnitMgr->selectedList.end(); iterSelected++)
						{
// TODO (Corentin#1#): Keep track of spell target => Unit manager.
							iterSelected->second->target(mUnitMgr->newOvering);
						}
					}
					else
					{
						if (attack) // It's, obviously, an attack order
						{
							map<string, Unit*>::iterator iter;
							for (iter = mUnitMgr->selectedList.begin(); iter != mUnitMgr->selectedList.end(); iter++)
							{
								Unit* u = iter->second;
								if (!u->isDead())
								{
									string reason;
									u->target(target);
									if (u->isCastable(u->getDefaultSpell(), &reason, true))
									{
										if (u->isInSpellRange(target->getX(), target->getY()))
											u->incant(u->getDefaultSpell(), target);
										else
										{
											u->moveInRange(target);
											if (mUnitMgr->orderList.find(u->getName()) == mUnitMgr->orderList.end())
											{
												mUnitMgr->orderList[u->getName()] = u;
											}
										}
									}
									else
										mGUIMgr->addErrorMessage(u->getName() + " : " + mSceneMgr->strTable->GetString(reason.c_str()));
								}
							}
						}
						else // It's a movement order
						{
							if (!CheckPointCollision(toInt(mInputMgr->gmx), toInt(mInputMgr->gmy)))
							{
								// If the destination is not obstruded, set it to the mouse position
								mUnitMgr->leadingUnit->destPoint.set(toInt(mInputMgr->gmx), toInt(mInputMgr->gmy));
							}
							else
							{
								// Else define which is the nearest free point to go
								mUnitMgr->leadingUnit->destPoint = getNearestFreePoint(
									mUnitMgr->leadingUnit->getGX(), mUnitMgr->leadingUnit->getGY(),
									toInt(mInputMgr->gmx), toInt(mInputMgr->gmy)
								);
							}

							vector<Point> destPoint;
							// If Ctrl is not pressed, make several destinations
							if (!mInputMgr->ctrlPressed)
							{
								// Get the size of the unit
								hgeRect* tmpRect = mUnitMgr->leadingUnit->getBox();
								float space = tmpRect->x2-tmpRect->x1;
								// And call the function
								destPoint = getDestPoints(mUnitMgr->leadingUnit, mUnitMgr->selectedList.size(), space);
							}
							// Else, make only one
							vector<Point>::iterator iterPoint = destPoint.begin();

							// Then parse all selected units to give them orders
							map<string, Unit*>::iterator iter;
							for (iter = mUnitMgr->selectedList.begin(); iter != mUnitMgr->selectedList.end(); iter++)
							{
								Unit *u = iter->second;
								if (!u->isDead())
								{
									u->stop();

									// If ctrl is not pressed, give this unit a unique destination
									if (!mInputMgr->ctrlPressed)
									{
										u->destPoint = *iterPoint;
										iterPoint++;
									}
									else // Else, all units are going to the same point
									{
										u->destPoint = mUnitMgr->leadingUnit->destPoint;
									}

									// Get the path
									mSceneMgr->requestWPPath(u);
									u->pathRequested = false;
									u->pathObtained = false;
									u->following = false;
									u->followingWp = false;
									u->order = MOVEMENT_MOVE;

									// Add the unit to the order list
									if (mUnitMgr->orderList.find(u->getName()) == mUnitMgr->orderList.end())
									{
										mUnitMgr->orderList[u->getName()] = u;
									}

									mUnitMgr->orderGiven = true;
								}
							}
						}
					}
				}
				else if ( (mInputMgr->mRState==2) && (mUnitMgr->castingSpell) )
				{
					mUnitMgr->castingSpell = false;
					mUnitMgr->castedButton = NULL;
					if (!mSceneMgr->panning)
						mGUIMgr->cursor = mGUIMgr->switchCursor("normal");
				}
			}

		/* ---------------------------------------------------- */
		/* Handle clicking : selections and actions             */
		/* ---------------------------------------------------- */

			if (mUnitMgr->castingSpell)
			{
				if (mUnitMgr->castedButton->spell->target == SPELL_TARGET_HOSTILES)
				{
					bool attack=false;
					map<string, Unit*>::iterator iterHostile;
					for (iterHostile = mUnitMgr->hostileList.begin(); iterHostile != mUnitMgr->hostileList.end(); iterHostile++)
					{
						Unit* u = iterHostile->second;
						attack = u->getBox()->TestPoint(mInputMgr->mx, mInputMgr->my);
						if (attack)
						{
							mUnitMgr->targetUnit = u;
							if (!mSceneMgr->panning)
								mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action");
							mUnitMgr->castable = true;
							break;
						}
						else
						{
							if (!mSceneMgr->panning)
								mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action_imp");
							mUnitMgr->castable = false;
						}
					}
				}
				if (mUnitMgr->castedButton->spell->target == SPELL_TARGET_FRIENDS)
				{
					bool attack=false;
					map<string, Unit>::iterator iterUnit;
					for (iterUnit = mUnitMgr->unitList.begin(); iterUnit != mUnitMgr->unitList.end(); iterUnit++)
					{
						Unit *u = &iterUnit->second;
						if (!u->isHostile())
						{
							attack = u->getBox()->TestPoint(mInputMgr->mx, mInputMgr->my);
							if (attack)
							{
								mUnitMgr->targetUnit = u;
								if (!mSceneMgr->panning)
									mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action");
								mUnitMgr->castable = true;
								break;
							}
							else
							{
								if (!mSceneMgr->panning)
									mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action_imp");
								mUnitMgr->castable = false;
							}
						}
					}
				}
				else if (mUnitMgr->castedButton->spell->target == SPELL_TARGET_ALL)
				{
					bool attack=false;
					map<string, Unit>::iterator iterUnit;
					for (iterUnit = mUnitMgr->unitList.begin(); iterUnit != mUnitMgr->unitList.end(); iterUnit++)
					{
						Unit *u = &iterUnit->second;
						attack = u->getBox()->TestPoint(mInputMgr->mx, mInputMgr->my);
						if (attack)
						{
							mUnitMgr->targetUnit = u;
							if (!mSceneMgr->panning)
								mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action");
							mUnitMgr->castable = true;
							break;
						}
						else
						{
							if (!mSceneMgr->panning)
								mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action_imp");
							mUnitMgr->castable = false;
						}
					}
				}
				else if (mUnitMgr->castedButton->spell->target == SPELL_TARGET_DEADS)
				{
					bool attack=false;
					map<string, Unit*>::iterator iterDeath;
					for (iterDeath = mUnitMgr->deadList.begin(); iterDeath != mUnitMgr->deadList.end(); iterDeath++)
					{
						Unit *u = iterDeath->second;
						attack = u->getBox()->TestPoint(mInputMgr->mx, mInputMgr->my);
						if (attack)
						{
							mUnitMgr->targetUnit = u;
							if (!mSceneMgr->panning)
								mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action");
							mUnitMgr->castable = true;
							break;
						}
						else
						{
							if (!mSceneMgr->panning)
								mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action_imp");
							mUnitMgr->castable = false;
						}
					}
				}
				else if (mUnitMgr->castedButton->spell->target == SPELL_TARGET_DEAD_FRIENDS)
				{
					bool attack=false;
					map<string, Unit*>::iterator iterDeath;
					for (iterDeath = mUnitMgr->deadList.begin(); iterDeath != mUnitMgr->deadList.end(); iterDeath++)
					{
						Unit *u = iterDeath->second;
						if (!u->isHostile())
						{
							attack = u->getBox()->TestPoint(mInputMgr->mx, mInputMgr->my);
							if (attack)
							{
								mUnitMgr->targetUnit = u;
								if (!mSceneMgr->panning)
									mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action");
								mUnitMgr->castable = true;
								break;
							}
							else
							{
								if (!mSceneMgr->panning)
									mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action_imp");
								mUnitMgr->castable = false;
							}
						}
					}
				}
				else if (mUnitMgr->castedButton->spell->target == SPELL_TARGET_DEAD_HOSTILES)
				{
					bool attack=false;
					map<string, Unit*>::iterator iterDeath;
					for (iterDeath = mUnitMgr->deadList.begin(); iterDeath != mUnitMgr->deadList.end(); iterDeath++)
					{
						Unit *u = iterDeath->second;
						if (u->isHostile())
						{
							attack = u->getBox()->TestPoint(mInputMgr->mx, mInputMgr->my);
							if (attack)
							{
								mUnitMgr->targetUnit = u;
								if (!mSceneMgr->panning)
									mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action");
								mUnitMgr->castable = true;
								break;
							}
							else
							{
								if (!mSceneMgr->panning)
									mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action_imp");
								mUnitMgr->castable = false;
							}
						}
					}
				}
			}

			// Simple selection : only one unit is selected
			if ( (mInputMgr->mLState == 2) && (mSceneMgr->mouseOverPlayField) )
			{
				if (!mUnitMgr->castingSpell)
				{
					if (!mInputMgr->shiftPressed)
					{
						mUnitMgr->deselectAll();
					}
					if (mInputMgr->ctrlPressed)
					{
						Class* c;
						map<string, Unit>::iterator iter;
						for (iter = mUnitMgr->unitList.begin(); iter != mUnitMgr->unitList.end(); iter++)
						{
							Unit *u = &(*iter).second;
							if (!u->isHostile())
							{
								if (u->getBox()->TestPoint(mInputMgr->mx, mInputMgr->my))
								{
									u->setSelected(true);
									c = u->getClass();
									break;
								}
							}
						}
						for (iter = mUnitMgr->unitList.begin(); iter != mUnitMgr->unitList.end(); iter++)
						{
							Unit *u = &(*iter).second;
							if (!u->isHostile())
							{
								if (u->getClass() == c)
								{
									u->setSelected(true);
								}
							}
						}
					}
					else
					{
						map<string, Unit>::iterator iter;
						for (iter = mUnitMgr->unitList.begin(); iter != mUnitMgr->unitList.end(); iter++)
						{
							Unit *u = &(*iter).second;
							if (!u->isHostile())
							{
								if (u->getBox()->TestPoint(mInputMgr->mx, mInputMgr->my))
								{
									if (u->isSelected())
										u->setSelected(false);
									else
										u->setSelected(true);
									break;
								}
							}
						}
					}
					if (!mUnitMgr->selectedList.empty())
						mUnitMgr->selected = true;
					else
						mUnitMgr->selected = false;
				}
				else
				{
					if (mUnitMgr->castable)
					{
						Unit* u = mUnitMgr->casterUnit;
						Unit* t = mUnitMgr->targetUnit;
						u->stop();
						u->target(t);
						string reason;
						if (u->isCastable(mUnitMgr->castedButton->spell, &reason, true))
						{
							string reason;
							if (u->isTargetInRange(mUnitMgr->castedButton->spell))
								u->incant(mUnitMgr->castedButton->spell, t);
							else
							{
								u->target(t);
								u->moveInRange(t);
								if (mUnitMgr->orderList.find(u->getName()) == mUnitMgr->orderList.end())
								{
									mUnitMgr->orderList[u->getName()] = u;
								}
							}
						}
						else
							mGUIMgr->addErrorMessage(mUnitMgr->casterUnit->getName() + " : " + mSceneMgr->strTable->GetString(reason.c_str()));

						mUnitMgr->castingSpell = false;
						mUnitMgr->castable = false;
						mUnitMgr->castedButton = NULL;
						if (!mSceneMgr->panning)
							mGUIMgr->cursor = mGUIMgr->switchCursor("normal");
					}
				}
			}

			#ifdef PROFILE
				c2.Stop();
			#endif

			#ifdef PROFILE
				Profiler* prof3 = mTimeMgr->getProfiler(8, "FrameFunc - Updates", false);
				Chrono c3(prof3);
			#endif

			// Update the UI...
			mGUIMgr->updateUI();

			// Update the selection square
			mGUIMgr->selSquare.Update();

		/* ---------------------------------------------------- */
		/* End loop maths                                       */
		/* ---------------------------------------------------- */

			// Global alpha glow
			timerAlpha += mInputMgr->dt;
			if (timerAlpha > M_PI_2)
				timerAlpha = 0;

		/* ---------------------------------------------------- */
		/* Updates                                              */
		/* ---------------------------------------------------- */

			// Update leading unit
			if (mUnitMgr->selected)
			{
				if (mUnitMgr->selectedList.empty())
				{
					mUnitMgr->leadingUnit = NULL;
					mUnitMgr->selected = false;
				}
				else
				{
					mUnitMgr->leadingUnit = NULL;
					map<string, Unit*>::iterator iter;
					for (iter = mUnitMgr->selectedList.begin(); iter != mUnitMgr->selectedList.end(); iter++)
					{
						if (!iter->second->isDead())
						{
							mUnitMgr->leadingUnit = iter->second;
							break;
						}
					}
					if (mUnitMgr->leadingUnit == NULL)
					{
						mUnitMgr->leadingUnit = mUnitMgr->selectedList.begin()->second;
					}
				}
			}
			else
			{
				mUnitMgr->leadingUnit = NULL;
			}

			if (!mSceneMgr->gamePaused)
			{
				// Update scrolling combat texts
				mGUIMgr->updateScrollingTexts();

				// Update error texts
				mGUIMgr->updateErrorTexts();

				// Build a certain amount of the requested paths
				mSceneMgr->buildWPPaths();

				// Build some other paths
				mSceneMgr->buildPaths();
				mSceneMgr->buildDirectPaths();

				#ifdef PROFILE
					Profiler* prof5 = mTimeMgr->getProfiler(8, "FrameFunc - Updates - Projectiles", false);
					Chrono c5(prof5);
				#endif

				// Update all projectiles and their particle system
				map<string, Projectile>::iterator iterProj, lastProj;
				lastProj = NULL;
				for (iterProj = mUnitMgr->projectileList.begin(); iterProj != mUnitMgr->projectileList.end(); iterProj++)
				{
					Projectile *p = &iterProj->second;
					if (!p->updatePos())
					{
						p->getPSys()->Stop();
						mUnitMgr->projectileList.erase(iterProj);
						if (mUnitMgr->projectileList.empty())
						{
							break;
						}
						if (lastProj == NULL)
						{
							iterProj = mUnitMgr->projectileList.begin();
							continue;
						}
						else
							iterProj = lastProj;
					}
					else
					{
						p->getPSys()->MoveTo(p->x, p->y);
						p->getPSys()->Transpose(mSceneMgr->gx, mSceneMgr->gy);
						p->getPSys()->Update(mInputMgr->dt);
					}
					lastProj = iterProj;
				}
			}
			else
			{
				map<string, Projectile>::iterator iterProj, lastProj;
				lastProj = NULL;
				for (iterProj = mUnitMgr->projectileList.begin(); iterProj != mUnitMgr->projectileList.end(); iterProj++)
				{
					Projectile *p = &iterProj->second;
					p->getPSys()->MoveTo(p->x, p->y);
					p->getPSys()->Transpose(mSceneMgr->gx, mSceneMgr->gy);
				}
			}

			mGFXMgr->buildRenderList();

			if (mUnitMgr->orderGiven)
			{
				setGlowing(mGUIMgr->orderCircle, timerAlpha);
				if (mUnitMgr->orderList.empty())
					mUnitMgr->orderGiven = false;
			}

			// Update the cursor animation if it has one
			if (mGUIMgr->cursor->animated)
				mGUIMgr->cursor->anim->Update(mInputMgr->dt);

			// Update target links color
			if (mUnitMgr->selected)
			{
				mGUIMgr->targetLinkTimer += mInputMgr->dt/2;
				if (mGUIMgr->targetLinkTimer > 1.0f)
					mGUIMgr->targetLinkTimer = 0.0f;

				mGUIMgr->targetLinkColorF1 = ARGB(
					255, 0,
					127.5f*sin((mGUIMgr->targetLinkTimer+0.25f)*2*M_PI)+127.5f,
					0
				);
				mGUIMgr->targetLinkColorF2 = ARGB(
					255, 0,
					127.5f*sin(mGUIMgr->targetLinkTimer*2*M_PI)+127.5f,
					0
				);
				mGUIMgr->targetLinkColorF3 = ARGB(
					255, 0,
					127.5f*sin((mGUIMgr->targetLinkTimer-0.25f)*2*M_PI)+127.5f,
					0
				);

				mGUIMgr->targetLinkColorE1 = ARGB(
					255,
					127.5f*sin((mGUIMgr->targetLinkTimer+0.25f)*2*M_PI)+127.5f,
					0, 0
				);
				mGUIMgr->targetLinkColorE2 = ARGB(
					255,
					127.5f*sin(mGUIMgr->targetLinkTimer*2*M_PI)+127.5f,
					0, 0
				);
				mGUIMgr->targetLinkColorE3 = ARGB(
					255,
					127.5f*sin((mGUIMgr->targetLinkTimer-0.25f)*2*M_PI)+127.5f,
					0, 0
				);
			}

			#ifdef PROFILE
				c3.Stop();
			#endif

			break;
		}

/********************************/
		case LOADING:
/********************************/
		{
			static string classes_file;
			static string effects_file;
			static string cursors_file;
			static string fonts_file;
			static int state1 = 1;
			static int state2 = 1;

			if (mSceneMgr->loaderState == 0)
			{
				mGUIMgr->initValues();

				int error = luaL_dofile(mSceneMgr->luaVM, "Tables/def_table.lua");
				if (error) l_logPrint(mSceneMgr->luaVM);

				hge->System_Log("Parsing Scripts/config.lua...");
				mZoneMgr->actualZone.name = mlua_getGlobalString("Files_starting_zone");

				mSceneMgr->aspectRatio = 1.0f/mlua_getGlobalFloat("Game_aspect_ratio");
				mSceneMgr->inCombatTimer = mlua_getGlobalFloat("Game_out_of_combat_timer");
				mSceneMgr->regenTimer = mlua_getGlobalFloat("Game_regen_tick");
				mSceneMgr->maxComputedPaths = mlua_getGlobalInt("Game_max_computed_path");

				mGUIMgr->showStatusBars = mlua_getGlobalBool("UI_show_status_bars");
				mGUIMgr->showEnemiesStatusBars = mlua_getGlobalBool("UI_show_enemies_status_bars");
				mGUIMgr->scrollingTextMaxLife = mlua_getGlobalFloat("UI_scrolling_texts_duration");
				mGUIMgr->scrollingTextSpeed = mlua_getGlobalFloat("UI_scrolling_texts_speed");
				mGUIMgr->scrollingTextFade = mlua_getGlobalBool("UI_scrolling_texts_fade");
				mGUIMgr->errorTextsDuration = mlua_getGlobalFloat("UI_error_texts_duration");
				mGUIMgr->errorTextsFadeDelay = mlua_getGlobalFloat("UI_error_texts_fade_delay");

				hge->System_Log("Parsing Scripts/config.lua : done.\n");

				string fnt = mlua_getGlobalString("Fonts_default_font");
				mGUIMgr->defaultFont = mFontMgr->getFont(true, fnt, 15, false, false);
				if (mGUIMgr->defaultFont == NULL) {hge->System_Log("# Error # : missing default font...");}
				mGUIMgr->scrollingTextFont = mFontMgr->getFont(true, fnt, 16, true, false); // outlined
				mGUIMgr->errorFont = mFontMgr->getFont(true, fnt, 18, true, false); // outlined
				mFontMgr->systemFont = mGUIMgr->scrollingTextFont;

				mGUIMgr->mLoadingBar.initialize();

				mSceneMgr->jumpToNextState = true;
				mGUIMgr->mLoadingBar.filling += 0.05f;
				mGUIMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading_zone");
			}
			else if (mSceneMgr->loaderState == 1)
			{
				bool finished, state;
				state = mZoneMgr->parseZoneDyn(mSceneMgr->luaVM, state1, state2, &finished, 0.35f);
				if (finished)
				{
					mSceneMgr->jumpToNextState = true;
					mGUIMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading_cursors");
					state1 = 1;
					state2 = 1;
				}
				else
				{
					if (state)
					{
						state1++;
						state2 = 1;
					}
					else
						state2++;
				}
			}
			else if (mSceneMgr->loaderState == 2)
			{
				mGUIMgr->parseCursors(mSceneMgr->luaVM);
				mSceneMgr->jumpToNextState = true;
				mGUIMgr->mLoadingBar.filling += 0.05f;
				mGUIMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading_classes");
			}
			else if (mSceneMgr->loaderState == 3)
			{
				bool finished, state;
				state = mUnitMgr->parseClassesDyn(mSceneMgr->luaVM, state1, &finished, 0.05f);
				if (finished)
				{
					mSceneMgr->jumpToNextState = true;
					mGUIMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading_animations");
					state1 = 1;
					state2 = 0;
				}
				else
				{
					if (state)
						state1++;
				}
			}
			else if (mSceneMgr->loaderState == 4)
			{
				bool finished, state;
				state = mGFXMgr->parseAnimationsDyn(mSceneMgr->luaVM, state1, state2, &finished, 0.3f);
				if (finished)
				{
					mSceneMgr->jumpToNextState = true;
					mGUIMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading_effects");
					state1 = 1;
					state2 = 1;
				}
				else
				{
					if (state)
					{
						state1++;
						state2 = 0;
					}
					else
						state2++;
				}
			}
			else if (mSceneMgr->loaderState == 5)
			{
				mGFXMgr->parseEffects(mSceneMgr->luaVM);
				mSceneMgr->jumpToNextState = true;
				mGUIMgr->mLoadingBar.filling += 0.15f;
				mGUIMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading_ui");
			}
			else if (mSceneMgr->loaderState == 6)
			{
				// Create sprites
				hge->System_Log("Creating system data...");
				HTEXTURE px_tex = mGFXMgr->loadTexture("pixel.png");
				mGFXMgr->pixel = mGFXMgr->createSprite(px_tex,0,0,1,1);

				// Create the screen BBs
				mSceneMgr->screenLRect = mGFXMgr->createRect(0, 0, 6, mGFXMgr->sHeight);
				mSceneMgr->screenTRect = mGFXMgr->createRect(0, 0, mGFXMgr->sWidth, 6);
				mSceneMgr->screenRRect = mGFXMgr->createRect(mGFXMgr->sWidth-6, 0, mGFXMgr->sWidth, mGFXMgr->sHeight);
				mSceneMgr->screenBRect = mGFXMgr->createRect(0, mGFXMgr->sHeight-6, mGFXMgr->sWidth, mGFXMgr->sHeight);
				mGFXMgr->scrRect = mGFXMgr->createRect(0, 0, mGFXMgr->sWidth, mGFXMgr->sHeight);

				// Choose the cursor
				mGUIMgr->cursor = mGUIMgr->switchCursor("normal");

				hge->System_Log("Creating system data : done.");

				// Reading tables
				hge->System_Log("Reading tables...");
				mUnitMgr->lvl_healthTable = new hgeStringTable("Tables/lvl_health.tbl");
				mUnitMgr->lvl_manaTable = new hgeStringTable("Tables/lvl_mana.tbl");
				mUnitMgr->lvl_xp_neededTable = new hgeStringTable("Tables/lvl_xp_needed.tbl");
				hge->System_Log("Reading tables : done.");

				hge->System_Log("Creating units...");

				// Run the initialization script
				int error = luaL_dofile(mSceneMgr->luaVM, "Scripts/init.lua");
				if (error) l_logPrint(mSceneMgr->luaVM);

				hge->System_Log("Creating units : done.");

				// Load the UI
				hge->System_Log("Loading UI...");
				mGUIMgr->loadUI(mSceneMgr->luaVM);
				hge->System_Log("Loading UI : done.");

				mSceneMgr->jumpToNextState = true;
				mGUIMgr->mLoadingBar.filling += 0.05f;
			}
			else if (mSceneMgr->loaderState == 7)
			{
				hge->System_Log("Now playing !\n");
				mSceneMgr->gameState = GAME;
			}

			if (mSceneMgr->jumpToNextState)
			{
				mSceneMgr->jumpToNextState = false;
				mSceneMgr->loaderState++;
			}

			break;
		}
	}

	return false;
}


bool RenderFunc()
{
	switch (mSceneMgr->gameState)
	{
/********************************/
		case GAME:
/********************************/
		{
			// Begin rendering.
			hge->Gfx_BeginScene(mGFXMgr->tMainTarget);
			mGFXMgr->mDxDevice->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, FALSE);
			mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
			mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

			// Clear screen with black color
			hge->Gfx_Clear(0);

			// Render the background first
			hge->System_SetState(HGE_TEXTUREFILTER, false);
			std::map<float, BGPart>::iterator iterParts;
			for (iterParts = mZoneMgr->actualZone.parts.begin(); iterParts != mZoneMgr->actualZone.parts.end(); iterParts++)
			{
				BGPart* tmpPart = &iterParts->second;
				tmpPart->bg->Render(tmpPart->x+mSceneMgr->gx, tmpPart->y+mSceneMgr->gy);
			}
			hge->System_SetState(HGE_TEXTUREFILTER, true);

			// Render order circles
			if (mUnitMgr->orderGiven)
			{
				map<string, Unit*>::iterator iter = mUnitMgr->orderList.begin();
				Unit *u = iter->second;
				float mdist = getPointDistortion(toInt(u->destPoint.x), toInt(u->destPoint.y));
				float scale = mZoneMgr->actualZone.distortion_scale_min-mdist*(mZoneMgr->actualZone.distortion_scale_min-mZoneMgr->actualZone.distortion_scale_max);
				for (iter = mUnitMgr->orderList.begin(); iter != mUnitMgr->orderList.end(); iter++)
				{
					u = iter->second;
					if (u->isSelected())
					{
						float s_scale = u->getClass()->shadow_scale;
						float vscale = mZoneMgr->actualZone.distortion_vscale_min-mdist*(mZoneMgr->actualZone.distortion_vscale_min-mZoneMgr->actualZone.distortion_vscale_max);
						mGUIMgr->orderCircle->RenderEx(u->destPoint.x+mSceneMgr->gx, u->destPoint.y+mSceneMgr->gy, 0.0f, 2.0f*scale*s_scale, 1.4f*scale*s_scale*vscale);
					}
				}
			}

			// Render selection, death and hostile circles and shadows
			map<float, Unit*>::iterator iterUnit;
			for (iterUnit = mGFXMgr->zSortedUnitList.begin(); iterUnit != mGFXMgr->zSortedUnitList.end(); iterUnit++)
			{
				Unit *u = iterUnit->second;
				float ux = u->getX();
				float uy = u->getY();
				float scale = u->getScale()*(u->getClass()->scale);
				float s_scale = u->getClass()->shadow_scale;
				mGUIMgr->p_shadow->RenderEx(ux, uy, 0.0f, scale*s_scale, scale*s_scale);
				if (u->isDead() && u->isSelected())
					mGUIMgr->deathCircle->RenderEx(ux, uy, 0.0f, 2.0f*scale*s_scale, 1.2f*scale*s_scale);
				else
				{
					if (u->isSelected())
						mGUIMgr->selectionCircle->RenderEx(ux, uy, 0.0f, 2.0f*scale*s_scale, 1.2f*scale*s_scale);
					if (u->isHostile() && !u->isDead())
						mGUIMgr->hostileCircle->RenderEx(ux, uy, 0.0f, 2.0f*scale*s_scale, 1.2f*scale*s_scale);
				}
			}

			// Render target links
			map<string, Unit*>::iterator iterUnit2;
			for (iterUnit2 = mUnitMgr->selectedList.begin(); iterUnit2 != mUnitMgr->selectedList.end(); iterUnit2++)
			{
				Unit* u = iterUnit2->second;
				Unit* t = u->getTarget();
				if (t != NULL)
				{
					DWORD col1, col2, col3;
					if (t->isHostile())
					{
						col1 = mGUIMgr->targetLinkColorE1;
						col2 = mGUIMgr->targetLinkColorE2;
						col3 = mGUIMgr->targetLinkColorE3;
					}
					else
					{
						col1 = mGUIMgr->targetLinkColorF1;
						col2 = mGUIMgr->targetLinkColorF2;
						col3 = mGUIMgr->targetLinkColorF3;
					}

					hgeVector vec = hgeVector(u->getX()-t->getX(), u->getY()-t->getY());
					hgeVector vecO = vec;
					vecO.Normalize(); vecO.Rotate(M_PI_2);

					mGUIMgr->targetLink1.v[0].col = col1;
					mGUIMgr->targetLink1.v[0].x = u->getX()-vecO.x;
					mGUIMgr->targetLink1.v[0].y = u->getY()-vecO.y;
					mGUIMgr->targetLink1.v[1].col = col1;
					mGUIMgr->targetLink1.v[1].x = u->getX()+vecO.x;
					mGUIMgr->targetLink1.v[1].y = u->getY()+vecO.y;
					mGUIMgr->targetLink1.v[2].col = col2;
					mGUIMgr->targetLink1.v[2].x = u->getX()-vec.x/2+vecO.x;
					mGUIMgr->targetLink1.v[2].y = u->getY()-vec.y/2+vecO.y;
					mGUIMgr->targetLink1.v[3].col = col2;
					mGUIMgr->targetLink1.v[3].x = u->getX()-vec.x/2-vecO.x;
					mGUIMgr->targetLink1.v[3].y = u->getY()-vec.y/2-vecO.y;

					mGUIMgr->targetLink2.v[0].col = col2;
					mGUIMgr->targetLink2.v[0].x = u->getX()-vec.x/2-vecO.x;
					mGUIMgr->targetLink2.v[0].y = u->getY()-vec.y/2-vecO.y;
					mGUIMgr->targetLink2.v[1].col = col2;
					mGUIMgr->targetLink2.v[1].x = u->getX()-vec.x/2+vecO.x;
					mGUIMgr->targetLink2.v[1].y = u->getY()-vec.y/2+vecO.y;
					mGUIMgr->targetLink2.v[2].col = col3;
					mGUIMgr->targetLink2.v[2].x = t->getX()+vecO.x;
					mGUIMgr->targetLink2.v[2].y = t->getY()+vecO.y;
					mGUIMgr->targetLink2.v[3].col = col3;
					mGUIMgr->targetLink2.v[3].x = t->getX()-vecO.x;
					mGUIMgr->targetLink2.v[3].y = t->getY()-vecO.y;

					hge->Gfx_RenderQuad(&mGUIMgr->targetLink1);
					hge->Gfx_RenderQuad(&mGUIMgr->targetLink2);
				}
			}

			// Render units and doodads
			map<float, Object>::iterator iterObj;
			for (iterObj = mGFXMgr->zSortedList.begin(); iterObj != mGFXMgr->zSortedList.end(); iterObj++)
			{
				if (iterObj->second.type == UNIT)
				{
					Unit *u = static_cast<Unit*>(iterObj->second.ptr);
					float ux = u->getX();
					float uy = u->getY();
					float scale = u->getScale();
					float shadow = u->getShadow();
					RGB color = u->getColor();

					if (mUnitMgr->newOvering == u)
					{
						if (u->isDead())
							u->getAnimation()->SetColor(ARGB(100, 255, 255, 255));
						else if (u->isHostile())
							u->getAnimation()->SetColor(ARGB(100, 255, 0, 0));
						else
							u->getAnimation()->SetColor(ARGB(100, 0, 255, 0));
						u->getAnimation()->SetBlendMode(BLEND_COLORADD | BLEND_ALPHAADD | BLEND_NOZWRITE);
						for (float f = 0.0f; f < 1.0f; f += 0.1f)
						{
							u->getAnimation()->RenderEx(ux+2*cos(f*2*M_PI), uy+2*sin(f*2*M_PI), 0.0f, scale, scale);
						}
						u->getAnimation()->SetBlendMode(BLEND_DEFAULT);
					}

					u->getAnimation()->SetColor(ARGB(255, shadow+color.R, shadow+color.G, shadow+color.B));
					u->getAnimation()->RenderEx(ux, uy, 0.0f, scale, scale);
					// Render effects
					if (u->FXPlaying)
					{
						map<string, Effect> fxList = u->getEffectList();
						map<string, Effect>::iterator iterFX;
						for (iterFX = fxList.begin(); iterFX != fxList.end(); iterFX++)
						{
							iterFX->second.RenderEx(ux, uy, 0.0f, scale);
						}
					}
				}
				else if (iterObj->second.type == DOODAD)
				{
					Doodad* d = static_cast<Doodad*>(iterObj->second.ptr);
					d->sprite->Render(floor(d->getX()),floor(d->getY()));
				}
			}

			// Render projectiles
			map<string, Projectile>::iterator iterProj;
			for (iterProj = mUnitMgr->projectileList.begin(); iterProj != mUnitMgr->projectileList.end(); iterProj++)
			{
				iterProj->second.getPSys()->Render();
			}

			// Render always in top doodads
			map<float, Doodad*>::iterator iterDoodad;
			for (iterDoodad = mGFXMgr->renderInTopList.begin(); iterDoodad != mGFXMgr->renderInTopList.end(); iterDoodad++)
			{
				Doodad* d = iterDoodad->second;
				d->sprite->Render(toInt(d->getX()), toInt(d->getY()));
			}

			// Render status bars
			if (mGUIMgr->showStatusBars)
			{
				for (iterUnit = mGFXMgr->zSortedUnitList.begin(); iterUnit != mGFXMgr->zSortedUnitList.end(); iterUnit++)
				{
					if (!(iterUnit->second->isHostile() && mGUIMgr->showEnemiesStatusBars))
					{
						StatusBar* sb = iterUnit->second->getStatusBar();
						sb->Render();
					}
				}
			}

			mGUIMgr->renderScrollingTexts();

			// Render the selection square
			mGUIMgr->selSquare.Render();

		/* --------------------------------- */
		/*  RENDER UI						*/
		/* --------------------------------- */

			// Pause text
			if (mSceneMgr->gamePaused)
			{
				mGUIMgr->errorFont->SetColor(ARGB(255, 255, 60, 60));
				mGUIMgr->errorFont->printf
				(
					mGFXMgr->sWidth/2.0f, mGFXMgr->sHeight-195, HGETEXT_CENTER,
					mSceneMgr->strTable->GetString("game_paused")
				);
			}

			hge->Gfx_EndScene();
			hge->Gfx_BeginScene(mGFXMgr->tMainTarget);
			mGFXMgr->mDxDevice->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, FALSE);
			//mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ONE);
			mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

			// LUA UI
			multimap<int, GUIElement*>::iterator iterGUI2;
			for (iterGUI2 = mGUIMgr->sortedGUIList.begin(); iterGUI2 != mGUIMgr->sortedGUIList.end(); iterGUI2++)
			{
				GUIElement* g = iterGUI2->second;
				g->Render(false);
			}

			hge->Gfx_EndScene();
			hge->Gfx_BeginScene(mGFXMgr->tMainTarget);
			mGFXMgr->mDxDevice->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, FALSE);
			mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
			mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

			// Error texts
			vector<ErrorText>::iterator iter;
			float errorY = 115.0f;
			for (iter = mGUIMgr->errorTextList.begin(); iter != mGUIMgr->errorTextList.end(); iter++)
			{
				mGUIMgr->errorFont->SetColor(ARGB(toInt(iter->alpha), 255, 60, 60));
				mGUIMgr->errorFont->printf
				(
					mGFXMgr->sWidth/2.0f, errorY, HGETEXT_CENTER,
					iter->caption.c_str()
				);
				errorY += 25.0f;
			}

			// FPS counter
			mFontMgr->systemFont->SetColor(ARGB(255, 255, 255, 255));
			mFontMgr->systemFont->printf
			(
				mGFXMgr->sWidth-10, mGFXMgr->sHeight-20, HGETEXT_RIGHT,
				"FPS : %d",
				mInputMgr->GetFPS()
			);

			// Render the cursor above all
			if (mGUIMgr->cursor->animated)
			{
				mGUIMgr->cursor->anim->RenderEx(mInputMgr->mx, mInputMgr->my, mGUIMgr->cursor->rot, 1.0f);
			}
			else
			{
				mGUIMgr->cursor->sprite->RenderEx(mInputMgr->mx, mInputMgr->my, mGUIMgr->cursor->rot, 1.0f);
			}

			// End rendering, update the screen
			hge->Gfx_EndScene();

			/*static int frameCount = 1;
			hge->System_Log("[%d]", frameCount);
			frameCount++;*/

			hge->Gfx_BeginScene();
			mGFXMgr->mDxDevice->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, FALSE);
			mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
			mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

			mGFXMgr->sprMainSprite->Render(0, 0);

			hge->Gfx_EndScene();

			break;
		}

/********************************/
		case LOADING:
/********************************/
		{
			// Begin rendering.
			hge->Gfx_BeginScene();

			mGUIMgr->loadingBackground->RenderStretch(0, 0, mGFXMgr->sWidth, mGFXMgr->sHeight);
			mGUIMgr->mLoadingBar.Render();

			hge->Gfx_EndScene();
			break;
		}
	}

	return false;
}


bool RestoreFunc()
{
	map<string, GUIElement>::iterator iterGUI;
	for (iterGUI = mGUIMgr->guiList.begin(); iterGUI != mGUIMgr->guiList.end(); iterGUI++)
	{
		GUIElement* g = &iterGUI->second;
		if (g->target && g->spr)
		{
			g->spr->SetTexture(hge->Target_GetTexture(g->target));
			if (g->useBackdrop)
				if (g->backdrop.target && g->backdrop.spr)
					g->backdrop.spr->SetTexture(hge->Target_GetTexture(g->backdrop.target));
		}
		g->rebuildCache = true;
		g->rebuildBackdrop = true;
	}

	mGFXMgr->sprMainSprite->SetTexture(hge->Target_GetTexture(mGFXMgr->tMainTarget));

	return false;
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	srand((unsigned)time(0));

	// Initialize HGE
	hge = hgeCreate(HGE_VERSION);
	hge->Random_Seed(0);

	hge->System_SetState(HGE_LOGFILE, "WoWRL.log"); // Initialize the Log file
	hge->System_SetState(HGE_TITLE, "WoW Raid Leader"); // Set the frame title
	hge->System_SetState(HGE_FRAMEFUNC, FrameFunc);
	hge->System_SetState(HGE_RENDERFUNC, RenderFunc);
	hge->System_SetState(HGE_GFXRESTOREFUNC, RestoreFunc);

	// Create managers
	mSceneMgr = SceneManager::getSingleton();
	mUnitMgr = UnitManager::getSingleton();
	mFontMgr = FontManager::getSingleton();
	mGUIMgr = GUIManager::getSingleton();
	mTimeMgr = TimeManager::getSingleton();
	mZoneMgr = ZoneManager::getSingleton();
	mGFXMgr = GFXManager::getSingleton();
	mInputMgr = InputManager::getSingleton();

	mSceneMgr->gameVersion = GAMEVERSION;
	hge->System_Log("##########################");
	hge->System_Log("# Starting WoWRL v.%.3f #", mSceneMgr->gameVersion);
	hge->System_Log("##########################\n");

	// Initialize LUA
	mSceneMgr->luaVM = lua_open();
	if (mSceneMgr->luaVM == NULL)
	{
		hge->System_Log("# Error initializing lua.");
		return 0;
	}
	mluaL_openlibs(mSceneMgr->luaVM);
	mlua_registerAll(mSceneMgr->luaVM);
	// Set panic function
	lua_atpanic(mSceneMgr->luaVM, l_logPrint);

	hge->System_Log("Parsing display config...");

	int error = luaL_dofile(mSceneMgr->luaVM, "Scripts/config.lua");
	if (error) l_logPrint(mSceneMgr->luaVM);

	mGFXMgr->sWidth = mlua_getGlobalInt("Display_screen_width");
	mGFXMgr->sHeight = mlua_getGlobalInt("Display_screen_height");
	int sDepth = mlua_getGlobalInt("Display_screen_depth");
	int sMaxFPS = mlua_getGlobalInt("Display_max_fps");
	bool windowed = !mlua_getGlobalBool("Display_fullscreen");
	mSceneMgr->locale = mlua_getGlobalString("Game_locale");
	string strTableFile = "Tables/locale_" + mSceneMgr->locale + ".str";

	hge->System_Log("Parsing display config : done.\n");

	mSceneMgr->strTable = new hgeStringTable(strTableFile.c_str());

	hge->System_SetState(HGE_FPS, sMaxFPS);
	hge->System_SetState(HGE_WINDOWED, windowed);
	hge->System_SetState(HGE_SCREENWIDTH, mGFXMgr->sWidth);
	hge->System_SetState(HGE_SCREENHEIGHT, mGFXMgr->sHeight);
	hge->System_SetState(HGE_SCREENBPP, sDepth);

	hge->System_SetState(HGE_ICON, MAKEINTRESOURCE (1));

	hge->System_SetState(HGE_USESOUND, false); // Disactivate sound

	if(hge->System_Initiate())
	{
		// Create the main render target
		mGFXMgr->mDxDevice = hge->Gfx_GetDevice();
		mGFXMgr->tMainTarget = hge->Target_Create(mGFXMgr->sWidth, mGFXMgr->sHeight, false);
		mGFXMgr->sprMainSprite = new hgeSprite
		(
			hge->Target_GetTexture(mGFXMgr->tMainTarget),
			0, 0,
			mGFXMgr->sWidth, mGFXMgr->sHeight
		);

		// Create loading bar
		string loadingBar = "UI/ui_default_loading_bar.png";
		HTEXTURE lTex = mGFXMgr->loadTexture(loadingBar);
		mGUIMgr->mLoadingBar.border = mGFXMgr->createSprite(lTex,1,57,250,30);
		mGUIMgr->mLoadingBar.border->SetHotSpot(125, 0);
		mGUIMgr->mLoadingBar.spark = mGFXMgr->createSprite(lTex,84,30,7,24);
		mGUIMgr->mLoadingBar.spark->SetHotSpot(5, 0);
		mGUIMgr->mLoadingBar.spark->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHABLEND | BLEND_NOZWRITE);
		mGUIMgr->mLoadingBar.gauge_active = mGFXMgr->createSprite(lTex,1,29,26,26);
		mGUIMgr->mLoadingBar.gauge_error = mGFXMgr->createSprite(lTex,29,29,26,26);
		mGUIMgr->mLoadingBar.gauge_finish = mGFXMgr->createSprite(lTex,57,29,26,26);
		mGUIMgr->mLoadingBar.background = mGFXMgr->createSprite(lTex,1,1,246,26);
		mGUIMgr->mLoadingBar.background->SetHotSpot(123, 0);
		mGUIMgr->mLoadingBar.filling = 0.0f;

		//int fileNbr = hge->Random_Int(1,2);
		int fileNbr = 1;

		// Load the loading background
		if (mGFXMgr->sWidth == 1024)
		{
			HTEXTURE bgTex = mGFXMgr->loadTexture("Zones/LoadingScreen/loading_screen_" + toString(fileNbr)+ "_1024.jpg");
			mGUIMgr->loadingBackground = mGFXMgr->createSprite(bgTex,0,0,1024,768);
		}
		else
		{
			HTEXTURE bgTex = mGFXMgr->loadTexture("Zones/LoadingScreen/loading_screen_" + toString(fileNbr)+ "_1280.jpg");
			mGUIMgr->loadingBackground = mGFXMgr->createSprite(bgTex,0,0,1280,1024);
		}
		mGUIMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading");

		// Load ressources and start
		mSceneMgr->gameState = LOADING;

		hge->System_Start();
	}
	else
	{
		MessageBox(NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_APPLMODAL);
	}

	hge->System_Log("Game ended.\n");

	// End, delete/free everything
	hge->System_Log("Freeing resources :");
	hge->System_Log("   Closing UI...");
	mGUIMgr->closeUI(mSceneMgr->luaVM);
	hge->System_Log("   Freeing textures...");
	mGFXMgr->freeTextures();
	hge->System_Log("   Deleting sprites...");
	mGFXMgr->deleteSprites();
	hge->System_Log("   Deleting animations...");
	mGFXMgr->deleteAnimations();
	hge->System_Log("   Deleting particle systems...");
	mGFXMgr->deletePSys();
	hge->System_Log("   Deleting rects...");
	mGFXMgr->deleteRects();
	hge->System_Log("   Deleting doodads...");
	mZoneMgr->deleteDoodads();
	hge->System_Log("   Deleting units...");
	mUnitMgr->deleteUnits();
	hge->System_Log("   Deleting fonts...");
	mFontMgr->deleteFonts();

	// Print out profiling info
	mTimeMgr->Print();

	lua_close(mSceneMgr->luaVM);

// FIXME (Corentin#1#): Crash ?
	//delete mSceneMgr;
	//delete mFontMgr;
	//delete mTimeMgr;
	//delete mGUIMgr;
	//delete mUnitMgr;
	//delete mZoneMgr;
	//delete mGFXMgr;

	hge->System_Log("Done.");

	hge->System_Shutdown();
	hge->Release();

	return 0;
}

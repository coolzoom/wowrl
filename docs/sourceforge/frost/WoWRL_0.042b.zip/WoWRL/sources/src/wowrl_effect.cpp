/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Effect source             */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Effect class.                  */
/*       An Effect is used to store all   */
/*  kind of special effects, such as      */
/*  particle systems or animated sprites. */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_scenemanager.h"

#include "wowrl_effect.h"

extern SceneManager* mSceneMgr;

void Effect::Render(float x, float y)
{
	if (type == FX_ANIMATED_EFFECT)
	{
		anim->RenderEx(x+offset_x, y+offset_y, 0.0f, scale);
	}
	else if (type == FX_PARTICLE_SYSTEM)
	{
		psys->MoveTo(x-mSceneMgr->gx+offset_x, y-mSceneMgr->gy+offset_y);
		psys->Transpose(mSceneMgr->gx, mSceneMgr->gy);
		psys->Render();
	}
}

void Effect::RenderEx(float x, float y, float angle, float h_scale, float v_scale)
{
	if (v_scale == 0.0f)
		v_scale = h_scale;

	if (type == FX_ANIMATED_EFFECT)
	{
		anim->RenderEx(x+offset_x*v_scale, y+offset_y*h_scale, angle, v_scale*scale, h_scale*scale);
	}
	else if (type == FX_PARTICLE_SYSTEM)
	{
		psys->MoveTo(x-mSceneMgr->gx+offset_x*v_scale, y-mSceneMgr->gy+offset_y*h_scale);
		psys->Transpose(mSceneMgr->gx, mSceneMgr->gy);
		psys->Render();
	}
}

void Effect::SetColor(DWORD col)
{
	if (type == FX_ANIMATED_EFFECT)
	{
		anim->SetColor(col);
	}
}

void Effect::Play()
{
	if (type == FX_ANIMATED_EFFECT)
	{
		anim->Play();
	}
	else if (type == FX_PARTICLE_SYSTEM)
	{
		psys->Fire();
	}
}

void Effect::Stop()
{
	if (type == FX_ANIMATED_EFFECT)
	{
		anim->Stop();
	}
	else if (type == FX_PARTICLE_SYSTEM)
	{
		psys->Stop();
	}
}

void Effect::Update(float dt)
{
	if (type == FX_ANIMATED_EFFECT)
	{
		anim->Update(dt);
	}
	else if (type == FX_PARTICLE_SYSTEM)
	{
		psys->Update(dt);
	}
}

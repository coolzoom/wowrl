/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          InputManager source           */
/*                                        */
/*  ## : ...                              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_timemanager.h"
#include "wowrl_inputmanager.h"

#include "memory.h"

#define INPUT_LONGPRESS_DELAY 0.7f

extern TimeManager *mTimeMgr;
extern HGE *hge;

InputManager::InputManager()
{
	QueryPerformanceFrequency(&freq);

	QueryPerformanceCounter(&os);

	gmx = 0.0f; gmy = 0.0f;
	dmx = 0.0f; dmy = 0.0f;
	old_mx = 0.0f; old_my = 0.0f;

	iFPS = 0;

	memset(key_delay, 0, 256 * sizeof(float));
	memset(key_long, 0, 256 * sizeof(bool));
	memset(key_buf, 0, 256 * sizeof(bool));
	memset(key_buf_old, 0, 256 * sizeof(bool));
	doubleclickDelay[0] = 0;
	doubleclickDelay[1] = 0;
	doubleclickDelay[2] = 0;
	doubleclickTime = 0.25;

	ctrlPressed = false;
	shiftPressed = false;
	altPressed = false;

	lastDragged = false;

	focus = false;
}

InputManager* InputManager::mInputMgr = NULL;

InputManager* InputManager::getSingleton()
{
	if (mInputMgr == NULL)
		mInputMgr = new InputManager;
	return mInputMgr;
}

double InputManager::GetTime()
{
	QueryPerformanceCounter(&ts);
	return (double)ts.QuadPart/(double)freq.QuadPart;
}

double InputManager::GetDelta()
{
	if (dt > 0.001f)
		return dt;
	else
		return 1.0f/(double)iFPS;
}

int InputManager::GetFPS()
{
	return iFPS;
}

char InputManager::GetChar( bool format, bool force )
{
	if (!force && focus)
		return 0;
	else if (format)
	{
		// Filter non printable characters and special keys
		char c = hge->Input_GetChar();
		if ((c == 8)  || // Backspace
			(c == 9)  || // Tab
			(c == 13) || // Enter
			(c == 27)    // Escape
			)
			c = 0;
		return c;
	}
	else
		return hge->Input_GetChar();
}

bool InputManager::GetKey( bool force )
{
	if (!force && focus)
		return false;
	else
		return key;
}

void InputManager::GetMousePos()
{
	hge->Input_GetMousePos(&mx, &my);
}

bool InputManager::KeyIsDown( int index, bool force )
{
	if (!force && focus)
		return false;
	else
		return key_buf[index];
}

bool InputManager::KeyIsDownLong( int index, bool force )
{
	if (!force && focus)
		return false;
	else
		return (key_buf[index] && key_long[index]);
}

bool InputManager::KeyIsPressed( int index, bool force )
{
	if (!force && focus)
		return false;
	else
		return (key_buf[index] && !key_buf_old[index]);
}

bool InputManager::KeyIsReleased( int index, bool force )
{
	if (!force && focus)
		return false;
	else
		return (!key_buf[index] && key_buf_old[index]);
}

bool InputManager::KeyIsDoubleClicked( int index, bool force )
{
	if (!force && focus)
		return false;
	else
	{
		switch (index)
		{
			case HGEK_LBUTTON: return (KeyIsPressed(HGEK_LBUTTON) && doubleclickDelay[0]>0); break;
			case HGEK_RBUTTON: return (KeyIsPressed(HGEK_RBUTTON) && doubleclickDelay[1]>0); break;
			case HGEK_MBUTTON: return (KeyIsPressed(HGEK_MBUTTON) && doubleclickDelay[2]>0); break;
		}
		return false;
	}
}

void InputManager::Update()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->getProfiler(0, "InputManager::Update", false);
		Chrono c(prof);
	#endif

	// Get delta time
	/*double time = GetTime();
	dt = time - lastTime;
	lastTime = time;*/

	QueryPerformanceCounter(&ts);
	dt = (double)(ts.QuadPart-os.QuadPart)/(double)freq.QuadPart;
	os = ts;

	// Update FPS
	static float timer = 0.0f;
	static int   frameRateCount = 0;
	static int   frameCount = 0;
	timer -= dt;
	frameCount++;

	if (dt <= 0.001f)
		frameRateCount += 1000;
	else
		frameRateCount += (int)(1/dt);

	if (timer < 0.0f)
	{
		iFPS = frameRateCount/frameCount;
		frameRateCount = 0;
		frameCount = 0;
		timer = 1.0f;
	}

	// Update keys
	for (int i = 0; i < 256; i++)
		key_buf_old[i] = key_buf[i];

	// Control extreme dTime after loading/at startup etc
	float delta = dt;
	if (delta<0 || delta>1)
		delta = 0.05f;

	doubleclickDelay[0] -= delta;
	doubleclickDelay[1] -= delta;
	doubleclickDelay[2] -= delta;

	if(key_buf[HGEK_LBUTTON])
		doubleclickDelay[0] = doubleclickTime;
	if(key_buf[HGEK_RBUTTON])
		doubleclickDelay[1] = doubleclickTime;
	if(key_buf[HGEK_MBUTTON])
		doubleclickDelay[2] = doubleclickTime;

	key = false;
	for (int i = 0; i < 256; i++)
	{
		key_buf[i] = hge->Input_GetKeyState(i);
		// Get if any key has been pressed (exclude mouse buttons)
		if ( key_buf[i] && (i!=1) && (i!=2) && (i!=4) ) key = true;
	}

	// Update delays
	for (int i = 0; i < 256; i++)
	{
		if (key_buf[i])
		{
			key_delay[i] += dt;
			if (key_delay[i] >= INPUT_LONGPRESS_DELAY)
				key_long[i] = true;
		}
		else
		{
			key_delay[i] = 0.0f;
			key_long[i] = false;
		}
	}

	// Update mouse
	GetMousePos();

	dmx = old_mx-mx;
	dmy = old_my-my;
	old_mx = mx;
	old_my = my;

	gmx = mx-gx;
	gmy = my-gy;

	// Handle left mouse button
	if (KeyIsDown(HGEK_LBUTTON, true))
	{
		if (KeyIsPressed(HGEK_LBUTTON, true))
			mLState = 2; // single pressed
		else if(KeyIsDoubleClicked(HGEK_LBUTTON, true))
			mLState = 4; // double clicked
		else
			mLState = 1; // dragged

		mouseButton = "LeftButton";
	}
	else if (KeyIsReleased(HGEK_LBUTTON, true))
	{
		mLState = 3; // released
		mouseButton = "LeftButton";
	}
	else
	{
		mLState = 0; // no input
		if (mRState == 0)
			mouseButton = "";
	}

	// Handle right mouse button
	if (KeyIsDown(HGEK_RBUTTON, true))
	{
		if (KeyIsPressed(HGEK_RBUTTON, true))
			mRState = 2;
		else if (KeyIsDoubleClicked(HGEK_RBUTTON, true))
			mRState = 4;
		else
			mRState = 1;

		if (mouseButton == "LeftButton")
			mouseButton = "BothButtons";
		else
			mouseButton = "RightButton";
	}
	else if (KeyIsReleased(HGEK_RBUTTON, true))
	{
		mRState = 3;
		if (mouseButton == "LeftButton")
			mouseButton = "BothButtons";
		else
			mouseButton = "RightButton";
	}
	else
	{
		mRState = 0;
		if (mLState == 0)
			mouseButton = "";
	}

	if (KeyIsDown(HGEK_CTRL, true))
		ctrlPressed = true;
	else
		ctrlPressed = false;

	if (KeyIsDown(HGEK_SHIFT, true))
		shiftPressed = true;
	else
		shiftPressed = false;

	if (KeyIsDown(HGEK_ALT, true))
		altPressed = true;
	else
		altPressed = false;
}

void InputManager::SetDoubleclickTime( float setTime )
{
	doubleclickTime = setTime;
}

void InputManager::SetGlobalDisplacement( float ngx, float ngy )
{
	gx = ngx; gy = ngy;
	gmx = mx-gx;
	gmy = my-gy;
}

void InputManager::SetFocus( bool f )
{
	focus = f;
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_lua.h"
#include "wowrl_unitmanager.h"
#include "wowrl_scenemanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_timemanager.h"
#include "wowrl_unit.h"

using namespace std;

extern SceneManager *mSceneMgr;
extern UnitManager *mUnitMgr;
extern GUIManager *mGUIMgr;
extern GFXManager *mGFXMgr;
extern TimeManager *mTimeMgr;
extern HGE *hge;

int l_getLeadingUnit( lua_State* luaVM )
{
	if (mUnitMgr->leadingUnit != NULL)
		lua_pushstring(luaVM, mUnitMgr->leadingUnit->getName().c_str());
	else
		lua_pushnil(luaVM);

	return 1;
}

int l_Unit_spawn( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 6)
	{
		mlua_printError("Too few arguments in \"UnitSpawn\" (6 expected : unit name, x, y, level, class, speed)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSpawn must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSpawn must be a number (x)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitSpawn must be a number (y)");
		error++;
	}
	if (!lua_isnumber(luaVM, 4))
	{
		mlua_printError("Argument 4 of UnitSpawn must be a number (level)");
		error++;
	}
	if (!lua_isstring(luaVM, 5))
	{
		mlua_printError("Argument 5 of UnitSpawn must be a string (class)");
		error++;
	}
	if (!lua_isnumber(luaVM, 6))
	{
		mlua_printError("Argument 6 of UnitSpawn must be a number (speed)");
		error++;
	}

	if (error == 0)
	{
		mUnitMgr->createUnit
		(
			lua_tostring(luaVM, 1),
			lua_tonumber(luaVM, 2),
			lua_tonumber(luaVM, 3),
			(int)lua_tonumber(luaVM, 4),
			mUnitMgr->getClass(lua_tostring(luaVM, 5)),
			lua_tonumber(luaVM, 6)
		);
		mGFXMgr->forceUpdate();
	}
	return 0;
}

int l_Unit_addEffect( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitAddEffect\" (2 expected : unit name, effect name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitAddEffect must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitAddEffect must be a string (effect name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				string fx = lua_tostring(luaVM, 2);
				if (mGFXMgr->FXList.find(fx) == mGFXMgr->FXList.end())
					hge->System_Log("# ERROR # : Unknown effect \"%s\"", fx.c_str());
				else
					u->addEffect(fx);
			}
		}
	}
	return 0;
}

int l_Unit_setHostile( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitSetHostile\" (2 expected : unit name, hostile)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSetHostile must be a string (unit name)");
		error++;
	}
	if (!lua_isboolean(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSetHostile must be a bool (hostile)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
				u->setHostile(lua_toboolean(luaVM, 2));
		}
	}
	return 0;
}

int l_Unit_setMaxHP( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		mlua_printError("Too few arguments in \"UnitSetMaxHP\" (3 expected : unit name, hp, fill to max)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSetMaxHP must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSetMaxHP must be a number (hp)");
		error++;
	}
	if (!lua_isboolean(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitSetMaxHP must be a bool (fill to max)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
				u->setMaxHealth(lua_tonumber(luaVM, 2), lua_toboolean(luaVM, 3));
		}
	}
	return 0;
}

int l_Unit_setAggroRange( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitSetAggroRange\" (2 expected : unit name, aggro range)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSetAggroRange must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSetAggroRange must be a number (aggro range)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
				u->setAggroRange(lua_tonumber(luaVM, 2));
		}
	}
	return 0;
}

int l_Unit_getMaxMana( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitMaxMana\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitMaxMana must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				float mmana = u->getMaxMana();
				lua_pushnumber(luaVM, mmana);
			}
			else
				lua_pushnumber(luaVM, 1);
		}
		else
			lua_pushnumber(luaVM, 1);
	}
	return 1;
}

int l_Unit_getMaxHealth( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitMaxHealth\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitMaxHealth must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				float mhealth = u->getMaxHealth();
				lua_pushnumber(luaVM, mhealth);
			}
			else
				lua_pushnumber(luaVM, 1);
		}
		else
			lua_pushnumber(luaVM, 1);
	}
	return 1;
}

int l_Unit_getMana( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitMana\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitMana must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				float mana = u->getMana();
				lua_pushnumber(luaVM, mana);
			}
			else
				lua_pushnumber(luaVM, 0);
		}
		else
			lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_getLevel( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitLevel\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitLevel must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				int lvl = u->getLvl();
				lua_pushnumber(luaVM, lvl);
			}
			else
				lua_pushnumber(luaVM, 0);
		}
		else
			lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_getHealth( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitHealth\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitHealth must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				float health = u->getHealth();
				lua_pushnumber(luaVM, health);
			}
			else
				lua_pushnumber(luaVM, 0);
		}
		else
			lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_getPowerType( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitPowerType\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitPowerType must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				int p = u->getPowerType();
				lua_pushnumber(luaVM, p);
			}
		}
	}
	return 1;
}

int l_Unit_getY( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitY\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitY must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				float y = u->getGY();
				lua_pushnumber(luaVM, y);
			}
			else
				lua_pushnumber(luaVM, 0);
		}
		else
			lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_getX( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitX\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitX must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				float x = u->getGX();
				lua_pushnumber(luaVM, x);
			}
			else
				lua_pushnumber(luaVM, 0);
		}
		else
			lua_pushnumber(luaVM, 0);
	}
	return 1;
}

int l_Unit_getTarget( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitTarget\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitTarget must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				Unit* t = u->getTarget();
				if (t != NULL)
				{
					string str = t->getName().c_str();
					lua_pushstring(luaVM, str.c_str());
				}
				else
					lua_pushnil(luaVM);
			}
			else
				lua_pushnil(luaVM);
		}
		else
			lua_pushnil(luaVM);
	}
	return 1;
}

int l_Unit_isTargetInRange( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitIsTargetInRange\" (2 expected : unit name, spell name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitIsTargetInRange must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitIsTargetInRange must be a string (spell name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		string sname = lua_tostring(luaVM, 2);
		if ( (uname != "") && (sname != "") )
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				Spell* s = &mUnitMgr->spellList[sname];
				if (s->name != "")
				{
					bool r = u->isTargetInRange(s);
					lua_pushboolean(luaVM, r);
				}
				else
					lua_pushboolean(luaVM, false);
			}
			else
				lua_pushboolean(luaVM, false);
		}
		else
			lua_pushboolean(luaVM, false);
	}
	return 1;
}

int l_Unit_isDead( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitIsDead\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitIsDead must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				bool d = u->isDead();
				lua_pushboolean(luaVM, d);
			}
			else
				lua_pushboolean(luaVM, false);
		}
		else
			lua_pushboolean(luaVM, false);
	}
	return 1;
}

int l_Unit_isHostile( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitIsHostile\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitIsHostile must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				bool h = u->isHostile();
				lua_pushboolean(luaVM, h);
			}
			else
				lua_pushboolean(luaVM, false);
		}
		else
			lua_pushboolean(luaVM, false);
	}
	return 1;
}

int l_Unit_setTarget( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitSetTarget\" (2 expected : unit name, target name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSetTarget must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSetTarget must be a string (target name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		string tname = lua_tostring(luaVM, 2);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
				u->target(mUnitMgr->getUnitByName(tname));
		}
	}

	return 0;
}

int l_Unit_setX( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitSetX\" (2 expected : unit name, x)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSetX must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSetX must be a string (x)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
				u->setX(lua_tonumber(luaVM, 2));
		}
	}

	return 0;
}

int l_Unit_setY( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitSetY\" (2 expected : unit name, y)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSetY must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSetY must be a number (y)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
				u->setY(lua_tonumber(luaVM, 2));
		}
	}

	return 0;
}

int l_Unit_addItem( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitAddItem\" (2 expected : unit name, item id)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitAddItem must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitAddItem must be a number (item id)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
				u->getInventory()->addItem(mSceneMgr->parseItem(toInt(lua_tonumber(luaVM, 2))));
		}
	}
	return 0;
}

int l_Unit_getActionTexture( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitGetActionTexture\" (2 expected : unit name, action id)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitGetActionTexture must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitGetActionTexture must be a number (action id)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				int i = toInt(lua_tonumber(luaVM, 2));
				if ( (i <= 120) && (i >= 0) )
				{
					ActionButton ab = u->getABList()[i];
					if (ab.spell != NULL)
					{
						if (ab.type == GUI_CASTBUTTON_SPELL)
						{
							lua_pushstring(luaVM, ab.spell->iconPath.c_str());
						}
						else if (ab.type == GUI_CASTBUTTON_STOP)
							lua_pushstring(luaVM, "Icons/Stop.png");
						else
							lua_pushstring(luaVM, "");
					}
					else
						lua_pushstring(luaVM, "");

				}
				else
					lua_pushstring(luaVM, "");
			}
			else
				lua_pushstring(luaVM, "");
		}
		else
			lua_pushstring(luaVM, "");
	}
	else
		lua_pushstring(luaVM, "");

	return 1;
}

int l_Unit_getActionInfo( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitGetActionInfo\" (2 expected : unit name, action id)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitGetActionInfo must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitGetActionInfo must be a number (action id)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				int i = toInt(lua_tonumber(luaVM, 2));
				if ( (i <= 120) && (i >= 0) )
				{
					ActionButton ab = u->getABList()[i];
					if (ab.spell != NULL)
					{
						if (ab.type == GUI_CASTBUTTON_SPELL)
						{
							lua_pushstring(luaVM, "spell");
						}
						else if (ab.type == GUI_CASTBUTTON_STOP)
							lua_pushstring(luaVM, "stop");
						else
							lua_pushstring(luaVM, "");
					}
					else
						lua_pushstring(luaVM, "");

				}
				else
					lua_pushstring(luaVM, "");
			}
			else
				lua_pushstring(luaVM, "");
		}
		else
			lua_pushstring(luaVM, "");
	}
	else
		lua_pushstring(luaVM, "");

	return 1;
}

int l_Unit_isActionInRange( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitIsActionInRange\" (2 expected : unit name, action id)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitIsActionInRange must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitIsActionInRange must be a number (action id)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				Unit* t = u->getTarget();
				if (t != NULL)
				{
					int i = toInt(lua_tonumber(luaVM, 2));
					if ( (i <= 120) && (i >= 0) )
					{
						ActionButton ab = u->getABList()[i];
						if (ab.type == GUI_CASTBUTTON_SPELL)
						{
							if (ab.spell != NULL)
							{
								lua_pushnumber(luaVM, u->isTargetInRange(ab.spell));
							}
							else
								lua_pushnil(luaVM);
						}
						else
							lua_pushnil(luaVM);
					}
					else
						lua_pushnil(luaVM);
				}
				else
					lua_pushnil(luaVM);
			}
			else
				lua_pushnil(luaVM);
		}
		else
			lua_pushnil(luaVM);
	}
	else
		lua_pushnil(luaVM);

	return 1;
}

int l_Unit_isUsableAction( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitIsUsableAction\" (2 expected : unit name, action id)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitIsUsableAction must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitIsUsableAction must be a number (action id)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (uname != "")
		{
			Unit* u = mUnitMgr->getUnitByName(uname);
			if (u != NULL)
			{
				int i = toInt(lua_tonumber(luaVM, 2));
				if ( (i <= 120) && (i >= 0) )
				{
					ActionButton ab = u->getABList()[i];
					if (ab.type == GUI_CASTBUTTON_SPELL)
					{
						if (ab.spell != NULL)
						{
							string reason;
							lua_pushnumber(luaVM, u->isCastable(ab.spell, &reason, true));
							if (reason == "error_out_of_mana")
								lua_pushnumber(luaVM, 1);
							else
								lua_pushnil(luaVM);
						}
						else
						{
							lua_pushnil(luaVM);
							lua_pushnil(luaVM);
						}
					}
					else
					{
						lua_pushnil(luaVM);
						lua_pushnil(luaVM);
					}
				}
				else
				{
					lua_pushnil(luaVM);
					lua_pushnil(luaVM);
				}
			}
			else
			{
				lua_pushnil(luaVM);
				lua_pushnil(luaVM);
			}
		}
		else
		{
			lua_pushnil(luaVM);
			lua_pushnil(luaVM);
		}
	}
	else
	{
		lua_pushnil(luaVM);
		lua_pushnil(luaVM);
	}

	return 2;
}

int l_Unit_castSpell( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitCastSpell\" (3 expected : unit name, spell id, spell book)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitCastSpell must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitCastSpell must be a number (spell id)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitCastSpell must be a string (spell book)");
		error++;
	}

	if (error == 0)
	{
		int spellID = toInt(lua_tonumber(luaVM, 2));
		if ( (spellID >= 0) && (spellID <= 120) )
		{
			Unit* u = &mUnitMgr->unitList[lua_tostring(luaVM, 1)];
			if (u != NULL)
			{
				ActionButton* ab = &u->getABList()[spellID];
				Spell* s = ab->spell;
				if (s != NULL)
				{
					Unit* t = u->getTarget();
					if (t != NULL)
					{
						if (ab->type == GUI_CASTBUTTON_SPELL)
						{
							string reason;
							if (u->isCastable(s, &reason))
							{
								u->stop();
								if (s->self_only)
									u->incant(s, u);
								else
									u->incant(s, t);
							}
							else
								mGUIMgr->addErrorMessage(u->getName() + " : " + mSceneMgr->strTable->GetString(reason.c_str()));
						}
						else if (ab->type == GUI_CASTBUTTON_STOP)
						{
							u->stop();
						}
					}
					else
					{
						if (ab->type == GUI_CASTBUTTON_SPELL)
						{
							string reason;
							if (u->isCastable(s, &reason, true, true))
							{
								mUnitMgr->castedButton = ab;
								mUnitMgr->casterUnit = u;

								if (!s->self_only)
									mUnitMgr->castingSpell = true;

								if (s->self_only)
								{
									u->stop();
									u->incant(s, u);
								}
								else
									mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action_imp");
							}
							else
								mGUIMgr->addErrorMessage(u->getName() + " : " + mSceneMgr->strTable->GetString(reason.c_str()));
						}
						else if (ab->type == GUI_CASTBUTTON_STOP)
						{
							u->stop();
						}
					}
				}
			}
		}
	}

	return 0;
}

int l_Unit_castSpellIndirect( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitCastSpellIndirect\" (3 expected : unit name, spell id, spell book)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitCastSpellIndirect must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitCastSpellIndirect must be a number (spell id)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitCastSpellIndirect must be a string (spell book)");
		error++;
	}

	if (error == 0)
	{
		int spellID = toInt(lua_tonumber(luaVM, 2));
		if ( (spellID >= 0) && (spellID <= 120) )
		{
			Unit* u = &mUnitMgr->unitList[lua_tostring(luaVM, 1)];
			if (u != NULL)
			{
				ActionButton* ab = &u->getABList()[spellID];
				Spell* s = ab->spell;
				if (s != NULL)
				{
					if (ab->type == GUI_CASTBUTTON_SPELL)
					{
						string reason;
						if (u->isCastable(s, &reason, true, true))
						{
							mUnitMgr->castedButton = ab;
							mUnitMgr->casterUnit = u;

							if (!s->self_only)
								mUnitMgr->castingSpell = true;

							if (s->self_only)
							{
								u->stop();
								u->incant(s, u);
							}
							else
								mGUIMgr->cursor = mGUIMgr->switchCursor("normal_action_imp");
						}
						else
							mGUIMgr->addErrorMessage(u->getName() + " : " + mSceneMgr->strTable->GetString(reason.c_str()));
					}
					else if (ab->type == GUI_CASTBUTTON_STOP)
					{
						u->stop();
					}
				}
			}
		}
	}

	return 0;
}

int l_Unit_isCasting( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitIsCasting\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitIsCasting must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (mUnitMgr->unitList.find(uname) != mUnitMgr->unitList.end())
		{
			Unit* u = &mUnitMgr->unitList[uname];
			if(u->isCasting())
			{
				if (!u->getSpell()->channeled)
				{
					lua_pushstring(luaVM, "SPELL");
				}
				else
				{
					lua_pushstring(luaVM, "CHANNELED");
				}
			}
			else
				lua_pushstring(luaVM, "");
		}
		else
			lua_pushstring(luaVM, "");
	}
	else
		lua_pushstring(luaVM, "");

	return 1;
}

int l_Unit_castingInfo( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitCastingInfo\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitCastingInfo must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (mUnitMgr->unitList.find(uname) != mUnitMgr->unitList.end())
		{
			Unit* u = &mUnitMgr->unitList[uname];
			if (u->isCasting())
			{
				Spell* s = u->getSpell();
				lua_pushstring(luaVM, s->name.c_str());
				if (s->rank != -1)
					lua_pushstring(luaVM, string(string(mSceneMgr->strTable->GetString("gui_cb_rank")) + string(" ") + toString(s->rank)).c_str());
				else
					lua_pushstring(luaVM, "");
				lua_pushstring(luaVM, mSceneMgr->strTable->GetString(s->display_name.c_str()));
				lua_pushstring(luaVM, s->iconPath.c_str());
				lua_pushnumber(luaVM, (mTimeMgr->GetTime()-u->getActionState()*s->cast_time)*1000);
				lua_pushnumber(luaVM, (mTimeMgr->GetTime()+(1-u->getActionState())*s->cast_time)*1000);
			}
			else
			{
				for (int i = 0; i < 6; i++)
					lua_pushnil(luaVM);
			}
		}
		else
		{
			for (int i = 0; i < 6; i++)
				lua_pushnil(luaVM);
		}
	}
	else
	{
		for (int i = 0; i < 6; i++)
			lua_pushnil(luaVM);
	}

	return 6;
}

int l_Unit_getSpellInfo( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 2)
	{
		mlua_printError("Too few arguments in \"UnitSpellInfo\" (2 expected : unit name, spell id)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitSpellInfo must be a string (unit name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitSpellInfo must be a number (spell id)");
		error++;
	}

	if (error == 0)
	{
		int spellID = toInt(lua_tonumber(luaVM, 2));
		if ( (spellID >= 0) && (spellID <= 120) )
		{
			Unit* u = &mUnitMgr->unitList[lua_tostring(luaVM, 1)];
			if (u != NULL)
			{
				ActionButton* ab = &u->getABList()[spellID];
				if (ab != NULL)
				{
					Spell* s = ab->spell;
					if (s != NULL)
					{
						lua_getglobal(luaVM, "Spells");
						lua_getfield(luaVM, -1, s->name.c_str());
					}
					else
						lua_pushnil(luaVM);
				}
				else
					lua_pushnil(luaVM);
			}
			else
				lua_pushnil(luaVM);
		}
		else
			lua_pushnil(luaVM);
	}
	else
		lua_pushnil(luaVM);

	return 1;
}

int l_Unit_setAttacking( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitSetAttacking\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitSetAttacking must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (mUnitMgr->unitList.find(uname) != mUnitMgr->unitList.end())
		{
			Unit* u = &mUnitMgr->unitList[uname];
			u->attacking = true;
			mUnitMgr->attackerList[u->getName()] = u;
			mUnitMgr->actingList[u->getName()] = u;
		}
	}

	return 0;
}

int l_Unit_setHealing( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitSetHealing\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitSetHealing must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (mUnitMgr->unitList.find(uname) != mUnitMgr->unitList.end())
		{
			Unit* u = &mUnitMgr->unitList[uname];
			u->healing = true;
			mUnitMgr->healerList[u->getName()] = u;
			mUnitMgr->actingList[u->getName()] = u;
		}
	}

	return 0;
}

int l_Unit_setResurrecting( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitSetResurrecting\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitSetResurrecting must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (mUnitMgr->unitList.find(uname) != mUnitMgr->unitList.end())
		{
			Unit* u = &mUnitMgr->unitList[uname];
			u->resurrecting = true;
			mUnitMgr->reserList[u->getName()] = u;
			mUnitMgr->actingList[u->getName()] = u;
		}
	}

	return 0;
}

int l_Unit_damage( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 6)
	{
		mlua_printError("Too few arguments in \"UnitDamage\" (6 expected : unit name, caster name, spell name, damages, generate aggro, scrolling text)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitDamage must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitDamage must be a string (caster name)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitDamage must be a string (spell name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 4))
	{
		mlua_printError("Argument 4 of UnitDamage must be a number (dammages)");
		error++;
	}
	if (!lua_isboolean(luaVM, 5))
	{
		mlua_printError("Argument 5 of UnitDamage must be a bool (generate aggro)");
		error++;
	}
	if (!lua_isboolean(luaVM, 6))
	{
		mlua_printError("Argument 6 of UnitDamage must be a bool (scrolling text)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		string cname = lua_tostring(luaVM, 2);
		string sname = lua_tostring(luaVM, 3);
		if (mUnitMgr->unitList.find(uname) != mUnitMgr->unitList.end())
		{
			if (mUnitMgr->unitList.find(cname) != mUnitMgr->unitList.end())
			{
				if (mUnitMgr->spellList.find(sname) != mUnitMgr->spellList.end())
				{
					Unit* u = &mUnitMgr->unitList[uname];
					Unit* c = &mUnitMgr->unitList[cname];
					Spell* s = &mUnitMgr->spellList[sname];
					int value = toInt(lua_tonumber(luaVM, 4));
					u->damage(s, c, value, lua_toboolean(luaVM, 5));

					int type;
					if (s->school == SPELL_SCHOOL_NONE)
						type = GUI_SCRTXT_TYPE_PHYSICAL;
					else
						type = GUI_SCRTXT_TYPE_SPELL;

					if (lua_toboolean(luaVM, 6))
						mGUIMgr->addScrollingText(u, type, toString(value));
				}
			}
		}
	}

	return 0;
}

int l_Unit_heal( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 5)
	{
		mlua_printError("Too few arguments in \"UnitHeal\" (5 expected : unit name, caster name, healings, generate aggro, scrolling text)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitHeal must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitHeal must be a string (caster name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitHeal must be a number (healings)");
		error++;
	}
	if (!lua_isboolean(luaVM, 4))
	{
		mlua_printError("Argument 4 of UnitHeal must be a bool (generate aggro)");
		error++;
	}
	if (!lua_isboolean(luaVM, 5))
	{
		mlua_printError("Argument 5 of UnitHeal must be a bool (scrolling text)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		string cname = lua_tostring(luaVM, 2);
		if (mUnitMgr->unitList.find(uname) != mUnitMgr->unitList.end())
		{
			if (mUnitMgr->unitList.find(cname) != mUnitMgr->unitList.end())
			{
				Unit* u = &mUnitMgr->unitList[uname];
				Unit* c = &mUnitMgr->unitList[cname];
				int value = toInt(lua_tonumber(luaVM, 3));
				u->heal(c, value, lua_toboolean(luaVM, 4));
				if (lua_toboolean(luaVM, 5))
					mGUIMgr->addScrollingText(u, GUI_SCRTXT_TYPE_HEAL, toString(value));
			}
		}
	}

	return 0;
}

int l_Unit_res( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 4)
	{
		mlua_printError("Too few arguments in \"UnitRes\" (4 expected : unit name, caster name, health gained, mana gained)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitRes must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitRes must be a string (caster name)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitRes must be a number (health gained)");
		error++;
	}
	if (!lua_isnumber(luaVM, 4))
	{
		mlua_printError("Argument 4 of UnitRes must be a number (mana gained)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		string cname = lua_tostring(luaVM, 2);
		if (mUnitMgr->unitList.find(uname) != mUnitMgr->unitList.end())
		{
			if (mUnitMgr->unitList.find(cname) != mUnitMgr->unitList.end())
			{
				Unit* u = &mUnitMgr->unitList[uname];
				Unit* c = &mUnitMgr->unitList[cname];
				int health = toInt(lua_tonumber(luaVM, 3));
				int mana = toInt(lua_tonumber(luaVM, 4));
				u->res(health, mana, c);
			}
		}
	}

	return 0;
}

int l_Unit_addBuff( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		mlua_printError("Too few arguments in \"UnitAddBuff\" (3 expected : unit name, caster name, buff)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of UnitAddBuff must be a string (unit name)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of UnitAddBuff must be a string (caster name)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		mlua_printError("Argument 3 of UnitAddBuff must be a string (buff)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		string cname = lua_tostring(luaVM, 2);
		if (mUnitMgr->unitList.find(uname) != mUnitMgr->unitList.end())
		{
			if (mUnitMgr->unitList.find(cname) != mUnitMgr->unitList.end())
			{
				Unit* u = &mUnitMgr->unitList[uname];
				Unit* c = &mUnitMgr->unitList[cname];

				u->addBuff(lua_tostring(luaVM, 3));
			}
		}
	}

	return 0;
}

int l_Unit_getBuffs( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"UnitGetBuffs\" (one expected : unit name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of UnitGetBuff must be a string (unit name)");
		error++;
	}

	if (error == 0)
	{
		string uname = lua_tostring(luaVM, 1);
		if (mUnitMgr->unitList.find(uname) != mUnitMgr->unitList.end())
		{
			Unit* u = &mUnitMgr->unitList[uname];
			multimap<float, Buff*> buffList = u->getBuffList();
			lua_pushnumber(luaVM, buffList.size());

			lua_newtable(luaVM);
			multimap<float, Buff*>::iterator iterBuff;
			int i = 1;
			for (iterBuff = buffList.begin(); iterBuff != buffList.end(); iterBuff++)
			{
				Buff* b = iterBuff->second;
				lua_createtable(luaVM, 0, 2);
				mlua_setFieldFloat("time_remaining", b->buff->duration-b->life, luaVM);
				mlua_setFieldInt("count", b->count, luaVM);
				mlua_setFieldString("icon", b->buff->icon_file, luaVM);
				lua_rawseti(luaVM, -2, i);
			}
		}
	}

	return 2;
}

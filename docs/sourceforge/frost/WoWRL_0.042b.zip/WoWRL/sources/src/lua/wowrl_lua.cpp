/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               Lua source               */
/*                                        */
/*  ## : This file contains two things :  */
/*    - a lua interface for frequently    */
/*      used function combination.        */
/*    - the lua glues, to call the progs' */
/*      functions inside lua scripts.     */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_luaglues.h"

#include "wowrl_global.h"
#include "wowrl_scenemanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_timemanager.h"
#include "wowrl_gui.h"

#include <sstream>

using namespace std;

extern SceneManager *mSceneMgr;
extern GUIManager *mGUIMgr;
extern InputManager *mInputMgr;
extern TimeManager *mTimeMgr;
extern HGE *hge;

void mlua_registerAll( lua_State* luaVM )
{
	// [#] This function registers all the LUA methods and LUNAR classes.
	lua_register(luaVM, "LogPrint", l_logPrint);
	lua_register(luaVM, "RandomInt", l_randomInt);
	lua_register(luaVM, "RandomFloat", l_randomFloat);
	lua_register(luaVM, "StrReplace", l_strReplace);
	lua_register(luaVM, "StrCapitalStart", l_strCapitalStart);
	lua_register(luaVM, "GetDelta", l_getDelta);
	lua_register(luaVM, "GetLeadingUnit", l_getLeadingUnit);
	lua_register(luaVM, "GetLocale", l_getLocale);
	lua_register(luaVM, "GetLocalizedString", l_getLocalizedString);
	lua_register(luaVM, "GetTime", l_getTime);
	lua_register(luaVM, "GetTimeOfTheDay", l_getTimeOfTheDay);
	lua_register(luaVM, "GetGlobal", l_getGlobal);
	lua_register(luaVM, "GetMousePos", l_getMousePos);
	lua_register(luaVM, "RunScript", l_doString);

	lua_register(luaVM, "Gfx_createSprite", l_Gfx_createSprite);
	lua_register(luaVM, "Gfx_renderSprite", l_Gfx_renderSprite);
 	lua_register(luaVM, "Gfx_createAnimation", l_Gfx_createAnimation);
 	lua_register(luaVM, "Gfx_updateAnimation", l_Gfx_updateAnimation);
 	lua_register(luaVM, "Gfx_renderAnimation", l_Gfx_renderAnimation);
 	lua_register(luaVM, "Gfx_createPSys", l_Gfx_createPSys);
 	lua_register(luaVM, "Gfx_updatePSys", l_Gfx_updatePSys);
 	lua_register(luaVM, "Gfx_renderPSys", l_Gfx_renderPSys);

 	lua_register(luaVM, "GUI_createElement", l_GUI_createElement);

 	lua_register(luaVM, "UnitSpawn", l_Unit_spawn);
 	lua_register(luaVM, "UnitAddEffect", l_Unit_addEffect);
 	lua_register(luaVM, "UnitSetHostile", l_Unit_setHostile);
 	lua_register(luaVM, "UnitSetMaxHP", l_Unit_setMaxHP);
 	lua_register(luaVM, "UnitSetAggroRange", l_Unit_setAggroRange);
 	lua_register(luaVM, "UnitSetTarget", l_Unit_setTarget);
	lua_register(luaVM, "UnitSetX", l_Unit_setX);
	lua_register(luaVM, "UnitSetY", l_Unit_setY);
	lua_register(luaVM, "UnitIsHostile", l_Unit_isHostile);
	lua_register(luaVM, "UnitIsDead", l_Unit_isDead);
	lua_register(luaVM, "UnitIsTargetInRange", l_Unit_isTargetInRange);
	lua_register(luaVM, "UnitTarget", l_Unit_getTarget);
	lua_register(luaVM, "UnitX", l_Unit_getX);
	lua_register(luaVM, "UnitY", l_Unit_getY);
	lua_register(luaVM, "UnitLevel", l_Unit_getLevel);
	lua_register(luaVM, "UnitHealth", l_Unit_getHealth);
	lua_register(luaVM, "UnitMana", l_Unit_getMana);
	lua_register(luaVM, "UnitHealthMax", l_Unit_getMaxHealth);
	lua_register(luaVM, "UnitManaMax", l_Unit_getMaxMana);
	lua_register(luaVM, "UnitPowerType", l_Unit_getPowerType);
	lua_register(luaVM, "UnitAddItem", l_Unit_addItem);
	lua_register(luaVM, "UnitGetActionTexture", l_Unit_getActionTexture);
	lua_register(luaVM, "UnitGetActionInfo", l_Unit_getActionInfo);
	lua_register(luaVM, "UnitIsActionInRange", l_Unit_isActionInRange);
	lua_register(luaVM, "UnitIsUsableAction", l_Unit_isUsableAction);
	lua_register(luaVM, "UnitCastSpell", l_Unit_castSpell);
	lua_register(luaVM, "UnitCastSpellIndirect", l_Unit_castSpellIndirect);
	lua_register(luaVM, "UnitIsCasting", l_Unit_isCasting);
	lua_register(luaVM, "UnitCastingInfo", l_Unit_castingInfo);
	lua_register(luaVM, "UnitSpellInfo", l_Unit_getSpellInfo);
	lua_register(luaVM, "UnitSetAttacking", l_Unit_setAttacking);
	lua_register(luaVM, "UnitSetHealing", l_Unit_setHealing);
	lua_register(luaVM, "UnitSetResurrecting", l_Unit_setResurrecting);
	lua_register(luaVM, "UnitDamage", l_Unit_damage);
	lua_register(luaVM, "UnitHeal", l_Unit_heal);
	lua_register(luaVM, "UnitRes", l_Unit_res);
	lua_register(luaVM, "UnitAddBuff", l_Unit_addBuff);
	lua_register(luaVM, "UnitGetBuffs", l_Unit_getBuffs);

	Lunar<l_UIObject>::Register(luaVM);
	Lunar<l_Region>::Register(luaVM);
	Lunar<l_Frame>::Register(luaVM);
	Lunar<l_StatusBar>::Register(luaVM);
	Lunar<l_EditBox>::Register(luaVM);
	Lunar<l_ScrollingMessageFrame>::Register(luaVM);
	Lunar<l_Button>::Register(luaVM);
	Lunar<l_LayeredRegion>::Register(luaVM);
	Lunar<l_Texture>::Register(luaVM);
	Lunar<l_FontString>::Register(luaVM);

	lua_newtable(luaVM);
	lua_setglobal(luaVM, "Functions");
}

// Modified openlibs function to load my own libs
const luaL_Reg lualibs[] = {
	{"", luaopen_base},
	{LUA_LOADLIBNAME, luaopen_package},
	{LUA_TABLIBNAME, luaopen_table},
	{LUA_IOLIBNAME, luaopen_io},
	{LUA_OSLIBNAME, luaopen_os},
	{LUA_MSTRLIBNAME, mluaopen_string}, // Modified string lib
	{LUA_MATHLIBNAME, luaopen_math},
	{LUA_DBLIBNAME, luaopen_debug},
	{NULL, NULL}
};
void mluaL_openlibs(lua_State* luaVM)
{
	const luaL_Reg *lib = lualibs;
	for ( ; lib->func; lib++)
	{
		lua_pushcfunction(luaVM, lib->func);
		lua_pushstring(luaVM, lib->name);
		lua_call(luaVM, 1, 0);
	}
}

string mlua_concTable(lua_State* luaVM, string table )
{
	/* [#] This function converts a LUA table into a formated string. It is used
	/* to save the content of the table in the SavedVariables.
	*/
	string s = "";
	s += "tbl = \"" + table + "\";\n";
	s += "temp = \"\";\n";
	s += "for k, v in pairs (" + table + ") do\n";
	s += "local s, t;\n";
	s += "if (type(k) == \"number\") then\ns = k;\nend\n";
	s += "if (type(k) == \"string\") then\ns = \"\\\"\"..k..\"\\\"\";\nend\n";

	s += "if (type(v) == \"number\") then\nt = v;\nend\n";
	s += "if (type(v) == \"string\") then\nt = \"\\\"\"..v..\"\\\"\";\nend\n";
	s += "if (type(v) == \"boolean\") then\nif v then\nt = \"'true'\";\nelse\nt = \"'false'\";\nend\nend\n";
	s += "if (type(v) == \"table\") then\n";
	s += "t = \"'table'\";\nsendString(s..\" \"..t..\" \");\nconcTable(temp, tbl..\"[\"..s..\"]\");\n";
	s += "else\n";
	s += "sendString(s..\" \"..t..\" \");\n";
	s += "end\n";
	s += "end\n";
	s += "sendString(\"'end' \");\n";

	luaL_dostring(luaVM, s.c_str());

	return mSceneMgr->tmpString;
}

void mlua_printError( string error )
{
	lua_Debug d;
	lua_getstack(mSceneMgr->luaVM, 1, &d);
	lua_getinfo(mSceneMgr->luaVM, "Sl" , &d);
	string debugStr = string(d.short_src) + ", line " + toString(d.currentline)
				+ string(" : ") + error;
	lua_pushstring(mSceneMgr->luaVM, debugStr.c_str());
	l_logPrint(mSceneMgr->luaVM);
}

void mlua_print( string str )
{
	lua_pushstring(mSceneMgr->luaVM, str.c_str());
	l_logPrint(mSceneMgr->luaVM);
}

/* [#] The following functions are shortcuts to the LUA C API. They are very
/* usefull when dealing with tables, and allow default values.
*/
int mlua_getGlobalInt( string name, bool critical, int defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isnumber(mSceneMgr->luaVM, -1))
	{
		hge->System_Log("4 : %d", lua_gettop(mSceneMgr->luaVM));
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		int i = (int)lua_tonumber(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return i;
	}
}

float mlua_getGlobalFloat( string name, bool critical, float defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isnumber(mSceneMgr->luaVM, -1))
	{
		mlua_print("Field is expected to be a number");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		float f = lua_tonumber(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return f;
	}
}

string mlua_getGlobalString( string name, bool critical, string defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isstring(mSceneMgr->luaVM, -1))
	{
		mlua_print("Field is expected to be a string");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		string s = lua_tostring(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return s;
	}
}

bool mlua_getGlobalBool( string name, bool critical, bool defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isboolean(mSceneMgr->luaVM, -1))
	{
		mlua_print("Field is expected to be a bool");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		bool b = lua_toboolean(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return b;
	}
}

int mlua_getFieldInt( string name, bool critical, int defaultValue, bool setValue, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_getfield(luaVM, -1, name.c_str());
	if (lua_isnil(luaVM, -1))
	{
		lua_pop(luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else if (setValue)
		{
			mlua_setFieldInt(name, defaultValue, luaVM);
			return defaultValue;
		}
		else
			return defaultValue;
	}
	else if (!lua_isnumber(luaVM, -1))
	{
		mlua_print("Field is expected to be a number");
		lua_pop(luaVM, 1);
	}
	else
	{
		int i = (int)lua_tonumber(luaVM, -1);
		lua_pop(luaVM, 1);
		return i;
	}
}

float mlua_getFieldFloat( string name, bool critical, float defaultValue, bool setValue, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_getfield(luaVM, -1, name.c_str());
	if (lua_isnil(luaVM, -1))
	{
		lua_pop(luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else if (setValue)
		{
			mlua_setFieldFloat(name, defaultValue, luaVM);
			return defaultValue;
		}
		else
			return defaultValue;
	}
	else if (!lua_isnumber(luaVM, -1))
	{
		mlua_print("Field is expected to be a number");
		lua_pop(luaVM, 1);
	}
	else
	{
		float f = lua_tonumber(luaVM, -1);
		lua_pop(luaVM, 1);
		return f;
	}
}

string mlua_getFieldString( string name, bool critical, string defaultValue, bool setValue, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_getfield(luaVM, -1, name.c_str());
	if (lua_isnil(luaVM, -1))
	{
		lua_pop(luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else if (setValue)
		{
			mlua_setFieldString(name, defaultValue, luaVM);
			return defaultValue;
		}
		else
			return defaultValue;
	}
	else if (!lua_isstring(luaVM, -1))
	{
		mlua_print("Field is expected to be a string");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		string str = lua_tostring(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return str;
	}
}

bool mlua_getFieldBool( string name, bool critical, bool defaultValue, bool setValue, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_getfield(luaVM, -1, name.c_str());
	if (lua_isnil(luaVM, -1))
	{
		lua_pop(luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else if (setValue)
		{
			mlua_setFieldBool(name, defaultValue, luaVM);
			return defaultValue;
		}
		else
			return defaultValue;
	}
	else if (!lua_isboolean(luaVM, -1))
	{
		mlua_print("Field is expected to be a bool");
		lua_pop(luaVM, 1);
	}
	else
	{
		bool b = lua_toboolean(luaVM, -1);
		lua_pop(luaVM, 1);
		return b;
	}
}

void mlua_setFieldInt( string name, int value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushstring(luaVM, name.c_str());
	lua_pushnumber(luaVM, value);
	lua_settable(luaVM, -3);
}

void mlua_setFieldFloat( string name, float value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushstring(luaVM, name.c_str());
	lua_pushnumber(luaVM, value);
	lua_settable(luaVM, -3);
}

void mlua_setFieldString( string name, string value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushstring(luaVM, name.c_str());
	lua_pushstring(luaVM, value.c_str());
	lua_settable(luaVM, -3);
}

void mlua_setFieldBool( string name, bool value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushstring(luaVM, name.c_str());
	lua_pushboolean(luaVM, value);
	lua_settable(luaVM, -3);
}

void mlua_setIFieldInt( int id, int value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushnumber(luaVM, id);
	lua_pushnumber(luaVM, value);
	lua_settable(luaVM, -3);
}

void mlua_setIFieldFloat( int id, float value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushnumber(luaVM, id);
	lua_pushnumber(luaVM, value);
	lua_settable(luaVM, -3);
}

void mlua_setIFieldString( int id, string value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushnumber(luaVM, id);
	lua_pushstring(luaVM, value.c_str());
	lua_settable(luaVM, -3);
}

void mlua_setIFieldBool( int id, bool value, lua_State* luaVM )
{
	if (luaVM == NULL) luaVM = mSceneMgr->luaVM;
	lua_pushnumber(luaVM, id);
	lua_pushboolean(luaVM, value);
	lua_settable(luaVM, -3);
}

/* [#] The following functions are called "glues". They aren't used in C++ but
/* in the LUA environnement. To get a description of what they do, you can refer
/* to :
/*              http://www.wowwiki.com/World_of_Warcraft_API
/*
/* They aren't all described there, but the most complexe ones are. Their use is,
/* in many case, obvious. So I won't make a description for each : it would be
/* redundant.
*/

int l_sendString( lua_State* luaVM )
{
	mSceneMgr->tmpString += lua_tostring(luaVM, 1);

	return 0;
}

int l_concTable( lua_State* luaVM )
{
	string t = lua_tostring(luaVM, 1);
	string s = mlua_concTable(luaVM, lua_tostring(luaVM, 2));
	s = t+s;
	lua_pushstring(luaVM, s.c_str());

	return 1;
}

int l_logPrint( lua_State* luaVM )
{
	if (!lua_isstring(luaVM, -1))
		mlua_printError("Argument of LogPrint must be a string (caption)");
	else
		hge->System_Log("# LUA : %s", lua_tostring(luaVM, -1));

	return 0;
}

int l_randomInt( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"randomInt\" (2 expected : low, high)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of RandomInt must be a number (low)");
		error++;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 2 of RandomInt must be a number (high)");
		error++;
	}

	if (error == 0)
	{
		int low = toInt(lua_tonumber(luaVM, 1));
		int high = toInt(lua_tonumber(luaVM, 2));
		int rand = hge->Random_Int(low, high);
		lua_pushnumber(luaVM, rand);
	}

	return 1;
}

int l_randomFloat( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"RandomFloat\" (2 expected : low, high)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of RandomFloat must be a number (low)");
		error++;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 2 of RandomFloat must be a number (high)");
		error++;
	}

	if (error == 0)
	{
		float low = lua_tonumber(luaVM, 1);
		float high = lua_tonumber(luaVM, 2);
		float rand = hge->Random_Float(low, high);
		lua_pushnumber(luaVM, rand);
	}

	return 1;
}

int l_strReplace( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		mlua_printError("Too few arguments in \"StrReplace\" (3 expected : base string, pattern, replacement)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of StrReplace must be a string (base string)");
		error++;
	}
	if (!lua_isstring(luaVM, 2))
	{
		mlua_printError("Argument 2 of StrReplace must be a string (pattern)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		mlua_printError("Argument 3 of StrReplace must be a string (replacement)");
		error++;
	}

	if (error == 0)
	{
		string base = lua_tostring(luaVM, 1);
		int i = strReplace(&base, lua_tostring(luaVM, 2), lua_tostring(luaVM, 3));
		lua_pushstring(luaVM, base.c_str());
		lua_pushnumber(luaVM, i);
	}

	return 2;
}

int l_strCapitalStart( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"StrCapitalStart\" (one expected : base string)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of StrCapitalStart must be a string (base string)");
		error++;
	}

	if (error == 0)
	{
		lua_pushstring(luaVM, strCapitalStart(lua_tostring(luaVM, 1), true).c_str());
	}

	return 1;
}

int l_getDelta( lua_State* luaVM )
{
	lua_pushnumber(luaVM, mInputMgr->dt);

	return 1;
}

int l_getLocale( lua_State* luaVM )
{
	lua_pushstring(luaVM, mSceneMgr->locale.c_str());

	return 1;
}

int l_getLocalizedString( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"GetLocalizedString\" (one expected : string id)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of GetLocalizedString must be a string (string id)");
		error++;
	}

	if (error == 0)
	{
		lua_pushstring(luaVM, mSceneMgr->strTable->GetString(lua_tostring(luaVM, 1)));
	}

	return 1;
}

int l_getTime( lua_State* luaVM )
{
	lua_pushnumber(luaVM, mTimeMgr->GetTime());

	return 1;
}

int l_getTimeOfTheDay( lua_State* luaVM )
{
	lua_pushnumber(luaVM, mTimeMgr->GetHour());
	lua_pushnumber(luaVM, mTimeMgr->GetMinutes());
	lua_pushnumber(luaVM, mTimeMgr->GetSeconds());

	return 3;
}

int l_getGlobal( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"GetGlobal\" (one expected : variable name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of GetGlobal must be a string (variable name)");
		error++;
	}

	if (error == 0)
	{
		lua_getglobal(luaVM, lua_tostring(luaVM, 1));
	}
	return 1;
}

int l_getMousePos( lua_State* luaVM )
{
	float mx, my;
	hge->Input_GetMousePos(&mx,&my);
	lua_pushnumber(luaVM, mx);
	lua_pushnumber(luaVM, my);
	return 2;
}

int l_GUI_createElement( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"GUI_createElement\" (one expected : element name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of GUI_createElement must be a string (element name)");
		error++;
	}

	if (error == 0)
	{
		if (mGUIMgr->guiList.find(lua_tostring(luaVM, 1)) == mGUIMgr->guiList.end())
		{
			string name = lua_tostring(luaVM, 1);
			if (name != "")
			{
				GUIElement g;
				mGUIMgr->guiList[name] = g;
			}
		}

		lua_pushstring(luaVM, lua_tostring(luaVM, 1));
		return 1;
	}
	else
		return 0;
}

int l_doString( lua_State* luaVM )
{
	int error = 0;
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"DoString\" (one expected : string)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of DoString must be a string");
		error++;
	}

	if (error == 0)
	{
		int error = luaL_dostring(luaVM, lua_tostring(luaVM, 1));
		if (error) l_logPrint(luaVM);
	}

	return 0;
}

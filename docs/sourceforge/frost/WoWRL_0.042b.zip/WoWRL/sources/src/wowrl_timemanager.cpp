/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Profiler source             */
/*                                        */
/*  ## : A class that manages code        */
/*  profiling.                            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_timemanager.h"
#include "hge/hge.h"

#include <time.h>

using namespace std;

//extern TimeManager* mTimeMgr;
extern HGE* hge;

TimeManager::TimeManager()
{
	QueryPerformanceFrequency(&freq);
	profiled = false;
	profiling = false;
	last = GetTime();
	profileTime = 0.0f;
}

TimeManager* TimeManager::mTimeMgr = NULL;

TimeManager* TimeManager::getSingleton()
{
	if (mTimeMgr == NULL)
		mTimeMgr = new TimeManager;
	return mTimeMgr;
}

//returns the current tick count in seconds
double TimeManager::GetTime()
{
	QueryPerformanceCounter(&ts);
	return (double)ts.QuadPart/(double)freq.QuadPart;
}

Profiler* TimeManager::GetProfiler(int group, std::string name, bool autoPrint)
{
	if (profiling == true)
	{
		profiled = true;

		if (profilerList.find(name) == profilerList.end())
		{
			Profiler p(group, name, autoPrint);
			profilerList.insert(make_pair(name, p));
		}

		return &profilerList.find(name)->second;
	}
	else
		return NULL;
}

Profiler::Profiler(int g, string n, bool keep)
{
	name = n;
	group = g;
	callNbr = 0;
	totalTime = 0.0f;
	lowestTime = -1.0f;
	highestTime = -1.0f;
	keepRecords = keep;
}

Chrono::Chrono(Profiler* p)
{
	if (p != NULL)
		start = TimeManager::getSingleton()->GetTime();
	parent = p;
	stopped = false;
}

void Chrono::Stop()
{
	stopped = true;
	if (parent != NULL)
	{
		double time = TimeManager::getSingleton()->GetTime() - start;
		parent->AddTiming(time);
	}
}

double Chrono::GetTime()
{
	return TimeManager::getSingleton()->GetTime() - start;
}

Chrono::~Chrono()
{
	if ( (parent != NULL) && (!stopped) )
	{
		double time = TimeManager::getSingleton()->GetTime() - start;
		parent->AddTiming(time);
	}
}

void Profiler::AddTiming(double time)
{
	callNbr++;

	if ( (lowestTime == -1.0f) || (time < lowestTime) )
		lowestTime = time;
	if ( (highestTime == -1.0f) || (time > highestTime) )
		highestTime = time;

	totalTime += time;

	if (keepRecords)
		records.push_back(time);
}

void Profiler::SetKeepRecords(bool keep)
{
	keepRecords = keep;
}

void Profiler::PrintProfile(double profileTime)
{
	hge->System_Log("  - %s :", name.c_str());
	hge->System_Log("     - call number : %d", callNbr);
	hge->System_Log("     - total time : %f s (%.4f%% of total)", totalTime, 100*totalTime/profileTime);
	hge->System_Log("     - average time : %f ms", 1000*totalTime/callNbr);
	hge->System_Log("     - highest time : %f ms", 1000*highestTime);
	hge->System_Log("     - lowest time : %f ms", 1000*lowestTime);
	if (keepRecords)
	{
		hge->System_Log("     - listing records :");
		int i = 1;
		vector<double>::iterator iter;
		for (iter = records.begin(); iter != records.end(); iter++)
		{
			hge->System_Log("        [%d] : %f ms", i, (*iter)*1000);
			i++;
		}
	}
}

void TimeManager::SetProfiling(bool prof)
{
	// Update total profiling time
	if (prof && !profiling)
		last = GetTime();
	else if (!prof && profiling)
		profileTime = GetTime()-last;

	profiling = prof;
}

void TimeManager::Print(int group)
{
	if (profiled)
	{
		if (profiling)
		{
			profileTime = GetTime()-last;
			profiling = false;
		}

		if (group == -1)
			hge->System_Log("\n# Profiling info : %f s of profiling", profileTime);
		else
			hge->System_Log("\n# Profiling info for group [%d] : %f s of profiling", group, profileTime);
		map<string, Profiler>::iterator iter;
		for (iter = profilerList.begin(); iter != profilerList.end(); iter++)
		{
			Profiler* p = &iter->second;
			if ( (p->GetGroup() == group) || (group == -1) )
				p->PrintProfile(profileTime);
		}
		hge->System_Log("# end.");
	}
}

int TimeManager::GetYear()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_year + 1900;
}

int TimeManager::GetMonth()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_mon + 1;
}

int TimeManager::GetDayName()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_wday + 1;
}

int TimeManager::GetDay()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_mday;
}

int TimeManager::GetHour()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_hour;
}

int TimeManager::GetMinutes()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_min;
}

int TimeManager::GetSeconds()
{
	time_t timestamp = time(NULL);
	return localtime(&timestamp)->tm_sec;
}


/*****************************************************************/
/* # PeriodicTimer :                                             */
/* ------------------------------------------------------------- */
/*   This class is useful if you need a timer that automaticaly  */
/* resets itself every X seconds.                                */
/*****************************************************************/

PeriodicTimer::PeriodicTimer( double p, bool s, bool tickFirst )
{
	period = p;
	if (tickFirst) elapsed = p;
	else elapsed = 0.0f;
	if (s) Start();
}

// Returns the time elapsed since last reset.
double PeriodicTimer::GetElapsed()
{
	if (!paused)
		return elapsed + TimeManager::getSingleton()->GetTime() - start;
	else
		return elapsed;
}

// Returns true when the period is reached.
bool PeriodicTimer::Ticks()
{
	if (!paused)
	{
		if ((elapsed + TimeManager::getSingleton()->GetTime() - start) >= period)
		{
			Zero();
			return true;
		}
		else
			return false;
	}
	else
	{
		if (elapsed >= period)
			return true;
		else
			return false;
	}
}

// Stops and reset the timer.
void PeriodicTimer::Stop()
{
	elapsed = 0;
	paused = true;
}

// Starts the timer. Can be automatically called in the constructor.
void PeriodicTimer::Start()
{
	if (paused)
	{
		start = TimeManager::getSingleton()->GetTime();
		paused = false;
	}
}

// Stops the timer, but keeps the time elapsed.
void PeriodicTimer::Pause()
{
	if (!paused)
	{
		elapsed += TimeManager::getSingleton()->GetTime() - start;
		paused = true;
	}
}

// Resets the timer, but doesn't stop it.
void PeriodicTimer::Zero()
{
	elapsed = 0;
	start = TimeManager::getSingleton()->GetTime();
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_guimanager.h"

#include "wowrl_gui.h"

using namespace std;

extern GUIManager* mGUIMgr;
extern bool debugGUI;

int l_LayeredRegion::_init(lua_State* luaVM)
{
	if ( (name != "") && (pname != "") )
	{
		if (mGUIMgr->guiList.find(pname) != mGUIMgr->guiList.end())
		{
			base = &mGUIMgr->guiList[pname].arts[name];
			rbase = base;
			abase = base;
		}
	}

	return 0;
}

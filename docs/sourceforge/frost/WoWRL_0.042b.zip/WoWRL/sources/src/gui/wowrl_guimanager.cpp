/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           GUIManager source            */
/*                                        */
/*  ## : A class that manages the GUI,    */
/*  including parsing, rendering,         */
/*  interacting and destructing.          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_scenemanager.h"
#include "wowrl_unitmanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_lua.h"
#include "wowrl_statusbar.h"
#include "wowrl_gui.h"
#include "wowrl_xml.h"

#include "wowrl_guimanager.h"

#include <fstream>

#define CARRET_SPEED 0.05f

using namespace std;

extern TimeManager *mTimeMgr;
extern SceneManager *mSceneMgr;
extern InputManager *mInputMgr;
extern UnitManager *mUnitMgr;
extern GFXManager *mGFXMgr;
extern HGE *hge;

GUIManager::GUIManager()
{
}

void GUIManager::initValues()
{
	// Default values
	loadingBarX = mGFXMgr->sWidth/2.0f;
	loadingBarY = mGFXMgr->sHeight-160;

	defaultFont = NULL;
	cursor = NULL;

	iFuncCount = 1;

	focus = NULL;
	newFocus = false;

	targetLink1.tex = 0;
	targetLink1.blend = 0;
	targetLink2.tex = 0;
	targetLink2.blend = 0;
	targetLinkTimer = 0.0f;

	rebuildGUIList = true;

	RegisterEvents();
}

GUIManager* GUIManager::mGUIMgr = NULL;

GUIManager* GUIManager::getSingleton()
{
	if (mGUIMgr == NULL)
		mGUIMgr = new GUIManager;
	return mGUIMgr;
}

void GUIManager::createStatusBar( Unit* parent )
{
	StatusBar tmpSB;
	tmpSB.parent = parent;
	statusBarList[parent->getName()] = tmpSB;
}

void GUIManager::addScrollingText( Unit* parent, int type, string value )
{
	ScrollingText st;
	st.parent = parent;
	st.type = type;
	st.value = value;
	hgeRect* tmpRect = parent->getBox();
	st.x = (tmpRect->x1+tmpRect->x2)/2-mSceneMgr->gx;
	st.y = tmpRect->y1-40*parent->getScale()-mSceneMgr->gy;
	st.lifeTime = 0.0f;
	if (type == GUI_SCRTXT_TYPE_PHYSICAL)
		st.color = ARGB(255, 255, 0, 0);
	else if (type == GUI_SCRTXT_TYPE_HEAL)
		st.color = ARGB(255, 0, 255, 0);
	else if (type == GUI_SCRTXT_TYPE_SPELL)
		st.color = ARGB(255, 255, 205, 0);

	scrollingTextList[parent->getName() + "_" + toString(parent->getTextNbr())] = st;
}

void GUIManager::updateScrollingTexts()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->getProfiler(7, "GUIManager::updateScrollingTexts", false);
		Chrono c(prof);
	#endif
	if (!scrollingTextList.empty())
	{
		map<string, ScrollingText>::iterator iterText, lastParsed;
		lastParsed = NULL;
		for (iterText=scrollingTextList.begin(); iterText!=scrollingTextList.end(); iterText++)
		{
			ScrollingText* st = &iterText->second;
			if (st->lifeTime >= scrollingTextMaxLife)
			{
				scrollingTextList.erase(iterText);
				if (scrollingTextList.empty())
				{
					break;
				}
				else
				{
					if (lastParsed == NULL)
					{
						iterText = scrollingTextList.begin();
						continue;
					}
					else
					{
						iterText = lastParsed;
					}
				}
			}
			else
			{
				st->lifeTime += mInputMgr->dt;
				st->y -= scrollingTextSpeed*mInputMgr->dt;
				if (scrollingTextFade)
				{
					float alpha = 255*(1-(st->lifeTime/scrollingTextMaxLife));
					st->color = ARGB(alpha, GETR(st->color), GETG(st->color), GETB(st->color));
				}
			}
			lastParsed = iterText;
		}
	}
}

void GUIManager::renderScrollingTexts()
{
	if (!scrollingTextList.empty())
	{
		map<string, ScrollingText>::iterator iterText;
		for (iterText=scrollingTextList.begin(); iterText!=scrollingTextList.end(); iterText++)
		{
			ScrollingText* st = &iterText->second;
			scrollingTextFont->SetColor(st->color);
			scrollingTextFont->printf(
				st->x+mSceneMgr->gx, st->y+mSceneMgr->gy,
				HGETEXT_CENTER, "%s", st->value.c_str()
			);
		}
	}
}

Cursor* GUIManager::switchCursor( string nCurName )
{
	Cursor* cur;
	if (cursorList.find(nCurName) != cursorList.end())
	{
		cur = &cursorList[nCurName];
		if ( (cur->animated) && !(cur->anim->IsPlaying()) )
			cur->anim->Play();

		return cur;
	}
	else
		hge->System_Log("# ERROR # : Unknown cursor \"%s\".", nCurName.c_str());
}

void GUIManager::addErrorMessage( string caption )
{
	ErrorText eT;
	eT.caption = caption;
	eT.lifeTime = errorTextsDuration;
	eT.alpha = 255.0f;

	errorTextList.insert(errorTextList.begin(), eT);
	if (errorTextList.size() == 6)
		errorTextList.pop_back();
}

void GUIManager::updateErrorTexts()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->getProfiler(7, "GUIManager::updateErrorTexts", false);
		Chrono c(prof);
	#endif
	if (!errorTextList.empty())
	{
		vector<ErrorText>::iterator iter;
		iter = errorTextList.end();
		while (iter != errorTextList.begin())
		{
			iter--;
			iter->lifeTime -= mInputMgr->dt;
			if (iter->lifeTime <= 0.0f)
			{
				errorTextList.pop_back();
				iter = errorTextList.end();
			}
			else if (iter->lifeTime <= errorTextsFadeDelay)
			{
				iter->alpha = iter->lifeTime*51;
			}
		}
	}
}

FormatedText GUIManager::ParseFormatedText(FormatedText ft)
{
	if (ft.fnt != NULL)
	{
		ft.lFStr.clear();
		ft.sBaseStr = ft.sStr;

		int i = ft.sStr.find_first_of('|');

		int iCharRemoved = 0;
		map<int, int> lEquiv;

		// First save the position of all escape characters
		while (i != ft.sStr.npos)
		{
			int k = ft.sBaseStr.find_first_of('|', i+iCharRemoved);
			lEquiv[k] = i;
			// If "||" is found, replace it by a single "|"
			if (ft.sStr[i+1] == '|')
			{
				ft.sStr = ft.sStr.erase(i, 1);
				iCharRemoved += 1;
			}
			else if (ft.sStr[i+1] == 'c')
			{
				ft.sStr = ft.sStr.erase(i, 10);
				iCharRemoved += 10;
			}
			else if (ft.sStr[i+1] == 'r')
			{
				ft.sStr = ft.sStr.erase(i, 2);
				iCharRemoved += 2;
			}

			i = ft.sStr.find_first_of('|', i+1);
		}

		int lastPos = ft.sBaseStr.length();

		// Then start creating formated strings
		if (iCharRemoved != 0)
		{
			int j = lastPos;
			if (ft.sStr[j] == '|')
			{
				ft.sStr += '|';
				j--;
			}

			i = ft.sBaseStr.find_last_of('|', j);

			while (i != ft.sBaseStr.npos)
			{
				if (ft.sBaseStr[i+1] == 'c')
				{
					FormatedString fs;

					// Read the color data
					string s = ft.sBaseStr.substr(i+2, 2);
					float a = hexToInt((char*)s.c_str());
					s = ft.sBaseStr.substr(i+4, 2);
					float r = hexToInt((char*)s.c_str());
					s = ft.sBaseStr.substr(i+6, 2);
					float g = hexToInt((char*)s.c_str());
					s = ft.sBaseStr.substr(i+8, 2);
					float b = hexToInt((char*)s.c_str());

					// And create a new formated string with this new color
					fs.dColor = ARGB(a, r, g, b);
					fs.sStr = ft.sBaseStr.substr(i+10, lastPos-(i+10));

					Point p = GetCarretPos(lEquiv[i], ft.fnt, ft.w, ft.h, ft.sStr);
					fs.fX = p.x;
					fs.fY = p.y;

					ft.lFStr.push_front(fs);

					lastPos = i;
				}
				else if (ft.sBaseStr[i+1] == 'r')
				{
					FormatedString fs;
					// Create a new formated string with the default color
					fs.dColor = ft.color;
					fs.sStr = ft.sBaseStr.substr(i+2, lastPos-(i+2));

					Point p = GetCarretPos(lEquiv[i], ft.fnt, ft.w, ft.h, ft.sStr);
					fs.fX = p.x;
					fs.fY = p.y;

					ft.lFStr.push_front(fs);

					lastPos = i;
				}

				if (i != 0)
					i = ft.sBaseStr.find_last_of('|', i-1);
				else
					i = ft.sBaseStr.npos;
			}
		}

		if ( (lastPos != 0) || (ft.sStr.empty()) )
		{
			FormatedString fs;
			fs.dColor = ft.color;
			if (!ft.sStr.empty())
				fs.sStr = ft.sStr.substr(0, lastPos);
			else
				fs.sStr = "";
			fs.fX = 0;
			fs.fY = 0;

			ft.lFStr.push_front(fs);
		}
	}

	return ft;
}

void GUIManager::RegisterFunc( GUIElement* frame, int type, string funcText )
{
	funcText = "function _intFunc" + toString(iFuncCount) + "()\n" + funcText;
	funcText += "\nend\n";
	funcText += "Functions[" + toString(iFuncCount) + "] = _intFunc" + toString(iFuncCount);
	int error = luaL_dostring(mSceneMgr->luaVM, funcText.c_str());
	if (error)
		l_logPrint(mSceneMgr->luaVM);
	else
		frame->SetOnFunction(type, iFuncCount);

	iFuncCount++;
}

bool GUIManager::HasFocus( GUIElement* g )
{
	return (focus == g);
}

void GUIManager::RequestFocus( GUIElement* g )
{
	if (g != NULL)
	{
		g->On(GUI_FUNC_EDITFOCUSGAINED);
		g->carretTimer = 0.0f;
		g->showCarret = true;
		focus = g;
		UpdateCarretPos(focus);
		mInputMgr->SetFocus(true);
		newFocus = true;
	}
}

void GUIManager::LooseFocus( GUIElement* g )
{
	if (g != NULL)
	{
		g->On(GUI_FUNC_EDITFOCUSLOST);
		g->_rebuildCache();
		focus = NULL;
		mInputMgr->SetFocus(false);
	}
}

int GetCarretLine( GUIArt* cFnt, int carretPos )
{
	int charNbr = 0;
	int l;

	// Get the TextBox from the hgeFont
	TextBox tb = cFnt->text.fnt->GetTextBox(cFnt->w, cFnt->h, cFnt->text.sStr.c_str());

	for (l = 0; l < tb.iLineNbr; l++)
	{
		if (carretPos <= charNbr+tb.lLines[l].iCharNbr)
		{
			// Line is found
			break;
		}

		// The "+1" is for end of line character
		charNbr += tb.lLines[l].iCharNbr +1;
	}

	return l;
}

Point GUIManager::GetCarretPos( int carretPos, hgeFont* fnt, float w, float h, string s )
{
	Point p;
	p.y = 0;

	int charNbr = 0;
	int l;

	// Get the TextBox from the hgeFont
	TextBox tb = fnt->GetTextBox(w, h, s.c_str());

	for (l = 0; l < tb.iLineNbr; l++)
	{
		if (carretPos <= charNbr+tb.lLines[l].iCharNbr)
		{
			// Line is found, now multiply the line's height by the number
			// of line : this is the carret's vertical position.
			p.y = tb.fLineHeight*l;
			break;
		}

		// The "+1" is for end of line character
		charNbr += tb.lLines[l].iCharNbr +1;
	}

	// Get the substring between the begining of the line and the carret
	// and get its width if rendered with the hgeFont : this is the carret's
	// horizontal position.
	p.x = fnt->GetStringWidth(tb.lLines[l].sText.substr(0, carretPos-charNbr).c_str());

	return p;
}

Point GUIManager::GetCarretPos( GUIElement* g, bool multiLine )
{
	Point p;
	p.y = 0;

	GUIArt* cFnt = g->captionFont;

	if (multiLine)
	{
		int charNbr = 0;
		int l;

		// Get the TextBox from the hgeFont
		TextBox tb = cFnt->text.fnt->GetTextBox(cFnt->w, cFnt->h, g->sEBText.c_str());

		for (l = 0; l < tb.iLineNbr; l++)
		{
			if (g->carretPos <= charNbr+tb.lLines[l].iCharNbr)
			{
				// Line is found, now multiply the line's height by the number
				// of line : this is the carret's vertical position.
				p.y = tb.fLineHeight*l;
				break;
			}

			// The "+1" is for end of line character
			charNbr += tb.lLines[l].iCharNbr +1;
		}

		// Get the substring between the begining of the line and the carret
		// and get its width if rendered with the hgeFont : this is the carret's
		// horizontal position.
		p.x = cFnt->text.fnt->GetStringWidth(tb.lLines[l].sText.substr(0, g->carretPos-charNbr).c_str());
	}
	else
	{
		string s = g->sEBText.substr(g->iSubStrStart, g->iSubStrLength);
		p.x = cFnt->text.fnt->GetStringWidth(s.substr(0, g->carretPos-g->iSubStrStart).c_str());
	}

	return p;
}

void GUIManager::UpdateCarretPos( GUIElement* g )
{
	if (g->multiLine)
	{
		Point p = GetCarretPos(g, true);
		g->carretX = p.x + g->EBinsL;
		g->carretY = p.y + g->EBinsT;

		// Update font text
		g->captionFont->text.sStr = g->sEBText;
		g->captionFont->text.lFStr.front().sStr = g->sEBText;
	}
	else
	{
		float fBoxWidth = g->w - g->EBinsL - g->EBinsR;

		if (g->carretPos - g->iSubStrStart < 0)
		{
			// Move the substring range to the left

			// Get the lower bound
			g->iSubStrStart = g->carretPos;
			float fNewWidth = g->captionFont->text.fnt->GetStringWidth(
				g->sEBText.substr(g->iSubStrStart, g->carretPos-g->iSubStrStart).c_str()
			);
			while ( (fNewWidth < fBoxWidth*0.75f) && (g->iSubStrStart != 0) )
			{
				g->iSubStrStart--;
				fNewWidth = g->captionFont->text.fnt->GetStringWidth(
					g->sEBText.substr(g->iSubStrStart, g->carretPos-g->iSubStrStart).c_str()
				);
			}
			if (g->iSubStrStart != 0)
				g->iSubStrStart++;

			// And the upper one
			g->iSubStrLength = 0;
			fNewWidth = g->captionFont->text.fnt->GetStringWidth(
				g->sEBText.substr(g->iSubStrStart, g->iSubStrLength).c_str()
			);
			while ( (fNewWidth < fBoxWidth) && (g->iSubStrStart+g->iSubStrLength < g->sEBText.length()) )
			{
				g->iSubStrLength++;
				fNewWidth = g->captionFont->text.fnt->GetStringWidth(
					g->sEBText.substr(g->iSubStrStart, g->iSubStrLength).c_str()
				);
			}
			if (g->iSubStrStart+g->iSubStrLength < g->sEBText.length())
				g->iSubStrLength--;

			Point p = GetCarretPos(g, false);
			g->carretX = p.x + g->EBinsL;
			g->carretY = g->EBinsT;
		}
		else
		{
			float fNewWidth = g->captionFont->text.fnt->GetStringWidth(
				g->sEBText.substr(g->iSubStrStart, g->carretPos-g->iSubStrStart).c_str()
			);

			if (fNewWidth > fBoxWidth)
			{
				// Move the substring range to the right

				// Get the lower bound
				g->iSubStrStart = g->carretPos;
				float fNewWidth = g->captionFont->text.fnt->GetStringWidth(
					g->sEBText.substr(g->iSubStrStart, g->carretPos-g->iSubStrStart).c_str()
				);
				while ( (fNewWidth < fBoxWidth*0.75f) && (g->iSubStrStart != 0) )
				{
					g->iSubStrStart--;
					fNewWidth = g->captionFont->text.fnt->GetStringWidth(
						g->sEBText.substr(g->iSubStrStart, g->carretPos-g->iSubStrStart).c_str()
					);
				}
				if (g->iSubStrStart != 0)
					g->iSubStrStart++;

				// And the upper one
				g->iSubStrLength = 0;
				fNewWidth = g->captionFont->text.fnt->GetStringWidth(
					g->sEBText.substr(g->iSubStrStart, g->iSubStrLength).c_str()
				);
				while ( (fNewWidth < fBoxWidth) && (g->iSubStrStart+g->iSubStrLength != g->sEBText.length()) )
				{
					g->iSubStrLength++;
					fNewWidth = g->captionFont->text.fnt->GetStringWidth(
						g->sEBText.substr(g->iSubStrStart, g->iSubStrLength).c_str()
					);
				}
				if (g->iSubStrStart+g->iSubStrLength != g->sEBText.length())
					g->iSubStrLength--;

				Point p = GetCarretPos(g, false);
				g->carretX = p.x + g->EBinsL;
				g->carretY = g->EBinsT;
			}
			else
			{
				// Nothing special to do, just check the upper bound
				g->iSubStrLength = 0;
				fNewWidth = g->captionFont->text.fnt->GetStringWidth(
					g->sEBText.substr(g->iSubStrStart, g->iSubStrLength).c_str()
				);
				while ( (fNewWidth < fBoxWidth) && (g->iSubStrStart+g->iSubStrLength != g->sEBText.length()) )
				{
					g->iSubStrLength++;
					fNewWidth = g->captionFont->text.fnt->GetStringWidth(
						g->sEBText.substr(g->iSubStrStart, g->iSubStrLength).c_str()
					);
				}
				if (g->iSubStrStart+g->iSubStrLength != g->sEBText.length())
					g->iSubStrLength--;

				Point p = GetCarretPos(g, false);
				g->carretX = p.x + g->EBinsL;
				g->carretY = g->EBinsT;
			}
		}

		// Update font text
		g->captionFont->text.sStr = g->sEBText.substr(g->iSubStrStart, g->iSubStrLength);
		g->captionFont->text.lFStr.front().sStr = g->sEBText.substr(g->iSubStrStart, g->iSubStrLength);
	}
}

void GUIManager::PlaceCarret(GUIElement* g, float x, float y)
{
	if (g->multiLine)
	{
		TextBox tb = g->captionFont->text.fnt->GetTextBox(
			g->captionFont->w, g->captionFont->h,
			g->sEBText.c_str()
		);

		float fGX = g->getX() + g->EBinsL;
		float fGY = -g->getY() + g->EBinsT;

		int i, j;
		int iCharNbr = 0;

		float fBestDiff = fabs(y - fGY);
		// First find the proper line
		for (j = 0; j < tb.iLineNbr; j++)
		{
			float fNewDiff = fabs(y - tb.fLineHeight*j - fGY);
			if (fNewDiff > fBestDiff)
			{
				j--;
				break;
			}
			else
				fBestDiff = fNewDiff;

			iCharNbr += tb.lLines[j].iCharNbr +1;
		}

		fBestDiff = fabs(x - fGX);
		// Then the proper character
		for (i = 0; i < tb.lLines[j].sText.length(); i++)
		{
			string s = tb.lLines[j].sText.substr(0, i);
			float fNewDiff = fabs(x - g->captionFont->text.fnt->GetStringWidth(s.c_str()) - fGX);
			if (fNewDiff > fBestDiff)
			{
				i--;
				break;
			}
			else
				fBestDiff = fNewDiff;
		}

		g->carretPos = iCharNbr + i;

		UpdateCarretPos(g);
		g->_rebuildCache();
	}
	else
	{
		// No need to bother with lines : just iterate through the
		// substring until the proper character is found
		float fGX = g->getX() + g->EBinsL;
		int i;
		float fBestDiff = fabs(x - fGX);
		for (i = 0; i < g->captionFont->text.sStr.length(); i++)
		{
			string s = g->captionFont->text.sStr.substr(0, i);
			float fNewDiff = fabs(x - g->captionFont->text.fnt->GetStringWidth(s.c_str()) - fGX);
			if (fNewDiff > fBestDiff)
			{
				i--;
				break;
			}
			else
				fBestDiff = fNewDiff;
		}

		g->carretPos = g->iSubStrStart + i;

		UpdateCarretPos(g);
		g->_rebuildCache();
	}
}

void GUIManager::UpdateEditBox()
{
	if (focus != NULL)
	{
		if (mInputMgr->GetKey(true))
		{
			focus->showCarret = true;
			focus->carretTimer = 0.0f;
		}

		if (mInputMgr->KeyIsReleased(HGEK_ESCAPE, true))
		{
			focus->On(GUI_FUNC_ESCAPEPRESSED);
			LooseFocus(focus);
		}
		else
		{
			if (focus->captionFont != NULL)
			{
				GUIArt* cFnt = focus->captionFont;

				if (newFocus)
				{
					UpdateCarretPos(focus);
					focus->_rebuildCache();
				}

				char c = mInputMgr->GetChar(true, true);
				if ( (c != 0) && !newFocus && ((cFnt->text.sStr.length() < focus->letters) || (focus->letters == 0)) )
				{
					// Add a character before the carret
					focus->On(GUI_FUNC_CHAR);

					focus->sEBText.insert(focus->carretPos, 1, c);
					focus->carretPos++;
					UpdateCarretPos(focus);

					focus->AdjustCache();
					focus->_rebuildCache();
				}

				if (mInputMgr->KeyIsPressed(HGEK_ENTER, true))
				{
					if ( mInputMgr->shiftPressed && focus->multiLine )
					{
						// Shift + Enter to start a new line
						focus->On(GUI_FUNC_CHAR);
						focus->sEBText.insert(focus->carretPos, 1, '\n');
						//cFnt->text.sStr = focus->sEBText;
						focus->carretPos++;
						UpdateCarretPos(focus);

						focus->AdjustCache();
						focus->_rebuildCache();
					}
					else
						focus->On(GUI_FUNC_ENTERPRESSED);
				}

				if ((mInputMgr->KeyIsPressed(HGEK_BACKSPACE, true)) ||
					(mInputMgr->KeyIsDownLong(HGEK_BACKSPACE, true)))
				{
					if (focus->carretPos != 0)
					{
						// Remove the character just before the carret
						string::iterator iter = focus->sEBText.begin();
						for (int i = 0; i < focus->carretPos-1; i++)
							iter++;
						focus->sEBText.erase(iter);
						focus->carretPos--;
						UpdateCarretPos(focus);

						focus->AdjustCache();
						focus->_rebuildCache();
					}
				}

				static PeriodicTimer tLeft(CARRET_SPEED, false, true);
				if (mInputMgr->KeyIsDownLong(HGEK_LEFT, true)) tLeft.Start();
				else tLeft.Stop();

				if ((mInputMgr->KeyIsPressed(HGEK_LEFT, true)) ||
					(mInputMgr->KeyIsDownLong(HGEK_LEFT, true) && tLeft.Ticks()))
				{
					if (focus->carretPos != 0)
					{
						// Move the carret to the left
						focus->carretPos--;
						UpdateCarretPos(focus);

						focus->_rebuildCache();
					}
				}

				static PeriodicTimer tRight(CARRET_SPEED, false, true);
				if (mInputMgr->KeyIsDownLong(HGEK_RIGHT, true)) tRight.Start();
				else tRight.Stop();

				if ((mInputMgr->KeyIsPressed(HGEK_RIGHT, true)) ||
					(mInputMgr->KeyIsDownLong(HGEK_RIGHT, true) && tRight.Ticks()))
				{
					if (focus->carretPos < cFnt->text.sStr.length())
					{
						// Move the carret to the right
						focus->carretPos++;
						UpdateCarretPos(focus);

						focus->_rebuildCache();
					}
				}

				static PeriodicTimer tUp(CARRET_SPEED, false, true);
				if (mInputMgr->KeyIsDownLong(HGEK_UP, true)) tUp.Start();
				else tUp.Stop();

				if ((mInputMgr->KeyIsPressed(HGEK_UP, true)) ||
					(mInputMgr->KeyIsDownLong(HGEK_UP, true)) && tUp.Ticks())
				{
					int iCarretLine = GetCarretLine(cFnt, focus->carretPos);

					if (focus->carretPos != 0)
					{
						if ( (iCarretLine == 0) || (!focus->multiLine) )
						{
							// The carret is already on the first line
							// so we just put it at the begining
							focus->carretPos = 0;
							focus->iSubStrStart = 0;
						}
						else
						{
							// Move the carret one line up
							TextBox tb = cFnt->text.fnt->GetTextBox(cFnt->w, cFnt->h, cFnt->text.sStr.c_str());
							int iPrevLinePos = 0;
							for (int i = 0; i < iCarretLine-1; i++)
								iPrevLinePos += tb.lLines[i].iCharNbr+1;

							Line lPrev = tb.lLines[iCarretLine-1];

							Point p = GetCarretPos(focus, true);

							// If the carret's horizontal position is larger than the
							// previous line's width, just put it at this line's end.
							if (p.x > lPrev.fWidth)
								focus->carretPos = iPrevLinePos + lPrev.iCharNbr;
							else
							{
								// Else, we put it at the closest horizontal position.
								float fNewWidth = 0.0f;
								float fDiff;
								float fLastDiff = lPrev.fWidth;
								int iCharPos;
								for (iCharPos = 0; iCharPos < lPrev.sText.length(); iCharPos++)
								{
									string s = lPrev.sText.substr(0, iCharPos+1);
									fNewWidth = cFnt->text.fnt->GetStringWidth(s.c_str());
									fDiff = fabs(fNewWidth - p.x);
									if (fDiff > fLastDiff)
										break;

									fLastDiff = fabs(fNewWidth - p.x);
								}

								focus->carretPos = iPrevLinePos + iCharPos;
							}
						}

						UpdateCarretPos(focus);

						focus->_rebuildCache();
					}
				}

				static PeriodicTimer tDown(CARRET_SPEED, false, true);
				if (mInputMgr->KeyIsDownLong(HGEK_DOWN, true)) tDown.Start();
				else tDown.Stop();

				if ((mInputMgr->KeyIsPressed(HGEK_DOWN, true)) ||
					(mInputMgr->KeyIsDownLong(HGEK_DOWN, true)) && tDown.Ticks())
				{
					int iCarretLine = GetCarretLine(cFnt, focus->carretPos);

					if (focus->carretPos != focus->sEBText.length())
					{
						TextBox tb = cFnt->text.fnt->GetTextBox(cFnt->w, cFnt->h, cFnt->text.sStr.c_str());
						if ( (iCarretLine == tb.iLineNbr-1) || (!focus->multiLine) )
						{
							// The carret is already on the last line
							// so we just put it at the end
							focus->carretPos = focus->sEBText.length();
						}
						else
						{
							// Move the carret one line down
							int iNextLinePos = 0;
							for (int i = 0; i < iCarretLine+1; i++)
								iNextLinePos += tb.lLines[i].iCharNbr+1;

							Line lNext = tb.lLines[iCarretLine+1];

							Point p = GetCarretPos(focus, true);

							// If the carret's horizontal position is larger than the
							// next line's width, just put it at this line's end.
							if (p.x > lNext.fWidth)
								focus->carretPos = iNextLinePos + lNext.iCharNbr;
							else
							{
								// Else, we put it at the closest horizontal position.
								float fNewWidth = 0.0f;
								float fDiff;
								float fLastDiff = lNext.fWidth;
								int iCharPos;
								for (iCharPos = 0; iCharPos < lNext.sText.length(); iCharPos++)
								{
									string s = lNext.sText.substr(0, iCharPos+1);
									fNewWidth = cFnt->text.fnt->GetStringWidth(s.c_str());
									fDiff = fabs(fNewWidth - p.x);
									if (fDiff > fLastDiff)
										break;

									fLastDiff = fabs(fNewWidth - p.x);
								}

								focus->carretPos = iNextLinePos + iCharPos;
							}
						}

						UpdateCarretPos(focus);

						focus->_rebuildCache();
					}
				}

				if (mInputMgr->KeyIsPressed(HGEK_END, true))
				{
					int iCarretLine = GetCarretLine(cFnt, focus->carretPos);

					if (focus->carretPos != cFnt->text.sStr.length())
					{
						TextBox tb = cFnt->text.fnt->GetTextBox(cFnt->w, cFnt->h, cFnt->text.sStr.c_str());
						if ( (iCarretLine == tb.iLineNbr-1) || (!focus->multiLine) )
						{
							// The carret is already on the last line
							// so we just put it at the end
							focus->carretPos = focus->sEBText.length();
							//focus->iSubStrLength = focus->sEBText.length();
						}
						else
						{
							// Get actual line's position
							int iLinePos = 0;
							for (int i = 0; i < iCarretLine; i++)
								iLinePos += tb.lLines[i].iCharNbr+1;

							// And put the carret at this line's end.
							focus->carretPos = iLinePos + tb.lLines[iCarretLine].iCharNbr;
						}

						UpdateCarretPos(focus);

						focus->_rebuildCache();
					}
				}

				if (mInputMgr->KeyIsPressed(HGEK_HOME, true))
				{
					int iCarretLine = GetCarretLine(cFnt, focus->carretPos);

					if (focus->carretPos != 0)
					{
						TextBox tb = cFnt->text.fnt->GetTextBox(cFnt->w, cFnt->h, cFnt->text.sStr.c_str());
						if ( (iCarretLine == 0) || (!focus->multiLine) )
						{
							// The carret is already on the first line
							// so we just put it at the begining
							focus->carretPos = 0;
							focus->iSubStrStart = 0;
						}
						else
						{
							// Get actual line's position
							int iLinePos = 0;
							for (int i = 0; i < iCarretLine; i++)
								iLinePos += tb.lLines[i].iCharNbr+1;

							// And put the carret at this line's begining.
							focus->carretPos = iLinePos;
						}

						UpdateCarretPos(focus);

						focus->_rebuildCache();
					}
				}
			}

			if (mInputMgr->KeyIsPressed(HGEK_TAB, true))
				focus->On(GUI_FUNC_TABPRESSED);

			if (mInputMgr->KeyIsPressed(HGEK_SPACE, true))
				focus->On(GUI_FUNC_SPACEPRESSED);
		}
	}

	if (newFocus) newFocus = false;
}

void GUIManager::UpdateScrollingMsgFrame(GUIElement* g)
{
	if (g->ready)
	{
		bool debugThis = false;
		if (g->bottomLine != g->oldBottomLine)
		{
			// Raise the new fontstring object
			if (debugThis) hge->System_Log("1 : %d", g->bottomLine);
			GUIArt* aNew = &g->arts[string("Msg") + toString(g->bottomLine)];
			aNew->anchors[0].parent = g;
			aNew->anchors[0].anchorPt = GUI_ANCHOR_BOTTOMLEFT;
			aNew->anchors[0].relativePt = GUI_ANCHOR_BOTTOMLEFT;
			aNew->anchors[0].x = g->SMFinsL;
			aNew->anchors[0].y = g->SMFinsB;
			aNew->w = g->w - g->SMFinsR - g->SMFinsL;

			TextBox tb = aNew->text.fnt->GetTextBox(aNew->w, aNew->h, aNew->text.sStr.c_str());
			aNew->h = tb.iLineNbr*tb.fLineHeight;

			// Move the previous one
			int iPrevN;
			if (g->oldBottomLine == g->maxLines)
				iPrevN = 1;
			else
				iPrevN = g->oldBottomLine+1;

			if (debugThis) hge->System_Log("2 : %d, %d", g->oldBottomLine, iPrevN);

			GUIArt* aOld = &g->arts[string("Msg") + toString(g->oldBottomLine)];
			GUIArt* aPrev = &g->arts[string("Msg") + toString(iPrevN)];
			aOld->anchors[0].parent = aPrev;
			aOld->anchors[0].anchorPt = GUI_ANCHOR_BOTTOMLEFT;
			aOld->anchors[0].relativePt = GUI_ANCHOR_TOPLEFT;
			aOld->anchors[0].x = 0;
			aOld->anchors[0].y = 0;

			// Check top inset
			float fBX = -g->getY() + g->SMFinsT;
			GUIArt* aAdj = NULL;

			for (int i = 0; i < g->maxLines; i++)
			{
				int iArtN;
				if (g->bottomLine-i < 1)
					iArtN = g->maxLines+g->bottomLine-i;
				else
					iArtN = g->bottomLine-i;
				aAdj = &g->arts[string("Msg") + toString(iArtN)];
				if (aAdj->text.sStr == "<empty>")
					break;

				float fArtY = -aAdj->getY();
				if (debugThis) hge->System_Log(" 3 : %d, %f < %f ?", iArtN, fArtY, fBX);
				if (fArtY < fBX)
					break;
				else
					aAdj->hidden = false; // We make sure it is shown
			}

			if (aAdj != NULL)
			{
				aAdj->hidden = true;
			}

			g->oldBottomLine = g->bottomLine;

			if (debugThis) hge->System_Log("4");

			g->_rebuildCache();
		}
	}
}

void GUIManager::loadUI( lua_State* luaVM )
{
	bool debugThis = false;
	mxml_initUI();

	if (debugThis) hge->System_Log("1");

	for (char* c = hge->Resource_EnumFolders("Interface/BaseUI/*"); c != 0; c = hge->Resource_EnumFolders())
	{
		loadAddOn(luaVM, c, "Interface/BaseUI/");
	}
	for (char* c = hge->Resource_EnumFolders("Interface/AddOns/*"); c != 0; c = hge->Resource_EnumFolders())
	{
		loadAddOn(luaVM, c, "Interface/AddOns/");
	}

	if (debugThis) hge->System_Log("2");

	map<string, GUIElement>::iterator iterElem;
	for (iterElem = guiList.begin(); iterElem != guiList.end(); iterElem++)
	{
		GUIElement* g = &iterElem->second;
		if (!g->child)
		{
			g->_init();

			map<string, GUIArt>::iterator iter;
			for (iter = g->arts.begin(); iter != g->arts.end(); iter++)
			{
				GUIArt* a = &iter->second;
				a->_init();
			}
		}
	}

	if (debugThis) hge->System_Log("3");

	multimap<int, GUIElement*> lLevelMap;

	for (iterElem = guiList.begin(); iterElem != guiList.end(); iterElem++)
	{
		if (debugThis) hge->System_Log("3.1 %s", iterElem->second.name.c_str());
		if (!iterElem->second.child)
			iterElem->second.On(GUI_FUNC_LOAD);
		if (debugThis) hge->System_Log("3.1.");

		lLevelMap.insert(make_pair(iterElem->second.GetChildLevel(), &iterElem->second));
	}

	if (debugThis) hge->System_Log("4");

	// Adjust cache from childs to parents, using the level map we built
	// just before to reduce the number of calls.
	multimap<int, GUIElement*>::iterator iterElem2 = lLevelMap.end();
	while (iterElem2 != lLevelMap.begin())
	{
		iterElem2--;
		iterElem2->second->AdjustCache(false);
	}

	if (debugThis) hge->System_Log("5");

	// Load saved variables
	char* saved = hge->Resource_EnumFiles("Saves/AddOns/*");
	while (saved != 0)
	{
		string s = "Saves/AddOns/";
		string f = saved;
		if (f.find(".lua") != f.npos)
		{
			s += f;
			int error = luaL_dofile(luaVM, s.c_str());
			if (error) l_logPrint(luaVM);
		}

		saved = hge->Resource_EnumFiles();
	}

	if (debugThis) hge->System_Log("6");

	rebuildGUIList = true;
}

void GUIManager::closeUI( lua_State* luaVM )
{
	// Delete GUI elements
	map<string, GUIElement>::iterator iterElem;
	for (iterElem = guiList.begin(); iterElem != guiList.end(); iterElem++)
	{
		iterElem->second.deleteMe();
	}

	lua_register(luaVM, "sendString", l_sendString);
	lua_register(luaVM, "concTable", l_concTable);

	// Write saved variables
	map<string, AddOn>::iterator iterAddOn;
	for (iterAddOn = this->addOnList.begin(); iterAddOn != this->addOnList.end(); iterAddOn++)
	{
		AddOn* a = &iterAddOn->second;
		if (a->enabled)
		{
			if (!a->saved.empty())
			{
				string sfile = "Saves/AddOns/" + a->name + ".lua";
				fstream file(sfile.c_str(), ios::out);
				file << "\n";
				vector<string>::iterator iterVar;
				for (iterVar = a->saved.begin(); iterVar != a->saved.end(); iterVar++)
				{
					string var = *iterVar;
					lua_getglobal(luaVM, var.c_str());
					int type = lua_type(luaVM, -1);
					if (type == LUA_TNUMBER)
					{
						file << var + " = " + toString(lua_tonumber(luaVM, -1)) + ";\n";
					}
					else if (type == LUA_TNIL)
					{
						file << var + " = nil;\n";
					}
					else if (type == LUA_TBOOLEAN)
					{
						file << var + " = " + BtoString(lua_toboolean(luaVM, -1)) + ";\n";
					}
					else if (type == LUA_TSTRING)
					{
						file << var + " = \"" + lua_tostring(luaVM, -1) + "\";\n";
					}
					else if (type == LUA_TTABLE)
					{
						mSceneMgr->tmpString = "";
						string exec = "str = \"\";\nstr = concTable(str, \"" + var + "\");\n";
						luaL_dostring(luaVM, exec.c_str());

						string s = mSceneMgr->tmpString;
						string tab = "	";
						file << var + " = {\n";
						int tableIndent = 1;
						bool tableEnded = false;
						int lineNbr = 0;
						while (!tableEnded)
						{
							if (lineNbr > 1000)
								break;

							if (tableIndent == -1)
							{
								tableEnded = true;
							}
							else
							{
								int i = s.find(" ");
								string k = s.substr(0, i);
								s.erase(0, i+1);
								if (k == "'end'")
								{
									tableIndent--;
									tab = tab.substr(0, tab.size()-4);
									if (tableIndent == -1)
										file << tab + "}\n";
									else
										file << tab + "},\n";
								}
								else
								{
									k = "[" + k + "]";

									i = s.find(" ");
									string v = s.substr(0, i);
									s.erase(0, i+1);

									int type;
									if (v == "'table'")
										type = LUA_TTABLE;
									else
									{
										type = LUA_TNUMBER;
										int j = v.find("\"");
										if (j != v.npos)
											type = LUA_TSTRING;
										j = v.find("'");
										if (j != v.npos)
										{
											type = LUA_TBOOLEAN;
											strRemoveSurChar(&v, '\'');
										}
									}

									if (type == LUA_TNUMBER)
									{
										file << tab + k + " = " + v + ";\n";
									}
									else if (type == LUA_TNIL)
									{
										file << tab + k + " = nil;\n";
									}
									else if (type == LUA_TBOOLEAN)
									{
										file << tab + k + " = " + v + ";\n";
									}
									else if (type == LUA_TSTRING)
									{
										file << tab + k + " = " + v + ";\n";
									}
									else if (type == LUA_TTABLE)
									{
										file << tab + k + " = {\n";
										tab += "	";
									}
								}
							}
						}
					}
				}
				file.close();
			}
		}
	}

	// Write addons activation
	fstream file("Interface/AddOns.txt", ios::out);
	for (iterAddOn = this->addOnList.begin(); iterAddOn != this->addOnList.end(); iterAddOn++)
	{
		string s = iterAddOn->second.name;
		if (s != "")
		{
			s += ": ";
			if (iterAddOn->second.enabled)
				s += "1\n";
			else
				s += "0\n";

			file << s;
		}
	}
	file.close();

	// Delete UI sprites
	vector<hgeSprite*>::iterator iter;
	while (!GUIspriteList.empty())
	{
		iter = GUIspriteList.begin();
		delete *iter;
		GUIspriteList.erase(iter);
	}
}

lua_State* GUIManager::reLoadUI( lua_State* luaVM )
{
	hge->System_Log("Reloading UI...");

	hge->System_Log(" Closing...");

	// Delete the UI
	closeUI(luaVM);

	// Clear lists
	guiList.clear();
	addOnList.clear();
	parentList.clear();
	templateList.clear();

	// Clear LUA
	lua_close(luaVM);

	hge->System_Log(" Done.");
	hge->System_Log(" Loading...");

	luaVM = lua_open();
	if (luaVM == NULL)
	{
		hge->System_Log("# Error initializing lua.");
		return NULL;
	}
	mluaL_openlibs(luaVM);

	mlua_registerAll(luaVM);

	lua_atpanic(luaVM, l_logPrint);

// FIXME (Corentin#1#): bug if comment this line
	mSceneMgr->luaVM = luaVM; // Debug...

	// Reload important LUA data
	iFuncCount = 1;
	int error = luaL_dofile(luaVM, "Scripts/config.lua");
	if (error) l_logPrint(luaVM);

	error = luaL_dofile(luaVM, "Tables/buff_table.lua");
	if (error) l_logPrint(luaVM);

	error = luaL_dofile(luaVM, "Tables/spell_scripts_table.lua");
	if (error) l_logPrint(luaVM);

	error = luaL_dofile(luaVM, "Tables/spell_table.lua");
	if (error) l_logPrint(luaVM);

	map<string, Spell>::iterator iterSpell;
	for (iterSpell = mUnitMgr->spellList.begin(); iterSpell != mUnitMgr->spellList.end(); iterSpell++)
	{
		mUnitMgr->parseSpell(luaVM, iterSpell->second.name, true);
	}

	error = luaL_dofile(luaVM, "Tables/item_table.lua");
	if (error) l_logPrint(luaVM);

	mSceneMgr->locale = mlua_getGlobalString("Game_locale");
	string strTableFile = "Tables/locale_" + mSceneMgr->locale + ".str";
	delete mSceneMgr->strTable;
	mSceneMgr->strTable = new hgeStringTable(strTableFile.c_str());

	mInputMgr->SetFocus(false);

	// Load the new UI
	loadUI(luaVM);

	hge->System_Log(" Done.");

	hge->System_Log("Reloading UI : done.");

	return luaVM;
}

void GUIManager::loadAddOn( lua_State* luaVM, string name, string folder )
{
	bool debugThis = false;

	if (debugThis) hge->System_Log("1");

	if (this->addOnList[name].enabled)
	{
		if (debugThis) hge->System_Log("2");
		AddOn a;
		AddOn* pa;
		a.enabled = true;
		a.folder = folder + name;
		string tocFile = a.folder + "/" + name + ".toc";
		if (debugThis) {hge->System_Log(" Loading AddOn %s", name.c_str());}
		fstream file(tocFile.c_str(), ios::in);

		if (file.is_open())
		{
			if (debugThis) hge->System_Log("3");
			char line[256];
			while (!file.eof())
			{
				if (debugThis) hge->System_Log("3.1");
				file.getline(line, 256);
				if ( (line[0] == '#') && (line[1] == '#') )
				{
					if (debugThis) hge->System_Log("3.1.1");
					string temp = line;
					temp = temp.substr(3);
					int i = temp.find(":");
					if (i != temp.npos)
					{
						if (debugThis) hge->System_Log("3.1.2");
						string field = temp.substr(0, i);
						strRemoveSurChar(&field, ' ');
						string value = temp.substr(i+1);
						strRemoveSurChar(&value, ' ');
						if (field == "Interface")
						{
							value = value.substr(0, 4);
							value.insert(1, ".");
							a.UIVersion = atof(value.c_str());

							if (a.UIVersion >= mSceneMgr->gameVersion)
								a.enabled = true;
							else
								a.enabled = false;
						}
						else if (field == "Title")
						{
							a.name = value;
						}
						else if (field == "Version")
						{
							a.version = value;
						}
						else if (field == "Author")
						{
							a.author = value;
						}
						else if (field == "SavedVariables")
						{
							while (value != "")
							{
								int j = value.find(",");
								string variable;
								if (j == value.npos)
								{
									variable = value;
									a.saved.push_back(variable);
									value = "";
								}
								else
								{
									variable = value.substr(0, j);
									a.saved.push_back(variable);
									value = value.erase(0, j+1);
									strRemoveSurChar(&value, ' ');
								}
							}
						}
					}
				}
				else
				{
					if (debugThis) hge->System_Log("3.1.2");
					string temp = line;
					strRemoveSurChar(&temp, ' ');
					int i = temp.find(".lua");
					int j = temp.find(".xml");
					if ( (i != temp.npos) || (j != temp.npos) )
					{
						a.files.push_back(a.folder + "/" + temp);
					}
					if (debugThis) hge->System_Log("3.1.3");
				}
			}

			if (debugThis) hge->System_Log("4");

			file.close();

			if (a.name == "")
				hge->System_Log("# Error # : missing AddOn name in %s", tocFile.c_str());
			else if (this->addOnList[a.name].loaded)
				hge->System_Log("# Error # : duplicated AddOn name : %s", a.name.c_str());
			else
			{
				if (debugThis) hge->System_Log("5");
				this->addOnList[a.name] = a;
				pa = &this->addOnList[a.name];

				fstream file2("Interface/AddOns.txt", ios::in);
				if (file2.is_open())
				{
					if (debugThis) hge->System_Log("6");
					char line[256];
					while (!file2.eof())
					{
						if (debugThis) hge->System_Log("7");
						file2.getline(line, 256);
						string temp = line;
						int i = temp.find(":");
						if (i != temp.npos)
						{
							if (debugThis) hge->System_Log("8");
							string field = temp.substr(0, i);
							strRemoveSurChar(&field, ' ');
							string value = temp.substr(i+1);
							strRemoveSurChar(&value, ' ');
							if (field == pa->name)
							{
								if (debugThis) hge->System_Log("9");
								if (value != string("1"))
								{
									pa->enabled = false;
								}
								break;
							}
						}
					}
					file2.close();
				}

				if (debugThis) hge->System_Log("6");

				if (pa->enabled)
				{
					vector<string>::iterator iterFile;
					for (iterFile = pa->files.begin(); iterFile != pa->files.end(); iterFile++)
					{
						if (debugThis) hge->System_Log("6.1 %s", iterFile->c_str());
						int i = iterFile->find(".lua");
						int j = iterFile->find(".xml");
						if (i != iterFile->npos)
						{
							if (fileExists(*iterFile))
							{
								int error = luaL_dofile(luaVM, iterFile->c_str());
								if (error) l_logPrint(luaVM);
							}
						}
						else if (j != iterFile->npos)
						{
							if (fileExists(*iterFile))
							{
								TiXmlDocument doc(iterFile->c_str());
								if (!doc.LoadFile())
									hge->System_Log("# XML : %s: %s", iterFile->c_str(), doc.ErrorDesc());
								else
								{
									mxml_parseUIFile(pa, doc);
								}
							}
						}
					}
				}

				if (debugThis) hge->System_Log("7");

				pa->loaded = true;
			}
		}
	}
	else
	{
		AddOn a;
		a.enabled = false;
		this->addOnList[name] = a;
	}

	if (debugThis) hge->System_Log("8");
}

void GUIManager::updateUI()
{
	#ifdef PROFILE
		Profiler* prof = mTimeMgr->getProfiler(8, "GUIManager::updateUI", false);
		Chrono c(prof);
	#endif

	// Update the GUI...
	mGUIMgr->lScriptsStr = "";
	mSceneMgr->mouseOverPlayField = true;
	map<string, GUIElement>::iterator iterGUI;
	for (iterGUI = mGUIMgr->guiList.begin(); iterGUI != mGUIMgr->guiList.end(); iterGUI++)
	{
		GUIElement* g = &iterGUI->second;
		if (g->IsVisible())
		{
			g->CheckInput(mInputMgr->mx, mInputMgr->my, mInputMgr->mLState, mInputMgr->mRState);
			g->On(GUI_FUNC_UPDATE);
			if ( (g->type == GUI_OBJECT_TYPE_EDITBOX) && HasFocus(g) )
				g->UpdateCarret();
		}
	}
	// Call events
	for (iterGUI = mGUIMgr->guiList.begin(); iterGUI != mGUIMgr->guiList.end(); iterGUI++)
	{
		GUIElement* g = &iterGUI->second;
		if (g->IsVisible())
		{
			if (g->funcList.find(GUI_FUNC_EVENT) != g->funcList.end())
			{
				vector<Event>::iterator iterEvent;
				for (iterEvent = mGUIMgr->lEvents.begin(); iterEvent != mGUIMgr->lEvents.end(); iterEvent++)
				{
					if (g->lRegEvents.find(iterEvent->iID) != g->lRegEvents.end())
					{
						g->On(GUI_FUNC_EVENT, &(*iterEvent));
					}
				}
			}
		}
	}
	mGUIMgr->lEvents.clear();

	UpdateEditBox();

	if (mGUIMgr->rebuildGUIList)
	{
		mGUIMgr->sortedGUIList.clear();
		for (iterGUI = mGUIMgr->guiList.begin(); iterGUI != mGUIMgr->guiList.end(); iterGUI++)
		{
			GUIElement* g = &iterGUI->second;
			if (g->IsVisible())
			{
				if (!g->child)
				{
					mGUIMgr->sortedGUIList.insert(make_pair(g->frameStrata, g));
				}
			}
		}
		mGUIMgr->rebuildGUIList = false;
	}

	// ... and the cache
	multimap<int, GUIElement*>::iterator iterGUI2;
	for (iterGUI2 = mGUIMgr->sortedGUIList.begin(); iterGUI2 != mGUIMgr->sortedGUIList.end(); iterGUI2++)
	{
		GUIElement* g = iterGUI2->second;
		g->Render(true);
	}
}

void GUIManager::FireEvent(Event event)
{
	if (!event.bCumulable)
	{
		bool bEventFired = false;
		vector<Event>::iterator iter;

		for (iter = lEvents.begin(); iter != lEvents.end(); iter++)
		{
			if (iter->iID == event.iID)
			{
				bEventFired = true;
				break;
			}
		}

		if (!bEventFired)
			lEvents.push_back(event);
	}
	else
		lEvents.push_back(event);
}

void GUIManager::RegisterEvents()
{
	lEventNToS[EVENT_CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS] = "CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS";
	lEventSToN["CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS"] = EVENT_CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS;

	lEventNToS[EVENT_CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMMAGE] = "CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMMAGE";
	lEventSToN["CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMMAGE"] = EVENT_CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMMAGE;

	lEventNToS[EVENT_CHAT_MSG_COMBAT_PARTY_HITS] = "CHAT_MSG_COMBAT_PARTY_HITS";
	lEventSToN["CHAT_MSG_COMBAT_PARTY_HITS"] = EVENT_CHAT_MSG_COMBAT_PARTY_HITS;

	lEventNToS[EVENT_CHAT_MSG_SPELL_PARTY_DAMAGE] = "CHAT_MSG_SPELL_PARTY_DAMAGE";
	lEventSToN["CHAT_MSG_SPELL_PARTY_DAMAGE"] = EVENT_CHAT_MSG_SPELL_PARTY_DAMAGE;

	lEventNToS[EVENT_CHAT_MSG_COMBAT_FRIENDLY_DEATH] = "CHAT_MSG_COMBAT_FRIENDLY_DEATH";
	lEventSToN["CHAT_MSG_COMBAT_FRIENDLY_DEATH"] = EVENT_CHAT_MSG_COMBAT_FRIENDLY_DEATH;

	lEventNToS[EVENT_CHAT_MSG_COMBAT_HOSTILE_DEATH] = "CHAT_MSG_COMBAT_HOSTILE_DEATH";
	lEventSToN["CHAT_MSG_COMBAT_HOSTILE_DEATH"] = EVENT_CHAT_MSG_COMBAT_HOSTILE_DEATH;
}

int GUIManager::ToEventNbr( string sEvent )
{
	int iEvent = 0;

	if (lEventSToN.find(sEvent) != lEventSToN.end())
		iEvent = lEventSToN[sEvent];

	return iEvent;
}

string GUIManager::ToEventName( int iEvent )
{
	string sEvent = "";

	if (lEventNToS.find(iEvent) != lEventNToS.end())
		sEvent = lEventNToS[iEvent];

	return sEvent;
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_guimanager.h"
#include "wowrl_gfxmanager.h"

#include "wowrl_gui.h"

using namespace std;

extern GUIManager *mGUIMgr;
extern GFXManager *mGFXMgr;
extern HGE* hge;
extern bool debugGUI;

l_Frame::l_Frame(lua_State* luaVM) : l_Region(luaVM)
{
	name = lua_tostring(luaVM, 1);
	base = NULL;
}

int l_Frame::_init(lua_State* luaVM)
{
	if (name != "")
	{
		if (mGUIMgr->guiList.find(name) != mGUIMgr->guiList.end())
		{
			base = &mGUIMgr->guiList[name];
			rbase = base;
			ebase = base;
		}
	}

	return 0;
}

int l_Frame::GetBackdrop(lua_State* luaVM)
{
	/* Creates a tables containing backdrop informations :
	/* {
	/*    ["bgFile"]
	/*    ["edgeFile"]
	/*    ["tile"]
	/*    ["tileSize"]
	/*    ["edgeSize"]
	/*    ["insets"] = {
	/*         ["left"]
	/*         ["right"]
	/*         ["top"]
	/*         ["bottom"]
	/*    },
	/* },
	*/
	if (base != NULL)
	{
		if (base->useBackdrop)
		{
			Backdrop* b = &base->backdrop;
			lua_createtable(luaVM, 3, 3);
			mlua_setFieldString("bgFile", b->bgFile, luaVM);
			mlua_setFieldString("edgeFile", b->edgeFile, luaVM);
			mlua_setFieldBool("tile", b->tile, luaVM);
			mlua_setFieldFloat("tileSize", b->tileSize, luaVM);
			mlua_setFieldFloat("edgeSize", b->edgeSize, luaVM);
			lua_pushstring(luaVM, "insets");
			lua_createtable(luaVM, 0, 4);
			mlua_setFieldFloat("left", b->insL, luaVM);
			mlua_setFieldFloat("right", b->insR, luaVM);
			mlua_setFieldFloat("top", b->insT, luaVM);
			mlua_setFieldFloat("bottom", b->insB, luaVM);
			lua_settable(luaVM, -3);
		}
		else
			lua_pushnil(luaVM);
	}

	return 1;
}

int l_Frame::SetBackdrop(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		mlua_printError("Too few argument in \"Frame:SetBackdrop\" (one expected : backdrop table)");
		return 0;
	}
	else if ( !lua_istable(luaVM, 1) && !lua_isnil(luaVM, 1) )
	{
		mlua_printError("Argument of StatusBar:SetBackdrop must be a table (or nil) (backdrop table)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			if (lua_isnil(luaVM, 1))
			{
				base->useBackdrop = false;
			}
			else
			{
				lua_settop(luaVM, 1); // Remove possible junk

				Backdrop bd;

				if (base->useBackdrop)
				{
					hge->Target_Free(base->backdrop.target);
					delete base->backdrop.spr;

					bd.bgColor = base->backdrop.bgColor;
					bd.edgeColor = base->backdrop.edgeColor;
					bd.bgReadyC = base->backdrop.bgReadyC;
				}
				else
				{
					bd.bgColor = ARGB(255,255,255,255);
					bd.edgeColor = ARGB(255,255,255,255);
					bd.bgReadyC = false;
				}

				bd.bgFile = mlua_getFieldString("bgFile", false, "", false, luaVM);
				bd.edgeFile = mlua_getFieldString("edgeFile", false, "", false, luaVM);
				bd.tile = mlua_getFieldBool("tile", false, false, false, luaVM);
				bd.tileSize = mlua_getFieldFloat("tileSize", false, -1, false, luaVM);
				bd.edgeSize = mlua_getFieldFloat("edgeSize", false, -1, false, luaVM);

				lua_getfield(luaVM, 1, "insets");
				bd.insL = mlua_getFieldFloat("left", false, 0, false, luaVM);
				bd.insR = mlua_getFieldFloat("right", false, 0, false, luaVM);
				bd.insT = mlua_getFieldFloat("top", false, 0, false, luaVM);
				bd.insB = mlua_getFieldFloat("bottom", false, 0, false, luaVM);

				// Create edges
				if (bd.edgeFile != "")
				{
					HTEXTURE tex1 = mGFXMgr->loadTexture(bd.edgeFile, false);
					float size = (int)floor(hge->Texture_GetWidth(tex1, true)/8.0f);
					if (base->useBackdrop && base->backdrop.edgeReady)
					{
						delete base->backdrop.edgeL;
						delete base->backdrop.edgeR;
						delete base->backdrop.edgeT;
						delete base->backdrop.edgeB;
						delete base->backdrop.cornerTL;
						delete base->backdrop.cornerTR;
						delete base->backdrop.cornerBL;
						delete base->backdrop.cornerBR;
					}
					bd.edgeL = new hgeSprite(tex1, 0, 0, size, size);
					bd.edgeR = new hgeSprite(tex1, size, 0, size, size);
					bd.edgeT = new hgeSprite(tex1, 2*size, 0, size, size);
					bd.edgeB = new hgeSprite(tex1, 3*size, 0, size, size);
					bd.cornerTL = new hgeSprite(tex1, 4*size, 0, size, size);
					bd.cornerTR = new hgeSprite(tex1, 5*size, 0, size, size);
					bd.cornerBL = new hgeSprite(tex1, 6*size, 0, size, size);
					bd.cornerBR = new hgeSprite(tex1, 7*size, 0, size, size);
					bd.edgeOriginalSize = size;
					if (bd.edgeSize == -1)
						bd.edgeSize = bd.edgeOriginalSize;
					bd.edgeReady = true;
				}
				else
					bd.edgeReady = false;

				// Create background
				if (bd.bgFile != "")
				{
					HTEXTURE tex2;
					tex2 = mGFXMgr->loadTexture(bd.bgFile, false);

					bd.bgW = hge->Texture_GetWidth(tex2, true);
					bd.bgH = hge->Texture_GetHeight(tex2, true);

					if (base->useBackdrop && base->backdrop.bgReady)
						delete base->backdrop.background;
					if (bd.tile)
						bd.background = new hgeSprite(tex2, 0, 0, base->w-bd.insL-bd.insR, base->h-bd.insT-bd.insB);
					else
						bd.background = new hgeSprite(tex2, 0, 0, bd.bgW, bd.bgH);

					bd.bgReady = true;
				}
				else
					bd.bgReady = false;

				bd.target = hge->Target_Create(toInt(base->w), toInt(base->h), false);
				bd.spr = new hgeSprite(hge->Target_GetTexture(bd.target), 0, 0, toInt(base->w), toInt(base->h));

				base->backdrop = bd;
				base->useBackdrop = true;

				base->_rebuildCache();
				base->rebuildBackdrop = true;
			}
		}
	}

	return 0;
}

int l_Frame::SetBackdropColor(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 3)
	{
		mlua_printError("Too few argument in \"Frame:SetBackdropColor\" (3 or 4 expected : red, green, blue (+alpha))");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of Frame:SetBackdropColor must be a number (red)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of Frame:SetBackdropColor must be a number (green)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of Frame:SetBackdropColor must be a number (blue)");
		error++;
	}
	if ( (lua_gettop(luaVM) >= 4) && (!lua_isnumber(luaVM, 4)) )
	{
		mlua_printError("Argument 4 of Frame:SetBackdropColor must be a number (alpha)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			if (base->useBackdrop)
			{
				float a, r, g, b;
				r = lua_tonumber(luaVM, 1);
				g = lua_tonumber(luaVM, 2);
				b = lua_tonumber(luaVM, 3);
				if (lua_gettop(luaVM) >= 4)
					a = lua_tonumber(luaVM, 4);
				else
					a = 1.0f;

				DWORD color = ARGB(a*255, r*255, g*255, b*255);

				base->backdrop.bgReadyC = true;

				if (base->backdrop.bgColor != color)
				{
					base->backdrop.bgColor = color;
					base->_rebuildCache();
					base->rebuildBackdrop = true;
				}
			}
		}
	}
	return 0;
}

int l_Frame::RegisterEvent(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		mlua_printError("Too few argument in \"Frame:RegisterEvent\" (one expected : event name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of Frame:RegisterEvent must be a string (event name)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			int iEvent = mGUIMgr->ToEventNbr(lua_tostring(luaVM, 1));
			base->lRegEvents[iEvent] = true;
		}
	}

	return 0;
}

int l_Frame::UnregisterAllEvents(lua_State* luaVM)
{
	if (base != NULL)
		base->lRegEvents.clear();

	return 0;
}

int l_Frame::UnregisterEvent(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		mlua_printError("Too few argument in \"Frame:UnregisterEvent\" (one expected : event name)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of Frame:UnregisterEvent must be a string (event name)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			int iEvent = mGUIMgr->ToEventNbr(lua_tostring(luaVM, 1));
			base->lRegEvents[iEvent] = false;
		}
	}

	return 0;
}

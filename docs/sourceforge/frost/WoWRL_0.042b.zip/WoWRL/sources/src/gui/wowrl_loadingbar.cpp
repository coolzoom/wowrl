/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           LoadingBar source            */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the LoadingBar class.              */
/*       A LoadingBar is a GUI element    */
/*  that displays the state of the game   */
/*  while loading data.                   */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_fontmanager.h"
#include "wowrl_guimanager.h"

#include "wowrl_loadingbar.h"

extern FontManager* mFontMgr;
extern GUIManager* mGUIMgr;

void LoadingBar::initialize()
{
	captionFnt = mFontMgr->getFont(true, "Fonts/Calibri.ttf", 13, true, false);
}

void LoadingBar::Render()
{
	background->Render(mGUIMgr->loadingBarX, mGUIMgr->loadingBarY);
	gauge_active->RenderEx
	(
		mGUIMgr->loadingBarX+2-246.0f/2.0f, mGUIMgr->loadingBarY,
		0.0f,
		filling*242.0f/26.0f,
		1.0f
	);
	border->Render(mGUIMgr->loadingBarX, mGUIMgr->loadingBarY-2);

	spark->Render
	(
		mGUIMgr->loadingBarX+2-246.0f/2.0f+filling*242.0f,
		mGUIMgr->loadingBarY+1
	);

	// The font is rendered twice with a small offset to simulate a shadow
	if (captionFnt != NULL)
	{
		captionFnt->SetColor(ARGB(255,0,0,0));
		captionFnt->printf
		(
			mGUIMgr->loadingBarX-113, mGUIMgr->loadingBarY+5, HGETEXT_LEFT, "%s",
			caption.c_str()
		);
		captionFnt->SetColor(ARGB(255,255,255,255));
		captionFnt->printf
		(
			mGUIMgr->loadingBarX-114, mGUIMgr->loadingBarY+4, HGETEXT_LEFT, "%s",
			caption.c_str()
		);
	}
}

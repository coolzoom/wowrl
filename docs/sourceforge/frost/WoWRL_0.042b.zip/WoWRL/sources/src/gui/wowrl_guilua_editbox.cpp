/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_guimanager.h"

#include "wowrl_gui.h"

using namespace std;

extern GUIManager* mGUIMgr;
extern bool debugGUI;

l_EditBox::l_EditBox(lua_State* luaVM) : l_Frame(luaVM)
{
	name = lua_tostring(luaVM, 1);
}

int l_EditBox::ClearFocus(lua_State* luaVM)
{
	mGUIMgr->LooseFocus(base);

	return 0;
}

int l_EditBox::GetText(lua_State* luaVM)
{
	if (base != NULL)
	{
		if (base->captionFont != NULL)
		{
			lua_pushstring(luaVM, base->sEBText.c_str());
		}
		else
			lua_pushnil(luaVM);
	}
	else
		lua_pushnil(luaVM);

	return 1;
}

int l_EditBox::SetFocus(lua_State* luaVM)
{
	mGUIMgr->RequestFocus(base);

	return 0;
}

int l_EditBox::SetText(lua_State* luaVM)
{
	int error = 0;
	if ( (lua_gettop(luaVM) >= 1) && !lua_isstring(luaVM, 1) )
	{
		mlua_printError("Argument of EditBox:SetText must be a string (text)");
		error++;
	}

	if (error == 0)
	{
		string nstr;
		if (lua_gettop(luaVM) >= 1)
			nstr = lua_tostring(luaVM, 1);
		else
			nstr = "";

		if (base->sEBText != nstr)
		{
			base->sEBText = nstr;
			base->carretPos = base->sEBText.length();
			mGUIMgr->UpdateCarretPos(base);

			base->AdjustCache();
			base->_rebuildCache();
		}
	}

	return 0;
}



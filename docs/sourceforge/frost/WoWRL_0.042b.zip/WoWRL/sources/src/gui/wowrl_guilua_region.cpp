/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_scenemanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_gfxmanager.h"

#include "wowrl_gui.h"


using namespace std;

extern InputManager *mInputMgr;
extern GUIManager *mGUIMgr;
extern GFXManager *mGFXMgr;
extern bool debugGUI;

int l_Region::GetBottom(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushnumber(luaVM, mGFXMgr->sHeight+rbase->getY(false)+rbase->h);
	return 1;
}

int l_Region::GetCenter(lua_State* luaVM)
{
	if (rbase != NULL)
	{
		lua_pushnumber(luaVM, rbase->getX(false)+rbase->w/2);
		lua_pushnumber(luaVM, mGFXMgr->sHeight+rbase->getY(false)+rbase->h/2);
	}
	return 2;
}

int l_Region::GetHeight(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushnumber(luaVM, rbase->h);
	return 1;
}

int l_Region::GetLeft(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushnumber(luaVM, rbase->getX(false));
	return 1;
}

int l_Region::GetName(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushstring(luaVM, rbase->name.c_str());
	return 1;
}

int l_Region::GetParent(lua_State* luaVM)
{
	if (rbase != NULL)
	{
		if (rbase->parent != NULL)
		{
			lua_getglobal(luaVM, rbase->parent->name.c_str());
			lua_pushvalue(luaVM, -1);
		}
		else
			lua_pushnil(luaVM);
	}

	return 1;
}

int l_Region::GetPoint(lua_State* luaVM)
{
	if (rbase != NULL)
	{
		Anchor a = rbase->anchors[0];
		switch (a.anchorPt)
		{
			case GUI_ANCHOR_TOPLEFT: lua_pushstring(luaVM, "TOPLEFT"); break;
			case GUI_ANCHOR_TOP: lua_pushstring(luaVM, "TOPL"); break;
			case GUI_ANCHOR_TOPRIGHT: lua_pushstring(luaVM, "TOPRIGHT"); break;
			case GUI_ANCHOR_RIGHT: lua_pushstring(luaVM, "RIGHT"); break;
			case GUI_ANCHOR_BOTTOMRIGHT: lua_pushstring(luaVM, "BOTTOMRIGHT"); break;
			case GUI_ANCHOR_BOTTOM: lua_pushstring(luaVM, "BOTTOM"); break;
			case GUI_ANCHOR_BOTTOMLEFT: lua_pushstring(luaVM, "BOTTOMLEFT"); break;
			case GUI_ANCHOR_LEFT: lua_pushstring(luaVM, "LEFT"); break;
			case GUI_ANCHOR_CENTER: lua_pushstring(luaVM, "CENTER"); break;
		}
		lua_pushstring(luaVM, a.parent_name.c_str());
		switch (a.relativePt)
		{
			case GUI_ANCHOR_TOPLEFT: lua_pushstring(luaVM, "TOPLEFT"); break;
			case GUI_ANCHOR_TOP: lua_pushstring(luaVM, "TOPL"); break;
			case GUI_ANCHOR_TOPRIGHT: lua_pushstring(luaVM, "TOPRIGHT"); break;
			case GUI_ANCHOR_RIGHT: lua_pushstring(luaVM, "RIGHT"); break;
			case GUI_ANCHOR_BOTTOMRIGHT: lua_pushstring(luaVM, "BOTTOMRIGHT"); break;
			case GUI_ANCHOR_BOTTOM: lua_pushstring(luaVM, "BOTTOM"); break;
			case GUI_ANCHOR_BOTTOMLEFT: lua_pushstring(luaVM, "BOTTOMLEFT"); break;
			case GUI_ANCHOR_LEFT: lua_pushstring(luaVM, "LEFT"); break;
			case GUI_ANCHOR_CENTER: lua_pushstring(luaVM, "CENTER"); break;
		}
		lua_pushnumber(luaVM, a.x);
		lua_pushnumber(luaVM, a.y);
	}
	return 5;
}

int l_Region::GetRight(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushnumber(luaVM, rbase->getX(false)+rbase->w);
	return 1;
}

int l_Region::GetTop(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushnumber(luaVM, mGFXMgr->sHeight+rbase->getY(false));
	return 1;
}

int l_Region::GetWidth(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushnumber(luaVM, rbase->w);
	return 1;
}

int l_Region::Hide(lua_State* luaVM)
{
	if (rbase != NULL)
	{
		if (!rbase->hidden)
		{
			rbase->hidden = true;
			if (ebase != NULL)
			{
				ebase->_rebuildCache();
				if ( (ebase->type == GUI_OBJECT_TYPE_EDITBOX) && mGUIMgr->HasFocus(ebase) )
					mGUIMgr->LooseFocus(ebase);
			}
			else if (rbase->parent != NULL)
			{
				rbase->parent->_rebuildCache();
			}
		}
	}
	return 0;
}

int l_Region::IsShown(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushboolean(luaVM, !rbase->hidden);
	return 1;
}

int l_Region::IsVisible(lua_State* luaVM)
{
	if (rbase != NULL)
		lua_pushboolean(luaVM, rbase->IsVisible());
	return 1;
}

int l_Region::SetHeight(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		mlua_printError("Too few argument in \"Region:SetHeight\" (one expected : region height)");
		return 0;
	}
	else if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument of Region:SetHeight must be a number (region height)");
		error++;
	}

	if (error == 0)
	{
		if (rbase != NULL)
		{
			float h = lua_tonumber(luaVM, 1);
			if (h != rbase->h)
			{
				rbase->h = h;
				if (abase != NULL)
				{
					abase->text.h = abase->h;
					if (abase->type == GUI_OBJECT_TYPE_FSMSGFRAME)
					{
						abase->h -= abase->parent->SMFinsT + abase->parent->SMFinsB;
						abase->text.h = abase->h;
					}
				}
				else if (ebase != NULL)
				{
					if (ebase->useBackdrop)
					{
						if (ebase->backdrop.tile)
							ebase->backdrop.background->SetTextureRect(
								0, 0,
								ebase->w-ebase->backdrop.insL-ebase->backdrop.insR,
								ebase->h-ebase->backdrop.insT-ebase->backdrop.insB
							);
						if (ebase->h < 2*ebase->backdrop.edgeSize)
						{
							ebase->h = 2*ebase->backdrop.edgeSize;
						}
					}
					ebase->recreateCache = true;
					ebase->fTD = 0;
					ebase->fBD = 0;
					ebase->AdjustCache(false);
				}

				if (rbase->parent != NULL)
				{
					rbase->parent->AdjustCache();
					rbase->parent->_rebuildCache();
				}
			}
		}
	}

	return 0;
}

int l_Region::SetPoint(lua_State* luaVM)
{
	int error = 0;
	bool offsetDefined = false;
	if (lua_gettop(luaVM) < 3)
	{
		mlua_printError("Too few argument in \"Region:SetPoint\" (3 or 5 expected : point, relativeTo, relativePoint [, offx, offy])");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of Region:SetPoint must be a string (anchor point)");
		error++;
	}
	if (!lua_isstring(luaVM, 2) && !lua_isnil(luaVM, 2))
	{
		mlua_printError("Argument 2 of Region:SetPoint must be a string (or nil) (anchor parent)");
		error++;
	}
	if (!lua_isstring(luaVM, 3))
	{
		mlua_printError("Argument 3 of Region:SetPoint must be a string (parent point)");
		error++;
	}
	if (lua_gettop(luaVM) >= 5)
	{
		offsetDefined = true;
		if (!lua_isnumber(luaVM, 4))
		{
			mlua_printError("Argument 4 of Region:SetPoint must be a number (x offset)");
			error++;
		}
		if (!lua_isnumber(luaVM, 5))
		{
			mlua_printError("Argument 5 of Region:SetPoint must be a number (y offset)");
			error++;
		}
	}

	if (error == 0)
	{
		if (rbase != NULL)
		{
			bool noParent;
			if (lua_isnil(luaVM, 2))
				noParent = true;
			else
				noParent = false;

			string point, relativeTo, relativePoint;
			float ox, oy;

			point = lua_tostring(luaVM, 1);

			if (!noParent)
				relativeTo = lua_tostring(luaVM, 2);

			relativePoint = lua_tostring(luaVM, 3);

			if (offsetDefined)
			{
				ox = lua_tonumber(luaVM, 4);
				oy = lua_tonumber(luaVM, 5);
			}

			if ((mGUIMgr->guiList.find(relativeTo) != mGUIMgr->guiList.end()) ||
				(noParent))
			{
				Anchor a;
				if (point == string("TOPLEFT"))
					a.anchorPt = GUI_ANCHOR_TOPLEFT;
				else if (point == string("TOP"))
					a.anchorPt = GUI_ANCHOR_TOP;
				else if (point == string("TOPRIGHT"))
					a.anchorPt = GUI_ANCHOR_TOPRIGHT;
				else if (point == string("RIGHT"))
					a.anchorPt = GUI_ANCHOR_RIGHT;
				else if (point == string("BOTTOMRIGHT"))
					a.anchorPt = GUI_ANCHOR_BOTTOMRIGHT;
				else if (point == string("BOTTOM"))
					a.anchorPt = GUI_ANCHOR_BOTTOM;
				else if (point == string("BOTTOMLEFT"))
					a.anchorPt = GUI_ANCHOR_BOTTOMLEFT;
				else if (point == string("LEFT"))
					a.anchorPt = GUI_ANCHOR_LEFT;
				else if (point == string("CENTER"))
					a.anchorPt = GUI_ANCHOR_CENTER;

				if (!noParent)
				{
					a.parent_name = relativeTo;
					a.parent = &mGUIMgr->guiList[relativeTo];
				}

				if (relativePoint == string("TOPLEFT"))
					a.relativePt = GUI_ANCHOR_TOPLEFT;
				else if (relativePoint == string("TOP"))
					a.relativePt = GUI_ANCHOR_TOP;
				else if (relativePoint == string("TOPRIGHT"))
					a.relativePt = GUI_ANCHOR_TOPRIGHT;
				else if (relativePoint == string("RIGHT"))
					a.relativePt = GUI_ANCHOR_RIGHT;
				else if (relativePoint == string("BOTTOMRIGHT"))
					a.relativePt = GUI_ANCHOR_BOTTOMRIGHT;
				else if (relativePoint == string("BOTTOM"))
					a.relativePt = GUI_ANCHOR_BOTTOM;
				else if (relativePoint == string("BOTTOMLEFT"))
					a.relativePt = GUI_ANCHOR_BOTTOMLEFT;
				else if (relativePoint == string("LEFT"))
					a.relativePt = GUI_ANCHOR_LEFT;
				else if (relativePoint == string("CENTER"))
					a.relativePt = GUI_ANCHOR_CENTER;

				if (offsetDefined)
				{
					a.x = ox;
					a.y = oy;
				}

				Anchor a2 = rbase->anchors[0];
				if ((a.x != a2.x)               ||
					(a.y != a2.y)               ||
					(a.anchorPt != a2.anchorPt) ||
					(a.parent != a2.parent)     ||
					(a.relativePt != a2.relativePt))
				{
					rbase->anchors[0] = a;
					if (rbase->parent != NULL)
					{
						rbase->parent->AdjustCache();
						rbase->parent->_rebuildCache();
					}
				}
			}
			else
				mlua_printError("Error in " + rbase->name + ":SetPoint : unknown object \"" + relativeTo + "\"");
		}
	}

	return 0;
}

int l_Region::SetWidth(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		mlua_printError("Too few argument in \"Region:SetWidth\" (one expected : region width)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument of Region:SetWidth must be a number (region width)");
		error++;
	}

	if (error == 0)
	{
		if (rbase != NULL)
		{
			float w = lua_tonumber(luaVM, 1);
			if (w != rbase->w)
			{
				rbase->w = w;
				if (abase != NULL)
				{
					abase->text.w = abase->w;
					if (abase->type == GUI_OBJECT_TYPE_FSMSGFRAME)
					{
						abase->w -= abase->parent->SMFinsL + abase->parent->SMFinsR;
						abase->text.w = abase->w;
					}
				}
				else if (ebase != NULL)
				{
					if (ebase->useBackdrop)
					{
						if (ebase->backdrop.tile)
							ebase->backdrop.background->SetTextureRect(
								0, 0,
								ebase->w-ebase->backdrop.insL-ebase->backdrop.insR,
								ebase->h-ebase->backdrop.insT-ebase->backdrop.insB
							);
						if (ebase->w < 2*ebase->backdrop.edgeSize)
						{
							ebase->w = 2*ebase->backdrop.edgeSize;
						}
					}
					ebase->recreateCache = true;
					ebase->fTD = 0;
					ebase->fBD = 0;
					ebase->AdjustCache(false);
				}

				if (rbase->parent != NULL)
				{
					rbase->parent->AdjustCache();
					rbase->parent->_rebuildCache();
				}
			}
		}
	}

	return 0;
}

int l_Region::Show(lua_State* luaVM)
{
	if (rbase != NULL)
	{
		if (rbase->hidden)
		{
			rbase->hidden = false;
			if (ebase != NULL)
			{
				if (ebase->parent != NULL)
					ebase->parent->AdjustCache();
				ebase->_rebuildCache(true);
				if ( (ebase->type == GUI_OBJECT_TYPE_EDITBOX) && ebase->autoFocus )
					mGUIMgr->RequestFocus(ebase);
			}
			else if (rbase->parent != NULL)
			{
				rbase->parent->AdjustCache();
				rbase->parent->_rebuildCache(true);
			}
		}
	}
	return 0;
}

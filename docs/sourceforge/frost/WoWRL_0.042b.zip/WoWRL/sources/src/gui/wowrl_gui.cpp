/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               GUI source               */
/*                                        */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_lua.h"
#include "wowrl_scenemanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_global.h"

#include "wowrl_gui.h"

#define MAX_TARGET_SIZE 2048

extern SceneManager *mSceneMgr;
extern InputManager *mInputMgr;
extern GUIManager *mGUIMgr;
extern GFXManager *mGFXMgr;
extern HGE* hge;
using namespace std;

bool debugGUI = false;

GUIElement::GUIElement() : GUIBase()
{
	w = -1;
	h = -1;

	iHitInsL = 0;
    iHitInsR = 0;
    iHitInsT = 0;
    iHitInsB = 0;

	fLD = 0;
	fRD = 0;
	fTD = 0;
	fBD = 0;

	parent = NULL;
	parent_name = "";
	name = "";
	vname = "";
	hidden = false;
	virt = false;
	ready = true;
	child = false;
	rebuildList = true;
	rebuildCache = true;
	rebuildBackdrop = true;
	recreateCache = false;
	frameStrata = 2;
	lastOn = false;
	baseUI = false;
	useBackdrop = false;
	enableMouse = false;
	registeredForDrag = false;

	value = 1.0f;
	min_value = 0.0f;
	max_value = 1.0f;
	barTexture = NULL;

	sEBText = "";
	letters = 0;
	historyLines = 0;
	blinkSpeed = 0.5f;
	carretPos = 0;
	iSubStrStart = 0;
	iSubStrLength = 0;
	carretTimer = 0.0f;
	carretScale = 1.0f;
	EBinsL = 0;
	EBinsR = 0;
	EBinsT = 0;
	EBinsB = 0;
	showCarret = true;
	numeric = false;
	password = false;
	multiLine = false;
	ignoreArrows = false;
	autoFocus = true;
	captionFont = NULL;

	maxLines = 8;
	actualLine = 1;
	bottomLine = 1;
	oldBottomLine = 1;
    fadeDuration = 3.0f;
    displayDuration = 10.0f;
    fade = true;
    SMFinsL = 0;
    SMFinsR = 0;
    SMFinsT = 0;
    SMFinsB = 0;

	texNormal = NULL;
	texPushed = NULL;
	texDisabled = NULL;
	texHighlight = NULL;
	fontNormal = NULL;
	fontHighlight = NULL;
	fontDisabled = NULL;
	iPushTxtOffX = 0;
	iPushTxtOffY = 0;
	bMouseDown = false;
	bButtonFontReady = false;
	bButtonTextureReady = false;
	bButtonDisabled = false;
	bAtBottom = true;
	bAtTop = true;
	sButtonText = "";
	iButtonState = GUI_BUTTON_STATE_NORMAL;

	spr = NULL;
	banchor = NULL;
}

void GUIElement::deleteMe()
{
	hge->Target_Free(target);
	if (spr) delete spr;

	if (useBackdrop)
	{
		hge->Target_Free(backdrop.target);
		if (backdrop.spr) delete backdrop.spr;

		if (backdrop.edgeReady)
		{
			delete backdrop.edgeL;
			delete backdrop.edgeR;
			delete backdrop.edgeT;
			delete backdrop.edgeB;
			delete backdrop.cornerTL;
			delete backdrop.cornerTR;
			delete backdrop.cornerBL;
			delete backdrop.cornerBR;
		}

		if (backdrop.bgReady)
			delete backdrop.background;
	}
}

float GUIBase::getX( bool relative )
{
	if (banchor == NULL)
		banchor = &anchors[0];
	float px = 0.0f;
	float pw = 0.0f;
	if (banchor->parent != NULL)
	{
		if (banchor->parent != this)
		{
			pw = banchor->parent->w;
			if (!relative)
				px += banchor->parent->getX(false);
		}
	}
	else
	{
		pw = mGFXMgr->sWidth;
	}

	switch (banchor->anchorPt)
	{
		case GUI_ANCHOR_TOPLEFT: px-=0; break;
		case GUI_ANCHOR_TOP: px-=w/2.0f; break;
		case GUI_ANCHOR_TOPRIGHT: px-=w; break;
		case GUI_ANCHOR_RIGHT: px-=w; break;
		case GUI_ANCHOR_BOTTOMRIGHT: px-=w; break;
		case GUI_ANCHOR_BOTTOM: px-=w/2.0f; break;
		case GUI_ANCHOR_BOTTOMLEFT: px-=0; break;
		case GUI_ANCHOR_LEFT: px-=0; break;
		case GUI_ANCHOR_CENTER: px-=w/2.0f; break;
	}

	switch (banchor->relativePt)
	{
		case GUI_ANCHOR_TOPLEFT: px+=0; break;
		case GUI_ANCHOR_TOP: px+=pw/2.0f; break;
		case GUI_ANCHOR_TOPRIGHT: px+=pw; break;
		case GUI_ANCHOR_RIGHT: px+=pw; break;
		case GUI_ANCHOR_BOTTOMRIGHT: px+=pw; break;
		case GUI_ANCHOR_BOTTOM: px+=pw/2.0f; break;
		case GUI_ANCHOR_BOTTOMLEFT: px+=0; break;
		case GUI_ANCHOR_LEFT: px+=0; break;
		case GUI_ANCHOR_CENTER: px+=pw/2.0f; break;
	}

	x = px+banchor->x;

	return x;
}

float GUIBase::getY( bool relative )
{
	if (banchor == NULL)
		banchor = &anchors[0];

	float py = 0.0f;
	float ph = 0.0f;
	if (banchor->parent != NULL)
	{
		if (banchor->parent != this)
		{
			ph = banchor->parent->h;
			if (!relative)
				py += banchor->parent->getY(false);
		}
	}
	else
	{
		ph = mGFXMgr->sHeight;
	}

	switch (banchor->anchorPt)
	{
		case GUI_ANCHOR_TOPLEFT: py+=0; break;
		case GUI_ANCHOR_TOP: py+=0; break;
		case GUI_ANCHOR_TOPRIGHT: py+=0; break;
		case GUI_ANCHOR_RIGHT: py+=h/2.0f; break;
		case GUI_ANCHOR_BOTTOMRIGHT: py+=h; break;
		case GUI_ANCHOR_BOTTOM: py+=h; break;
		case GUI_ANCHOR_BOTTOMLEFT: py+=h; break;
		case GUI_ANCHOR_LEFT: py+=h/2.0f; break;
		case GUI_ANCHOR_CENTER: py+=h/2.0f; break;
	}

	switch (banchor->relativePt)
	{
		case GUI_ANCHOR_TOPLEFT: py-=0; break;
		case GUI_ANCHOR_TOP: py-=0; break;
		case GUI_ANCHOR_TOPRIGHT: py-=0; break;
		case GUI_ANCHOR_RIGHT: py-=ph/2.0f; break;
		case GUI_ANCHOR_BOTTOMRIGHT: py-=ph; break;
		case GUI_ANCHOR_BOTTOM: py-=ph; break;
		case GUI_ANCHOR_BOTTOMLEFT: py-=ph; break;
		case GUI_ANCHOR_LEFT: py-=ph/2.0f; break;
		case GUI_ANCHOR_CENTER: py-=ph/2.0f; break;
	}

	y = py+banchor->y;

	return y;
}

void GUIBase::_init()
{
	/* [#] This function takes care of initialization of the GUIBase class.
	/* It calls the _init() lua method which creates a pointer to this object in
	/* it's corresponding element in the LUA environnement.
	*/
	bool debugThis = false;

	// Initialize LUA class
	if ((type != GUI_OBJECT_TYPE_FEDITBOX)   &&
		(type != GUI_OBJECT_TYPE_FSMSGFRAME) &&
		(type != GUI_OBJECT_TYPE_FNBUTTON)   &&
		(type != GUI_OBJECT_TYPE_FHBUTTON)   &&
		(type != GUI_OBJECT_TYPE_FDBUTTON)   &&
		(type != GUI_OBJECT_TYPE_TNBUTTON)   &&
		(type != GUI_OBJECT_TYPE_THBUTTON)   &&
		(type != GUI_OBJECT_TYPE_TDBUTTON)   &&
		(type != GUI_OBJECT_TYPE_TPBUTTON))
	{
		string exec = name + ":_init();";
		if (debugThis) hge->System_Log("%s", exec.c_str());
		int error = luaL_dostring(mSceneMgr->luaVM, exec.c_str());
		if (error) l_logPrint(mSceneMgr->luaVM);
		GUIBase* p = parent;
		string hierarchy = sname;
		string newObj;
		while (p != NULL)
		{
			newObj = p->name + "." + hierarchy;
			exec = newObj + " = " + name + ";\n";
			exec += newObj + ":_init();";
			if (debugThis) hge->System_Log("%s", exec.c_str());
			int error = luaL_dostring(mSceneMgr->luaVM, exec.c_str());
			if (error) l_logPrint(mSceneMgr->luaVM);
			hierarchy = p->sname + "." + hierarchy;
			p = p->parent;
		}
	}

	// Initialize position and anchors
	banchor = &anchors[0];
	this->getX();
	this->getY();

}

void GUIElement::_init()
{
	/* [#] This function takes care of initialization of the GUIElement class.
	/* It calls the GUIBase::_init() function and creates the render target
	/* associated with this element.
	*/
	GUIBase* thisB = this;
	thisB->_init();

	map<string, GUIElement*>::iterator iterChild;
	for (iterChild = childs.begin(); iterChild != childs.end(); iterChild++)
	{
		GUIElement* g = iterChild->second;
		g->_init();

		map<string, GUIArt>::iterator iter;
		for (iter = g->arts.begin(); iter != g->arts.end(); iter++)
		{
			GUIArt* a = &iter->second;
			a->_init();
		}
	}

	// Initialize cache
	target = hge->Target_Create(toInt(w), toInt(h), false);
	spr = new hgeSprite(hge->Target_GetTexture(target), 0, 0, toInt(w), toInt(h));
}

void GUIElement::_rebuildCache( bool child )
{
	/* [#] This function is used to tell the program to re-draw the cache the
	/* next time Render() is called. When called, this function also calls itself
	/* on the element's parent, and on all of it's child if stated.
	*/
	rebuildCache = true;
	if (child)
	{
		map<string, GUIElement*>::iterator iterChild;
		for (iterChild = childs.begin(); iterChild != childs.end(); iterChild++)
		{
			iterChild->second->_rebuildCache(true);
		}
	}
	if (parent != NULL)
		parent->_rebuildCache();
}

bool GUIBase::IsVisible()
{
	/* [#] This function checks if this GUI object is visible or not. That means
	/* that it is shown, and all it's parent also.
	*/
	if (parent == NULL)
		return !hidden;
	else
	{
		return (!hidden && parent->IsVisible());
	}
}

void GUIArt::Render()
{
	// [#] This function renders a GUI art (texture or text).
	if (ready && !hidden)
	{
		// The coordinates are relative to its parent.
		ax = this->getX()-parent->getX()+parent->fLD;
		ay = parent->getY()-this->getY()+parent->fTD;
		if ((type == GUI_OBJECT_TYPE_TEXTURE)  ||
			(type == GUI_OBJECT_TYPE_TNBUTTON) ||
			(type == GUI_OBJECT_TYPE_TPBUTTON) ||
			(type == GUI_OBJECT_TYPE_THBUTTON) ||
			(type == GUI_OBJECT_TYPE_TDBUTTON))
		{
			if (sprite != NULL)
			{
				sprite->RenderEx(ax, ay, angle, scale, vscale);
				//sprite->RenderEx(ax, ay, angle, scale, vscale);
			}
		}
		else if ((type == GUI_OBJECT_TYPE_FONTSTRING) ||
				 (type == GUI_OBJECT_TYPE_FEDITBOX)   ||
				 (type == GUI_OBJECT_TYPE_FSMSGFRAME) ||
				 (type == GUI_OBJECT_TYPE_FNBUTTON)   ||
				 (type == GUI_OBJECT_TYPE_FHBUTTON)   ||
				 (type == GUI_OBJECT_TYPE_FDBUTTON))
		{
			if (text.fnt != NULL)
			{
				if (text.outline != 0)
				{
					text.fnt->SetTracking(text.tracking);
					text.fnt->SetColor(ARGB(200, 0, 0, 0));

					// Render the text all around to acheive the outline effect
					for (float f = 0.0f; f <= 1.0f; f += 0.1f)
					{
						text.fnt->printfb
						(
							ax+text.outline*cos(f*2*M_PI), ay+text.outline*sin(f*2*M_PI),
							w, h, text.align,
							text.sStr.c_str()
						);
					}

					list<FormatedString>::iterator iterStr;
					for (iterStr = text.lFStr.begin(); iterStr != text.lFStr.end(); iterStr++)
					{
						FormatedString* fs = &(*iterStr);
						text.fnt->SetColor(fs->dColor);
						text.fnt->printfbd(fs->fX, fs->fY, ax, ay, w, h, text.align, fs->sStr.c_str());
						//text.fnt->printfbd(fs->fX, fs->fY, ax, ay, w, h, text.align, fs->sStr.c_str());
					}
				}
				else
				{
					text.fnt->SetTracking(text.tracking);

					if (text.shadow)
					{
						text.fnt->SetColor(text.scolor);
						text.fnt->printfb(ax+text.sox, ay-text.soy, w, h, text.align, text.sStr.c_str());
						//text.fnt->printfb(ax+text.sox, ay-text.soy, w, h, text.align, text.sStr.c_str());
					}

					list<FormatedString>::iterator iterStr;
					for (iterStr = text.lFStr.begin(); iterStr != text.lFStr.end(); iterStr++)
					{
						FormatedString* fs = &(*iterStr);
						text.fnt->SetColor(fs->dColor);
						text.fnt->printfbd(fs->fX, fs->fY, ax, ay, w, h, text.align, fs->sStr.c_str());
						//text.fnt->printfbd(fs->fX, fs->fY, ax, ay, w, h, text.align, fs->sStr.c_str());
					}
				}
			}
		}
		else if (type == GUI_OBJECT_TYPE_TSTATUSBAR)
		{
			if (sprite != NULL)
			{
				float x,y,w,h;
				sprite->GetTextureRect(&x, &y, &w, &h);
				// Here we adjust the texture coordinate to achieve the status bar effect.
				w = parent->base_width*((parent->value-parent->min_value)/(parent->max_value-parent->min_value));
				sprite->SetTextureRect(x, y, w, h);
				sprite->RenderEx(ax, ay, angle, scale, vscale);
				//sprite->RenderEx(ax, ay, angle, scale, vscale);
			}
		}
	}
}

void GUIElement::AdjustCache( bool adjustParent )
{
	if (!baseUI)
	{
		bool debugThis = false;
		//if (name == "CastBarStatusBar") debugThis = true;

		// Save old displacements
		float fOldLD = fLD;
		float fOldRD = fRD;
		float fOldTD = fTD;
		float fOldBD = fBD;

		float fMaxW = w+fRD;
		float fMaxH = h+fBD;
		float fMinW = -fLD;
		float fMinH = -fTD;

		if (debugThis) hge->System_Log("old disp : %f, %f, %f, %f", fLD, fRD, fTD, fBD);
		if (debugThis) hge->System_Log("old dims : %f, %f, %f, %f", fMinW, fMaxW, fMinH, fMaxH);

		// Check childs
		map<string, GUIElement*>::iterator iterChild;
		for (iterChild = childs.begin(); iterChild != childs.end(); iterChild++)
		{
			GUIElement* g = iterChild->second;
			if (!g->hidden)
			{
				float gx = g->getX()-this->getX();
				float gy = -g->getY()+this->getY();

				float fNewMaW = gx+g->w+g->fRD;
				if (fNewMaW > fMaxW)
					fMaxW = fNewMaW;
				float fNewMiW = gx-g->fLD;
				if (fNewMiW < fMinW)
					fMinW = fNewMiW;

				float fNewMaH = gy+g->h+g->fBD;
				if (fNewMaH > fMaxH)
					fMaxH = fNewMaH;
				float fNewMiH = gy-g->fTD;
				if (fNewMiH < fMinH)
					fMinH = fNewMiH;
				if (debugThis) hge->System_Log(" child : %s, %f, %f, %f, %f", g->name.c_str(), fNewMiW, fNewMaW, fNewMiH, fNewMaH);
			}
		}

		// Check arts
		map<std::string, GUIArt>::iterator iterArt;
		for (iterArt = arts.begin(); iterArt != arts.end(); iterArt++)
		{
			GUIArt* a = &iterArt->second;
			if (!a->hidden)
			{
				float ax = a->getX()-this->getX()+parent->fLD;
				float ay = -a->getY()+this->getY()+parent->fTD;

				float fNewMaW = ax+a->w;
				if (fNewMaW > fMaxW)
					fMaxW = fNewMaW;
				float fNewMiW = ax;
				if (fNewMiW < fMinW)
					fMinW = fNewMiW;

				float fNewMaH = ay+a->h;
				if (fNewMaH > fMaxH)
					fMaxH = fNewMaH;
				float fNewMiH = ay;
				if (fNewMiH < fMinH)
					fMinH = fNewMiH;
				if (debugThis) hge->System_Log("   art : %s, %f, %f, %f, %f", a->name.c_str(), fNewMiW, fNewMaW, fNewMiH, fNewMaH);
			}
		}

		// Get new displacements
		fLD = -fMinW;
		fRD = fMaxW-w;
		fTD = -fMinH;
		fBD = fMaxH-h;

		if (debugThis) hge->System_Log("new disp : %f, %f, %f, %f", fLD, fRD, fTD, fBD);

		// If at least a single one of them has changed, rebuild everything
		if ( (fOldLD != fLD) || (fOldRD != fRD) || (fOldTD != fTD) || (fOldBD != fBD) )
		{
			recreateCache = true;
			_rebuildCache();
		}

		// And call it for its parent
		if ( (parent != NULL) && adjustParent )
			parent->AdjustCache();

	}
}

void GUIElement::Render( bool cache )
{
	/* [#] This function renders a GUI element on the screen or on it's parent
	/* cache depending on the provided boolean. The cache system is used to
	/* increase the GUI performance by re-drawing every element only if needed.
	*/

	if (this->IsVisible() && ready)
	{
		if (cache)
		{
			if (recreateCache)
			{
				// The cache needs to be re-created (size change, mainly)
				if (debugGUI) {hge->System_Log("%s : recreateCache...", name.c_str());}
				float fTW = hge->Texture_GetWidth(hge->Target_GetTexture(target));
				float fTH = hge->Texture_GetHeight(hge->Target_GetTexture(target));
				int iNewW = toInt(w+fLD+fRD);
				int iNewH = toInt(h+fTD+fBD);
				if ( (iNewW > fTW) || (iNewH > fTH) )
				{
					// Create a new target only if it would be bigger than the previous one
					hge->Target_Free(target);
					target = hge->Target_Create(
						min(MAX_TARGET_SIZE, nearestPow2Up(iNewW)),
						min(MAX_TARGET_SIZE, nearestPow2Up(iNewH)),
						false
					);
				}
				delete spr;
				spr = new hgeSprite(hge->Target_GetTexture(target), 0, 0, toInt(w+fLD+fRD), toInt(h+fTD+fBD));
				recreateCache = false;
				rebuildCache = true;
				if (useBackdrop)
				{
					hge->Target_Free(backdrop.target);
					backdrop.target = hge->Target_Create(
						min(MAX_TARGET_SIZE, toInt(w)),
						min(MAX_TARGET_SIZE, toInt(h)),
						false
					);
					delete backdrop.spr;
					backdrop.spr = new hgeSprite(hge->Target_GetTexture(backdrop.target), 0, 0, toInt(w), toInt(h));
					rebuildBackdrop = true;
				}
			}

			if (rebuildCache)
			{
				if (debugGUI) {hge->System_Log("%s : rebuildCache...", name.c_str());}
				if (useBackdrop && rebuildBackdrop)
				{
					if (debugGUI) {hge->System_Log(" rebuildBackdrop...", name.c_str());}
					// Cache the backdrop
					hge->Gfx_BeginScene(backdrop.target);
					mGFXMgr->mDxDevice->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, TRUE);
					mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
					mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
					mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLENDALPHA, D3DBLEND_ONE);
					mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLENDALPHA, D3DBLEND_INVSRCALPHA);
					hge->Gfx_Clear(ARGB(0,0,0,0));

					// Render the background
					if (backdrop.bgReady)
					{
						if (fabs(h-backdrop.insT-backdrop.insB) > 0.1f)
						{
							backdrop.background->SetColor(backdrop.bgColor);
							if (backdrop.tile)
								backdrop.background->Render(backdrop.insL, backdrop.insT);
							else
								backdrop.background->RenderEx(
									backdrop.insL,
									backdrop.insT,
									0.0f,
									(w-backdrop.insL-backdrop.insR)/backdrop.bgW,
									(h-backdrop.insT-backdrop.insB)/backdrop.bgH
								);
						}
					}
					else if (backdrop.bgReadyC)
					{
						hgeQuad q;
						q.tex = 0;
						q.blend = BLEND_DEFAULT;
						q.v[0].col = backdrop.bgColor;
						q.v[0].x = backdrop.insL;
						q.v[0].y = backdrop.insT;
						q.v[1].col = backdrop.bgColor;
						q.v[1].x = w-backdrop.insR;
						q.v[1].y = backdrop.insT;
						q.v[2].col = backdrop.bgColor;
						q.v[2].x = w-backdrop.insR;
						q.v[2].y = h-backdrop.insB;
						q.v[3].col = backdrop.bgColor;
						q.v[3].x = backdrop.insL;
						q.v[3].y = h-backdrop.insB;

						hge->Gfx_RenderQuad(&q);
					}

					if (backdrop.edgeReady)
					{
						// Render corners
						backdrop.cornerTL->RenderEx(0, 0, 0.0f, backdrop.edgeSize/backdrop.edgeOriginalSize);
						backdrop.cornerTR->RenderEx(w-backdrop.edgeSize, 0, 0.0f, backdrop.edgeSize/backdrop.edgeOriginalSize);
						backdrop.cornerBL->RenderEx(0, h-backdrop.edgeSize, 0.0f, backdrop.edgeSize/backdrop.edgeOriginalSize);
						backdrop.cornerBR->RenderEx(w-backdrop.edgeSize, h-backdrop.edgeSize, 0.0f, backdrop.edgeSize/backdrop.edgeOriginalSize);
						// Render edges
						backdrop.edgeL->Render4V(
							0, backdrop.edgeSize,
							backdrop.edgeSize, backdrop.edgeSize,
							backdrop.edgeSize, h-backdrop.edgeSize,
							0, h-backdrop.edgeSize
						);
						backdrop.edgeR->Render4V(
							w-backdrop.edgeSize, backdrop.edgeSize,
							w, backdrop.edgeSize,
							w, h-backdrop.edgeSize,
							w-backdrop.edgeSize, h-backdrop.edgeSize
						);
						backdrop.edgeT->Render4V(
							w-backdrop.edgeSize, 0,
							w-backdrop.edgeSize, backdrop.edgeSize,
							backdrop.edgeSize, backdrop.edgeSize,
							backdrop.edgeSize, 0
						);
						backdrop.edgeB->Render4V(
							w-backdrop.edgeSize, h-backdrop.edgeSize,
							w-backdrop.edgeSize, h,
							backdrop.edgeSize, h,
							backdrop.edgeSize, h-backdrop.edgeSize
						);
					}

					hge->Gfx_EndScene();

					if (debugGUI) {hge->System_Log(" done.", name.c_str());}

					rebuildBackdrop = false;
				}

				// Re-order childs acording to their frameStrata
				if (rebuildList)
				{
					sortedGUIList.clear();
					map<string, GUIElement*>::iterator iterChild;
					for (iterChild = childs.begin(); iterChild != childs.end(); iterChild++)
					{
						GUIElement* g = iterChild->second;
						sortedGUIList.insert(make_pair(g->frameStrata, g));
					}
					rebuildList = false;
				}

				// Allow them to re-draw/re-create their cache
				multimap<int, GUIElement*>::iterator iterChild2;
				for (iterChild2 = sortedGUIList.begin(); iterChild2 != sortedGUIList.end(); iterChild2++)
				{
					iterChild2->second->Render(true);
				}

				hge->Gfx_BeginScene(target);
				mGFXMgr->mDxDevice->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, TRUE);
				mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
				mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
				mGFXMgr->mDxDevice->SetRenderState(D3DRS_SRCBLENDALPHA, D3DBLEND_ONE);
				mGFXMgr->mDxDevice->SetRenderState(D3DRS_DESTBLENDALPHA, D3DBLEND_INVSRCALPHA);
				hge->Gfx_Clear(ARGB(0,0,0,0));

				//hge->Gfx_Clear(ARGB(255,hge->Random_Int(0, 255),hge->Random_Int(0, 255),hge->Random_Int(0, 255)));

				// Render the backdrop
				if (useBackdrop)
				{
					backdrop.spr->Render(fLD,fTD);
				}

				// Sort arts by layers
				multimap<int, GUIArt*> sortedMap;
				map<std::string, GUIArt>::iterator iterArt;
				for (iterArt = arts.begin(); iterArt != arts.end(); iterArt++)
				{
					sortedMap.insert(make_pair(iterArt->second.layer, &iterArt->second));
				}

				// Then render them in the proper order
				multimap<int, GUIArt*>::iterator iterSArt;
				for (iterSArt = sortedMap.begin(); iterSArt != sortedMap.end(); iterSArt++)
				{
					GUIArt* a = iterSArt->second;
					a->Render();
				}

				// Render the carret for the EditBox
				if ( (type == GUI_OBJECT_TYPE_EDITBOX) && showCarret && mGUIMgr->HasFocus(this) )
				{
					mGUIMgr->carret->RenderEx(carretX+fLD, carretY+2+fTD, 0.0f, carretScale);
				}

				if (debugGUI) {hge->System_Log(" childs...");}

				// Render childs
				for (iterChild2 = sortedGUIList.begin(); iterChild2 != sortedGUIList.end(); iterChild2++)
				{
					iterChild2->second->Render(false);
				}

				hge->Gfx_EndScene();

				if (debugGUI) {hge->System_Log("Done.");}

				rebuildCache = false;
			}
		}
		else
		{
			if (parent != NULL)
			{
				gx = this->getX()-parent->getX()+parent->fLD-fLD;
				gy = parent->getY()-this->getY()+parent->fTD-fTD;
			}
			else
			{
				gx = this->getX();
				gy = -this->getY();
			}

			// Just render the cache
			spr->Render(gx, gy);
		}
	}
}

void GUIElement::copyVirt(GUIElement* frame)
{
	/* [#] This function copies this virtual frame's properties in the provided
	/* real frame. This function allows inheritance and templates.
	*/
	bool debugThis = false;
	if (frame == NULL)
	{
		if (debugThis) hge->System_Log("Error copying %s to unknown frame", vname.c_str());
	}
	else
	{
		if (debugThis) hge->System_Log("Copying %s to %s", vname.c_str(), frame->name.c_str());
		if (virt && !frame->virt)
		{
			// Copy base parameters
			if (debugThis) hge->System_Log("1");
			frame->hidden = hidden;
			frame->w = w;
			frame->h = h;
			frame->alpha = alpha;
			frame->enableMouse = enableMouse;

			frame->funcList = funcList;

			// Status bar
			frame->value = value;
			frame->min_value = min_value;
			frame->max_value = max_value;
			frame->base_width = base_width;
			frame->barTextureName = barTextureName;

			// Edit box
			frame->letters = letters;
			frame->historyLines = historyLines;
			frame->blinkSpeed = blinkSpeed;
			frame->numeric = numeric;
			frame->password = password;
			frame->multiLine = multiLine;
			frame->ignoreArrows = ignoreArrows;
			frame->autoFocus = autoFocus;
			frame->captionFontName = captionFontName;

			// Copy and update backdrop
			frame->useBackdrop = useBackdrop;
			if (useBackdrop)
			{
				frame->backdrop = backdrop;

				// Load edges
				if (frame->backdrop.edgeFile != "")
				{
					HTEXTURE tex1 = mGFXMgr->loadTexture(frame->backdrop.edgeFile, false);
					float size = (int)floor(hge->Texture_GetWidth(tex1, true)/8.0f);
					frame->backdrop.edgeL = new hgeSprite(tex1, 0, 0, size, size);
					frame->backdrop.edgeR = new hgeSprite(tex1, size, 0, size, size);
					frame->backdrop.edgeT = new hgeSprite(tex1, 2*size, 0, size, size);
					frame->backdrop.edgeB = new hgeSprite(tex1, 3*size, 0, size, size);
					frame->backdrop.cornerTL = new hgeSprite(tex1, 4*size, 0, size, size);
					frame->backdrop.cornerTR = new hgeSprite(tex1, 5*size, 0, size, size);
					frame->backdrop.cornerBL = new hgeSprite(tex1, 6*size, 0, size, size);
					frame->backdrop.cornerBR = new hgeSprite(tex1, 7*size, 0, size, size);
					frame->backdrop.edgeOriginalSize = size;
					frame->backdrop.edgeReady = true;
				}
				else
					frame->backdrop.edgeReady = false;

				// Load background
				if (frame->backdrop.bgFile != "")
				{
					HTEXTURE tex2;
					tex2 = mGFXMgr->loadTexture(frame->backdrop.bgFile, false);

					frame->backdrop.bgW = hge->Texture_GetWidth(tex2, true);
					frame->backdrop.bgH = hge->Texture_GetHeight(tex2, true);

					if (frame->backdrop.tile)
						frame->backdrop.background = new hgeSprite(tex2, 0, 0, frame->w-frame->backdrop.insL-frame->backdrop.insR, frame->h-frame->backdrop.insT-frame->backdrop.insB);
					else
						frame->backdrop.background = new hgeSprite(tex2, 0, 0, frame->backdrop.bgW, frame->backdrop.bgH);

					frame->backdrop.bgReady = true;
				}
				else
					frame->backdrop.bgReady = false;

				frame->backdrop.target = hge->Target_Create(toInt(frame->w), toInt(frame->h), false);
				frame->backdrop.spr = new hgeSprite(hge->Target_GetTexture(frame->backdrop.target), 0, 0, toInt(frame->w), toInt(frame->h));
			}

			// Copy and update anchors
			map<int, Anchor>::iterator iter;
			for (iter = anchors.begin(); iter != anchors.end(); iter++)
			{
				Anchor a = iter->second;
				int i = a.parent_name.find("$parent");
				if (i != a.parent_name.npos)
				{
					a.parent_name = a.parent_name.erase(i, 7);
					if (frame->parent != NULL)
						a.parent_name.insert(i, frame->parent->name);
				}
				if (mGUIMgr->parentList.find(a.parent_name) != mGUIMgr->parentList.end())
				{
					a.parent = mGUIMgr->parentList[a.parent_name];
					frame->anchors[iter->first] = a;
				}
				else
					hge->System_Log("# Error # : unknown parent %s", a.parent_name.c_str());
			}

			// Copy and update arts
			if (debugThis) hge->System_Log("2");
			map<string, GUIArt>::iterator iterArt;
			for (iterArt = arts.begin(); iterArt != arts.end(); iterArt++)
			{
				if (debugThis) hge->System_Log("2.1");
				GUIArt a = iterArt->second;
				a.virt = false;
				a.parent = frame;
				a.sname = a.name;
				int i = a.name.find("$parent");
				if (i != a.name.npos)
				{
					a.name = a.name.erase(i, 7);
					a.sname = a.name;
					a.name.insert(i, frame->name);
				}

				if (debugThis) hge->System_Log("2.2 %s", a.name.c_str());

				if ((frame->arts.find(a.name) == frame->arts.end()) && (a.name != ""))
				{
					if (debugThis) hge->System_Log("2.3");
					map<int, Anchor>::iterator iter;
					for (iter = a.anchors.begin(); iter != a.anchors.end(); iter++)
					{
						if (debugThis) hge->System_Log("2.3.1");
						Anchor* an = &iter->second;
						if (an->parent_name != "")
						{
							int i = an->parent_name.find("$parent");
							if (i != an->parent_name.npos)
							{
								an->parent_name = an->parent_name.erase(i, 7);
								an->parent_name.insert(i, frame->name);
							}
						}
					}
					if (debugThis) hge->System_Log("2.4");
					if ( (a.type == GUI_OBJECT_TYPE_TEXTURE) || (a.type == GUI_OBJECT_TYPE_TSTATUSBAR) )
					{
						if (debugThis) hge->System_Log("2.4.1");
						if (iterArt->second.ready)
							a.sprite = mGFXMgr->createSprite(iterArt->second.sprite, true);
						string exec = a.name + " = Texture(\"" + a.parent->name + "\", \"" + a.name + "\");";
						if (debugThis) hge->System_Log("2.4.2");
						luaL_dostring(mSceneMgr->luaVM, exec.c_str());
						if (debugThis) hge->System_Log("2.4.3");
					}
					else if (a.type == GUI_OBJECT_TYPE_FONTSTRING)
					{
						if (debugThis) hge->System_Log("2.4.4");
						string exec = a.name + " = FontString(\"" + a.parent->name + "\", \"" + a.name + "\");";
						if (debugThis) hge->System_Log("2.4.5");
						luaL_dostring(mSceneMgr->luaVM, exec.c_str());
						if (debugThis) hge->System_Log("2.4.6");
					}
					frame->arts[a.name] = a;
					mGUIMgr->parentList[a.name] = &frame->arts[a.name];
				}
			}

			if (debugThis) hge->System_Log("3");
			for (iterArt = frame->arts.begin(); iterArt != frame->arts.end(); iterArt++)
			{
				if (debugThis) hge->System_Log("3.1");
				GUIArt* a = &iterArt->second;
				map<int, Anchor>::iterator iter;
				for (iter = a->anchors.begin(); iter != a->anchors.end(); iter++)
				{
					if (debugThis) hge->System_Log("3.1.1");
					Anchor* an = &iter->second;
					if (mGUIMgr->parentList.find(an->parent_name) != mGUIMgr->parentList.end())
						an->parent = mGUIMgr->parentList[an->parent_name];
					else
						hge->System_Log("# Error # : unknown parent %s", an->parent_name.c_str());
				}
			}

			// Update specific pointers
			if (frame->barTextureName != "")
			{
				int i = frame->barTextureName.find("$parent");
				if (i != frame->barTextureName.npos)
				{
					frame->barTextureName = frame->barTextureName.erase(i, 7);
					frame->barTextureName.insert(i, frame->name);
				}
				if (frame->arts.find(frame->barTextureName) != frame->arts.end())
				{
					frame->barTexture = &frame->arts[frame->barTextureName];
				}
			}
			if (frame->captionFontName != "")
			{
				int i = frame->captionFontName.find("$parent");
				if (i != frame->captionFontName.npos)
				{
					frame->captionFontName = frame->captionFontName.erase(i, 7);
					frame->captionFontName.insert(i, frame->name);
				}
				if (frame->arts.find(frame->captionFontName) != frame->arts.end())
				{
					frame->captionFont = &frame->arts[frame->captionFontName];
				}
			}

			// Copy and update childs
			if (debugThis) hge->System_Log("4");
			map<string, GUIElement>::iterator iterChild;
			for (iterChild = vchilds.begin(); iterChild != vchilds.end(); iterChild++)
			{
				if (debugThis) hge->System_Log("4.1");
				GUIElement* base = &iterChild->second;
				GUIElement c;
				c.name = base->name;
				c.anchors = base->anchors;
				c.type = base->type;
				c.child = base->child;
				c.virt = false;
				c.parent = frame;
				c.parent_name = frame->name;
				c.sname = c.name;

				int i = c.name.find("$parent");
				if (i != c.name.npos)
				{
					c.name = c.name.erase(i, 7);
					c.sname = c.name;
					c.name.insert(i, frame->name);
				}
				if (debugThis) hge->System_Log("4.2 %s", c.name.c_str());

				if ((mGUIMgr->guiList.find(c.name) == mGUIMgr->guiList.end()) && (c.name != ""))
				{
					if (debugThis) hge->System_Log("4.3");
					mGUIMgr->guiList[c.name] = c;
					mGUIMgr->parentList[c.name] = &mGUIMgr->guiList[c.name];
					frame->childs[c.name] = &mGUIMgr->guiList[c.name];

					base->copyVirt(&mGUIMgr->guiList[c.name]);

					if (debugThis) hge->System_Log("4.4");

					string exec;
					if (c.type == GUI_OBJECT_TYPE_STATUSBAR)
						exec = c.name + " = StatusBar(\"" + c.name + "\");";
					else if (c.type == GUI_OBJECT_TYPE_EDITBOX)
						exec = c.name + " = EditBox(\"" + c.name + "\");";
					else
						exec = c.name + " = Frame(\"" + c.name + "\");";

					luaL_dostring(mSceneMgr->luaVM, exec.c_str());

					if (debugThis) hge->System_Log("4.5");
				}
			}
		}
	}
	if (debugThis) hge->System_Log("5");
}

GUIBase* GUIBase::getHighestVirtParent()
{
	// [#] This function returns the highest parent which is virtual.
	if (parent != NULL)
	{
		GUIElement* tparent = parent;
		while (tparent->virt)
		{
			if (tparent->parent == NULL)
				break;
			else
				tparent = tparent->parent;
		}
		return tparent;
	}
	else
	{
		if (type == GUI_OBJECT_TYPE_FRAME)
			return this;
		else
			return NULL;
	}
}

int GUIElement::GetChildLevel()
{
	int iLevel = 0;
	GUIElement* p = parent;

	while (p != NULL)
	{
		p = p->parent;
		iLevel++;
	}

	return iLevel;
}

void GUIElement::_print(int level)
{
	/* [#] This function prints in the log a very detailed set of informations
	/* about itself, its arts and its childs. It's a recursive function.
	*/
	string tab = string(level*4, ' ');
	string lparent_name, aparent_name;
	if (parent == NULL)
		lparent_name = "no parent";
	else
		lparent_name = parent->name;
	if (anchors[0].parent == NULL)
		aparent_name = "no parent (" + anchors[0].parent_name + ")";
	else
		aparent_name = anchors[0].parent->name;
	hge->System_Log("%s - [%d] (%d) %s (%.0f, %.0f, %.2f, %.2f, %s, %s, %d)", tab.c_str(), frameStrata, !hidden, name.c_str(), gx, gx, w, h, lparent_name.c_str(), aparent_name.c_str(), anchors.size());
	hge->System_Log("%s   # Arts :", tab.c_str());
	map<string, GUIArt>::iterator iter3;
	for (iter3 = arts.begin(); iter3 != arts.end(); iter3++)
	{
		GUIArt* a = &iter3->second;
		string parentname;
		if (a->anchors[0].parent == NULL)
			parentname = "no parent (" + a->anchors[0].parent_name + ")";
		else
			parentname = a->anchors[0].parent->name;
		hge->System_Log("%s    - (%d) %s : (anchor : %d, %s, %d)", tab.c_str(), !a->hidden, a->name.c_str(), a->anchors[0].anchorPt, parentname.c_str(), a->anchors[0].relativePt);
		hge->System_Log("%s      %.0f, %.0f, %.2f, %.2f", tab.c_str(), a->ax, a->ay, a->scale, a->vscale);
	}
	hge->System_Log("%s   # Childs :", tab.c_str());
	map<string, GUIElement*>::iterator iterChild;
	for (iterChild = childs.begin(); iterChild != childs.end(); iterChild++)
	{
		iterChild->second->_print(level+1);
	}
}

void GUIElement::UpdateCarret()
{
	if (type == GUI_OBJECT_TYPE_EDITBOX)
	{
		carretTimer += mInputMgr->dt;
		if (carretTimer >= blinkSpeed)
		{
			showCarret = !showCarret;
			carretTimer = 0.0f;
			this->_rebuildCache();
		}
	}
}

void GUIElement::CheckInput(float mx, float my, int lbutton, int rbutton)
{
	/* [#] This function tracks inputs on this element, such as mouse hovering,
	/* cliks, ...
	*/
	if (enableMouse && ready)
	{
		if ( (mx >= x+iHitInsL) && (mx < x+w-iHitInsR) && (my >= -y+iHitInsT) && (my < h-y-iHitInsB) )
		{
			if (!baseUI)
				mSceneMgr->mouseOverPlayField = false;

			// Mouse just entered this object
			if (!lastOn)
			{
				if (type == GUI_OBJECT_TYPE_BUTTON)
				{
					if (bButtonTextureReady)
					{
						texPushed->hidden = true;
						if (bButtonDisabled)
						{
							texHighlight->hidden = true;
							texNormal->hidden = true;
							texDisabled->hidden = false;
						}
						else
						{
							texDisabled->hidden = true;
							texNormal->hidden = false;
							texHighlight->hidden = false;
						}

					}

					if (bButtonFontReady)
					{
						fontNormal->hidden = true;
						if (bButtonDisabled)
						{
							fontHighlight->hidden = true;
							fontDisabled->hidden = false;
						}
						else
						{
							fontDisabled->hidden = true;
							fontHighlight->hidden = false;
						}
					}

					iButtonState = GUI_BUTTON_STATE_NORMAL;
					_rebuildCache();
				}

				this->On(GUI_FUNC_ENTER);
			}

			// Mouse dragged upon this object
			if ( (lbutton == 1) || (rbutton == 1) )
			{
				if (!mInputMgr->lastDragged && registeredForDrag && !mGUIMgr->selSquare.IsActive())
				{
					this->On(GUI_FUNC_DRAGSTART);
					mInputMgr->lastDragged = true;
				}
			}
			// Mouse cliked down on this object
			else if ( (lbutton == 2) || (rbutton == 2) )
			{
				if (type == GUI_OBJECT_TYPE_EDITBOX)
				{
					if (!mGUIMgr->HasFocus(this))
						mGUIMgr->RequestFocus(this);

					mGUIMgr->PlaceCarret(this, mx, my);
				}

				if ( (type == GUI_OBJECT_TYPE_BUTTON) && !bButtonDisabled )
				{
					if (bButtonTextureReady)
					{
						texNormal->hidden = true;
						texDisabled->hidden = true;
						texHighlight->hidden = true;
						texPushed->hidden = false;
					}

					if (bButtonFontReady)
					{
						fontDisabled->hidden = true;
						fontHighlight->hidden = true;
						fontNormal->hidden = false;
					}

					bMouseDown = true;
					iButtonState = GUI_BUTTON_STATE_PUSHED;
					_rebuildCache();
				}

				this->On(GUI_FUNC_MOUSEDOWN);
			}
			// Mouse released on this object
			else if ( (lbutton == 3) || (rbutton == 3) )
			{
				if ( (type == GUI_OBJECT_TYPE_BUTTON) && bMouseDown )
				{
					this->On(GUI_FUNC_CLICK);

					if (bButtonTextureReady)
					{
						texPushed->hidden = true;
						if (bButtonDisabled)
						{
							texHighlight->hidden = true;
							texNormal->hidden = true;
							texDisabled->hidden = false;
						}
						else
						{
							texDisabled->hidden = true;
							texNormal->hidden = false;
							texHighlight->hidden = false;
						}
					}

					if (bButtonFontReady)
					{
						fontNormal->hidden = true;
						if (bButtonDisabled)
						{
							fontHighlight->hidden = true;
							fontDisabled->hidden = false;
						}
						else
						{
							fontDisabled->hidden = true;
							fontHighlight->hidden = false;
						}
					}

					iButtonState = GUI_BUTTON_STATE_NORMAL;
					_rebuildCache();
				}

				this->On(GUI_FUNC_MOUSEUP);

				if (mInputMgr->lastDragged && !mGUIMgr->selSquare.IsActive())
				{
					if (registeredForDrag)
						this->On(GUI_FUNC_RECEIVEDRAG);
					mInputMgr->lastDragged = false;
				}

				bMouseDown = false;
			}

			lastOn = true;
		}
		else
		{
			// Mouse left this object
			if (lastOn)
			{
				this->On(GUI_FUNC_LEAVE);

				if (type == GUI_OBJECT_TYPE_BUTTON)
				{
					if (bButtonTextureReady)
					{
						texHighlight->hidden = true;
						texPushed->hidden = true;
						if (bButtonDisabled)
						{
							texNormal->hidden = true;
							texDisabled->hidden = false;
						}
						else
						{
							texDisabled->hidden = true;
							texNormal->hidden = false;
						}

					}

					if (bButtonFontReady)
					{
						fontHighlight->hidden = true;
						if (bButtonDisabled)
						{
							fontNormal->hidden = true;
							fontDisabled->hidden = false;
						}
						else
						{
							fontDisabled->hidden = true;
							fontNormal->hidden = false;
						}
					}

					iButtonState = GUI_BUTTON_STATE_NORMAL;
					_rebuildCache();
				}
			}

			lastOn = false;
			bMouseDown = false;
		}
	}
}

void GUIElement::On( int type, Event* event )
{
	if (funcList.find(type) != funcList.end())
	{
		OnFunc* f = &funcList[type];

		if (f->bFuncDefined)
		{
			lua_getglobal(mSceneMgr->luaVM, name.c_str());
			lua_setglobal(mSceneMgr->luaVM, "this");

			if ((f->iType == GUI_FUNC_KEYDOWN) ||
				(f->iType == GUI_FUNC_KEYUP) )
			{
				// Set key name
			}
			else if ((f->iType == GUI_FUNC_MOUSEDOWN)  ||
				(f->iType == GUI_FUNC_MOUSEUP)    ||
				(f->iType == GUI_FUNC_DRAGSTART)  ||
				(f->iType == GUI_FUNC_RECEIVEDRAG)||
				(f->iType == GUI_FUNC_CLICK))
			{
				// Set mouse button
				lua_pushstring(mSceneMgr->luaVM, mInputMgr->mouseButton.c_str());
				lua_setglobal(mSceneMgr->luaVM, "arg1");
			}
			else if (f->iType == GUI_FUNC_UPDATE)
			{
				// Set delta time
				lua_pushnumber(mSceneMgr->luaVM, mInputMgr->dt);
				lua_setglobal(mSceneMgr->luaVM, "arg1");
			}
			else if (f->iType == GUI_FUNC_CHAR)
			{
				// Set character
				char c[1]; c[0] = mInputMgr->GetChar(true, true);
				lua_pushstring(mSceneMgr->luaVM, c);
				lua_setglobal(mSceneMgr->luaVM, "arg1");
			}
			else if (f->iType == GUI_FUNC_EVENT)
			{
				if (event != NULL)
				{
					// Set event name
					lua_pushstring(mSceneMgr->luaVM, event->sName.c_str());
					lua_setglobal(mSceneMgr->luaVM, "event");

					// Set arguments
					for (int i = 0; i < event->iArgNbr; i++)
					{
						if (event->arg[i].iType == ARG_TYPE_INTEGER)
							lua_pushnumber(mSceneMgr->luaVM, event->arg[i].vInt);
						else if (event->arg[i].iType == ARG_TYPE_FLOAT)
							lua_pushnumber(mSceneMgr->luaVM, event->arg[i].vFloat);
						else if (event->arg[i].iType == ARG_TYPE_STRING)
							lua_pushstring(mSceneMgr->luaVM, event->arg[i].vString.c_str());
						else
							break;

						lua_setglobal(mSceneMgr->luaVM, string("arg" + toString(i+1)).c_str());
					}
				}
			}

			lua_getglobal(mSceneMgr->luaVM, "Functions");
			lua_rawgeti(mSceneMgr->luaVM, -1, f->iFuncId);
			if (lua_isfunction(mSceneMgr->luaVM, -1))
			{
				int error = lua_pcall(mSceneMgr->luaVM, 0, 0, 0);
				if (error) l_logPrint(mSceneMgr->luaVM);
			}
			else
				lua_pop(mSceneMgr->luaVM, 1);

			lua_pop(mSceneMgr->luaVM, 1);
		}
	}

	if (type == GUI_FUNC_LOAD)
	{
		// OnLoad must be called from parent to childs, because childs often
		// rely on parents parameters/state
		map<string, GUIElement*>::iterator iterChild;
		for (iterChild = childs.begin(); iterChild != childs.end(); iterChild++)
		{
			iterChild->second->On(GUI_FUNC_LOAD);
		}
	}
}

void GUIElement::SetOnFunction( int type, int funcId )
{
	if (funcList.find(type) != funcList.end())
	{
		OnFunc* f = &funcList[type];
		if (funcId != -1)
		{
			f->iFuncId = funcId;
			f->bFuncDefined = true;
		}
		else
			f->bFuncDefined = false;
	}
	else if (funcId != -1)
	{
		// This handler isn't registered yet, let's do it
		OnFunc f;
		f.iType = type;
		f.iFuncId = funcId;
		f.bFuncDefined = true;
		funcList[type] = f;
	}
}

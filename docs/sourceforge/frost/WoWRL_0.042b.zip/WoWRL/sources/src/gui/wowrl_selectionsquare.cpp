/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*        SelectionSquare source          */
/*                                        */
/*  ## : ...                              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_global.h"
#include "wowrl_inputmanager.h"
#include "wowrl_unitmanager.h"
#include "wowrl_scenemanager.h"

#include "wowrl_selectionsquare.h"

extern InputManager *mInputMgr;
extern UnitManager *mUnitMgr;
extern SceneManager *mSceneMgr;
extern HGE *hge;

using namespace std;

SelectionSquare::SelectionSquare()
{
	active = false;
	renderBG = false;

	rect = new hgeRect();

	bg.tex = 0;
	bg.blend = BLEND_DEFAULT;
	bg.v[0].col = bg.v[1].col = bg.v[2].col = bg.v[3].col =
		ARGB(85, 0, 255, 0);

	border.tex = 0;
	border.blend = BLEND_DEFAULT;
	border.v[0].col = border.v[1].col = border.v[2].col = border.v[3].col =
		ARGB(255, 0, 255, 0);
}

bool SelectionSquare::IsActive()
{
	return active;
}

void SelectionSquare::Update()
{
	if ( (mInputMgr->mLState == 1) &&
		 (!mUnitMgr->castingSpell) &&
		 (!mInputMgr->lastDragged) &&
		 (mSceneMgr->mouseOverPlayField) )
	{
		if (!active)
		{
			x = mInputMgr->gmx;
			y = mInputMgr->gmy;
			active = true;
			mUnitMgr->tempSelectedList.empty();
			mUnitMgr->tempSelectedList = map<string, Unit*>(mUnitMgr->selectedList);
		}

		if (active)
		{
			w = (mInputMgr->gmx-x);
			h = (mInputMgr->gmy-y);

			if ( (x-mInputMgr->gmx != 0.0f) && (y-mInputMgr->gmy != 0.0f) )
			{
				if (w < 0.0f)
				{
					rect->x1 = x+mSceneMgr->gx+w;
					rect->x2 = rect->x1-w;
				}
				else
				{
					rect->x1 = x+mSceneMgr->gx;
					rect->x2 = rect->x1+w;
				}
				if (h < 0.0f)
				{
					rect->y1 = y+mSceneMgr->gy+h;
					rect->y2 = rect->y1-h;
				}
				else
				{
					rect->y1 = y+mSceneMgr->gy;
					rect->y2 = rect->y1+h;
				}
				map<string, Unit>::iterator iter;
				for (iter = mUnitMgr->unitList.begin(); iter != mUnitMgr->unitList.end(); iter++)
				{
					Unit *u = &iter->second;
					if (!u->isHostile())
					{
						if (rect->Intersect(u->getBox()))
						{
							if (!u->isSelected())
							{
								u->setSelected(true);
							}
						}
						else
						{
							if (u->isSelected())
							{
								if (mInputMgr->shiftPressed)
								{
									if (mUnitMgr->tempSelectedList.find(u->getName()) == mUnitMgr->tempSelectedList.end())
									{
										u->setSelected(false);
									}
								}
								else
									u->setSelected(false);
							}
						}
					}
				}
			}
			if (!mUnitMgr->selectedList.empty())
				mUnitMgr->selected = true;
			else
				mUnitMgr->selected = false;
		}
	}
	else if (mInputMgr->mLState == 0)
		active = false;
}

void SelectionSquare::Render()
{
	if (active)
	{
		float x1 = x+mSceneMgr->gx;
		float y1 = y+mSceneMgr->gy;
		float x2 = x+mSceneMgr->gx+w;
		float y2 = y+mSceneMgr->gy+h;
		float insetSize = 1.0f;

		// Background
		bg.v[0].x = x1; bg.v[0].y = y1;
		bg.v[1].x = x2; bg.v[1].y = y1;
		bg.v[2].x = x2; bg.v[2].y = y2;
		bg.v[3].x = x1; bg.v[3].y = y2;
		hge->Gfx_RenderQuad(&bg);

		// Left border
		border.v[0].x = x1; border.v[0].y = y1;
		border.v[1].x = x1+signOf(w)*insetSize; border.v[1].y = y1;
		border.v[2].x = x1+signOf(w)*insetSize; border.v[2].y = y2;
		border.v[3].x = x1; border.v[3].y = y2;
		hge->Gfx_RenderQuad(&border);

		// Top border
		border.v[0].x = x1; border.v[0].y = y1;
		border.v[1].x = x2; border.v[1].y = y1;
		border.v[2].x = x2; border.v[2].y = y1+signOf(h)*insetSize;
		border.v[3].x = x1; border.v[3].y = y1+signOf(h)*insetSize;
		hge->Gfx_RenderQuad(&border);

		// Right border
		border.v[0].x = x2-signOf(w)*insetSize; border.v[0].y = y1;
		border.v[1].x = x2; border.v[1].y = y1;
		border.v[2].x = x2; border.v[2].y = y2;
		border.v[3].x = x2-signOf(w)*insetSize; border.v[3].y = y2;
		hge->Gfx_RenderQuad(&border);

		// Bottom border
		border.v[0].x = x1; border.v[0].y = y2-signOf(h)*insetSize;
		border.v[1].x = x2; border.v[1].y = y2-signOf(h)*insetSize;
		border.v[2].x = x2; border.v[2].y = y2;
		border.v[3].x = x1; border.v[3].y = y2;
		hge->Gfx_RenderQuad(&border);
	}
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_scenemanager.h"

#include "wowrl_gui.h"

using namespace std;

//extern SceneManager* mSceneMgr;
extern bool debugGUI;

l_StatusBar::l_StatusBar(lua_State* luaVM) : l_Frame(luaVM)
{
	name = lua_tostring(luaVM, 1);
}

int l_StatusBar::SetMinMaxValues(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 2)
	{
		mlua_printError("Too few argument in \"StatusBar:SetMinMaxValues\" (2 expected : min, max)");
		return 0;
	}
	else if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of StatusBar:SetMinMaxValues must be a number (min)");
		error++;
	}
	else if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of StatusBar:SetMinMaxValues must be a number (max)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			float min_value = lua_tonumber(luaVM, 1);
			float max_value = lua_tonumber(luaVM, 2);
			if (min_value != base->min_value)
			{
				base->min_value = min_value;
				base->_rebuildCache();
			}
			if (max_value != base->max_value)
			{
				base->max_value = max_value;
				base->_rebuildCache();
			}
		}
	}

	return 0;
}

int l_StatusBar::SetStatusBarColor(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 3)
	{
		mlua_printError("Too few argument in \"StatusBar:SetStatusBarColor\" (3 or 4 expected : red, green, blue (+alpha))");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of StatusBar:SetStatusBarColor must be a number (red)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of StatusBar:SetStatusBarColor must be a number (green)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of StatusBar:SetStatusBarColor must be a number (blue)");
		error++;
	}
	if ( (lua_gettop(luaVM) >= 4) && (!lua_isnumber(luaVM, 4)) )
	{
		mlua_printError("Argument 4 of StatusBar:SetStatusBarColor must be a number (alpha)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			if (base->barTexture != NULL)
			{
				if (base->barTexture->ready)
				{
					float a, r, g, b;
					r = lua_tonumber(luaVM, 1);
					g = lua_tonumber(luaVM, 2);
					b = lua_tonumber(luaVM, 3);
					if (lua_gettop(luaVM) >= 4)
						a = lua_tonumber(luaVM, 4);
					else
						a = GETA(base->barTexture->sprite->GetColor())/255.0f;

					DWORD color = ARGB(a*255, r*255, g*255, b*255);
					if (color != base->barTexture->color)
					{
						base->barTexture->color = color;
						base->barTexture->sprite->SetColor(base->barTexture->color);
						base->_rebuildCache();
					}
				}
			}
		}
	}

	return 0;
}

int l_StatusBar::SetValue(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) == 0)
	{
		mlua_printError("Too few argument in \"StatusBar:SetValue\" (one expected : value)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument of StatusBar:SetValue must be a number (value)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			float value = lua_tonumber(luaVM, 1);
			if (value != base->value)
			{
				base->value = value;
				base->_rebuildCache();
			}
		}
	}

	return 0;
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Status bar source            */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Status bar class.              */
/*       A Status bar is used to display  */
/*	the health of a unit.				  */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge/hgesprite.h"

#include "wowrl_global.h"
#include "wowrl_structs.h"
#include "wowrl_unit.h"

#include "wowrl_statusbar.h"

StatusBar::StatusBar() : background_left(NULL),
						 background_middle(NULL),
						 background_right(NULL),
						 gauge(NULL)

{
}

StatusBar::~StatusBar()
{
	if (background_left != NULL) {delete background_left;}
	if (background_middle != NULL) {delete background_middle;}
	if (background_right != NULL) {delete background_right;}
	if (gauge != NULL) {delete gauge;}
}

void StatusBar::Render()
{
	hgeRect* pBox = parent->getStandBox();
	int bx = toInt(parent->getX()-size/2.0f);
	int by = toInt(parent->getY()-parent->getClass()->status_bar_y_offset*parent->getScale()-8);

	gauge->SetColor(ARGB(200, color.R, color.G, color.B));
	gauge->RenderStretch(bx+2, by+2, bx+ceil((size-1)*state), by+6);
	background_left->Render(bx, by);
	background_right->Render(ceil(bx+size-3), by);
	background_middle->RenderStretch(bx+3, by, ceil(bx+size-3), by+8);
}

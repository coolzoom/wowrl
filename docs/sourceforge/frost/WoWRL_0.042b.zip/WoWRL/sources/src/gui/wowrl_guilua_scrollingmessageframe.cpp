/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_gui.h"
#include "wowrl_guimanager.h"
#include "wowrl_lua.h"
#include "wowrl_global.h"

using namespace std;

extern GUIManager* mGUIMgr;
extern HGE* hge;

l_ScrollingMessageFrame::l_ScrollingMessageFrame(lua_State* luaVM) : l_Frame(luaVM)
{
	name = lua_tostring(luaVM, 1);
}

void SetAtTop(GUIElement* base)
{
	// Check if the frame is at top
	int iNewN;
	if (base->bottomLine == 1)
		iNewN = base->maxLines;
	else
		iNewN = base->bottomLine-1;

	if (iNewN != base->actualLine) // Necessary ?
	{
		bool bEmptyLine = false;
		float fBY = -base->getY() + base->SMFinsT;
		int iPrevAct = base->actualLine;
		if (iPrevAct == 1)
			iPrevAct = base->maxLines;
		else
			iPrevAct--;

		// Check if there is no empty lines
		for (int i = 0; i < base->maxLines; i++)
		{
			int iArtN;
			if (iNewN-i < 1)
				iArtN = base->maxLines+iNewN-i;
			else
				iArtN = iNewN-i;

			GUIArt* aAdj = &base->arts[string("Msg") + toString(iArtN)];
			if (aAdj->text.sStr == "<empty>")
			{
				bEmptyLine = true;
				break;
			}
			// Stop the search if the last message is found...
			if (iArtN == iPrevAct)
			{
				bEmptyLine = true;
				break;
			}
			// ... or if the top of the frame is reached
			float fArtY = -aAdj->getY();
			if (fArtY < fBY)
				break;
		}

		if (!bEmptyLine)
			base->bAtTop = false;
		else
			base->bAtTop = true;
	}
}

int l_ScrollingMessageFrame::AddMessage(lua_State* luaVM)
{
	int error = 0;
	if ( (lua_gettop(luaVM) >= 1) && !lua_isstring(luaVM, 1) )
	{
		mlua_printError("Argument of ScrollingMessageFrame:AddMessage must be a string (message)");
		error++;
	}

	if (error == 0)
	{
		string nstr;
		if (lua_gettop(luaVM) >= 1)
			nstr = lua_tostring(luaVM, 1);
		else
			nstr = "";

		GUIArt* aNew = &base->arts[string("Msg") + toString(base->actualLine)];
		aNew->text.sStr = nstr;
		aNew->text.w = base->w - base->SMFinsR - base->SMFinsL;
		aNew->text = mGUIMgr->ParseFormatedText(aNew->text);

		base->actualLine++;
		if (base->actualLine > base->maxLines)
			base->actualLine = 1;

		if (base->bottomLine == base->actualLine);
		{
			base->oldBottomLine = base->bottomLine;
			base->bottomLine++;
			if (base->bottomLine > base->maxLines)
				base->bottomLine = 1;
		}

		SetAtTop(base);

		mGUIMgr->UpdateScrollingMsgFrame(base);
	}

	return 0;
}

int l_ScrollingMessageFrame::AtBottom(lua_State* luaVM)
{
	if (base != NULL)
		lua_pushboolean(luaVM, base->bAtBottom);

	return 1;
}

int l_ScrollingMessageFrame::AtTop(lua_State* luaVM)
{
	if (base != NULL)
		lua_pushboolean(luaVM, base->bAtTop);

	return 1;
}

int l_ScrollingMessageFrame::ScrollDown(lua_State* luaVM)
{
	int iNewN;
	if (base->bottomLine == base->maxLines)
		iNewN = 1;
	else
		iNewN = base->bottomLine+1;

	if (iNewN != base->actualLine)
	{
		base->bottomLine = iNewN;

		// Check if the frame is at bottom
		if (iNewN == base->maxLines)
			iNewN = 1;
		else
			iNewN = iNewN+1;

		if (iNewN != base->actualLine)
			base->bAtBottom = false;
		else
			base->bAtBottom = true;
	}
	else
		base->bAtBottom = true;

	SetAtTop(base);

	mGUIMgr->UpdateScrollingMsgFrame(base);

	return 0;
}

int l_ScrollingMessageFrame::ScrollToBottom(lua_State* luaVM)
{
	base->bottomLine = base->actualLine;
	if (base->bottomLine == 1)
		base->bottomLine = base->maxLines;
	else
		base->bottomLine = base->bottomLine-1;

	base->bAtBottom = true;

	SetAtTop(base);

	mGUIMgr->UpdateScrollingMsgFrame(base);

	return 0;
}

int l_ScrollingMessageFrame::ScrollToTop(lua_State* luaVM)
{
	// Not the best method, for sure, but it works
	int iOld = base->bottomLine;
	ScrollUp(luaVM);
	while (iOld != base->bottomLine)
	{
		iOld = base->bottomLine;
		ScrollUp(luaVM);
	}

	base->bAtTop = true;

	return 0;
}

int l_ScrollingMessageFrame::ScrollUp(lua_State* luaVM)
{
	int iNewN;
	if (base->bottomLine == 1)
		iNewN = base->maxLines;
	else
		iNewN = base->bottomLine-1;

	if (iNewN != base->actualLine) // Necessary ?
	{
		bool bEmptyLine = false;
		float fBY = -base->getY() + base->SMFinsT;
		int iPrevAct = base->actualLine;
		if (iPrevAct == 1)
			iPrevAct = base->maxLines;
		else
			iPrevAct--;

		// Check if there is no empty lines
		for (int i = 0; i < base->maxLines; i++)
		{
			int iArtN;
			if (iNewN-i < 1)
				iArtN = base->maxLines+iNewN-i;
			else
				iArtN = iNewN-i;

			GUIArt* aAdj = &base->arts[string("Msg") + toString(iArtN)];
			if (aAdj->text.sStr == "<empty>")
			{
				base->bAtTop = true;
				bEmptyLine = true;
				break;
			}
			// Stop the search if the last message is found...
			if (iArtN == iPrevAct)
			{
				base->bAtTop = true;
				bEmptyLine = true;
				break;
			}
			// ... or if the top of the frame is reached
			float fArtY = -aAdj->getY();
			if (fArtY < fBY)
				break;
		}

		if (!bEmptyLine)
		{
			base->bottomLine = iNewN;
			base->bAtBottom = false;

			SetAtTop(base);
		}
	}

	mGUIMgr->UpdateScrollingMsgFrame(base);

	return 0;
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              .... source               */
/*                                        */
/*  ## : ...                              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_gfxmanager.h"
#include "wowrl_lua.h"
#include "wowrl_gui.h"
#include "wowrl_xml.h"

#include "wowrl_guimanager.h"

extern TimeManager *mTimeMgr;
extern GFXManager *mGFXMgr;
extern HGE *hge;

using namespace std;

void GUIManager::parseUI( string file )
{
	// Default UI
	string status_bar_file = "UI/ui_default_status_bar.png";
	string circle_file = "UI/ui_default_circle.png";
	string order_file = "UI/ui_default_order.png";
	string shadow_file = "UI/ui_default_shadow.png";
	string carret_file = "UI/ui_default_carret.png";

	//  -- loading textures
	mGFXMgr->loadTexture(status_bar_file);
	mGFXMgr->loadTexture(circle_file, true);
	mGFXMgr->loadTexture(order_file, true);
	mGFXMgr->loadTexture(shadow_file, true);
	mGFXMgr->loadTexture(carret_file, false);
	//  -- statusbar
	this->statusB_bg_left = mGFXMgr->createSprite(mGFXMgr->textureList[status_bar_file],0,0,3,8);
	this->statusB_bg_middle = mGFXMgr->createSprite(mGFXMgr->textureList[status_bar_file],3,0,29,8);
	this->statusB_bg_right = mGFXMgr->createSprite(mGFXMgr->textureList[status_bar_file],0,0,3,8);
	this->statusB_bg_right->SetFlip(true,false);
	this->statusB_dead_bg_left = mGFXMgr->createSprite(mGFXMgr->textureList[status_bar_file],0,8,3,8);
	this->statusB_dead_bg_middle = mGFXMgr->createSprite(mGFXMgr->textureList[status_bar_file],3,8,29,8);
	this->statusB_dead_bg_right = mGFXMgr->createSprite(mGFXMgr->textureList[status_bar_file],0,8,3,8);
	this->statusB_dead_bg_right->SetFlip(true,false);
	this->statusB_gauge = mGFXMgr->createSprite(mGFXMgr->textureList[status_bar_file],3,18,29,2);
	// -- player shadow
	this->p_shadow = mGFXMgr->createSprite(mGFXMgr->textureList[shadow_file],0,0,128,128);
	this->p_shadow->SetHotSpot(64,64);
	// -- selection circle
	this->selectionCircle = mGFXMgr->createSprite(mGFXMgr->textureList[circle_file],0,0,32,32);
	this->selectionCircle->SetColor(ARGB(255, 20, 220, 64));
	this->selectionCircle->SetHotSpot(16,16);
	this->deathCircle = mGFXMgr->createSprite(mGFXMgr->textureList[circle_file],0,0,32,32);
	this->deathCircle->SetColor(ARGB(120, 100, 100, 100));
	this->deathCircle->SetHotSpot(16,16);
	this->hostileCircle = mGFXMgr->createSprite(mGFXMgr->textureList[circle_file],0,0,32,32);
	this->hostileCircle->SetColor(ARGB(180, 220, 64, 20));
	this->hostileCircle->SetHotSpot(16,16);
	// -- order circle
	this->orderCircle = mGFXMgr->createSprite(mGFXMgr->textureList[order_file],0,0,32,32);
	this->orderCircle->SetColor(ARGB(255, 20, 220, 64));
	this->orderCircle->SetHotSpot(16,16);
	// -- carret
	this->carret = mGFXMgr->createSprite(mGFXMgr->textureList[carret_file], 0, 0, 4, 16);
	this->carret->SetHotSpot(1, 0);
}

void GUIManager::parseCursors(lua_State* luaVM)
{
	hge->System_Log("Parsing Tables/cursor_table.lua...");

	int error = luaL_dofile(luaVM, "Tables/cursor_table.lua");
	if (error) l_logPrint(luaVM);

	lua_getglobal(luaVM, "Cursors");
	for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
	{
		if (!lua_isnil(luaVM, -1))
		{
			Cursor tmpCur;
			tmpCur.name = mlua_getFieldString("name");
			tmpCur.rot = 0.0f;
			tmpCur.animated = mlua_getFieldBool("animated", false, false);
			if (tmpCur.animated)
				tmpCur.anim = mGFXMgr->mlua_animList[mlua_getFieldString("anim")];
			else
				tmpCur.sprite = mGFXMgr->mlua_spriteList[mlua_getFieldString("sprite")];

			this->cursorList[tmpCur.name] = tmpCur;
		}
	}

	lua_pop(luaVM, 1);

	hge->System_Log("Parsing Tables/cursor_table.lua : done.");
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_fontmanager.h"
#include "wowrl_guimanager.h"

#include "wowrl_gui.h"

using namespace std;

extern FontManager* mFontMgr;
extern GUIManager* mGUIMgr;
extern HGE *hge;

extern bool debugGUI;

l_FontString::l_FontString(lua_State* luaVM) : l_LayeredRegion(luaVM)
{
	pname = lua_tostring(luaVM, 1);
	name = lua_tostring(luaVM, 2);
}

int l_FontString::SetFont(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 2)
	{
		mlua_printError("Too few argument in \"FontString:SetFont\" (2 or 3 expected : font, size (+flags))");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument 1 of FontString:SetFont must be a string (font)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of FontString:SetFont must be a number (size)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			bool bold = false;
			bool italic = false;

			// Read flags
			if (lua_isstring(luaVM, 3))
			{
				string s = lua_tostring(luaVM, 3);
				int i = s.find("OUTLINE");
				if (i != s.npos)
				{
					i = s.find("THICKOUTLINE");
					if (i != s.npos)
						base->text.outline = 3;
					else
					{
						i = s.find("THINOUTLINE");
						if (i != s.npos)
							base->text.outline = 1;
						else
							base->text.outline = 2;
					}
				}
				i = s.find("BOLD");
				if (i != s.npos)
				{
					bold = true;
				}
				i = s.find("ITALIC");
				if (i != s.npos)
				{
					italic = true;
				}
			}

			hgeFont* tmpFnt = NULL;
			tmpFnt = mFontMgr->getFont(true, lua_tostring(luaVM, 1), toInt(lua_tonumber(luaVM, 2)), bold, italic);

			if (tmpFnt == NULL)
			{
				base->text.fnt = NULL;

				base->parent->_rebuildCache();
				base->ready = false;
			}
			else if (tmpFnt != base->text.fnt)
			{
				base->text.fnt = tmpFnt;
				base->text.tracking = tmpFnt->GetTracking();
				base->text.sStr = base->text.sBaseStr;
				base->text = mGUIMgr->ParseFormatedText(base->text);

				TextBox tb = base->text.fnt->GetTextBox(base->w, base->h, base->text.sStr.c_str());
				base->h = tb.iLineNbr*tb.fLineHeight;

				if (base->parent != NULL)
				{
					base->parent->AdjustCache();
					base->parent->_rebuildCache();
				}
				base->ready = true;
			}
		}
	}

	return 0;
}

int l_FontString::SetTextColor(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 3)
	{
		mlua_printError("Too few argument in \"FontString:SetTextColor\" (3 or 4 expected : red, green, blue (+alpha))");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of FontString:SetTextColor must be a number (red)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of FontString:SetTextColor must be a number (green)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of FontString:SetTextColor must be a number (blue)");
		error++;
	}
	if ( (lua_gettop(luaVM) >= 4) && (!lua_isnumber(luaVM, 4)) )
	{
		mlua_printError("Argument 4 of FontString:SetTextColor must be a number (alpha)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			float a, r, g, b;
			r = lua_tonumber(luaVM, 1);
			g = lua_tonumber(luaVM, 2);
			b = lua_tonumber(luaVM, 3);
			if (lua_gettop(luaVM) >= 4)
				a = lua_tonumber(luaVM, 4);
			else
				a = 1.0f;

			base->text.color = ARGB(a*255, r*255, g*255, b*255);

			bool bChanged = false;
			list<FormatedString>::iterator iterStr;
			for (iterStr = base->text.lFStr.begin(); iterStr != base->text.lFStr.end(); iterStr++)
			{
				FormatedString* fs = &(*iterStr);
				if (fs->dColor != base->text.color)
				{
					fs->dColor = base->text.color;
					if (base->ready)
						bChanged = true;
				}
			}

			if (bChanged)
				base->parent->_rebuildCache();
		}
	}

	return 0;
}

int l_FontString::GetStringWidth(lua_State* luaVM)
{
	if (base != NULL)
	{
		if (base->ready)
		{
			lua_pushnumber(luaVM, base->text.fnt->GetStringWidth(base->text.sStr.c_str()));
		}
		else
			lua_pushnil(luaVM);
	}

	return 1;
}

int l_FontString::SetText(lua_State* luaVM)
{
	if (!lua_isstring(luaVM, 1) && !lua_isnil(luaVM, 1))
	{
		mlua_printError("Argument of FontString:SetText must be a string or nil (text)");
		return 0;
	}

	if (base != NULL)
	{
		string sNew;
		if (lua_isnil(luaVM, 1))
			sNew = "";
		else
			sNew = lua_tostring(luaVM, 1);


		if (sNew != base->text.sBaseStr)
		{
			base->text.sStr = sNew;
			base->text = mGUIMgr->ParseFormatedText(base->text);
			// We get the new text box's height to adjust the GUIArt's height
			if (base->ready)
			{
				if (base->text.fnt != NULL)
				{
					TextBox tb = base->text.fnt->GetTextBox(base->w, base->h, base->text.sStr.c_str());
					base->h = tb.iLineNbr*tb.fLineHeight;
					if (base->parent != NULL)
						base->parent->_rebuildCache();
				}
			}
		}
	}

	return 0;
}

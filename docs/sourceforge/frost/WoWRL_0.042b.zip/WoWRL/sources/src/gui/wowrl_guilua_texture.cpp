/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_gfxmanager.h"

#include "wowrl_gui.h"

using namespace std;

extern GFXManager *mGFXMgr;
extern HGE *hge;
extern bool debugGUI;

l_Texture::l_Texture(lua_State* luaVM) : l_LayeredRegion(luaVM)
{
	pname = lua_tostring(luaVM, 1);
	name = lua_tostring(luaVM, 2);
}

int l_Texture::SetTexCoord(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 4)
	{
		mlua_printError("Too few argument in \"Texture:SetTexCoord\" (4 expected : left, right, top, bottom)");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of Texture:SetTexCoord must be a number (left)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of Texture:SetTexCoord must be a number (right)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of Texture:SetTexCoord must be a number (top)");
		error++;
	}
	if (!lua_isnumber(luaVM, 4))
	{
		mlua_printError("Argument 4 of Texture:SetTexCoord must be a number (bottom)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			if (base->sprite != NULL)
			{
				float tw = hge->Texture_GetWidth(base->sprite->GetTexture(), true);
				float th = hge->Texture_GetHeight(base->sprite->GetTexture(), true);
				float sx = tw*lua_tonumber(luaVM, 1);
				float sy = th*lua_tonumber(luaVM, 3);
				float sw = tw*(lua_tonumber(luaVM, 2)-lua_tonumber(luaVM, 1));
				float sh = th*(lua_tonumber(luaVM, 4)-lua_tonumber(luaVM, 3));

				base->sprite->SetTextureRect(sx, sy, sw, sh);

				base->parent->_rebuildCache();
			}
		}
	}

	return 0;
}

int l_Texture::SetTexture(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 1)
	{
		mlua_printError("Too few argument in \"Texture:SetTexture\" (one expected : texture file)");
		return 0;
	}
	if (!lua_isstring(luaVM, 1))
	{
		mlua_printError("Argument of Texture:SetTexture must be a string (texture file)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			string nfile = lua_tostring(luaVM, 1);
			if (nfile != base->file)
			{
				base->file = nfile;

				if (base->file == "")
					base->ready = false;
				else
				{
					HTEXTURE tex = mGFXMgr->loadTexture(base->file, false);
					if (tex)
					{
						float sw, sh;
						sw = hge->Texture_GetWidth(tex);
						sh = hge->Texture_GetHeight(tex);
						base->sprite = mGFXMgr->createSprite
						(
							tex, 0, 0, sw, sh, true
						);
						if (base->sprite != NULL)
						{
							base->sprite->SetColor(base->color);
							base->scale = base->w/sw;
							base->vscale = base->h/sh;
							base->ready = true;
						}
						else
							base->ready = false;
					}
					else
						base->ready = false;
				}
				base->parent->_rebuildCache();
			}
		}
	}

	return 0;
}

int l_Texture::SetVertexColor(lua_State* luaVM)
{
	int error = 0;
	if (lua_gettop(luaVM) < 3)
	{
		mlua_printError("Too few argument in \"Texture:SetVertexColor\" (3 or 4 expected : red, green, blue (+alpha))");
		return 0;
	}
	if (!lua_isnumber(luaVM, 1))
	{
		mlua_printError("Argument 1 of Texture:SetVertexColor must be a number (red)");
		error++;
	}
	if (!lua_isnumber(luaVM, 2))
	{
		mlua_printError("Argument 2 of Texture:SetVertexColor must be a number (green)");
		error++;
	}
	if (!lua_isnumber(luaVM, 3))
	{
		mlua_printError("Argument 3 of Texture:SetVertexColor must be a number (blue)");
		error++;
	}
	if ( (lua_gettop(luaVM) >= 4) && (!lua_isnumber(luaVM, 4)) )
	{
		mlua_printError("Argument 4 of Texture:SetVertexColor must be a number (alpha)");
		error++;
	}

	if (error == 0)
	{
		if (base != NULL)
		{
			float a, r, g, b;
			r = lua_tonumber(luaVM, 1);
			g = lua_tonumber(luaVM, 2);
			b = lua_tonumber(luaVM, 3);
			if (lua_gettop(luaVM) >= 4)
				a = lua_tonumber(luaVM, 4);
			else
				a = GETA(base->color)/255.0f;

			DWORD color = ARGB(a*255, r*255, g*255, b*255);

			if (base->color != color)
			{
				base->color = color;
				if (base->sprite != NULL)
				{
					base->sprite->SetColor(base->color);
				}
				base->parent->_rebuildCache();
			}
		}
	}

	return 0;
}


/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_gui.h"
#include "wowrl_lua.h"

using namespace std;

extern HGE* hge;

l_Button::l_Button(lua_State* luaVM) : l_Frame(luaVM)
{
	name = lua_tostring(luaVM, 1);
}

int l_Button::Disable(lua_State* luaVM)
{
	if (base != NULL)
	{
		if (!base->bButtonDisabled)
		{
			base->bButtonDisabled = true;

			if (base->bButtonTextureReady)
			{
				base->texNormal->hidden = true;
				base->texHighlight->hidden = true;
				base->texPushed->hidden = true;
				base->texDisabled->hidden = false;
			}

			if (base->bButtonFontReady)
			{
				base->fontNormal->hidden = true;
				base->fontHighlight->hidden = true;
				base->fontDisabled->hidden = false;
			}

			base->bMouseDown = false;

			base->_rebuildCache();
		}
	}

	return 0;
}

int l_Button::Enable(lua_State* luaVM)
{
	if (base != NULL)
	{
		if (base->bButtonDisabled)
		{
			base->bButtonDisabled = false;

			if (base->bButtonTextureReady)
			{
				base->texHighlight->hidden = true;
				base->texPushed->hidden = true;
				base->texDisabled->hidden = true;
				base->texNormal->hidden = false;
			}

			if (base->bButtonFontReady)
			{
				base->fontHighlight->hidden = true;
				base->fontDisabled->hidden = true;
				base->fontNormal->hidden = false;
			}

			base->_rebuildCache();
		}
	}

	return 0;
}

int l_Button::GetButtonState(lua_State* luaVM)
{
	if (base != NULL)
	{
		if (base->iButtonState == GUI_BUTTON_STATE_NORMAL)
			lua_pushstring(luaVM, "NORMAL");
		else
			lua_pushstring(luaVM, "PUSHED");
	}

	return 1;
}

int l_Button::IsEnabled(lua_State* luaVM)
{
	if (base != NULL)
		lua_pushboolean(luaVM, !base->bButtonDisabled);
	return 1;
}

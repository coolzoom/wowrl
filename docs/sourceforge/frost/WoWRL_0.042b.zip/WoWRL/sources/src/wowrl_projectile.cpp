/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Projectile source           */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Projectile class.              */
/*       A Projecille is used whenever a  */
/*  spell is casted, a bullet is fired,   */
/*  an arrow is thrown, ... it can follow */
/*  its target and it has a particle      */
/*  system linked to it.                  */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge/hge.h"
#include "hge/hgerect.h"
#include "hge/hgeparticle.h"

#include "wowrl_unit.h"
#include "wowrl_global.h"
#include "wowrl_distortion.h"
#include "wowrl_scenemanager.h"
#include "wowrl_inputmanager.h"
#include "wowrl_gfxmanager.h"

#include "wowrl_projectile.h"

extern HGE *hge;
extern SceneManager *mSceneMgr;
extern InputManager *mInputMgr;
extern GFXManager *mGFXMgr;
extern hgeParticleManager myParticleManager;

Projectile::Projectile() : x(0.0f), y(0.0f), m_destination(NULL), m_psys(NULL)
{
}

Projectile::Projectile( Spell* spell,
						Unit* destination,
						Unit* origin ) :
							m_spell(spell),
							m_destination(destination),
							m_origin(origin),
							m_psys(NULL),
							arrived(false)
{
	m_psysname = spell->attack_effect;
	x = origin->getGX()+mGFXMgr->FXList[m_psysname].offset_x*origin->getScale();
	y = origin->getGY()+mGFXMgr->FXList[m_psysname].offset_y*origin->getScale();
	speed = spell->proj_speed;
}

Projectile::~Projectile()
{
    if (m_psys != NULL) {delete m_psys;}
}

hgeParticleSystem* Projectile::getPSys()
{
	if (m_psysname != m_old_psysname)
	{
		if (m_psys != NULL) {delete m_psys;}
		m_psys = new hgeParticleSystem(*mGFXMgr->FXList[m_psysname].pfx.psys);
		m_old_psysname = m_psysname;
	}
	return m_psys;
}

float Projectile::getZ()
{
	float z = y-mSceneMgr->gy;
    return z;
}

Unit* Projectile::getParent()
{
	return m_origin;
}

Unit* Projectile::getDestination()
{
	return m_destination;
}

Spell* Projectile::getSpell()
{
	return m_spell;
}

void Projectile::setDestination(Unit* destination)
{
	if (destination != NULL)
		{m_destination = destination;}
}

bool Projectile::updatePos()
{
	hgeVector destVec;
	//float speed = 600.0f;
	hgeRect *destBox = m_destination->getBox();
	float destx = destBox->x1 + (destBox->x2-destBox->x1)/2 - mSceneMgr->gx;
	float desty = destBox->y1 + (destBox->y2-destBox->y1)/2 - mSceneMgr->gy;
	destVec.x = destx-x;
	destVec.y = desty-y;

	float coefx, coefy;
	coefx = (speed/1.4142f)*cos(destVec.Angle());
	coefy = (speed/1.4142f)*sin(destVec.Angle());

	hgeRect* particleRect = new hgeRect(x+mSceneMgr->gx-5,y+mSceneMgr->gy-5,x+mSceneMgr->gx+5,y+mSceneMgr->gy+5);
	bool collides = particleRect->Intersect(m_destination->getBox());
	delete particleRect;

	if (!collides)
	{
		x += coefx*mInputMgr->dt;
		y += coefy*mInputMgr->dt;
		arrived = false;
		return true;
	}
	else
	{
		arrived = true;
		m_destination->receive(m_spell, m_origin);
		return false;
	}
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl.h"
#include "wowrl_unit.h"
#include "wowrl_global.h"
#include "wowrl_scenemanager.h"

using namespace std;

extern SceneManager *mSceneMgr;

string Unit::ParseString( string s )
{
	strReplace(&s, "[unit]", m_name);
	if (m_target != NULL)
	{
		strReplace(&s, "[target]", m_target->getName());
		strReplace(&s, "[target ]", m_target->getName() + " ");
	}
	else
	{
		strReplace(&s, "[target]", "");
		strReplace(&s, "[target ]", "");
	}

	return s;
}

string Unit::ParseStringAttack( string s, Unit* c, Spell* spell, int value )
{
	strReplace(&s, "[unit]", m_name);

	if (m_target != NULL)
	{
		strReplace(&s, "[target]", m_target->getName());
		strReplace(&s, "[target ]", m_target->getName() + " ");
	}
	else
	{
		strReplace(&s, "[target]", "");
		strReplace(&s, "[target ]", "");
	}

	if (c != NULL)
	{
		strReplace(&s, "[caster]", c->getName());
		strReplace(&s, "[caster ]", c->getName() + " ");
	}
	else
	{
		strReplace(&s, "[caster]", "");
		strReplace(&s, "[caster ]", "");
	}

	if (value > 0)
	{
		strReplace(&s, "[value]", toString(value));
		strReplace(&s, "[value ]", toString(value) + " ");
	}
	else
	{
		strReplace(&s, "[value]", "");
		strReplace(&s, "[value ]", "");
	}

	if (spell != NULL)
	{
		strReplace(&s, "[cspell]", spell->name);
		strReplace(&s, "[cspell ]", spell->name + " ");

		string school = "";
		if (spell->school == SPELL_SCHOOL_HOLY)
			school = mSceneMgr->strTable->GetString("school_holy");
		else if (spell->school == SPELL_SCHOOL_FROST)
			school = mSceneMgr->strTable->GetString("school_frost");
		else if (spell->school == SPELL_SCHOOL_FIRE)
			school = mSceneMgr->strTable->GetString("school_fire");
		else if (spell->school == SPELL_SCHOOL_NATURE)
			school = mSceneMgr->strTable->GetString("school_nature");
		else if (spell->school == SPELL_SCHOOL_SHADOW)
			school = mSceneMgr->strTable->GetString("school_shadow");
		else if (spell->school == SPELL_SCHOOL_ARCANE)
			school = mSceneMgr->strTable->GetString("school_arcane");
		strReplace(&s, "[school]", school);
		strReplace(&s, "[school ]", school + " ");
	}
	else
	{
		strReplace(&s, "[cspell]", "");
		strReplace(&s, "[cspell ]", "");
	}

	return s;
}

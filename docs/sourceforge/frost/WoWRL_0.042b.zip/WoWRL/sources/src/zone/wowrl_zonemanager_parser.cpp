/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_lua.h"
#include "wowrl_scenemanager.h"
#include "wowrl_guimanager.h"
#include "wowrl_gfxmanager.h"

#include "wowrl_zonemanager.h"

using namespace std;

extern SceneManager *mSceneMgr;
extern GUIManager *mGUIMgr;
extern GFXManager *mGFXMgr;
extern HGE *hge;

bool ZoneManager::parseZoneDyn( lua_State* luaVM, int state1, int state2, bool* finished, float filling )
{
	static int part_nbr = 0;
	static int doodad_nbr = 0;

	if (state1 == 1)
	{
		hge->System_Log("Parsing %s...",  actualZone.name.c_str());
		int error = luaL_dofile(luaVM,  actualZone.name.c_str());
		if (error) l_logPrint(luaVM);
		lua_getglobal(luaVM, "Zone");
		actualZone.w = mlua_getFieldInt("width");
		actualZone.h = mlua_getFieldInt("height");
		actualZone.distortion_scale_max = actualZone.distortion_scale_min = mlua_getFieldFloat("scale", false, 1.0f);
		actualZone.distortion_vscale_max = actualZone.distortion_vscale_min = mlua_getFieldFloat("vscale", false, 1.0f);
		actualZone.distortion_angle_max = actualZone.distortion_angle_min = 0.0f;
		mSceneMgr->gx = -mlua_getFieldFloat("start_x", false, actualZone.w/2.0f);
		mSceneMgr->gy = -mlua_getFieldFloat("start_y", false, actualZone.h/2.0f);
		actualZone.partSize = 1024;
		lua_getfield(luaVM, -1, "Background");

		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			part_nbr++;
		}

		*finished = false;
		mGUIMgr->mLoadingBar.filling += 0.01f;
		return true;
	}
	else if (state1 == 2)
	{
		if (state2 > part_nbr)
		{
			lua_pop(luaVM, 1);
			*finished = false;
			return true;
		}

		static float x = 0.0f;
		static float y = 0.0f;
		int i = state2;

		BGPart tmpBGPart;
		tmpBGPart.i = i;
		tmpBGPart.x = x;
		tmpBGPart.y = y;

		lua_rawgeti(luaVM, -1, i);

		string bg = mlua_getFieldString("background");
		string dist = mlua_getFieldString("distortion", false, "");

		// Loading textures
		tmpBGPart.bg = mGFXMgr->createSprite(mGFXMgr->loadTexture(bg), 0, 0, 1024.0f, 1024.0f);

		if ( (dist == "0") || (dist == "none") || (dist == "") )
		{
			tmpBGPart.distData = false;
			tmpBGPart.globalDist = ARGB(255, 0, 255, 255);
		}
		else
		{
			tmpBGPart.distData = true;
			HTEXTURE dist_tex = mGFXMgr->loadTexture(dist);
			tmpBGPart.dist = hge->Texture_Lock(dist_tex);
			hge->Texture_Unlock(dist_tex);
		}

		float index = (y/1024.0f) * (actualZone.w/1024.0f) + (x/1024.0f);

		this->actualZone.parts[index] = tmpBGPart;

		i++;
		x += 1024.0f;
		if (x >= actualZone.w)
		{
			x = 0.0f;
			y += 1024.0f;
		}

		mGUIMgr->mLoadingBar.filling += ((filling-0.02f)/2)/part_nbr;

		lua_pop(luaVM, 1);
		*finished = false;
		return false;
	}
	else if (state1 == 3)
	{
		mGUIMgr->parseUI(mlua_getFieldString("UI", false, ""));

		lua_getfield(luaVM, -1, "Doodads");

		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			doodad_nbr++;
		}

		lua_pushnil(luaVM);

		*finished = false;
		mGUIMgr->mLoadingBar.filling += 0.01f;
		return true;
	}
	else if (state1 == 4)
	{
		if (doodad_nbr == 0)
		{
			mGUIMgr->mLoadingBar.filling += ((filling-0.02f)/2);
			*finished = false;
			return true;
		}

		if (!lua_next(luaVM, -2))
		{
			lua_pop(luaVM, 1);

			*finished = false;
			return true;
		}

		Doodad d;
		d.name = mlua_getFieldString("name");
		if (this->debugParser) {hge->System_Log(" Loading doodad \"%s\"...", d.name.c_str());}
		d.sprite = mGFXMgr->mlua_spriteList[mlua_getFieldString("sprite")];
		d.setX(mlua_getFieldFloat("x", false, 0.0f));
		d.setY(mlua_getFieldFloat("y", false, 0.0f));
		d.inTop = mlua_getFieldBool("always_in_top", false, false);
		if (!d.inTop)
			d.orientation = mlua_getFieldFloat("orientation");

		this->actualZone.doodadList[d.name] = d;
		this->actualZone.doodadList[d.name].setBox();

		lua_pop(luaVM, 1);

		mGUIMgr->mLoadingBar.filling += ((filling-0.02f)/2)/doodad_nbr;

		*finished = false;
		return false;
	}
	else if (state1 == 5)
	{
		lua_getfield(luaVM, -1, "Waypoints");
		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			Waypoint w;
			w.name = mlua_getFieldString("name");
			w.x = mlua_getFieldFloat("x");
			w.y = mlua_getFieldFloat("y");
			w.size = mlua_getFieldFloat("size");
			w.useless = false;
			w.opened = false;
			w.closed = false;
			w.parent = NULL;

			actualZone.wPntList[w.name] = w;
		}
		for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
		{
			string wpName = mlua_getFieldString("name");
			Waypoint* w = &actualZone.wPntList[wpName];

			lua_getfield(luaVM, -1, "childs");
			for (lua_pushnil(luaVM); lua_next(luaVM, -2); lua_pop(luaVM, 1))
			{
				string childName = mlua_getFieldString("name");
				float dist = mlua_getFieldFloat("distance");

				w->childs.insert(make_pair(dist, &actualZone.wPntList[childName]));
			}
			lua_pop(luaVM, 1);
		}
		lua_pop(luaVM, 1);

		*finished = false;
		return true;
	}
	else
	{
		lua_pop(luaVM, 1);
		hge->System_Log("Parsing %s : done.", actualZone.name.c_str());
		*finished = true;
		return true;
	}
}


/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Zone source               */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Zone class.                    */
/*       A Zone stores all the infos that */
/*  are used in a particular place. It    */
/*  contains the collision and distortion */
/*  maps, all the doodads that are ren-   */
/*  dered, the links between zones, ...   */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge/hge.h"

#include "wowrl_structs.h"

#include "wowrl_zone.h"

BGPart* Zone::getBGPart( float x, float y )
{
	std::map<float, BGPart>:: iterator iter;
	float index = floor(y/partSize)*w/partSize+floor(x/partSize);
	iter = parts.lower_bound(index);
	return &iter->second;
}

void Zone::deleteSelf()
{
	std::map<float, BGPart>::iterator iterParts;
	for (iterParts = parts.begin(); iterParts != parts.end(); iterParts++)
	{
		delete iterParts->second.bg;
	}
}

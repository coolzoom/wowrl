/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              .... source               */
/*                                        */
/*  ## : ...                              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.7                 */
/* Copyright (C) 2007-2008, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"

#include "wowrl_zonemanager.h"

extern HGE *hge;

using namespace std;

ZoneManager::ZoneManager()
{
	bgx = 0;
	bgy = 0;
	debugParser = false;
}

ZoneManager* ZoneManager::mZoneMgr = NULL;

ZoneManager* ZoneManager::getSingleton()
{
	if (mZoneMgr == NULL)
		mZoneMgr = new ZoneManager;
	return mZoneMgr;
}

void ZoneManager::deleteDoodads()
{
	map<string, Doodad>::iterator iterDoodad;
	for (iterDoodad = this->actualZone.doodadList.begin(); iterDoodad != this->actualZone.doodadList.end(); iterDoodad++)
	{
		iterDoodad->second.deleteSelf();
	}
	this->actualZone.doodadList.clear();
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               GUI source               */
/*                                        */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_gui.h"
#include "wowrl_scenemanager.h"
#include "wowrl_fontmanager.h"

using namespace std;

extern SceneManager* mSceneMgr;
extern FontManager* mFontMgr;
extern bool debugGUI;

/****************/
/* Constructors */
/****************/









/**************************/
/* Methods implementation */
/**************************/

/* [#] The following functions are called "glues". They aren't used in C++ but
/* in the LUA environnement. To get a description of what they do, you can refer
/* to :
/*                     http://www.wowwiki.com/Widget_API
/*
/* They are all described there. (Some aren't, but their use if obvious)
*/

/**********/
/* REGION */
/**********/


/**********/
/* FRAME  */
/**********/



/**************/
/* STATUS BAR */
/**************/



/******************/
/* LAYERED REGION */
/******************/



/***********/
/* TEXTURE */
/***********/


/***************/
/* FONT STRING */
/***************/


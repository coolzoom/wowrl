/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Font source               */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Font class.                    */
/*     A Font is used to draw text on the */
/*  screen. It can be bold or outlined.   */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_font.h"
#include "wowrl_scenemanager.h"

using namespace std;

extern HGE* hge;
extern SceneManager* mSceneMgr;

void Font::printf(string text, LPRECT rect, DWORD format, D3DCOLOR color, ID3DXSprite* sprite)
{
	if (fnt)
	{
		fnt->DrawText(sprite, text.c_str(), -1, rect, format, color);
	}
}

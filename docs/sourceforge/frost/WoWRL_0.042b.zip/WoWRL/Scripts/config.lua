-- WoWRL configuration file

-- Display
local full = false;
if (full) then
	Display_screen_width = 1280;
	Display_screen_height = 1024;
	Display_fullscreen = true;
else
	Display_screen_width = 1024;
	Display_screen_height = 768;
	Display_fullscreen = false;
end
Display_screen_depth = 32;
Display_max_fps = 1000;

-- Files
Files_starting_zone = "Zones/ZG/ZG_001.lua";

-- Game
Game_locale = "enGB";
Game_aspect_ratio = 1.6;
Game_regen_tick = 2.0;
Game_out_of_combat_timer = 5.0;
Game_max_computed_path = 2;

-- UI
Fonts_default_font = "Fonts/Calibri.ttf";
UI_show_status_bars = true;
UI_show_enemies_status_bars = false;
UI_scrolling_texts_duration = 3.0;
UI_scrolling_texts_speed = 20.0;
UI_scrolling_texts_fade = true;
UI_error_texts_duration = 7.0;
UI_error_texts_fade_delay = 5.0;

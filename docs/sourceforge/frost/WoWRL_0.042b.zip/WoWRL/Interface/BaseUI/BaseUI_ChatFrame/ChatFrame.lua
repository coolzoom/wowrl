SLASH_SCRIPT1 = "/script";

SlashCmdList = { };

MESSAGE_SCROLLBUTTON_INITIAL_DELAY = 0.5;
MESSAGE_SCROLLBUTTON_SCROLL_DELAY = 0.05;

SlashCmdList["SCRIPT"] = function(msg)
	RunScript(msg);
end

TimeStamps = false;
TimeStampsSeconds = true;

---------
function BUI_ChatFrame_OnLoad()
---------
	ChatFrame:SetBackdropColor(0.6, 0, 0, 0.5);
	CombatFrame:SetBackdropColor(0, 0.2, 0.4, 0.5);
	ChatEditBox:SetBackdropColor(0, 0, 0, 0.5);
	
	ChatFrame:AddMessage(CHATFRAME_WELCOME_MSG);
end

---------
function BUI_ChatFrame_ParseText(text)
---------
	-- Code taken from Blizzard's FrameXML :
	if ( string.len(text) <= 0 ) then
		return false;
	end
	
	if ( string.sub(text, 1, 1) ~= "/" ) then
		return false;
	end

	-- If the string is in the format "/cmd blah", command will be "/cmd"
	local command = string.match(text, "^(/[^%s]+)") or "";
	local msg = "";

	if ( command ~= text ) then
		msg = string.sub(text, string.len(command) + 2);
	end
	
	command = string.upper(command);
	
	for index, value in pairs(SlashCmdList) do
		local i = 1;
		local cmdString = GetGlobal("SLASH_"..index..i);
		while ( cmdString ) do
			cmdString = string.upper(cmdString);
			if ( cmdString == command ) then
				local called, error = pcall(value, msg);
				if not(called) then
					LogPrint(error);
				end
				return true;
			end
			i = i + 1;
			cmdString = GetGlobal("SLASH_"..index..i);
		end
	end
	
	return true;
end


function AddZero(nb, size)
	local snb = "";
	snb = snb..nb;
	
	while (string.len(snb) < size) do
		snb = "0"..snb;
	end
	
	return snb;
end

function GetStamp()
	local ts;
	if (TimeStamps) then
		-- Get time
		local hour, min, sec = GetTimeOfTheDay();
		-- Adjust values
		hour = AddZero(hour, 2);
		min = AddZero(min, 2);
		sec = AddZero(sec, 2);
		if (TimeStampsSeconds) then
			ts = hour..":"..min..":"..sec.."> ";
		else
			ts = hour..":"..min.."> ";
		end
	else
		ts = "";
	end
	
	return ts;
end

---------
function BUI_ChatFrame_OnEnterPressed()
---------
	local text = this:GetText();
	if not(BUI_ChatFrame_ParseText(text)) then
		-- Send the message to the chat frame
		ChatFrame:AddMessage(GetStamp()..text);
	end
	
	-- Clear the edit box
	this:SetText();
	this:ClearFocus();
end

---------
function BUI_ChatFrameButton_OnLoad()
---------
	this.clickDelay = MESSAGE_SCROLLBUTTON_INITIAL_DELAY;
end

---------
function BUI_ChatFrameButton_OnUpdate(elapsed, chatFrame)
---------	
	if (this:GetButtonState() == "PUSHED") then
		if ( this.clickDelay == MESSAGE_SCROLLBUTTON_INITIAL_DELAY ) then
			local name = this:GetName();
			if ( name == this:GetParent():GetName().."DownButton" ) then
				chatFrame:ScrollDown();
			elseif ( name == this:GetParent():GetName().."UpButton" ) then
				chatFrame:ScrollUp();
			end
			this.clickDelay = this.clickDelay - elapsed;
		else
			if ( this.clickDelay < 0 ) then
				local name = this:GetName();
				if ( name == this:GetParent():GetName().."DownButton" ) then
					chatFrame:ScrollDown();
				elseif ( name == this:GetParent():GetName().."UpButton" ) then
					chatFrame:ScrollUp();
				end
				this.clickDelay = MESSAGE_SCROLLBUTTON_SCROLL_DELAY;
			end
			this.clickDelay = this.clickDelay - elapsed;
		end
	end
end

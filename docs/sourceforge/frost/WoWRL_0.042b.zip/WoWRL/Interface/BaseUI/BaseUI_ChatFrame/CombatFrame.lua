
local C_FRIENDLY_DEATH = "|cFFFFFFFF";
local C_HOSTILE_DEATH = "|cFFC4C4C4";

local C_PARTY_DAMAGE = "|cFFFF0000";
local C_PARTY_SPELL = "|cFFFEE300";
local C_PARTY_HEAL = "|cFF00C405";

local C_CREATURE_DAMAGE = "|cFFFFFFFF";
local C_CREATURE_SPELL = "|cFFFFFFFF";
local C_CREATURE_HEAL = "|cFFFFFFFF";

---------
function BUI_CombatFrame_OnLoad()
---------
	this:RegisterEvent("CHAT_MSG_COMBAT_FRIENDLY_DEATH");
	this:RegisterEvent("CHAT_MSG_COMBAT_HOSTILE_DEATH");
	this:RegisterEvent("CHAT_MSG_COMBAT_PARTY_HITS");
	this:RegisterEvent("CHAT_MSG_SPELL_PARTY_DAMAGE");
	this:RegisterEvent("CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS");
	this:RegisterEvent("CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMMAGE");
end

---------
function BUI_CombatFrame_OnEvent()
---------
	if (event == "CHAT_MSG_COMBAT_FRIENDLY_DEATH") then
		this:AddMessage(C_FRIENDLY_DEATH..GetStamp()..arg1);
	elseif (event == "CHAT_MSG_COMBAT_HOSTILE_DEATH") then
		this:AddMessage(C_HOSTILE_DEATH..GetStamp()..arg1);
	elseif (event == "CHAT_MSG_COMBAT_PARTY_HITS") then
		this:AddMessage(C_PARTY_DAMAGE..GetStamp()..arg1);
	elseif (event == "CHAT_MSG_SPELL_PARTY_DAMAGE") then
		this:AddMessage(C_PARTY_SPELL..GetStamp()..arg1);
	elseif (event == "CHAT_MSG_COMBAT_CREATURE_VS_PARTY_HITS") then
		this:AddMessage(C_CREATURE_DAMAGE..GetStamp()..arg1);
	elseif (event == "CHAT_MSG_SPELL_CREATURE_VS_PARTY_DAMMAGE") then
		this:AddMessage(C_CREATURE_SPELL..GetStamp()..arg1);
	end
end

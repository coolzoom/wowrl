
---------
function BUI_HelpPageBox_OnEnterPressed()
---------
	
end

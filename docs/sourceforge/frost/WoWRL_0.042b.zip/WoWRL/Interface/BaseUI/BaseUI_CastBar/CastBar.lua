
---------
function BUI_CB_OnUpdate()
---------
	local UNIT = GetLeadingUnit();
	if (UNIT ~= nil) then
		if (UnitIsCasting(UNIT) == "SPELL") then
			CastBar.StatusBar:SetStatusBarColor(1.0, 0.7, 0.0, 1.0);
			
			local spellName, spellRank, displayName, texture, startTime, endTime = UnitCastingInfo(UNIT);
			CastBar.StatusBar.startTime = (startTime/1000);
			CastBar.StatusBar.maxValue = (endTime/1000);
			CastBar.StatusBar:SetMinMaxValues(CastBar.StatusBar.startTime, CastBar.StatusBar.maxValue);
			local curTime = GetTime();
			if (curTime > CastBar.StatusBar.maxValue) then
				curTime = CastBar.StatusBar.maxValue;
			end
			CastBar.StatusBar:SetValue(curTime);
			
			local state = string.format("%.1f", CastBar.StatusBar.maxValue-curTime);
			CastBar.StatusBar.Time:SetText(state);
			
			if (string.len(spellRank) > 0) then
				CastBar.StatusBar.Text:SetText(displayName.." ("..spellRank..")");
			else
				CastBar.StatusBar.Text:SetText(displayName);
			end
			
			local SparkPos = (curTime - CastBar.StatusBar.startTime) / (CastBar.StatusBar.maxValue - CastBar.StatusBar.startTime);
			SparkPos = SparkPos*CastBar.StatusBar:GetWidth();
			if (SparkPos < 0) then
				SparkPos = 0;
			end

		    CastBar.StatusBar.Spark:SetPoint("CENTER", "CastBarStatusBar", "LEFT", SparkPos, 0);
			
			CastBar:Show();
		else
			CastBar:Hide();
		end
	else
		CastBar:Hide();
	end

end

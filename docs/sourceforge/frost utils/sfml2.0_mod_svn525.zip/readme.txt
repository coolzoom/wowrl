Here are the modifications I made to SFML.

Graphics :
    - added Line, LineList, Point, PointList and Quad.
    - modified Sprite.
    - modified Image to allow texture repeat

Window :
    - Input : added mouse wheel.
    - Input : added buffered input

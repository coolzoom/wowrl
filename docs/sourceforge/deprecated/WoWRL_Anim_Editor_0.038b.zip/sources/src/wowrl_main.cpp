/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               Main source              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge.h"
#include "hgesprite.h"
#include "hgefont.h"
#include "hgerect.h"
#include "hgeanim.h"
#include <math.h>
#include <string>
#include <map>
#include <vector>

#include "keyhandler.h"
#include "wowrl_global.h"

struct Box
{
	int x, y;
	int w, h;
	int hx, hy;
};

struct AnimState
{
	int rot;
	int startx, starty;
	int w, h;
	int hx, hy;
	hgeAnimation* anim;
};

using namespace std;

// Global variables
HGE *hge = 0;
KeyHandler myKeyHandler;
int sWidth = 1024, sHeight = 768;
string file;
string bgFile;
hgeSprite* anim;
HTEXTURE aTex;
hgeSprite* buildB;
hgeSprite* removeB;
hgeSprite* saveB;
hgeSprite* loadB;
hgeSprite* buttonP;
hgeSprite* buttonM;
hgeSprite* arrowL;
hgeSprite* arrowR;
hgeFont* defaultFont;
hgeAnimation* currentAnim;
hgeAnimation* currentBGAnim;
bool ctrlPressed;
bool shiftPressed;
int mLState;
int mRState;
float dt;
float mx, my;
float waitTimer = 0.5f;
bool startTimer = false;
bool allowLongPress = false;
bool build = false;
bool rem = false;
bool save = false;
bool load = false;
bool loaded = false;
float pressTimer = 0.0f;
float pressTimer2 = 0.0f;

int rot = 0;
int frames = 0;
float fps = 10;
int h = 32;
int w = 32;
int hx;
int hy;
int startx = 0;
int starty = 0;
int tW;
int tH;
map<int, Box> boxList;
vector<AnimState> animList;
vector<AnimState> animBGList;
vector<AnimState>::iterator iterAnim;
vector<AnimState>::iterator iterBGAnim;

// Function called by HGE once per frame.
bool FrameFunc()
{
	dt = hge->Timer_GetDelta();
	myKeyHandler.updateKeys(dt);

	hge->Input_GetMousePos(&mx,&my);

	if (myKeyHandler.keyIsDown(HGEK_ESCAPE))
		return true;

	if (myKeyHandler.keyIsDown(HGEK_CTRL))
	{
		ctrlPressed = true;
	}
	else
		ctrlPressed = false;

	if (myKeyHandler.keyIsDown(HGEK_SHIFT))
	{
		shiftPressed = true;
	}
	else
		shiftPressed = false;

	// Handle left mouse button
	if (myKeyHandler.keyIsDown(HGEK_LBUTTON))
	{
		if (myKeyHandler.keyIsPressed(HGEK_LBUTTON))
			mLState = 2; // single pressed
		else if(myKeyHandler.keyIsDoubleClicked(HGEK_LBUTTON))
			mLState = 4; // double clicked
		else
			mLState = 1; // dragged
	}
	else if (myKeyHandler.keyIsReleased(HGEK_LBUTTON))
	{
		mLState = 3; // released
	}
	else
		mLState = 0; // no input

	// Handle right mouse button
	if (myKeyHandler.keyIsDown(HGEK_RBUTTON))
	{
		if (myKeyHandler.keyIsPressed(HGEK_RBUTTON))
			mRState = 2;
		else if (myKeyHandler.keyIsDoubleClicked(HGEK_RBUTTON))
			mRState = 4;
		else
			mRState = 1;
	}
	else if (myKeyHandler.keyIsReleased(HGEK_RBUTTON))
	{
		mRState = 3;
	}
	else
		mRState = 0;

	if (mLState == 2)
	{
		if (!loaded)
		{
			for (int i=0; i < 7; i ++)
			{
				hgeRect* bBox = new hgeRect();
				buttonP->GetBoundingBox(sWidth-60, 10+i*25, bBox);
				if (bBox->TestPoint(mx, my))
				{
					if (i == 0)
					{
						rot++;
						if (rot == 8)
							rot = 0;
					}
					if (i == 1)
						fps += 0.1f;
					if (i == 2)
						frames++;
					if (i == 3)
					{
						startx++;
						if (startx > tW)
							startx = tW;
					}
					if (i == 4)
					{
						starty++;
						if (starty > tH)
							starty = tH;
					}
					if (i == 5)
					{
						w++;
						if (w > tW)
							w = tW;
					}
					if (i == 6)
					{
						h++;
						if (h > tH)
							h = tH;
					}
					delete bBox;
					startTimer = true;
					break;
				}
				delete bBox;
				bBox = new hgeRect();
				buttonM->GetBoundingBox(sWidth-35, 10+i*25, bBox);
				if (bBox->TestPoint(mx, my))
				{
					if (i == 0)
					{
						rot--;
						if (rot == -1)
							rot = 7;
					}
					if (i == 1)
					{
						fps -= 0.1f;
						if (fps < 0.0f)
							fps = 0.0f;
					}
					if (i == 2)
					{
						frames--;
						if (frames < 0)
							frames = 0;
					}
					if (i == 3)
					{
						startx--;
						if (startx < 0)
							startx = 0;
					}
					if (i == 4)
					{
						starty--;
						if (starty < 0)
							starty = 0;
					}
					if (i == 5)
					{
						w--;
						if (w < 0)
							w = 0;
					}
					if (i == 6)
					{
						h--;
						if (h < 0)
							h = 0;
					}
					delete bBox;
					startTimer = true;
					break;
				}
				delete bBox;
			}
			hgeRect* bBox = new hgeRect();
			buildB->GetBoundingBox(sWidth-138, 200, bBox);
			if (bBox->TestPoint(mx, my))
			{
				build = true;
			}
			delete bBox;
			bBox = new hgeRect();
			removeB->GetBoundingBox(sWidth-74, 200, bBox);
			if (bBox->TestPoint(mx, my))
			{
				rem = true;
			}
			delete bBox;
			bBox = new hgeRect();
			saveB->GetBoundingBox(sWidth-106, 240, bBox);
			if (bBox->TestPoint(mx, my))
			{
				save = true;
			}
			delete bBox;
			bBox = new hgeRect();
			loadB->GetBoundingBox(sWidth-138, 280, bBox);
			if (bBox->TestPoint(mx, my))
			{
				load = true;
			}
			delete bBox;
		}
		else
		{
			hgeRect* bBox = new hgeRect();
			arrowL->GetBoundingBox(sWidth-120, 340, bBox);
			if (bBox->TestPoint(mx, my))
			{
				iterAnim++;
				if (iterAnim == animList.end())
					iterAnim = animList.begin();

				currentAnim = iterAnim->anim;

				if (bgFile == "true")
				{
					iterBGAnim++;
					if (iterBGAnim == animBGList.end())
						iterBGAnim = animBGList.begin();
					currentBGAnim = iterBGAnim->anim;
				}

				rot = iterAnim->rot;
				float thx, thy;
				iterAnim->anim->GetHotSpot(&thx, &thy);
				hx = toInt(thx);
				hy = toInt(thy);
			}
			delete bBox;
			bBox = new hgeRect();
			arrowR->GetBoundingBox(sWidth-70, 340, bBox);
			if (bBox->TestPoint(mx, my))
			{
				if (iterAnim == animList.begin())
					iterAnim = animList.end();

				iterAnim--;

				currentAnim = iterAnim->anim;

				if (bgFile == "true")
				{
					if (iterBGAnim == animBGList.begin())
						iterBGAnim = animBGList.end();

					iterBGAnim--;

					currentBGAnim = iterBGAnim->anim;
				}

				rot = iterAnim->rot;
				float thx, thy;
				iterAnim->anim->GetHotSpot(&thx, &thy);
				hx = toInt(thx);
				hy = toInt(thy);
			}
			delete bBox;
			bBox = new hgeRect();
			buttonP->GetBoundingBox(sWidth-100, 365+currentAnim->GetHeight()*2, bBox);
			if (bBox->TestPoint(mx, my))
			{
				hx++;
				if (hx > currentAnim->GetWidth())
					hx = toInt(currentAnim->GetWidth());

				currentAnim->SetHotSpot(hx, hy);
				startTimer = true;
				waitTimer = 0.5f;
			}
			delete bBox;
			bBox = new hgeRect();
			buttonM->GetBoundingBox(sWidth-75, 365+currentAnim->GetHeight()*2, bBox);
			if (bBox->TestPoint(mx, my))
			{
				hx--;
				if (hx < 0)
					hx = 0;

				currentAnim->SetHotSpot(hx, hy);
				startTimer = true;
				waitTimer = 0.5f;
			}
			delete bBox;
			bBox = new hgeRect();
			buttonP->GetBoundingBox(sWidth-100, 390+currentAnim->GetHeight()*2, bBox);
			if (bBox->TestPoint(mx, my))
			{
				hy++;
				if (hy > currentAnim->GetHeight())
					hy = toInt(currentAnim->GetHeight());

				currentAnim->SetHotSpot(hx, hy);
				startTimer = true;
				waitTimer = 0.5f;
			}
			delete bBox;
			bBox = new hgeRect();
			buttonM->GetBoundingBox(sWidth-75, 390+currentAnim->GetHeight()*2, bBox);
			if (bBox->TestPoint(mx, my))
			{
				hy--;
				if (hy < 0)
					hy = 0;

				currentAnim->SetHotSpot(hx, hy);
				startTimer = true;
				waitTimer = 0.5f;
			}
			delete bBox;
		}
		hgeRect* bBox = new hgeRect();
		saveB->GetBoundingBox(sWidth-106, 240, bBox);
		if (bBox->TestPoint(mx, my))
		{
			save = true;
		}
	}

	if ( (mLState == 1) && allowLongPress )
	{
		startTimer = false;
		int add, a;
		pressTimer += dt;
		pressTimer2 += dt;
		if (pressTimer2 < 3.0f)
			a = 1;
		else if (pressTimer2 < 7.0f)
			a = 5;
		else
			a = 10;

		if (pressTimer > 0.05f)
		{
			pressTimer = 0.0f;
			add = a;
		}
		else
			add = 0;

		if (!loaded)
		{
			for (int i=0; i < 7; i ++)
			{
				hgeRect* bBox = new hgeRect();
				buttonP->GetBoundingBox(sWidth-60, 10+i*25, bBox);
				if (bBox->TestPoint(mx, my))
				{
					if (i == 0)
					{
						rot += add;
						if (rot == 8)
							rot = 0;
					}
					if (i == 1)
						fps += add*0.1f;
					if (i == 2)
						frames += add;
					if (i == 3)
					{
						startx += add;
						if (startx > tW)
							startx = tW;
					}
					if (i == 4)
					{
						starty += add;
						if (starty > tH)
							starty = tH;
					}
					if (i == 5)
					{
						w += add;
						if (w > tW)
							w = tW;
					}
					if (i == 6)
					{
						h += add;
						if (h > tH)
							h = tH;
					}
					delete bBox;
					startTimer = true;
					break;
				}
				delete bBox;
				bBox = new hgeRect();
				buttonM->GetBoundingBox(sWidth-35, 10+i*25, bBox);
				if (bBox->TestPoint(mx, my))
				{
					if (i == 0)
					{
						rot -= add;
						if (rot == -1)
							rot = 7;
					}
					if (i == 1)
					{
						fps -= add*0.1f;
						if (fps < 0.0f)
							fps = 0.0f;
					}
					if (i == 2)
					{
						frames -= add;
						if (frames < 0)
							frames = 0;
					}
					if (i == 3)
					{
						startx -= add;
						if (startx < 0)
							startx = 0;
					}
					if (i == 4)
					{
						starty -= add;
						if (starty < 0)
							starty = 0;
					}
					if (i == 5)
					{
						w -= add;
						if (w < 0)
							w = 0;
					}
					if (i == 6)
					{
						h -= add;
						if (h < 0)
							h = 0;
					}
					delete bBox;
					startTimer = true;
					break;
				}
				delete bBox;
			}
		}
		else
		{
			hgeRect* bBox = new hgeRect();
			buttonP->GetBoundingBox(sWidth-100, 365+currentAnim->GetHeight()*2, bBox);
			if (bBox->TestPoint(mx, my))
			{
				hx += add;
				if (hx > currentAnim->GetWidth())
					hx = toInt(currentAnim->GetWidth());

				currentAnim->SetHotSpot(hx, hy);
			}
			delete bBox;
			bBox = new hgeRect();
			buttonM->GetBoundingBox(sWidth-75, 365+currentAnim->GetHeight()*2, bBox);
			if (bBox->TestPoint(mx, my))
			{
				hx -= add;
				if (hx < 0)
					hx = 0;

				currentAnim->SetHotSpot(hx, hy);
			}
			delete bBox;
			bBox = new hgeRect();
			buttonP->GetBoundingBox(sWidth-100, 390+currentAnim->GetHeight()*2, bBox);
			if (bBox->TestPoint(mx, my))
			{
				hy += add;
				if (hy > currentAnim->GetHeight())
					hy = toInt(currentAnim->GetHeight());

				currentAnim->SetHotSpot(hx, hy);
			}
			delete bBox;
			bBox = new hgeRect();
			buttonM->GetBoundingBox(sWidth-75, 390+currentAnim->GetHeight()*2, bBox);
			if (bBox->TestPoint(mx, my))
			{
				hy -= add;
				if (hy < 0)
					hy = 0;

				currentAnim->SetHotSpot(hx, hy);
			}
			delete bBox;
		}
	}
	else
	{
		pressTimer = 0.0f;
		pressTimer2 = 0.0f;
		allowLongPress = false;
	}

	if (startTimer)
		waitTimer -= dt;
	if (waitTimer <= 0.0f)
	{
		startTimer = false;
		waitTimer = 0.5f;
		allowLongPress = true;
		pressTimer = 0.0f;
	}

	boxList.clear();
	int x = startx;
	int y = starty;
	for (int i = 1; i <= frames; i++)
	{
		Box b;
		b.x = x;
		b.y = y;
		b.w = w;
		b.h = h;
		boxList[i] = b;

		x += w;
		if (x + w > tW)
		{
			x = 0;
			y += h;
		}
	}

	vector<AnimState>::iterator iter2;
	for (iter2 = animList.begin(); iter2 != animList.end(); iter2++)
	{
		hgeAnimation* a = iter2->anim;
		a->Update(dt);
	}
	if (bgFile == "true")
	{
		for (iter2 = animBGList.begin(); iter2 != animBGList.end(); iter2++)
		{
			hgeAnimation* a = iter2->anim;
			a->Update(dt);
		}
	}

	if (build)
	{
		if (frames != 0 && w != 0 && h != 0)
		{
			AnimState a;
			a.rot = rot;
			a.startx = startx;
			a.starty = starty;
			a.w = w;
			a.h = h;
			a.anim = new hgeAnimation(aTex, frames, fps, startx, starty, w, h);
			a.anim->Play();
			animList.push_back(a);
		}
		build = false;
	}
	if (rem)
	{
		if (!animList.empty())
			animList.pop_back();
		rem = false;
	}
	if (save)
	{
		if (!loaded)
		{
			hge->System_SetState(HGE_INIFILE, "anim.txt");
			string section = "animset";
			string base = "rot_";
			hge->Ini_SetFloat(section.c_str(), "fps", fps);
			hge->Ini_SetInt(section.c_str(), "frames", frames);
			hge->Ini_SetString(section.c_str(), "loop", "true");
			vector<AnimState>::iterator iter2;
			for (iter2 = animList.begin(); iter2 != animList.end(); iter2++)
			{
				AnimState* a = &(*iter2);
				string base2 = "rot_" + toString(iter2->rot) + "_";
				hge->Ini_SetString(section.c_str(), (base2 + "file").c_str(), file.c_str());
				hge->Ini_SetInt(section.c_str(), (base2 + "x").c_str(), a->startx);
				hge->Ini_SetInt(section.c_str(), (base2 + "y").c_str(), a->starty);
				hge->Ini_SetInt(section.c_str(), (base2 + "w").c_str(), a->w);
				hge->Ini_SetInt(section.c_str(), (base2 + "h").c_str(), a->h);
			}
		}
		else
		{
			hge->System_SetState(HGE_INIFILE, "anim.txt");
			string section = "animset";
			string base = "rot_";
			vector<AnimState>::iterator iter2;
			for (iter2 = animList.begin(); iter2 != animList.end(); iter2++)
			{
				AnimState* a = &(*iter2);
				string base2 = "rot_" + toString(iter2->rot) + "_";
				float thx, thy;
				a->anim->GetHotSpot(&thx, &thy);
				hge->Ini_SetInt(section.c_str(), (base2 + "hx").c_str(), toInt(thx));
				hge->Ini_SetInt(section.c_str(), (base2 + "hy").c_str(), toInt(thy));
			}
		}
		save = false;
	}
	if (load)
	{
		hge->System_SetState(HGE_INIFILE, "anim.txt");
		string section = "animset";
		string base = "rot_";
		animList.clear();
		fps = hge->Ini_GetFloat(section.c_str(), "fps", -1);
		frames = toInt(hge->Ini_GetFloat(section.c_str(), "frames", -1));
		for (int i=0; i <= 7; i++)
		{
			AnimState a;
			string base2 = "rot_" + toString(i) + "_";
			string aFile = hge->Ini_GetString(section.c_str(), (base2 + "file").c_str(), "");
			int aX = toInt(hge->Ini_GetFloat(section.c_str(), (base2 + "x").c_str(), -1));
			int aY = toInt(hge->Ini_GetFloat(section.c_str(), (base2 + "y").c_str(), -1));
			int aW = toInt(hge->Ini_GetFloat(section.c_str(), (base2 + "w").c_str(), -1));
			int aH = toInt(hge->Ini_GetFloat(section.c_str(), (base2 + "h").c_str(), -1));
			int aHX = toInt(hge->Ini_GetFloat(section.c_str(), (base2 + "hx").c_str(), 0));
			int aHY = toInt(hge->Ini_GetFloat(section.c_str(), (base2 + "hy").c_str(), 0));

			HTEXTURE tTex = hge->Texture_Load(aFile.c_str());
			a.anim = new hgeAnimation(tTex, frames, fps, aX, aY, aW, aH);
			a.anim->SetHotSpot(aHX, aHY);
			a.anim->Play();
			a.rot = i;
			animList.push_back(a);
		}
		load = false;
		loaded = true;
		currentAnim = animList.begin()->anim;
		rot = animList.begin()->rot;
		iterAnim = animList.begin();

		float thx, thy;
		currentAnim->GetHotSpot(&thx, &thy);
		hx = toInt(thx);
		hy = toInt(thy);

		if (bgFile == "true")
		{
			hge->System_SetState(HGE_INIFILE, "anim2.txt");
			string section = "animset";
			string base = "rot_";
			animBGList.clear();
			fps = hge->Ini_GetFloat(section.c_str(), "fps", -1);
			frames = toInt(hge->Ini_GetFloat(section.c_str(), "frames", -1));
			for (int i=0; i <= 7; i++)
			{
				AnimState a;
				string base2 = "rot_" + toString(i) + "_";
				string aFile = hge->Ini_GetString(section.c_str(), (base2 + "file").c_str(), "");
				int aX = toInt(hge->Ini_GetFloat(section.c_str(), (base2 + "x").c_str(), -1));
				int aY = toInt(hge->Ini_GetFloat(section.c_str(), (base2 + "y").c_str(), -1));
				int aW = toInt(hge->Ini_GetFloat(section.c_str(), (base2 + "w").c_str(), -1));
				int aH = toInt(hge->Ini_GetFloat(section.c_str(), (base2 + "h").c_str(), -1));
				int aHX = toInt(hge->Ini_GetFloat(section.c_str(), (base2 + "hx").c_str(), 0));
				int aHY = toInt(hge->Ini_GetFloat(section.c_str(), (base2 + "hy").c_str(), 0));

				HTEXTURE tTex = hge->Texture_Load(aFile.c_str());
				a.anim = new hgeAnimation(tTex, frames, fps, aX, aY, aW, aH);
				a.anim->SetHotSpot(aHX, aHY);
				a.anim->Play();
				a.rot = i;
				animBGList.push_back(a);
				currentBGAnim = animBGList.begin()->anim;
				iterBGAnim = animBGList.begin();
			}
		}
	}

    return false;
}

// Rendering stuff
bool RenderFunc()
{
	hge->Gfx_BeginScene();
	hge->Gfx_Clear(ARGB(255,128,128,128));

	if (!loaded)
	{
		anim->Render(1,1);

		map<int, Box>::iterator iter;
		for (iter = boxList.begin(); iter != boxList.end(); iter++)
		{
			Box* b = &iter->second;
			hge->Gfx_RenderLine(b->x+1, b->y+1, b->x+w+1, b->y+1, ARGB(255,255,210,0));
			hge->Gfx_RenderLine(b->x+w+1, b->y+1, b->x+w+1, b->y+h+1, ARGB(255,255,210,0));
			hge->Gfx_RenderLine(b->x+w+1, b->y+h+1, b->x+1, b->y+h+1, ARGB(255,255,210,0));
			hge->Gfx_RenderLine(b->x+1, b->y+h+1, b->x+1, b->y+1, ARGB(255,255,210,0));
		}

		defaultFont->printf
		(
			sWidth - 60, 15, HGETEXT_RIGHT,
			"rot : %d", rot
		);
		buttonP->Render(sWidth-60, 10);
		buttonM->Render(sWidth-35, 10);

		defaultFont->printf
		(
			sWidth - 60, 40, HGETEXT_RIGHT,
			"fps : %.1f", fps
		);
		buttonP->Render(sWidth-60, 35);
		buttonM->Render(sWidth-35, 35);

		defaultFont->printf
		(
			sWidth - 60, 65, HGETEXT_RIGHT,
			"frames : %d", frames
		);
		buttonP->Render(sWidth-60, 60);
		buttonM->Render(sWidth-35, 60);

		defaultFont->printf
		(
			sWidth - 60, 90, HGETEXT_RIGHT,
			"startX : %d", startx
		);
		buttonP->Render(sWidth-60, 85);
		buttonM->Render(sWidth-35, 85);

		defaultFont->printf
		(
			sWidth - 60, 115, HGETEXT_RIGHT,
			"startY : %d", starty
		);
		buttonP->Render(sWidth-60, 110);
		buttonM->Render(sWidth-35, 110);

		defaultFont->printf
		(
			sWidth - 60, 140, HGETEXT_RIGHT,
			"width : %d", w
		);
		buttonP->Render(sWidth-60, 135);
		buttonM->Render(sWidth-35, 135);

		defaultFont->printf
		(
			sWidth - 60, 165, HGETEXT_RIGHT,
			"height : %d", h
		);
		buttonP->Render(sWidth-60, 160);
		buttonM->Render(sWidth-35, 160);

		buildB->Render(sWidth-138, 200);
		removeB->Render(sWidth-74, 200);
		loadB->Render(sWidth-138, 280);
	}

	saveB->Render(sWidth-106, 240);

	if (loaded)
	{
		if (bgFile == "true")
			currentBGAnim->Render(sWidth/2.0f, sHeight/2.0f);
		currentAnim->Render(sWidth/2.0f, sHeight/2.0f);

		hge->Gfx_RenderLine
		(
			sWidth/2.0f-100, sHeight/2.0f,
			sWidth/2.0f+100, sHeight/2.0f
		);
		hge->Gfx_RenderLine
		(
			sWidth/2.0f, sHeight/2.0f-100,
			sWidth/2.0f, sHeight/2.0f+100
		);

		arrowL->Render(sWidth-120, 340);
		defaultFont->printf
		(
			sWidth - 80, 345, HGETEXT_CENTER,
			"%d", rot
		);
		arrowR->Render(sWidth-70, 340);

		defaultFont->printf
		(
			sWidth - 100, 370+currentAnim->GetHeight()*2, HGETEXT_RIGHT,
			"hx : %d", hx
		);
		buttonP->Render(sWidth-100, 365+currentAnim->GetHeight()*2);
		buttonM->Render(sWidth-75, 365+currentAnim->GetHeight()*2);

		defaultFont->printf
		(
			sWidth - 100, 395+currentAnim->GetHeight()*2, HGETEXT_RIGHT,
			"hy : %d", hy
		);
		buttonP->Render(sWidth-100, 390+currentAnim->GetHeight()*2);
		buttonM->Render(sWidth-75, 390+currentAnim->GetHeight()*2);
	}

	int x = 100;
	vector<AnimState>::iterator iter2;
	if (bgFile == "true")
	{
		for (iter2 = animBGList.begin(); iter2 != animBGList.end(); iter2++)
		{
			hgeAnimation* a = iter2->anim;
			a->Render(sWidth-x, sHeight-125);
			x += 75;
		}
		x = 100;
	}
	for (iter2 = animList.begin(); iter2 != animList.end(); iter2++)
	{
		hgeAnimation* a = iter2->anim;
		a->Render(sWidth-x, sHeight-125);
		defaultFont->printf
		(
			sWidth-x+25, sHeight-50, HGETEXT_CENTER,
			"%d", iter2->rot
		);
		x += 75;
	}


	/*defaultFont->printf
	(
		sWidth - 30, sHeight - 30, HGETEXT_RIGHT,
		"presstimer2 : %f", pressTimer2
	);*/

	hge->Gfx_EndScene();
    return false;
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    hge = hgeCreate(HGE_VERSION);
    hge->System_SetState(HGE_LOGFILE, "AnimEditor.log"); // Initialize the Log file
    hge->System_SetState(HGE_FRAMEFUNC, FrameFunc);
    hge->System_SetState(HGE_RENDERFUNC, RenderFunc);

    hge->System_SetState(HGE_TITLE, "WoWRL - Anim Editor"); // Set the frame title

	hge->System_Log("Parsing config.ini...");
    hge->System_SetState(HGE_INIFILE, "config.ini");
    sWidth = toInt(hge->Ini_GetFloat("Display", "scr_width", 1024));
    sHeight = toInt(hge->Ini_GetFloat("Display", "scr_height", 768));
    int sDepth = toInt(hge->Ini_GetFloat("Display", "scr_depth", 32));
    file = hge->Ini_GetString("Anim", "file", "");
    bgFile = hge->Ini_GetString("Anim", "use_animset_background", "");
    hge->System_Log("Parsing config : done.");

    hge->System_SetState(HGE_FPS, 60);
    hge->System_SetState(HGE_WINDOWED, true);
    hge->System_SetState(HGE_SCREENWIDTH, sWidth);
    hge->System_SetState(HGE_SCREENHEIGHT, sHeight);
    hge->System_SetState(HGE_SCREENBPP, sDepth);
    hge->System_SetState(HGE_HIDEMOUSE, false);

    hge->System_SetState(HGE_ICON, MAKEINTRESOURCE (1));

    hge->System_SetState(HGE_USESOUND, false);

    if(hge->System_Initiate())
    {
    	aTex = hge->Texture_Load(file.c_str());
    	tW = hge->Texture_GetWidth(aTex, true);
    	tH = hge->Texture_GetHeight(aTex, true);
    	anim = new hgeSprite(aTex, 0, 0, tW, tH);

    	HTEXTURE bTex = hge->Texture_Load("buttons.png");
    	buttonP = new hgeSprite(bTex, 0, 0, 32, 32);
    	buttonM = new hgeSprite(bTex, 32, 32, 32, 32);

    	HTEXTURE buildTex = hge->Texture_Load("build.png");
    	buildB = new hgeSprite(buildTex, 0, 0, 64, 32);

    	HTEXTURE removeTex = hge->Texture_Load("remove.png");
    	removeB = new hgeSprite(removeTex, 0, 0, 64, 32);

    	HTEXTURE saveTex = hge->Texture_Load("save.png");
    	saveB = new hgeSprite(saveTex, 0, 0, 64, 32);

    	HTEXTURE loadTex = hge->Texture_Load("load_animset.png");
    	loadB = new hgeSprite(loadTex, 0, 0, 128, 32);

    	HTEXTURE arrowTex = hge->Texture_Load("arrows.png");
    	arrowL = new hgeSprite(arrowTex, 0, 0, 32, 32);
    	arrowR = new hgeSprite(arrowTex, 32, 32, 32, 32);

    	defaultFont = new hgeFont("Calibri_bold_18.fnt");

        // Start
        hge->System_Start();

        hge->Texture_Free(aTex);
        hge->Texture_Free(bTex);
        hge->Texture_Free(buildTex);
        hge->Texture_Free(removeTex);
        hge->Texture_Free(saveTex);
        hge->Texture_Free(loadTex);
        hge->Texture_Free(arrowTex);

        delete anim;
        delete buttonP;
        delete buttonM;
        delete buildB;
        delete removeB;
        delete saveB;
        delete loadB;
        delete arrowL;
        delete arrowR;
        delete defaultFont;
    }
    else
    {
        MessageBox(NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_APPLMODAL);
    }

    hge->System_Shutdown();

    hge->Release();

    return 0;
}

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             Global source              */
/*                                        */
/*  ## : Contains frequently used funcs.  */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include <math.h>
#include <string>
#include <sstream>

// Converts an integer to a string
std::string toString( float f )
{
	std::ostringstream s;
	s << f;
	return s.str();
}

// Converts a rounded float to a integer
int toInt( float f )
{
    int i = static_cast<int>(round(f));
    return i;
}

	/* ###################################### */
	/* ###     WoWRL EDITOR, by Kalith    ### */
	/* ###################################### */
	/*                                        */
	/* Powered by :                           */
	/* Haaf's Game Engine 1.7                 */
	/* Copyright (C) 2003-2007, Relish Games  */
	/* hge.relishgames.com                    */
	/*                                        */
	/*                  README                */
	/*                                        */
	/******************************************/

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of
    the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program; if not, write to the Free
    Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
    Boston, MA 02110-1301 USA.


## How to use ?
Put the picture you want to make an animation with in the exe folder,
and edit the "file" value in config.ini to point to your file.
Then launch the app.
You can then set the animation parameters.
When you feel your layout is good, press the "build" button and you'll
see your animation appear in the bottom right corner of the screen.
If this animation doesn't please you, simply remove it by pressing the
"remove" button.
Don't forget to set the rot value : it will be used by the game to decide
which animation to choose depending on the unit's orientation.
0 is oriented to the north, 1 is north-west, 2 west, ...
When you have builded all the animations of your file, press the "save"
button and all you animations will be saved in "anim.txt".
If you are making a whole new animation set (= an animation with its 8
points of view), don't forget to delete "anim.txt". 
If your animation is stored in more than one picture, keep "anim.txt"
between each session, and don't forget to set the right "rot" value.
When you have successfuly created your 8 subanimations, press the
"load animset" button. The GUI should change completely.
You can see a white cross in the center of the screen. This is the
coordinates at which the current animation is rendered.
The animation may not be well centered on this cross. If so, adjust its
hotspot (hx, hy) until it is in the right place. When you're done, push the
left arrow button and do the same, until you've centered the 8 subanimations.
When everything is good, press the "save" button again and the hotspots will
be written in "anim.txt", which is now complete.

If your animation is a special effect and you'd like to display an animation
under it so you can adjust precisely its hotspot, edit set the
"use_animset_background" value in config.ini to "true" (without brackets).
Then, copy your background animation file into anim2.txt (create it if it's
not there) and don't forget to copy your background animation pictures (and
edit the file names if needed).
Now, when you push the "load animset", the background animation will be
displayed under your effect.
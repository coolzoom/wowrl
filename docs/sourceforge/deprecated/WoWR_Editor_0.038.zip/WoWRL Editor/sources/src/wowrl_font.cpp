/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Font source               */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Font class.                    */
/*     A Font is used to draw text on the */
/*  screen. It can be bold or outlined.   */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "hge.h"
#include "hgesprite.h"

#include "wowrl_font.h"

using namespace std;

extern HGE* hge;

void Font::DrawText(string text, LPRECT pRect, DWORD format, D3DCOLOR color)
{
	if (outlined)
	{
		/*int outline = 1;

		LONG x1 = pRect->left;
		LONG y1 = pRect->top;
		LONG x2 = pRect->right+outline;
		LONG y2 = pRect->bottom+outline;

		for (float angle = 0.0f; angle<2*M_PI; angle += M_PI/3)
		{
			pRect->left = static_cast<LONG>(x1+outline*cos(angle));
			pRect->top = static_cast<LONG>(y1+outline*sin(angle));
			fnt->DrawText(NULL, text.c_str(), -1, pRect, format, ARGB(255,0,0,0));
		}

		pRect->left = x1;
		pRect->top = y1;
		pRect->right = x2;
		pRect->bottom = y2;*/

		fnt->DrawText(NULL, text.c_str(), -1, pRect, format, color);
	}
	else
	{
		fnt->DrawText(NULL, text.c_str(), -1, pRect, format, color);
	}
}

void Font::DrawTextB(string text, LPRECT pRect, DWORD format, D3DCOLOR color)
{
	if (outlined)
	{
		int outline = 2;

		//hge->System_Log("1");

		HTARGET tmpTarget = hge->Target_Create
		(
			pRect->right-pRect->left,
			pRect->bottom-pRect->top,
			false
		);

		//hge->System_Log("2");

		RECT* tmpRect = new RECT();
		tmpRect->left = 0;
		tmpRect->top = 0;
		tmpRect->right = pRect->right-pRect->left;
		tmpRect->bottom = pRect->bottom-pRect->top;

		//hge->System_Log("3");

		hge->Gfx_EndScene();
		hge->Gfx_BeginScene(tmpTarget);
		hge->Gfx_Clear(0);
		fnt->DrawText(NULL, text.c_str(), -1, tmpRect, format, ARGB(255,255,255,255));
		hge->Gfx_EndScene();
		hge->Gfx_BeginScene();

		delete tmpRect;

		//hge->System_Log("4");

		HTEXTURE tmpTexture = hge->Target_GetTexture(tmpTarget);
		hgeSprite* tmpSprite = new hgeSprite
		(
			tmpTexture,
			0,
			0,
			hge->Texture_GetWidth(tmpTexture),
			hge->Texture_GetHeight(tmpTexture)
		);

		//hge->System_Log("5");

		tmpSprite->SetColor(ARGB(255,0,0,0));

		for (float angle = 0.0f; angle<2*M_PI; angle += M_PI/3)
		{
			tmpSprite->Render(pRect->left+outline*cos(angle), pRect->top+outline*sin(angle));
		}

		//hge->System_Log("6");

		tmpSprite->SetColor(color);
		tmpSprite->Render(pRect->left, pRect->top);

		delete tmpSprite;

		//hge->System_Log("7");
	}
	else
	{
		fnt->DrawText(NULL, text.c_str(), -1, pRect, format, color);
	}
}

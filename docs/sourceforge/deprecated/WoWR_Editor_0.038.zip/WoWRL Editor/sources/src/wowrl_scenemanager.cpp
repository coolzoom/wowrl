/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          Scene manager source          */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the SceneManager class.            */
/*       A SceneManager is obviously a    */
/*  class that manages the scene and its  */
/*  components (units, background ...)    */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include <vector>
#include "hgestrings.h"
#include "wowrl_global.h"
#include "wowrl_zone.h"
#include "wowrl_doodad.h"
#include "wowrl_collision.h"

#include "wowrl_scenemanager.h"

extern HGE *hge;

using namespace std;

SceneManager::SceneManager()
{
}

void SceneManager::initValues()
{
	// Default values
	defaultFont = NULL;
	mForceUpdate = true;

	castBarX = sWidth/2.0f;
	castBarY = sHeight-160;

	debugParser = false;
	debugRenderList = false;
}

SceneManager* SceneManager::mSceneMgr = NULL;

SceneManager* SceneManager::getSingleton()
{
	if (mSceneMgr == NULL)
		mSceneMgr = new SceneManager;
	return mSceneMgr;
}

bool SceneManager::parseZoneDyn( int state1, int state2, bool* finished, float filling )
{
	static int part_nbr;
	static int doodad_nbr;

	if (state1 == 1)
	{
		hge->System_Log("Parsing %s...", this->actualZone.name.c_str());
		hge->System_SetState(HGE_INIFILE, this->actualZone.name.c_str());
		part_nbr = toInt(hge->Ini_GetFloat("Resources", "part_nbr", -1));
		if (part_nbr == -1) {hge->System_Log("# Error # : missing part_nbr in \"%s\"...", this->actualZone.name.c_str());}
		this->actualZone.distortion_scale_max = hge->Ini_GetFloat("Parameters", "distortion_scale_max", 1.00f);
		this->actualZone.distortion_scale_min = hge->Ini_GetFloat("Parameters", "distortion_scale_min", 1.00f);
		this->actualZone.distortion_vscale_max = hge->Ini_GetFloat("Parameters", "distortion_vscale_max", 1.00f);
		this->actualZone.distortion_vscale_min = hge->Ini_GetFloat("Parameters", "distortion_vscale_min", 1.00f);
		this->actualZone.distortion_angle_max = hge->Ini_GetFloat("Parameters", "distortion_angle_max", 0.0f);
		this->actualZone.distortion_angle_min = hge->Ini_GetFloat("Parameters", "distortion_angle_min", 0.0f);
		this->actualZone.w = toInt(hge->Ini_GetFloat("Parameters", "width", 1024));
		this->actualZone.h = toInt(hge->Ini_GetFloat("Parameters", "height", 1024));
		this->gx = -toInt(hge->Ini_GetFloat("Parameters", "start_x", this->actualZone.w/2));
		this->gy = -toInt(hge->Ini_GetFloat("Parameters", "start_y", this->actualZone.h/2));
		*finished = false;
		mSceneMgr->mLoadingBar.filling += 0.01f;
		return true;
	}
	else if (state1 == 2)
	{
		// Parsing background parts
		float x = 0;
		float y = 0;
		int i;
		for (i=1; i!=state2; i++)
		{
			x += this->actualZone.partSize;
			if (x >= this->actualZone.w)
			{
				x = 0;
				y += this->actualZone.partSize;
			}
		}

		string partName = "part_" + toString(state2);
		BGPart tmpBGPart;
		tmpBGPart.i = i;
		tmpBGPart.x = x;
		tmpBGPart.y = y;
		string background = hge->Ini_GetString("Resources", (partName + "_background").c_str(), "");
		if (background == "") {hge->System_Log("# Error # : missing background file in \"%s\" (part %d)...", this->actualZone.name.c_str(), i);}
		string collision = hge->Ini_GetString("Resources", (partName + "_collision").c_str(), "");
		if (collision == "") {hge->System_Log("# Warning # : missing collision file in \"%s\" (part %d)...", this->actualZone.name.c_str(), i);}
		string distortion = hge->Ini_GetString("Resources", (partName + "_distortion").c_str(), "");
		if (distortion == "") {hge->System_Log("# Warning # : missing distortion file in \"%s\" (part %d)...", this->actualZone.name.c_str(), i);}

		// Loading textures
		this->loadTexture(background);
		this->actualZone.partSize = hge->Texture_GetHeight(this->textureList[background]);
		tmpBGPart.bg = createSprite
		(
			this->textureList[background],
			0,
			0,
			this->actualZone.partSize,
			this->actualZone.partSize
		);

		if ( (collision == "0") || (collision == "none") || (collision == "") )
		{
			tmpBGPart.colData = false;
			tmpBGPart.bg_col = createSprite
			(
				this->textureList["black.png"],
				0,
				0,
				this->actualZone.partSize,
				this->actualZone.partSize
			);
		}
		else
		{
			tmpBGPart.colData = true;
			this->loadTexture(collision);
			tmpBGPart.col = hge->Texture_Lock(this->textureList[collision]);
			hge->Texture_Unlock(this->textureList[collision]);

			tmpBGPart.bg_col = createSprite
			(
				this->textureList[collision],
				0,
				0,
				this->actualZone.partSize,
				this->actualZone.partSize
			);
		}

		if ( (distortion == "0") || (distortion == "none") || (distortion == "") )
		{
			tmpBGPart.distData = false;
		}
		else
		{
			tmpBGPart.distData = true;
			this->loadTexture(distortion);
			tmpBGPart.dist = hge->Texture_Lock(this->textureList[distortion]);
			hge->Texture_Unlock(this->textureList[distortion]);
		}

		float index = y/this->actualZone.partSize*actualZone.w/this->actualZone.partSize+
			x/this->actualZone.partSize;

		this->actualZone.parts[index] = tmpBGPart;

		*finished = false;
		mSceneMgr->mLoadingBar.filling += ((filling-0.02f)/2)/part_nbr;

		if (state2 == part_nbr)
			return true;
		else
			return false;
	}
	else if (state1 == 3)
	{
		// Parsing doodads
		doodad_nbr = toInt(hge->Ini_GetFloat("Doodads", "number", 0));
		if (doodad_nbr != 0)
		{
			int i = state2;
			string d_name = hge->Ini_GetString("Doodads", string("doodad_" + toString(i)).c_str(), "");
			if (d_name == "") {hge->System_Log("# Error # : missing doodad name in \"%s\" (doodad %d)...", this->actualZone.name.c_str(), i);}
			if (this->debugParser) {hge->System_Log(" Loading doodad \"%s\"...", d_name.c_str());}
			string d_file = hge->Ini_GetString(d_name.c_str(), "file", "");
			if (d_file == "") {hge->System_Log("# Error # : missing texture file for \"%s\" (%s)...", d_name.c_str(), this->actualZone.name.c_str());}
			if (this->debugParser) {hge->System_Log("  Loading texture \"%s\"...", d_file.c_str());}
			this->loadTexture(d_file);
			float twsize = hge->Texture_GetWidth(this->textureList[d_file], true);
			float thsize = hge->Texture_GetHeight(this->textureList[d_file], true);
			hgeSprite* d_sprite = createSprite(this->textureList[d_file], 0, 0, twsize, thsize);
			float d_x = hge->Ini_GetFloat(d_name.c_str(), "x", 0);
			float d_y = hge->Ini_GetFloat(d_name.c_str(), "y", 0);
			float d_hx = hge->Ini_GetFloat(d_name.c_str(), "hx", twsize/2);
			float d_hy = hge->Ini_GetFloat(d_name.c_str(), "hy", thsize/2);
			float d_orient = hge->Ini_GetFloat(d_name.c_str(), "orientation", 0.0f);
			bool d_intop = toBool(hge->Ini_GetString(d_name.c_str(), "always_in_top", "false"));
			bool d_locked = toBool(hge->Ini_GetString(d_name.c_str(), "locked", "true"));
			d_sprite->SetHotSpot(d_hx, d_hy);
			Doodad d;
			d.name = d_name;
			d.sprite = d_sprite;
			d.setX(d_x);
			d.setY(d_y);
			d.orientation = d_orient;
			d.locked = d_locked;
			d.inTop = d_intop;
			this->actualZone.doodadList[d_name] = d;
			this->actualZone.doodadList[d_name].setBox();
		}

		if (doodad_nbr == 0)
			mSceneMgr->mLoadingBar.filling += 0.165f;
		else
			mSceneMgr->mLoadingBar.filling += 0.165f/doodad_nbr;

		*finished = false;

		if ( (doodad_nbr == 0) || (state2 == doodad_nbr) )
		{
			hge->System_Log("Parsing %s : done.", this->actualZone.name.c_str());
			//*finished = true;
			return true;
		}
		else
		{
			//*finished = false;
			return false;
		}
	}
	else if (state1 == 4)
	{
		int waypoint_nbr = toInt(hge->Ini_GetFloat("Waypoints", "number", 0));
		if (waypoint_nbr != 0)
		{
			for (int i=1; i<=waypoint_nbr; i++)
			{
				string wpNbr = "waypoint_" + toString(i);
				string wpName = hge->Ini_GetString("Waypoints", wpNbr.c_str(), "");
				if (this->debugParser) {hge->System_Log(" Loading waypoint \"%s\"...", wpName.c_str());}
				Waypoint wp;

				wp.x = hge->Ini_GetFloat(wpName.c_str(), "x", 0);
				wp.y = hge->Ini_GetFloat(wpName.c_str(), "y", 0);
				wp.size = hge->Ini_GetFloat(wpName.c_str(), "size", 0);
				wp.name = wpName;

				actualZone.wPntList[wpName] = wp;
			}
			for (int i=1; i<=waypoint_nbr; i++)
			{
				string wpNbr = "waypoint_" + toString(i);
				string wpName = hge->Ini_GetString("Waypoints", wpNbr.c_str(), "");
				Waypoint* wp = &actualZone.wPntList[wpName];

				int child_nbr = toInt(hge->Ini_GetFloat(wpName.c_str(), "child_nbr", 0));
				if (child_nbr != 0)
				{
					for (int j=1; j<=child_nbr; j++)
					{
						string childNbr = "child_" + toString(j);
						string distNbr = childNbr + "_dist";
						if (this->debugParser) {hge->System_Log("  Loading \"%s\"'s child \"%s\"...", wpName.c_str(), childNbr.c_str());}

						string childName = hge->Ini_GetString(wpName.c_str(), childNbr.c_str(), "");
						float dist = hge->Ini_GetFloat(wpName.c_str(), distNbr.c_str(), 0);

						wp->childs[dist] = &actualZone.wPntList[childName];
					}
				}
			}
		}
		*finished = true;
		return true;
	}
	else
	{
		*finished = true;
		return true;
	}

}

void SceneManager::parseFonts( string fonts_file )
{
	hge->System_Log("Parsing %s...", fonts_file.c_str());
	hge->System_SetState(HGE_INIFILE, fonts_file.c_str());
	int fontNbr = toInt(hge->Ini_GetFloat("General", "font_nbr", 1));
	for (int i=1; i<=fontNbr; i++)
	{
		string fnt_name = hge->Ini_GetString("General", string("font_" + toString(i)).c_str(), "");
		if (fnt_name == "") {hge->System_Log("# Error # : missing font name (font %d)...", i);}

		BFont tmpFont;
		tmpFont.name = fnt_name;

		float tracking = toInt(hge->Ini_GetFloat(fnt_name.c_str(), "tracking", 0));
		int subFontNbr = toInt(hge->Ini_GetFloat(fnt_name.c_str(), "sub_font_nbr", 1));
		for (int j=1; j<=subFontNbr; j++)
		{
			string sub_fnt_name = hge->Ini_GetString(fnt_name.c_str(), string("sub_font_" + toString(j)).c_str(), "");
			if (sub_fnt_name == "") {hge->System_Log("# Error # : missing sub font name for \"%s\" (sub font %d)...", fnt_name.c_str(), j);}
			int sub_fnt_size = toInt(hge->Ini_GetFloat(sub_fnt_name.c_str(), "size", -1));
			if (sub_fnt_size == -1)
			{
				hge->System_Log("# Error # : missing sub font size for \"%s\" (sub font %d)...", fnt_name.c_str(), j);
				sub_fnt_size = 16;
			}
			string sub_fnt_file = hge->Ini_GetString(sub_fnt_name.c_str(), "file", "");
			if (sub_fnt_file == "") {hge->System_Log("# Error # : missing sub font file for \"%s\"...", sub_fnt_name.c_str());}
			tmpFont.subFont[sub_fnt_size] = createFont(sub_fnt_file);
			tmpFont.subFont[sub_fnt_size]->SetTracking(tracking);
		}

		this->fontList[fnt_name] = tmpFont;
	}
	this->defaultFont = &this->fontList[hge->Ini_GetString("General", "default_font", "")];
	if (this->defaultFont == NULL) {hge->System_Log("# Error # : missing default font...");}
	//this->scrollingTextFont = this->getHGEFont(16, this->getBFont("calibri_bold_out"));

	hge->System_Log("Parsing %s : done.", fonts_file.c_str());
}

void SceneManager::parseCursors( string cursors_file )
{
	hge->System_Log("Parsing %s...", cursors_file.c_str());
	hge->System_SetState(HGE_INIFILE, cursors_file.c_str());
	int cursorNbr = toInt(hge->Ini_GetFloat("General", "cursor_nbr", 1));
	for (int i=1; i<=cursorNbr; i++)
	{
		string cur_name = hge->Ini_GetString("General", string("cursor_" + toString(i)).c_str(), "");
		if (cur_name == "") {hge->System_Log("# Error # : missing cursor name (cursor %d)...", i);}
		if (this->debugParser) {hge->System_Log(" Loading cursor \"%s\"...", cur_name.c_str());}
		string cur_file = hge->Ini_GetString(cur_name.c_str(), "file", "");
		if (cur_file == "") {hge->System_Log("# Error # : missing cursor file in cursor \"%s\"...", cur_name.c_str());}
		this->loadTexture(cur_file);
		int cur_hx = toInt(hge->Ini_GetFloat(cur_name.c_str(), "hx", 0));
		int cur_hy = toInt(hge->Ini_GetFloat(cur_name.c_str(), "hy", 0));
		Cursor tmpCur;
		tmpCur.name = cur_name;
		tmpCur.sprite = createSprite
		(
			this->textureList[cur_file],
			0,
			0,
			hge->Texture_GetWidth(this->textureList[cur_file]),
			hge->Texture_GetHeight(this->textureList[cur_file])
		);
		tmpCur.sprite->SetHotSpot(cur_hx, cur_hy);
		tmpCur.rot = 0;
		this->cursorList[cur_name] = tmpCur;
	}

	hge->System_Log("Parsing %s : done.", cursors_file.c_str());
}

void SceneManager::buildRenderList( bool debug, float updateTimer )
{
	if ( (updateTimer == 0.0f) || (mForceUpdate == true) )
	{
		this->debugRenderList = debug;
		this->zSortedList.clear();
		map<string, Doodad>::iterator iterDoodad;
		for (iterDoodad = this->actualZone.doodadList.begin(); iterDoodad != this->actualZone.doodadList.end(); iterDoodad++)
		{
			Doodad *d = &iterDoodad->second;
			if (d->getBox()->Intersect(scrRect))
			{
				float z = d->getZ();
				if (!d->inTop)
				{
					Object obj;
					obj.type = "doodad";
					obj.ptr = d;
					this->zSortedList[z] = obj;
				}
				else
				{
					this->renderInTopList[z] = d;
				}
			}
		}
	}
	mForceUpdate = false;
}

void SceneManager::forceUpdate()
{
	mForceUpdate = true;
}

HTEXTURE SceneManager::loadTexture( string file, bool mipmaps )
{
	if (textureList.find(file) != textureList.end())
    {
      	return textureList[file];
	}
	else
	{
		if (file == "") {hge->System_Log("# Error # : can't load texture : missing file name");}
		else
		{
			textureList[file] = hge->Texture_Load(file.c_str(), 0, mipmaps);
			return textureList[file];
		}
	}
}

void SceneManager::freeTextures()
{
	map<string, HTEXTURE>::iterator iterTex;
	for (iterTex = this->textureList.begin(); iterTex != this->textureList.end(); iterTex++)
	{
		hge->Texture_Free(iterTex->second);
	}
}

hgeSprite* SceneManager::createSprite( HTEXTURE tex, float x, float y, float w, float h )
{
	hgeSprite* spr = new hgeSprite(tex, x, y, w, h);
	spriteList.push_back(spr);
	return spr;
}

void SceneManager::deleteSprites()
{
	vector<hgeSprite*>::iterator iter;
	while (!spriteList.empty())
	{
		iter = spriteList.begin();
		delete *iter;
		spriteList.erase(iter);
	}
}

hgeRect* SceneManager::createRect( float x1, float y1, float x2, float y2 )
{
	hgeRect* rect = new hgeRect(x1, y1, x2, y2);
	rectList.push_back(rect);
	return rect;
}

void SceneManager::deleteRects()
{
	vector<hgeRect*>::iterator iter;
	while (!rectList.empty())
	{
		iter = rectList.begin();
		delete *iter;
		rectList.erase(iter);
	}
}

hgeFont* SceneManager::createFont( string file )
{
	hgeFont* fnt = new hgeFont(file.c_str());
	hFntList.push_back(fnt);
	return fnt;
}

void SceneManager::deleteFonts()
{
	vector<hgeFont*>::iterator iter;
	while (!hFntList.empty())
	{
		iter = hFntList.begin();
		delete *iter;
		hFntList.erase(iter);
	}
}

void SceneManager::deleteDoodads()
{
	map<string, Doodad>::iterator iterDoodad;
	for (iterDoodad = this->actualZone.doodadList.begin(); iterDoodad != this->actualZone.doodadList.end(); iterDoodad++)
	{
		iterDoodad->second.deleteSelf();
	}
	this->actualZone.doodadList.clear();
}

BFont* SceneManager::getBFont( string fntName )
{
	if (fontList.find(fntName) != fontList.end())
    {
        BFont *fnt = &fontList[fntName];
        return fnt;
    }
    else
    {
        hge->System_Log("# ERROR # : Unknown font name \"%s\"", fntName.c_str());
    }
}

hgeFont* SceneManager::getHGEFont( int size, BFont* fnt, float tracking )
{
	hgeFont* hFnt;
	if (fnt->subFont.find(size) == fnt->subFont.end())
	{
		if (fnt->subFont.size() > 1)
		{
			map<int, hgeFont*>::iterator iter1, iter2;
			iter1 = iter2 = fnt->subFont.upper_bound(size);
			if (iter2 != fnt->subFont.begin())
			{
				if (iter2 != fnt->subFont.end())
				{
					iter2--;
					if ( fabs(size-iter1->first) >= fabs(size-iter2->first) )
					{
						hFnt = iter2->second;
						float scale = static_cast<float>(size)/static_cast<float>(iter2->first);
						hFnt->SetScale(scale);
					}
					else
					{
						hFnt = iter1->second;
						float scale = static_cast<float>(size)/static_cast<float>(iter1->first);
						hFnt->SetScale(scale);
					}
				}
				else
				{
					iter2 = fnt->subFont.end();
					iter2--;
					hFnt = iter2->second;
					float scale = static_cast<float>(size)/static_cast<float>(iter2->first);
					hFnt->SetScale(scale);
				}
			}
			else
			{
				hFnt = iter1->second;
				float scale = static_cast<float>(size)/static_cast<float>(iter1->first);
				hFnt->SetScale(scale);
			}
		}
		else
		{
			map<int, hgeFont*>::iterator iter = fnt->subFont.begin();
			hFnt = iter->second;
			float scale = static_cast<float>(size)/static_cast<float>(iter->first);
			hFnt->SetScale(scale);
		}
	}
	else
	{
		hFnt = fnt->subFont[size];
		hFnt->SetScale(1.0f);
	}

	if (tracking != 1000.0f)
		hFnt->SetTracking(tracking);
	hFnt->SetColor(ARGB(255, 255, 255, 255));
	return hFnt;
}

Cursor* SceneManager::switchCursor( string nCurName )
{
	Cursor* cur;
	if (cursorList.find(nCurName) != cursorList.end())
	{
		cur = &cursorList[nCurName];
		return cur;
	}
	else
		hge->System_Log("# ERROR # : No cursor found with the name %s", nCurName.c_str());
}

Button* SceneManager::createButton( string name, /*float x, float y, */int state )
{
	HTEXTURE button_tex = mSceneMgr->loadTexture("button_" + name + ".png");
	HTEXTURE buttond_tex = mSceneMgr->loadTexture("button_" + name + "_d.png");
	HTEXTURE buttons_tex = mSceneMgr->loadTexture("button_" + name + "_s.png");
	Button b;
	b.name = name;
	b.up_spr = mSceneMgr->createSprite(button_tex,0,0,161,47);
	b.down_spr = mSceneMgr->createSprite(buttond_tex,0,0,161,47);
	b.sel_spr = mSceneMgr->createSprite(buttons_tex,0,0,161,47);
	//b.x = x;
	//b.y = y;
	b.state = state;
	b.pressed = false;
	//b.selected = false;

	this->buttonList[name] = b;
	//mSceneMgr->buttonList.push_back(wpButton);

	return &this->buttonList[name];
}

Menu* SceneManager::createMenu( Button* b )
{
	Menu m;
	m.title = b;

	this->menuList[b->name] = m;

	return &this->menuList[b->name];
}

void SceneManager::setMenu( string name )
{
	actualMenu = &this->menuList[name];
	actualMenu->title->x = 5;
	actualMenu->title->y = 120;

	float y = 120+47;
	vector<Button*>::iterator iterButton;
	for (iterButton = mSceneMgr->actualMenu->buttons.begin(); iterButton != mSceneMgr->actualMenu->buttons.end(); iterButton++)
	{
		Button* b = *iterButton;
		b->x = 25;
		b->y = y;

		y += 47;
	}
}


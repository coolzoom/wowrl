/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Point source              */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Point class.                   */
/*       A Point is a simple set of two   */
/*  float values. You can use it as a     */
/*  coordinate container.                 */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_point.h"

Point::Point() : x(0.0f), y(0.0f)
{
}

Point::Point(float nx, float ny) : x(nx), y(ny)
{
}

Point::Point(Point *p) : x(p->x), y(p->y)
{
}

Point::~Point()
{
    x = 0.0f; y = 0.0f;
}

void Point::set( float nx, float ny )
{
	x = nx;
	y = ny;
}

Point& Point::operator+= ( Point p )
{
    x += p.x; y += p.y;
}
Point& Point::operator-= ( Point p )
{
    x -= p.x; y -= p.y;
}
bool Point::operator== ( Point p )
{
    return ( (x==p.x) && (y==p.y) );
}
bool Point::operator!= ( Point p )
{
    return !( (x==p.x) && (y==p.y) );
}

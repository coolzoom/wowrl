/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Collision header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_COLLISION_H
#define WOWRL_COLLISION_H

#include "wowrl.h"

DWORD* getTextureData(HTEXTURE tex);
bool CheckPointCollision(int x, int y);
DWORD getColor(int x, int y);
Point getNearestAlignedFreePoint(float objx, float objy, float destx, float desty);
Point getNearestFreePoint(float xi, float yi, float destx, float desty, int precision = 10, int range = 512);
std::vector<Point> getDestPoints(float xi, float yi, int pointNumber, float space);

#endif

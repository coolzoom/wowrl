/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             CastBar header             */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_CASTBAR_H
#define WOWRL_CASTBAR_H

#include "wowrl.h"
#include "wowrl_structs.h"

class CastBar
{
public :

    float filling;
	std::string state;
	std::string caption;
	hgeSprite* border;
	hgeSprite* spark;
	hgeSprite* gauge_active;
	hgeSprite* gauge_error;
	hgeSprite* gauge_finish;
	hgeSprite* background;

	void initialize();

private :

	hgeFont* captionFnt;
};

#endif

#ifndef KEYHANDLER_H
#define KEYHANDLER_H

#include "memory.h"
#include "hge/hge.h"

extern HGE *hge;

class KeyHandler
{
private:
	float doubleclickTime;
	float doubleclickDelay[3];
	bool key_buf[256];
	bool key_buf_old[256];

public:
	KeyHandler()
	{
	   	memset(key_buf, 0, 256 * sizeof(bool));
	   	memset(key_buf_old, 0, 256 * sizeof(bool));
	   	doubleclickDelay[0] = 0;
	   	doubleclickDelay[1] = 0;
	   	doubleclickDelay[2] = 0;
	   	doubleclickTime = 0.6f;
	}

	bool keyIsDown(int index)
	{
	   	return key_buf[index];
	}

	bool keyIsPressed(int index)
	{
	   	return (key_buf[index] && !key_buf_old[index]);
	}

	bool keyIsReleased(int index)
	{
	   	return (!key_buf[index] && key_buf_old[index]);
	}

	bool keyIsDoubleClicked(int index)
	{
	   	switch (index)
	   	{
			case HGEK_LBUTTON: return (keyIsPressed(HGEK_LBUTTON) && doubleclickDelay[0]>0); break;
			case HGEK_RBUTTON: return (keyIsPressed(HGEK_RBUTTON) && doubleclickDelay[1]>0); break;
			case HGEK_MBUTTON: return (keyIsPressed(HGEK_MBUTTON) && doubleclickDelay[2]>0); break;
	   	}
	   	return false;
	}

	void updateKeys(float deltaTime)
	{
	    for (int i=0;i<256;i++)
		  	key_buf_old[i] = key_buf[i];

	   	// Control extreme dTime after loading/at startup etc
	   	if(deltaTime<0 || deltaTime>1)
		  	deltaTime=0.05f;

	   	doubleclickDelay[0] -= deltaTime;
	   	doubleclickDelay[1] -= deltaTime;
	   	doubleclickDelay[2] -= deltaTime;

	   	if(key_buf[HGEK_LBUTTON])
		  	doubleclickDelay[0] = doubleclickTime;
	   	if(key_buf[HGEK_RBUTTON])
		  	doubleclickDelay[1] = doubleclickTime;
	   	if(key_buf[HGEK_MBUTTON])
		  	doubleclickDelay[2] = doubleclickTime;

	   	for (int i=0;i<256;i++)
		  	key_buf[i] = hge->Input_GetKeyState(i);
	}

	void setDoubleclickTime(float setTime){
	   	doubleclickTime = setTime;
	}
};

#endif

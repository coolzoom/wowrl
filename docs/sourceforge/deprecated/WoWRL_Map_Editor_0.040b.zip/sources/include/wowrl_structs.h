/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*           Structures header            */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_STRUCTS_H
#define WOWRL_STRUCTS_H

#include "wowrl.h"

struct RGB
{
	float R;
	float G;
	float B;
};

struct FormatedString
{
	std::string type;
	float x, y;
	hgeFont* fnt;
	DWORD color;
	std::string str;
};

struct BFont
{
	std::string name;
	std::map<int, hgeFont*> subFont;
};

struct Object
{
	std::string type;
	void* ptr;
};

struct BGPart
{
	int i;
	float x, y;
	float w, h;
	std::string bg_file;
	std::string col_file;
	std::string dist_file;
	hgeSprite* bg;
	bool colData;
	hgeSprite* bg_col;
	DWORD* col;
	bool distData;
	DWORD* dist;
	DWORD globalCol;
	DWORD globalDist;
};

struct Cursor
{
	std::string name;
	bool animated;
	float rot;
	hgeSprite* sprite;
	hgeAnimation* anim;
};

struct Waypoint
{
	float       x, y;
	float       size;
	std::string name;
	std::multimap<float, Waypoint*> childs;

	// Temporary attributes used for pathfinding
	bool useless;
	bool opened;
	bool closed;
	float g;
	Waypoint* parent;
};

struct Button
{
	std::string name;
	hgeSprite* up_spr;
	hgeSprite* down_spr;
	hgeSprite* sel_spr;
	float x;
	float y;
	int state;
	bool pressed;
};

struct Menu
{
	Button* title;
	std::vector<Button*> buttons;
};

#endif

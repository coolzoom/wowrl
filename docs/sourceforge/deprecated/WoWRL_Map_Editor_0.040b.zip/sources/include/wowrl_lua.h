/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Lua header                */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_LUA_H
#define WOWRL_LUA_H

#include "wowrl.h"

void mlua_print( std::string str );
void mlua_printError( std::string error );

int mlua_getGlobalInt( std::string name, bool critical = true, int defaultValue = 0 );
float mlua_getGlobalFloat( std::string name, bool critical = true, float defaultValue = 0.0f );
std::string mlua_getGlobalString( std::string name, bool critical = true, std::string defaultValue = "" );
bool mlua_getGlobalBool( std::string name, bool critical = true, bool defaultValue = false );

int mlua_getFieldInt( std::string name, bool critical = true, int defaultValue = 0 );
float mlua_getFieldFloat( std::string name, bool critical = true, float defaultValue = 0.0f );
std::string mlua_getFieldString( std::string name, bool critical = true, std::string defaultValue = "" );
bool mlua_getFieldBool( std::string name, bool critical = true, bool defaultValue = false );

void mlua_registerAll();

/*********/
/* Glues */
/*********/

// Global functions
int l_logPrint( lua_State* luaVM );
int l_getDelta( lua_State* luaVM );

// Graphics functions
int l_Gfx_createSprite( lua_State* luaVM );
int l_Gfx_renderSprite( lua_State* luaVM );
int l_Gfx_createAnimation( lua_State* luaVM );
int l_Gfx_updateAnimation( lua_State* luaVM );
int l_Gfx_renderAnimation( lua_State* luaVM );
int l_Gfx_createPSys( lua_State* luaVM );
int l_Gfx_updatePSys( lua_State* luaVM );
int l_Gfx_renderPSys( lua_State* luaVM );

#endif

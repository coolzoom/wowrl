#include "dx9/d3dx9.h"

#include <math.h>
#include <string>
#include <map>
#include <vector>

#include "hge/hge.h"
#include "hge/hgesprite.h"
#include "hge/hgefont.h"
#include "hge/hgerect.h"
#include "hge/hgevector.h"
#include "hge/hgeanim.h"
#include "hge/hgeparticle.h"
#include "hge/hgestrings.h"
#include "keyhandler.h"

extern "C"
{
	#include "lua/lualib.h"
	#include "lua/lauxlib.h"
	#include "lua/lua.h"
}

class Doodad;
class Point;
class SceneManager;
class Zone;
class CastBar;

struct RGB;
struct FormatedString;
struct BFont;
struct Object;
struct Cursor;
struct BGPart;

/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*            Distortion header           */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_DISTORTION_H
#define WOWRL_DISTORTION_H

#include "wowrl.h"

float getPointDistortion(int x, int y);
float getPointShadow(int x, int y);
float getPointDepth(int x, int y);

#endif

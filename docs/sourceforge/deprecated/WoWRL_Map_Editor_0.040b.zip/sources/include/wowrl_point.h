/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Point header              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_POINT_H
#define WOWRL_POINT_H

#include "wowrl.h"

class Point
{
public :

    Point();
    Point(float, float);
    Point(Point*);
    ~Point();

    void set(float, float);

    Point& operator+= (Point);
    Point& operator-= (Point);
    bool operator== (Point);
    bool operator!= (Point);

    float x;
    float y;

private :

};

#endif

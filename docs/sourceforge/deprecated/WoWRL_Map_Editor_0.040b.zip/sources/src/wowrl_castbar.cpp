/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             CastBar source             */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the VastBar class.                 */
/*       A CastBar is a GUI element that  */
/*  displays the state of a unit's action */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "wowrl_scenemanager.h"

#include "wowrl_castbar.h"

extern SceneManager* mSceneMgr;

void CastBar::initialize()
{
	captionFnt = mSceneMgr->getHGEFont(13, mSceneMgr->getBFont("calibri"));
}

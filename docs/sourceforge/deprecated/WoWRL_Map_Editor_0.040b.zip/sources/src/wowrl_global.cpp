/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             Global source              */
/*                                        */
/*  ## : Contains frequently used funcs.  */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge/hgesprite.h"
#include <math.h>
#include <string>
#include <sstream>

#include "wowrl_structs.h"
#include "wowrl_point.h"

extern HGE* hge;

// Converts an integer to a string
std::string toString( float f )
{
	std::ostringstream s;
	s << f;
	return s.str();
}

// Replaces a part of a string by another
// There are two versions :
//  # the first returns the number of occurence replaced and
//  modifies the string at which the provided baseStr points at.
int strReplace( std::string* baseStr, std::string pattern, std::string replacement )
{
	size_t pos = baseStr->find(pattern);
	if (pos == std::string::npos)
		return 0;
	else
	{
		int count = 0;
		while (pos != std::string::npos)
		{
			baseStr->replace(pos, pattern.length(), replacement);
			pos = baseStr->find(pattern);
			count++;
		}
		return count;
	}
}
//  # the second returns the replaced string directly and does
//  not need you to provide a pointer.
std::string strReplace( std::string baseStr, std::string pattern, std::string replacement )
{
	size_t pos = baseStr.find(pattern);
	if (pos == std::string::npos)
		return baseStr;
	else
	{
		while (pos != std::string::npos)
		{
			baseStr.replace(pos, pattern.length(), replacement);
			pos = baseStr.find(pattern);
		}
		return baseStr;
	}
}

// Counts the number of time a string is found in another
int strCountOccurence( std::string baseStr, std::string pattern )
{
	size_t pos = baseStr.find(pattern);
	if (pos == std::string::npos)
		return 0;
	else
	{
		int count = 0;
		while (pos != std::string::npos)
		{
			count++;
			pos++;
			pos = baseStr.find(pattern, pos);
		}
		return count;
	}
}

// Replaces the printf specificators of a string by some values
std::string strPrintIn( std::string baseStr, ... )
{
	va_list args;
	va_start(args, baseStr);
	char buffer[baseStr.length()+sizeof(args)];
	vsprintf(buffer, baseStr.c_str(), args);
	va_end(args);
	return buffer;
}

// Edit a string to make its first letter CAPITAL or not
std::string strCapitalStart( std::string baseStr, bool capital )
{
	char c = baseStr.c_str()[0];
	char* str = (char*)baseStr.c_str();
	if (capital)
		str[0] = toupper(c);
	else
		str[0] = tolower(c);

	baseStr = str;
	return baseStr;
}

// Converts a rounded float to a integer
int toInt( float f )
{
    int i = static_cast<int>(round(f));
    return i;
}
// Converts a char to a integer
int toInt( char* s )
{
    int i = atoi(s);
    return i;
}
// Converts a string to a integer
int toInt( std::string s )
{
    int i = atoi(s.c_str());
    return i;
}

// Returns the sign of a value (+1 or -1)
int signOf( float f )
{
	return toInt(f/(fabs(f)));
}

// Converts a char* to a bool
bool toBool( char* c )
{
    if ( (std::string(c) == std::string("true"))
	  || (std::string(c) == std::string("1"))
	  || (std::string(c) == std::string("yes")) )
		return true;
	else
		return false;
}

// Quicker way to get square root, for lazy ones
float rac2( float f )
{
	return pow(f, 0.5);
}
// Quicker way to do x*x
float carre( float f )
{
	return pow(f, 2);
}

// Returns the distance between two points
float dist( Point p1, Point p2 )
{
	float dist;
	dist = rac2(carre(p1.x-p2.x)+carre(p1.y-p2.y));
	return dist;
}
float dist( float x1, float y1, float x2, float y2 )
{
	float dist;
	dist = rac2(carre(x1-x2)+carre(y1-y2));
	return dist;
}

// Change alpha of a sprite so it seems to glow, depending on the provided
// timerAlpha.
void setGlowing( hgeSprite* sprite, float timerAlpha, float speed )
{
	DWORD color = sprite->GetColor();
	float alpha = 105*fabs(sin(speed*timerAlpha))+100;
	sprite->SetColor(ARGB(alpha, GETR(color), GETG(color), GETB(color)));
}

// Angle conversion functions
float radToDeg( float r, bool negativeDeg )
{
	float d = r/(2*M_PI) * 360;
	if ( (!negativeDeg) && (d<0) )
		d = 360+d;
	return d;
}
float degToRad( float d )
{
	float r = d/360 * 2*M_PI;
	return r;
}

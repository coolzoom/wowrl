/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*              Doodad source             */
/*                                        */
/*  ## : Contains the member functions    */
/*  of the Doodad class.                  */
/*       A Doodad is a part of the back-  */
/*  ground that can be rendered above     */
/*  units, but it can also be rendered    */
/*  beneath units, depending on depth.    */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include <string>
#include "hge/hgevector.h"
#include "hge/hgesprite.h"
#include "wowrl_distortion.h"
#include "wowrl_global.h"
#include "wowrl_point.h"
#include "wowrl_scenemanager.h"

#include "wowrl_doodad.h"


extern HGE *hge;
extern SceneManager *mSceneMgr;

Doodad::Doodad() : z(-1.0f), locked(true)
{
	sprite = NULL;
	m_box = NULL;
}

Doodad::~Doodad()
{
}

void Doodad::setX(float x)
{
	m_x = x;
}

void Doodad::setY(float y)
{
	m_y = y;
}

float Doodad::getX()
{
	return m_x+mSceneMgr->gx;
}

float Doodad::getY()
{
	return m_y+mSceneMgr->gy;
}

float Doodad::getZ()
{
	// Check Z value only the first time or if the doodad is not locked
	if ( (z==-1.0f) || (!locked) )
	{
		z = m_y/mSceneMgr->actualZone.h;
	}
    return z;
}

void Doodad::setBox()
{
	old_x = mSceneMgr->gx;
	old_y = mSceneMgr->gy;
	if (m_box != NULL) {delete m_box;}
	m_box = new hgeRect();
	this->sprite->GetBoundingBox(this->getX(), this->getY(), m_box);
}

hgeRect* Doodad::getBox()
{
	if ( (old_x != mSceneMgr->gx) || (old_y != mSceneMgr->gy) )
	{
		m_box->Set
		(
			m_box->x1+(mSceneMgr->gx-old_x),
			m_box->y1+(mSceneMgr->gy-old_y),
			m_box->x2+(mSceneMgr->gx-old_x),
			m_box->y2+(mSceneMgr->gy-old_y)
		);
		old_x = mSceneMgr->gx;
		old_y = mSceneMgr->gy;
	}
    return m_box;
}

void Doodad::deleteSelf()
{
	if (m_box != NULL) {delete m_box;}
}

float Doodad::getRelativeDepth(Point p)
{
	float relz;
	hgeVector pvec;
	pvec.x = p.x-m_x;
	pvec.y = p.y-m_y;
	hgeVector ovec;
	ovec.x = cos(degToRad(orientation));
	ovec.y = -sin(degToRad(orientation));

	relz = pvec.Length()/mSceneMgr->actualZone.h;
	float angle = ovec.Angle()-pvec.Angle();
	angle = radToDeg(angle);
	if (angle < -180.0f)
	{
		angle = 360.0f+angle;
	}

	/* Now, angle is a float value that is ranging between -180 and 180.
	    # angle = 0 or -180 : the point is at the same depth as the doodad.
			-> 0, the unit is rendered behind (first), -180 it is rendered above (last)
	    # angle < 0 : the point is nearer than the doodad.
	    	-> the unit is rendered above (last)
		# angle > 0 : the point is more far than the doodad.
			-> the unit is rendered behind (first)
	*/

	if (angle >= 0.0f)
	{
		return -relz;
	}
	else if (angle < 0.0f)
	{
		return relz;
	}
}

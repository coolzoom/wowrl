/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               Lua source               */
/*                                        */
/*  ## : This file contains two things :  */
/*    - a lua interface for frequently    */
/*      used function combination.        */
/*    - the lua glues, to call the progs' */
/*      functions inside lua scripts.     */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "wowrl_global.h"
#include "wowrl_lua.h"
#include "wowrl_scenemanager.h"

using namespace std;

extern SceneManager* mSceneMgr;

void mlua_printError( string error )
{
	lua_Debug d;
	lua_getstack(mSceneMgr->luaVM, 1, &d);
	lua_getinfo(mSceneMgr->luaVM, "Sl" , &d);
	string debugStr = string(d.short_src) + ", line " + toString(d.currentline)
				+ string(" : ") + error;
	lua_pushstring(mSceneMgr->luaVM, debugStr.c_str());
	l_logPrint(mSceneMgr->luaVM);
}

void mlua_print( string str )
{
	lua_pushstring(mSceneMgr->luaVM, str.c_str());
	l_logPrint(mSceneMgr->luaVM);
}


int mlua_getGlobalInt( std::string name, bool critical, int defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isnumber(mSceneMgr->luaVM, -1))
	{
		hge->System_Log("4 : %d", lua_gettop(mSceneMgr->luaVM));
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		int i = (int)lua_tonumber(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return i;
	}
}

float mlua_getGlobalFloat( std::string name, bool critical, float defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isnumber(mSceneMgr->luaVM, -1))
	{
		mlua_print("Field is expected to be a number");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		float f = lua_tonumber(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return f;
	}
}

std::string mlua_getGlobalString( std::string name, bool critical, std::string defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isstring(mSceneMgr->luaVM, -1))
	{
		mlua_print("Field is expected to be a string");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		string s = lua_tostring(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return s;
	}
}

bool mlua_getGlobalBool( std::string name, bool critical, bool defaultValue )
{
	lua_getglobal(mSceneMgr->luaVM, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isboolean(mSceneMgr->luaVM, -1))
	{
		mlua_print("Field is expected to be a bool");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		bool b = lua_toboolean(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return b;
	}
}

int mlua_getFieldInt( std::string name, bool critical, int defaultValue )
{
	lua_getfield(mSceneMgr->luaVM, -1, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isnumber(mSceneMgr->luaVM, -1))
	{
		mlua_print("Field is expected to be a number");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		int i = (int)lua_tonumber(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return i;
	}
}

float mlua_getFieldFloat( std::string name, bool critical, float defaultValue )
{
	lua_getfield(mSceneMgr->luaVM, -1, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isnumber(mSceneMgr->luaVM, -1))
	{
		mlua_print("Field is expected to be a number");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		float f = lua_tonumber(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return f;
	}
}

std::string mlua_getFieldString( std::string name, bool critical, std::string defaultValue )
{
	lua_getfield(mSceneMgr->luaVM, -1, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isstring(mSceneMgr->luaVM, -1))
	{
		mlua_print("Field is expected to be a string");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		string str = lua_tostring(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return str;
	}
}

bool mlua_getFieldBool( std::string name, bool critical, bool defaultValue )
{
	lua_getfield(mSceneMgr->luaVM, -1, name.c_str());
	if (lua_isnil(mSceneMgr->luaVM, -1))
	{
		lua_pop(mSceneMgr->luaVM, 1);
		if (critical)
			mlua_print("Missing " + name + " attribute");
		else
			return defaultValue;
	}
	else if (!lua_isboolean(mSceneMgr->luaVM, -1))
	{
		mlua_print("Field is expected to be a bool");
		lua_pop(mSceneMgr->luaVM, 1);
	}
	else
	{
		bool b = lua_toboolean(mSceneMgr->luaVM, -1);
		lua_pop(mSceneMgr->luaVM, 1);
		return b;
	}
}

void mlua_registerAll()
{
	lua_register(mSceneMgr->luaVM, "logPrint", l_logPrint);
	lua_register(mSceneMgr->luaVM, "getDelta", l_getDelta);

	lua_register(mSceneMgr->luaVM, "Gfx_createSprite", l_Gfx_createSprite);
	lua_register(mSceneMgr->luaVM, "Gfx_renderSprite", l_Gfx_renderSprite);
 	lua_register(mSceneMgr->luaVM, "Gfx_createAnimation", l_Gfx_createAnimation);
 	lua_register(mSceneMgr->luaVM, "Gfx_updateAnimation", l_Gfx_updateAnimation);
 	lua_register(mSceneMgr->luaVM, "Gfx_renderAnimation", l_Gfx_renderAnimation);
}

// Glues

int l_Gfx_updateAnimation( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"Gfx_updateAnimation\" (1 expected : anim name)");
	}
	if (!lua_isstring(luaVM, 1))
		mlua_printError("Argument of Gfx_updateAnimation must be a string (anim name)");
	mSceneMgr->mlua_animList[lua_tostring(luaVM, 1)]->Update(mSceneMgr->dt);

	return 0;
}

int l_Gfx_renderAnimation( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 6)
	{
		mlua_printError("Too few arguments in \"Gfx_renderAnimation\" (6 expected : anim name, x, y, angle, horizontal scale, vertical scale)");
	}
	if (!lua_isstring(luaVM, 1))
		mlua_printError("Argument 1 of Gfx_renderAnimation must be a string (anim name)");
	if (!lua_isnumber(luaVM, 2))
		mlua_printError("Argument 2 of Gfx_renderAnimation must be a number (x)");
	if (!lua_isnumber(luaVM, 3))
		mlua_printError("Argument 3 of Gfx_renderAnimation must be a number (y)");
	if (!lua_isnumber(luaVM, 4))
		mlua_printError("Argument 4 of Gfx_renderAnimation must be a number (angle)");
	if (!lua_isnumber(luaVM, 5))
		mlua_printError("Argument 5 of Gfx_renderAnimation must be a number (horizontal scale)");
	if (!lua_isnumber(luaVM, 6))
		mlua_printError("Argument 6 of Gfx_renderAnimation must be a number (vertical scale)");
	hgeAnimation* a = mSceneMgr->mlua_animList[lua_tostring(luaVM, 1)];
	a->RenderEx
	(
		lua_tonumber(luaVM, 2),
		lua_tonumber(luaVM, 3),
		lua_tonumber(luaVM, 4),
		lua_tonumber(luaVM, 5),
		lua_tonumber(luaVM, 6)
	);

	return 0;
}

int l_Gfx_updatePSys( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 1)
	{
		mlua_printError("Too few arguments in \"Gfx_updatePSys\" (1 expected : psys name)");
	}
	if (!lua_isstring(luaVM, 1))
		mlua_printError("Argument of Gfx_updatePSys must be a string (psys name)");

	mSceneMgr->mlua_psysList[lua_tostring(luaVM, 1)]->Update(mSceneMgr->dt);

	return 0;
}

int l_Gfx_renderPSys( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 3)
	{
		mlua_printError("Too few arguments in \"Gfx_renderPSys\" (3 expected : psys name, x, y)");
	}
	if (!lua_isstring(luaVM, 1))
		mlua_printError("Argument 1 of Gfx_renderPSys must be a string (psys name)");
	if (!lua_isnumber(luaVM, 2))
		mlua_printError("Argument 2 of Gfx_renderPSys must be a number (x)");
	if (!lua_isnumber(luaVM, 3))
		mlua_printError("Argument 3 of Gfx_renderPSys must be a number (y)");

	hgeParticleSystem* psys = mSceneMgr->mlua_psysList[lua_tostring(luaVM, 1)];
	psys->MoveTo(lua_tonumber(luaVM, 2)-mSceneMgr->gx, lua_tonumber(luaVM, 3)-mSceneMgr->gy);
	psys->Transpose(mSceneMgr->gx, mSceneMgr->gy);
	psys->Render();

	return 0;
}

int l_Gfx_renderSprite( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 6)
	{
		mlua_printError("Too few arguments in \"Gfx_renderSprite\" (6 expected : sprite name, x, y, angle, horizontal scale, vertical scale)");
	}
	if (!lua_isstring(luaVM, 1))
		mlua_printError("Argument 1 of Gfx_renderSprite must be a string (sprite name)");
	if (!lua_isnumber(luaVM, 2))
		mlua_printError("Argument 2 of Gfx_renderSprite must be a number (x)");
	if (!lua_isnumber(luaVM, 3))
		mlua_printError("Argument 3 of Gfx_renderSprite must be a number (y)");
	if (!lua_isnumber(luaVM, 4))
		mlua_printError("Argument 4 of Gfx_renderSprite must be a number (angle)");
	if (!lua_isnumber(luaVM, 5))
		mlua_printError("Argument 5 of Gfx_renderSprite must be a number (horizontal scale)");
	if (!lua_isnumber(luaVM, 6))
		mlua_printError("Argument 6 of Gfx_renderSprite must be a number (vertical scale)");

	hgeSprite* spr = mSceneMgr->mlua_spriteList[lua_tostring(luaVM, 1)];
	spr->RenderEx
	(
		lua_tonumber(luaVM, 2),
		lua_tonumber(luaVM, 3),
		lua_tonumber(luaVM, 4),
		lua_tonumber(luaVM, 5),
		lua_tonumber(luaVM, 6)
	);

	return 0;
}

int l_logPrint( lua_State* luaVM )
{
	if (!lua_isstring(luaVM, -1))
			mlua_printError("Argument of logPrint must be a string (caption)");

	hge->System_Log("# LUA : %s", lua_tostring(luaVM, -1));
	return 0;
}

int l_Gfx_createSprite( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 9)
	{
		mlua_printError("Too few arguments in \"Gfx_createSprite\" (9 expected : sprite name, texture file, generate mipmaps, x offset, y offset, width, height, x hot spot, y hot spot)");
		return 0;
	}
	else
	{
		if (!lua_isstring(luaVM, 1))
			mlua_printError("Argument 1 of Gfx_createSprite must be a string (sprite name)");

		string sName = lua_tostring(luaVM, 1);
		if (mSceneMgr->mlua_spriteList.find(sName) != mSceneMgr->mlua_spriteList.end())
		{
    		mlua_printError("A sprite with the name " + sName + " already exists");
    		lua_pushstring(luaVM, sName.c_str());
    		return 1;
		}

		if (!lua_isstring(luaVM, 2))
			mlua_printError("Argument 2 of Gfx_createSprite must be a string (texture file)");
		if (!lua_isboolean(luaVM, 3))
			mlua_printError("Argument 3 of Gfx_createSprite must be a bool (generate mipmaps)");
		if (!lua_isnumber(luaVM, 4))
			mlua_printError("Argument 4 of Gfx_createSprite must be a number (x offset)");
		if (!lua_isnumber(luaVM, 5))
			mlua_printError("Argument 5 of Gfx_createSprite must be a number (y offset)");
		if (!lua_isnumber(luaVM, 8))
			mlua_printError("Argument 6 of Gfx_createSprite must be a number (x hot spot)");
		if (!lua_isnumber(luaVM, 9))
			mlua_printError("Argument 7 of Gfx_createSprite must be a number (y hot spot)");

		float w, h;
		HTEXTURE tex = mSceneMgr->loadTexture
		(
			lua_tostring(luaVM, 2),
			lua_toboolean(luaVM, 3)
		);
		if (lua_isnumber(luaVM, 6))
			w = lua_tonumber(luaVM, 6);
		else if (lua_isstring(luaVM, 6))
		{
			if (string(lua_tostring(luaVM, 6)) == "texw")
				w = hge->Texture_GetWidth(tex, true);
			else
				w = 0.0f;
		}
		else
			mlua_printError("Argument 6 of Gfx_createSprite must be a number or a string (width)");

		if (lua_isnumber(luaVM, 7))
			h = lua_tonumber(luaVM, 7);
		else if (lua_isstring(luaVM, 7))
		{
			if (string(lua_tostring(luaVM, 7)) == "texh")
				h = hge->Texture_GetHeight(tex, true);
			else
				h = 0.0f;
		}
		else
			mlua_printError("Argument 7 of Gfx_createSprite must be a number or a string (height)");

		mSceneMgr->mlua_spriteList[sName] = mSceneMgr->createSprite
		(
			tex,
			lua_tonumber(luaVM, 4),
			lua_tonumber(luaVM, 5),
			w,
			h
		);

		mSceneMgr->mlua_spriteList[sName]->SetHotSpot(lua_tonumber(luaVM, 8), lua_tonumber(luaVM, 9));

		lua_pushstring(luaVM, sName.c_str());
	}

	return 1;
}

int l_Gfx_createAnimation( lua_State* luaVM )
{
	int n = lua_gettop(luaVM);
	if (n < 11)
	{
		mlua_printError("Too few arguments in \"Gfx_createAnimation\" (11 expected : anim name, texture file, generate mipmaps, frame number, frame per second, x offset, y offset, width, height, x hot spot, y hot spot)");
		return 0;
	}
	else
	{
		if (!lua_isstring(luaVM, 1))
			mlua_printError("Argument 1 of Gfx_createAnimation must be a string (anim name)");
		string aName = lua_tostring(luaVM, 1);
		if (mSceneMgr->mlua_animList.find(aName) != mSceneMgr->mlua_animList.end())
		{
    		mlua_printError("An animation with the name " + aName + " already exists");
    		lua_pushstring(luaVM, aName.c_str());
    		return 1;
		}

		if (!lua_isstring(luaVM, 2))
			mlua_printError("Argument 2 of Gfx_createAnimation must be a string (texture file)");
		if (!lua_isboolean(luaVM, 3))
			mlua_printError("Argument 3 of Gfx_createAnimation must be a bool (generate mipmaps)");
		if (!lua_isnumber(luaVM, 4))
			mlua_printError("Argument 4 of Gfx_createAnimation must be a number (frame number)");
		if (!lua_isnumber(luaVM, 5))
			mlua_printError("Argument 5 of Gfx_createAnimation must be a number (frame per second)");
		if (!lua_isnumber(luaVM, 6))
			mlua_printError("Argument 6 of Gfx_createAnimation must be a number (x offset)");
		if (!lua_isnumber(luaVM, 7))
			mlua_printError("Argument 7 of Gfx_createAnimation must be a number (y offset)");
		if (!lua_isnumber(luaVM, 8))
			mlua_printError("Argument 8 of Gfx_createAnimation must be a number (width)");
		if (!lua_isnumber(luaVM, 9))
			mlua_printError("Argument 9 of Gfx_createAnimation must be a number (height)");
		if (!lua_isnumber(luaVM, 10))
			mlua_printError("Argument 10 of Gfx_createAnimation must be a number (x hot spot)");
		if (!lua_isnumber(luaVM, 11))
			mlua_printError("Argument 11 of Gfx_createAnimation must be a number (y hot spot)");

		HTEXTURE tex = mSceneMgr->loadTexture
		(
			lua_tostring(luaVM, 2),
			lua_toboolean(luaVM, 3)
		);
		mSceneMgr->mlua_animList[aName] = mSceneMgr->createAnimation
		(
			tex,
			(int)lua_tonumber(luaVM, 4),
			lua_tonumber(luaVM, 5),
			lua_tonumber(luaVM, 6),
			lua_tonumber(luaVM, 7),
			lua_tonumber(luaVM, 8),
			lua_tonumber(luaVM, 9)
		);

		mSceneMgr->mlua_animList[aName]->SetHotSpot(lua_tonumber(luaVM, 10), lua_tonumber(luaVM, 11));
		lua_pushstring(luaVM, aName.c_str());
	}

	return 1;
}

int l_getDelta( lua_State* luaVM )
{
	lua_pushnumber(luaVM, mSceneMgr->dt);

	return 1;
}

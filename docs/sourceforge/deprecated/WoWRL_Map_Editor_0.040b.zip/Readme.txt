	/* ###################################### */
	/* ###     WoWRL EDITOR, by Kalith    ### */
	/* ###################################### */
	/*                                        */
	/* Powered by :                           */
	/* Haaf's Game Engine 1.7                 */
	/* Copyright (C) 2003-2007, Relish Games  */
	/* hge.relishgames.com                    */
	/*                                        */
	/*                  README                */
	/*                                        */
	/******************************************/

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as
    published by the Free Software Foundation; either version 2 of
    the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program; if not, write to the Free
    Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
    Boston, MA 02110-1301 USA.


## To edit a zone :
Choose the zone you want to edit (locate its lua file) then put the entire zone
(including textures) in the Zone folder of the editor. Then, edit config.ini to
load your zone.
Note : at the moment, only waypoints are modifiable.

## Keybindings :

[C] : shows/hide collision map
[D] : shows/hide doodads
[E] : shows/hide waypoints
[S] : save changes

 # Waypoint editing :
 [W] : add a waypoint at the mouse location
 [Ctrl + right click] : delete the waypoint under the mouse
 [Shift + right click dragged] : create a randomisation zone around
                                 the waypoint under the mouse
 [Right click dragged] : create a link between a waypoint and another
 [Left click dragged] : moves the waypoint under the mouse
/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               Main source              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#include "hge.h"
#include "hgesprite.h"
#include "hgefont.h"
#include "hgerect.h"
#include <math.h>
#include <string>
#include <map>

#include "wowrl_global.h"

#include "png.h"

using namespace std;

struct Box
{
	float x1, y1;
	float x2, y2;
};

// Global variables
HGE *hge = 0;
int sWidth = 1024, sHeight = 768;
HTEXTURE pic_tex;
int space;
//int number;
float tWidth, tHeight;
DWORD* tData;
map<int, Box> boxList;
int xSize1, ySize1;
int xSize2, ySize2;
int nWidth, nHeight;
char* file;

class PNGError {};

void WarningCallback(png_structp png_ptr,
					 png_const_charp msg)
{
	hge->System_Log("LIBPNG Warning: %s", msg);
}

void ErrorCallback(png_structp png_ptr,
				   png_const_charp msg)
{
	hge->System_Log("LIBPNG Error: %s", msg);
	throw PNGError();
}

bool Write32BitPNG(FILE* fp, void* pBits, bool bNeedAlpha, int nWidth, int nHeight)
{
	png_structp png_ptr = 0;
	png_infop info_ptr = 0;
	try
	{
		//	create png structs
		png_ptr = png_create_write_struct
			(PNG_LIBPNG_VER_STRING, 0,
			ErrorCallback, WarningCallback);
		if (png_ptr == 0) return false;

		info_ptr = png_create_info_struct(png_ptr);
		if (info_ptr == 0) return false;

		//	init i/o
		png_init_io(png_ptr, fp);

		//	setup params
		if ( bNeedAlpha )
		{
			png_set_IHDR( png_ptr, info_ptr, nWidth, nHeight,
				8,
				PNG_COLOR_TYPE_RGB_ALPHA,
				PNG_INTERLACE_NONE,
				PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
		}
		else
		{
			png_set_IHDR( png_ptr, info_ptr, nWidth, nHeight,
				8,
				PNG_COLOR_TYPE_RGB,
				PNG_INTERLACE_NONE,
				PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
		}

		png_write_info(png_ptr, info_ptr);

		if ( !bNeedAlpha )
			png_set_filler(png_ptr, 0, PNG_FILLER_AFTER);	//	strip alpha

		png_set_bgr(png_ptr);	//	switch to little-endian notation

		//	writing
		unsigned char* pSrc = (unsigned char*)pBits;
		for ( int i = 0; i < nHeight; i++, pSrc+= nWidth*4 )
		{
			png_write_row( png_ptr, pSrc );
		}

		png_write_end(png_ptr, info_ptr);
	}
	catch(PNGError)
	{
		png_destroy_write_struct(&png_ptr, (info_ptr == 0) ? NULL : &info_ptr);
		return false;
	}

	//	cleanup
	png_destroy_write_struct( &png_ptr, (info_ptr == 0) ? NULL : &info_ptr);
	return true;
}


bool savePNG(HTEXTURE tex, char *filename)
{
	FILE *fp=0;
	DWORD *pTexData=0;
	int nWidth, nHeight;

	try
	{
		fp=fopen(filename,"wb");
		if(!fp) throw PNGError();
		nWidth=hge->Texture_GetWidth(tex);
		nHeight=hge->Texture_GetHeight(tex);
		pTexData=hge->Texture_Lock(tex, true);
		if(!pTexData) throw PNGError();
		if(!Write32BitPNG(fp, pTexData, true, nWidth, nHeight)) throw PNGError();
	}
	catch(PNGError)
	{
		if(fp) fclose(fp);
		if(pTexData) hge->Texture_Unlock(tex);
		remove(filename);
		return false;
	}

	fclose(fp);
	hge->Texture_Unlock(tex);
	return true;
}

bool testPoint(float x, float y)
{
	DWORD data = tData[toInt(x+y*tWidth)];
	int A = GETA(data);
	if (A == 0)
		return true;
	else
		return false;
}

void getSpace()
{
	int x, y;
	bool clearLine = false;

	int space1 = 0;
	int space2 = 0;
	for (x = 0; x < tWidth; x++)
	{
		for (y = 0; y < tHeight; y++)
		{
			if (!testPoint(x, y))
			{
				if (space1 == 0)
					space1 = x;
				clearLine = false;
				break;
			}
		}
		if ( (space1 != 0) && clearLine)
		{
			space2 = x;
			break;
		}
		clearLine = true;
	}

	float avgSpace = space2+space1;
	/*if (avgSpace < 1)
		space = 1;
	else if (avgSpace < 2)
		space = 2;
	else if (avgSpace < 4)
		space = 4;
	else if (avgSpace < 8)
		space = 8;
	else if (avgSpace < 16)
		space = 16;
	else if (avgSpace < 32)
		space = 32;
	else if (avgSpace < 64)
		space = 64;
	else if (avgSpace < 128)
		space = 128;
	else if (avgSpace < 256)
		space = 256;
	else if (avgSpace < 512)
		space = 512;
	else if (avgSpace < 1024)
		space = 1024;*/
	space = toInt(pow(2, round(log2(avgSpace))));
	hge->System_Log("space : %d", space);
}

void getBoxes()
{
	int x, y;
	xSize1 = toInt(tWidth);
	xSize2 = toInt(tWidth);
	ySize1 = toInt(tHeight);
	ySize2 = toInt(tHeight);
	int imageNbr = 0;

	for (x = 0; x < tWidth; x++)
	{
		for (y = 0; y < tHeight; y++)
		{
			if (!testPoint(x, y))
			{
				int txSize = x - imageNbr*space;
				if (txSize < xSize1)
					xSize1 = txSize;
				imageNbr++;
				x = imageNbr*space;
				break;
			}
		}
	}

	for (x = toInt(tWidth-1); x >= 0; x--)
	{
		for (y = 0; y < tHeight; y++)
		{
			if (!testPoint(x, y))
			{
				int txSize = imageNbr*space - x;
				if (txSize < xSize2)
					xSize2 = txSize;
				imageNbr--;
				x = imageNbr*space;
				break;
			}
		}
	}

	imageNbr = 0;
	for (y = 0; y < tHeight; y++)
	{
		for (x = 0; x < tWidth; x++)
		{
			if (!testPoint(x, y))
			{
				int tySize = y - imageNbr*space;
				if (tySize < ySize1)
					ySize1 = tySize;
				imageNbr++;
				y = imageNbr*space;
				break;
			}
		}
	}

	for (y = toInt(tHeight-1); y >= 0; y--)
	{
		for (x = 0; x < tWidth; x++)
		{
			if (!testPoint(x, y))
			{
				int tySize = imageNbr*space - y;
				if (tySize < ySize2)
					ySize2 = tySize;
				imageNbr--;
				y = imageNbr*space;
				break;
			}
		}
	}

	int num = 0;
	for (int j = 0; j < toInt(tHeight/space); j++)
	{
		for (int i = 0; i < toInt(tWidth/space); i++)
		{
			Box b;
			b.x1 = i*space + xSize1;
			b.y1 = j*space + ySize1;
			b.x2 = i*space + space-xSize2;
			b.y2 = j*space + space-ySize2;
			boxList[num] = b;
			num++;
			/*if (num > number)
				break;*/
		}
		/*if (num > number)
				break;*/
	}
}

void compressAndSave()
{
	Box* tempBox = &(boxList.begin()->second);
	int width = toInt(tempBox->x2 - tempBox->x1);
	int height = toInt(tempBox->y2 - tempBox->y1);
	hge->System_Log("%s : width : %d, height : %d", file, width, height);
	nWidth = toInt(tWidth/space)*(width+1);
	nHeight = toInt(tHeight/space)*(height+1);
	HTEXTURE nTex = hge->Texture_Create(nWidth, nHeight);
	map<int, Box>::iterator iter;
	int x = 0;
	int y = 0;
	int num = 0;
	DWORD *target_pixels = hge->Texture_Lock(nTex, false);
	DWORD *source_pixels = hge->Texture_Lock(pic_tex, true);
	int tW1 = hge->Texture_GetWidth(nTex);
	int tW2 = hge->Texture_GetWidth(pic_tex);

	for (iter = boxList.begin(); iter != boxList.end(); iter++)
	{
		Box* b = &(iter->second);
		int x2 = toInt(b->x1);
		int y2 = toInt(b->y1);
		for (int x1 = x; x1 <= x + width; x1++)
		{
			for (int y1 = y; y1 <= y + height; y1++)
			{
				int indexSrc = x2 + y2*tW2;
				DWORD src = source_pixels[indexSrc];
				int indexDest = x1 + y1*tW1;
				target_pixels[x1 + y1*tW1] = src;
				y2++;
			}
			x2++;
			y2 = toInt(b->y1);
		}
		x += width+1;
		num++;
		if (x >= nWidth )
		{
			x = 0;
			y += height+1;
			num = 0;
		}
	}

	hge->Texture_Unlock(pic_tex);
	hge->Texture_Unlock(nTex);

	savePNG(nTex, file);

	hge->Texture_Free(nTex);
}

// Function called by HGE once per frame.
bool FrameFunc()
{
    return true;
}

// Rendering stuff
bool RenderFunc()
{
    return false;
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    hge = hgeCreate(HGE_VERSION);
    hge->System_SetState(HGE_LOGFILE, "SpritePacker.log"); // Initialize the Log file
    hge->System_SetState(HGE_FRAMEFUNC, FrameFunc);
    hge->System_SetState(HGE_RENDERFUNC, RenderFunc);
    //hge->System_SetState(HGE_ZBUFFER, true); // Not used atm

    hge->System_SetState(HGE_TITLE, "WoWRL - Sprite Packer"); // Set the frame title

	hge->System_Log("Parsing config.ini...");
    hge->System_SetState(HGE_INIFILE, "config.ini");
    sWidth = toInt(hge->Ini_GetFloat("Display", "scr_width", 1024));
    sHeight = toInt(hge->Ini_GetFloat("Display", "scr_height", 768));
    int sDepth = toInt(hge->Ini_GetFloat("Display", "scr_depth", 32));
    //file = hge->Ini_GetString("Picture", "file", "");
    space = toInt(hge->Ini_GetFloat("Picture", "space", -1));
    //number = toInt(hge->Ini_GetFloat("Picture", "number", 1));
    hge->System_Log("Parsing config : done.");

    hge->System_SetState(HGE_FPS, 60);
    hge->System_SetState(HGE_WINDOWED, true);
    hge->System_SetState(HGE_SCREENWIDTH, sWidth);
    hge->System_SetState(HGE_SCREENHEIGHT, sHeight);
    hge->System_SetState(HGE_SCREENBPP, sDepth);
    hge->System_SetState(HGE_HIDEMOUSE, false);

    hge->System_SetState(HGE_ICON, MAKEINTRESOURCE (1));

    hge->System_SetState(HGE_USESOUND, false);

    if(hge->System_Initiate())
    {
    	hge->System_Log("space : %d", space);
    	bool spaceGiven;
    	if (space == -1)
    		spaceGiven = false;
		else
			spaceGiven = true;

    	file = hge->Resource_EnumFiles("*.png");
    	while (file != 0)
    	{
			pic_tex = hge->Texture_Load(file);
			tWidth = hge->Texture_GetWidth(pic_tex);
			tHeight = hge->Texture_GetHeight(pic_tex);

			tData = hge->Texture_Lock(pic_tex);
			hge->Texture_Unlock(pic_tex);

			if (!spaceGiven)
				getSpace();

			getBoxes();
			compressAndSave();

			hge->Texture_Free(pic_tex);

			file = hge->Resource_EnumFiles();
    	}

        // Start
        hge->System_Start();
    }
    else
    {
        MessageBox(NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_APPLMODAL);
    }

    hge->System_Shutdown();

    hge->Release();

    return 0;
}

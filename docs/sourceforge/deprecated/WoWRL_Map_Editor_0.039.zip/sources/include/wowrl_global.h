/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*             Global header              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_GLOBAL_H
#define WOWRL_GLOBAL_H

#ifndef NULL
#define NULL 0
#endif

#include "hgesprite.h"
#include <string>

#include "wowrl_structs.h"
#include "wowrl_point.h"

struct FormatedString;

std::string toString( float f );
int strReplace( std::string* baseStr, std::string pattern, std::string replacement );
std::string strReplace( std::string baseStr, std::string pattern, std::string replacement );
int strCountOccurence( std::string baseStr, std::string pattern );
std::string strPrintIn( std::string baseStr, ... );
std::string strCapitalStart( std::string baseStr, bool capital );
int toInt( float f );
int toInt( char* s );
int toInt( std::string s );
int signOf( float f );
bool toBool( char* c );
float rac2( float f );
float carre( float f );
float dist( Point p1, Point p2 );
float dist( float x1, float y1, float x2, float y2 );
void setGlowing( hgeSprite* Sprite, float timerAlpha, float speed = 2.0f );
float radToDeg( float r, bool negativeDeg = true );
float degToRad( float d );

#endif

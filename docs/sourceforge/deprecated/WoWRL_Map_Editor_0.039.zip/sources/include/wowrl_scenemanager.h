/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*          Scene manager header          */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */


#ifndef WOWRL_SCENEMANAGER_H
#define WOWRL_SCENEMANAGER_H

// Game states
#define GAME 0
#define LOADING 1

#define EDIT_IDDLE 0
#define EDIT_WAYPOINTS 1

#include "wowrl.h"
#include "wowrl_zone.h"
#include "wowrl_structs.h"
#include "wowrl_castbar.h"

class SceneManager
{
public :

	static SceneManager* getSingleton();
	void   initValues();

	// Global variables
	float 			  gx, gy, dt;
	float			  dgx, dgy;
	int				  sWidth, sHeight;
	IDirect3DDevice9* mDxDevice;
	int 			  gameState;
	hgeRect*          scrRect;

	// Zones
	bool parseZoneDyn( int, int, bool*, float );
	void deleteDoodads();
	Zone actualZone;

	// Textures
	HTEXTURE loadTexture( std::string, bool mipmaps = false );
	void     freeTextures();

	// Sprites
	hgeSprite* createSprite( HTEXTURE tex, float x, float y, float w, float h );
	void       deleteSprites();

	// Rects
	hgeRect* createRect( float x1, float y2, float x2, float y2 );
	void     deleteRects();

	// Fonts
	hgeFont* createFont( std::string );
	hgeFont* createFont( hgeFont* );
	void     deleteFonts();
	void     parseFonts(std::string);
	BFont*   getBFont(std::string);
	hgeFont* getHGEFont( int, BFont*, float tracking = 1000.0f );
	BFont* 	 defaultFont;
	hgeStringTable*	strTable;

	// Cursors
	void    parseCursors(std::string);
	Cursor* switchCursor(std::string);
	CastBar								 mLoadingBar;
	hgeSprite*							 loadingBackground;

	// Buttons
	Button* createButton( std::string, /*float, float,*/ int );

	// Menus
	Menu* createMenu( Button* );
	void setMenu( std::string );
	Menu* actualMenu;

	// GUI constants
	float castBarX, castBarY;
	float aspectRatio;

	// Z sorted object list for rendering
	void                     buildRenderList( bool, float );
	void                     forceUpdate();
	std::map<float, Object>  zSortedList;
	std::map<float, Doodad*> renderInTopList;

	// Lists
	std::map<std::string, HTEXTURE> 	  textureList;
	std::map<std::string, Cursor> 		  cursorList;
    std::map<std::string, BFont>		  fontList;
    std::vector<hgeSprite*>				  spriteList;
    std::vector<hgeRect*>				  rectList;
    std::vector<hgeFont*>				  hFntList;
    //std::map<std::string, Waypoint>       wPntList;
    //std::vector<Button>					  buttonList;
    std::map<std::string, Button>		  buttonList;
    std::map<std::string, Menu>		      menuList;

protected :

	SceneManager();

private:

	static SceneManager* mSceneMgr;

	bool debugParser;
	bool debugRenderList;
	bool mForceUpdate;

};

#endif

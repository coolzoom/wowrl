#include "d3dx9.h"

#include <math.h>
#include <string>
#include <map>
#include <vector>

#include "hge.h"
#include "hgesprite.h"
#include "hgefont.h"
#include "hgerect.h"
#include "hgevector.h"
#include "hgeanim.h"
#include "hgeparticle.h"
#include "hgestrings.h"
#include "keyhandler.h"

class Doodad;
class Point;
class SceneManager;
class Zone;
class CastBar;

struct RGB;
struct FormatedString;
struct BFont;
struct Object;
struct Cursor;
struct BGPart;

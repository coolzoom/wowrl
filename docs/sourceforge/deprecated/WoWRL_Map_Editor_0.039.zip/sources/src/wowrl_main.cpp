/* ###################################### */
/* ###   WoW Raid Leader, by Kalith   ### */
/* ###################################### */
/*               Main source              */
/*                                        */
/* Powered by :                           */
/* Haaf's Game Engine 1.6                 */
/* Copyright (C) 2003-2006, Relish Games  */
/* hge.relishgames.com                    */
/*                                        */
/*                                        */

#include "d3dx9.h"

#include "hge.h"
#include "hgesprite.h"
#include "hgefont.h"
#include "hgerect.h"
#include "hgevector.h"
#include "hgeanim.h"
#include "hgeparticle.h"
#include "hgestrings.h"
#include "keyhandler.h"

#include "wowrl_scenemanager.h"
#include "wowrl_point.h"
#include "wowrl_global.h"
#include "wowrl_collision.h"
#include "wowrl_distortion.h"
#include "wowrl_doodad.h"
#include "wowrl_structs.h"

#include <math.h>
#include <string>

using namespace std;

// Global variables
HGE *hge = 0;
SceneManager* mSceneMgr;
KeyHandler myKeyHandler;
float dt;
float dx=0.0f, dy=0.0f; // Global variations
const float speed=400; // Speed factor
float timerAlpha;
float timerUpdtateRender=0.0f;
float timerRender=0.0f;
float button_scale=0.625f;
bool ctrlPressed=false;
bool shiftPressed=false;
bool panning=false;
int loaderState=0;
bool jumpToNextState=false;

// Debug bools
bool debugZ=false;

// System
Cursor*				cursor;
bool showCollision = false;
bool showDoodads = true;
bool showWaypoints = true;
int wPntNbr = 0;
bool wpSelected = false;
Waypoint* selectedWaypoint = NULL;
Waypoint* linkingWaypoint = NULL;
Waypoint* linkedWaypoint = NULL;
bool wpLinking = false;
bool wpLinked = false;
bool waypointSizing = false;
Waypoint* waypointSized = NULL;
Button* buttonPressed = NULL;
int editorState = EDIT_IDDLE;
hgeSprite*          orderCircle; // Circle indicating selection (behind)
hgeSprite*			logo;
hgeSprite*			circle;
HTEXTURE            ordercircle_tex;
hgeFont*            debugFont;
hgeFont*            wpFont;

// Bouding boxes and stuff to prevent the background to fly out of screen
hgeRect*            bgRect = new hgeRect(); // Background Rect
hgeRect*            screenLRect; // Top Left BB
hgeRect*            screenTRect; // Top Right BB
hgeRect*            screenRRect; // Bottom Right BB
hgeRect*            screenBRect; // Bottom Left BB
bool screenLInt; // Checks intersection between BG's BB and Left BB
bool screenTInt; // Checks intersection between BG's BB and Top BB
bool screenRInt; // Checks intersection between BG's BB and Right BB
bool screenBInt; // Checks intersection between BG's BB and Bottom BB

// Bounding boxes and stuff for clicking
hgeRect*            mouseRect = new hgeRect(); // Mouse BB for click detection
hgeRect*            selectSquareRect = new hgeRect(); // Selection square's BB
bool selected=false;
bool squareSelection=false;
bool RenderSquare=false;
float squarex, squarey, squareXScale, squareYScale;
hgeVector mouseVec;

// Stuff for collision
bool destCollides=true;

// Background variables
float bgx=0, bgy=0; // BG initial pos and scale

// Bools and stuff for mouse input
bool mRButton=false;
bool mLButton=false;
bool lastRButton=false;
bool lastLButton=false;
int mRState;
int mLState;
float mSpeed=500.0f;
float mx=0, my=0; //mz=0; // Mouse pos and wheel state
float gmx=0,  gmy=0; // Global mouse pos (= mouse pos - global pos)
float dmx=0.0f, dmy=0.0f; //dmz=0.0f; // Mouse pos and wheel variation
float mx_old=0, my_old=0; // Old mouse pos, used to calculate the variation
float curx=0, cury=0; // Cursor pos

// Function called by HGE once per frame.
bool FrameFunc()
{
	if (myKeyHandler.keyIsPressed(HGEK_ESCAPE))
		return true;

	switch (mSceneMgr->gameState)
	{
/********************************/
		case GAME:
/********************************/
		{
			/* --------------------------------------------- */
			/* Get inputs and store them in global variables */
			/* --------------------------------------------- */

			dt = hge->Timer_GetDelta();
			mSceneMgr->dt = dt;

			// Get wheel state, not used atm
			//mz = hge->Input_GetMouseWheel();

			// Get mouse pos
			hge->Input_GetMousePos(&mx,&my);
			dmx = mx_old-mx;
			dmy = my_old-my;
			mx_old = mx;
			my_old = my;

			// Cursor pos
			curx=mx;
			cury=my;

			if (myKeyHandler.keyIsDown(HGEK_CTRL))
			{
				ctrlPressed = true;
			}
			else
				ctrlPressed = false;

			if (myKeyHandler.keyIsDown(HGEK_SHIFT))
			{
				shiftPressed = true;
			}
			else
				shiftPressed = false;

			// Handle left mouse button
			if (myKeyHandler.keyIsDown(HGEK_LBUTTON))
			{
				if (myKeyHandler.keyIsPressed(HGEK_LBUTTON))
					mLState = 2; // single pressed
				else if(myKeyHandler.keyIsDoubleClicked(HGEK_LBUTTON))
					mLState = 4; // double clicked
				else
					mLState = 1; // dragged
			}
			else if (myKeyHandler.keyIsReleased(HGEK_LBUTTON))
			{
				mLState = 3; // released
			}
			else
				mLState = 0; // no input

			// Handle right mouse button
			if (myKeyHandler.keyIsDown(HGEK_RBUTTON))
			{
				if (myKeyHandler.keyIsPressed(HGEK_RBUTTON))
					mRState = 2;
				else if (myKeyHandler.keyIsDoubleClicked(HGEK_RBUTTON))
					mRState = 4;
				else
					mRState = 1;
			}
			else if (myKeyHandler.keyIsReleased(HGEK_RBUTTON))
			{
				mRState = 3;
			}
			else
				mRState = 0;

			if (myKeyHandler.keyIsPressed(HGEK_C))
			{
				showCollision = !showCollision;
			}
			if (myKeyHandler.keyIsPressed(HGEK_D))
			{
				showDoodads = !showDoodads;
			}
			if (myKeyHandler.keyIsPressed(HGEK_E))
			{
				showWaypoints = !showWaypoints;
			}
			if (myKeyHandler.keyIsPressed(HGEK_W))
			{
				if (editorState == EDIT_WAYPOINTS)
				{
					Waypoint wp;
					wp.x = mx-mSceneMgr->gx;
					wp.y = my-mSceneMgr->gy;
					int i = 1;
					string wpName = "wp_" + toString(i);
					while (mSceneMgr->actualZone.wPntList.find(wpName) != mSceneMgr->actualZone.wPntList.end())
					{
						i++;
						wpName = "wp_" + toString(i);
					}
					wp.name = wpName;

					mSceneMgr->actualZone.wPntList[wp.name] = wp;
				}
			}
			if (myKeyHandler.keyIsPressed(HGEK_S))
			{
				hge->System_SetState(HGE_INIFILE, mSceneMgr->actualZone.name.c_str());
				int i = 1;

				hge->Ini_SetInt("Waypoints", "number", mSceneMgr->actualZone.wPntList.size());

				map<string, Waypoint>::iterator iterWp;
				for (iterWp = mSceneMgr->actualZone.wPntList.begin(); iterWp != mSceneMgr->actualZone.wPntList.end(); iterWp++)
				{
					string wpCnt = "waypoint_" + toString(i);
					string section = iterWp->second.name;
					hge->Ini_SetString("Waypoints", wpCnt.c_str(), section.c_str());
					hge->Ini_SetInt(section.c_str(), "x", toInt(iterWp->second.x));
					hge->Ini_SetInt(section.c_str(), "y", toInt(iterWp->second.y));
					hge->Ini_SetInt(section.c_str(), "size", toInt(iterWp->second.size));
					hge->Ini_SetInt(section.c_str(), "child_nbr", toInt(iterWp->second.childs.size()));
					map<float, Waypoint*>::iterator iterChild;
					int j = 1;
					for (iterChild = iterWp->second.childs.begin(); iterChild != iterWp->second.childs.end(); iterChild++)
					{
						string name = "child_" + toString(j);
						hge->Ini_SetString(section.c_str(), name.c_str(), iterChild->second->name.c_str());
						float distance = dist
						(
							iterWp->second.x,
							iterWp->second.y*mSceneMgr->aspectRatio,
							iterChild->second->x,
							iterChild->second->y*mSceneMgr->aspectRatio
						);
						while (iterWp->second.childs.find(distance) != iterWp->second.childs.end())
						{
							distance += 0.0001f;
						}
						while (iterWp->second.childs.find(distance) != iterWp->second.childs.end())
						{
							distance += 0.0001f;
						}
						hge->Ini_SetFloat(section.c_str(), (name + "_dist").c_str(), distance);
						j++;
					}
					i++;
				}
			}

			// If the mouse enters a 4 pixel zone around the screen, pan the view in the direction
			// given by the mouse pointer
			mouseRect->Set(curx-2,cury-2,curx+2,cury+2); // Set the mouse BB properties

			bool mouseLInt = mouseRect->Intersect(screenLRect);
			bool mouseTInt = mouseRect->Intersect(screenTRect);
			bool mouseRInt = mouseRect->Intersect(screenRRect);
			bool mouseBInt = mouseRect->Intersect(screenBRect);

			if (mouseLInt || mouseTInt || mouseRInt || mouseBInt)
			{
			    if (mouseLInt && !(mouseTInt && mouseRInt && mouseBInt))
			    {
				  	dx = mSpeed*dt;
			    }
			    if (mouseTInt && !(mouseLInt && mouseRInt && mouseBInt))
			    {
				 	dy = mSpeed*dt;
			    }
			    if (mouseRInt && !(mouseLInt && mouseTInt && mouseBInt))
			    {
				 	dx = -mSpeed*dt;
			    }
			    if (mouseBInt && !(mouseLInt && mouseTInt && mouseRInt))
			    {
				 	dy = -mSpeed*dt;
			    }
			    panning = true;
			}
			else
			{
				if (panning)
				{
					panning = false;
				}
			}

			if (mLState == 2)
			{
				buttonPressed = NULL;
				vector<Button*>::iterator iterButton;
				for (iterButton = mSceneMgr->actualMenu->buttons.begin(); iterButton != mSceneMgr->actualMenu->buttons.end(); iterButton++)
				{
					Button* b = *iterButton;
					hgeRect* buttonRect = new hgeRect();
					b->up_spr->GetBoundingBox(b->x, b->y, buttonRect);
					if (mouseRect->Intersect(buttonRect))
					{
						buttonPressed = b;
						b->pressed = true;
						delete buttonRect;
						break;
					}
					else
					{
						delete buttonRect;
					}
				}
			}

			if (mLState == 3)
			{
				if (buttonPressed != NULL)
				{
					editorState = buttonPressed->state;
					buttonPressed->pressed = false;
					//mSceneMgr->actualMenu = &mSceneMgr->menuList[buttonPressed->name];
					mSceneMgr->setMenu(buttonPressed->name);
					buttonPressed = NULL;
				}
			}

			if (mLState == 1)
			{
				if (editorState == EDIT_WAYPOINTS)
				{
					if (!wpSelected)
					{
						map<string, Waypoint>::iterator iterWp;
						for (iterWp = mSceneMgr->actualZone.wPntList.begin(); iterWp != mSceneMgr->actualZone.wPntList.end(); iterWp++)
						{
							hgeRect* wpRect = new hgeRect();
							orderCircle->GetBoundingBox(iterWp->second.x+mSceneMgr->gx, iterWp->second.y+mSceneMgr->gy, wpRect);
							if (mouseRect->Intersect(wpRect))
							{
								selectedWaypoint = &iterWp->second;
								wpSelected = true;
								delete wpRect;
								break;
							}
							else
								delete wpRect;
						}
					}
					if (wpSelected)
					{
						selectedWaypoint->x = mx-mSceneMgr->gx;
						selectedWaypoint->y = my-mSceneMgr->gy;
					}
				}
			}
			else
			{
				if (editorState == EDIT_WAYPOINTS)
				{
					wpSelected = false;
					selectedWaypoint = NULL;
				}
			}

			if ( (mRState == 1) && shiftPressed )
			{
				if (editorState == EDIT_WAYPOINTS)
				{
					if (!waypointSizing)
					{
						map<string, Waypoint>::iterator iterWp;
						for (iterWp = mSceneMgr->actualZone.wPntList.begin(); iterWp != mSceneMgr->actualZone.wPntList.end(); iterWp++)
						{
							hgeRect* wpRect = new hgeRect();
							orderCircle->GetBoundingBox(iterWp->second.x+mSceneMgr->gx, iterWp->second.y+mSceneMgr->gy, wpRect);
							if (mouseRect->Intersect(wpRect))
							{
								waypointSized = &iterWp->second;
								waypointSizing = true;
								delete wpRect;
								break;
							}
							else
								delete wpRect;
						}
					}
					if (waypointSizing)
					{
						waypointSized->size = dist(mx, my, waypointSized->x+mSceneMgr->gx, waypointSized->y+mSceneMgr->gy);
					}
				}
			}
			else
				waypointSizing = false;

			if ( (mRState == 1) && !ctrlPressed && !shiftPressed)
			{
				if (editorState == EDIT_WAYPOINTS)
				{
					if (!wpLinking)
					{
						map<string, Waypoint>::iterator iterWp;
						for (iterWp = mSceneMgr->actualZone.wPntList.begin(); iterWp != mSceneMgr->actualZone.wPntList.end(); iterWp++)
						{
							hgeRect* wpRect = new hgeRect();
							orderCircle->GetBoundingBox(iterWp->second.x+mSceneMgr->gx, iterWp->second.y+mSceneMgr->gy, wpRect);
							if (mouseRect->Intersect(wpRect))
							{
								wpLinking = true;
								linkingWaypoint = &iterWp->second;
								delete wpRect;
								break;
							}
							else
								delete wpRect;
						}
					}
					if (wpLinking)
					{
						map<string, Waypoint>::iterator iterWp;
						for (iterWp = mSceneMgr->actualZone.wPntList.begin(); iterWp != mSceneMgr->actualZone.wPntList.end(); iterWp++)
						{
							wpLinked = false;
							hgeRect* wpRect = new hgeRect();
							orderCircle->GetBoundingBox(iterWp->second.x+mSceneMgr->gx, iterWp->second.y+mSceneMgr->gy, wpRect);
							if (mouseRect->Intersect(wpRect))
							{
								linkedWaypoint = &iterWp->second;
								if (linkedWaypoint != linkingWaypoint)
								{
									wpLinked = true;
									delete wpRect;
									break;
								}
								else
								{
									linkedWaypoint = NULL;
									delete wpRect;
								}
							}
							else
								delete wpRect;
						}
					}
				}
			}
			else
			{
				if (editorState == EDIT_WAYPOINTS)
				{
					if (wpLinked)
					{
						float distance = dist
						(
							linkingWaypoint->x,
							linkingWaypoint->y*mSceneMgr->aspectRatio,
							linkedWaypoint->x,
							linkedWaypoint->y*mSceneMgr->aspectRatio
						);
						while (linkingWaypoint->childs.find(distance) != linkingWaypoint->childs.end())
						{
							distance += 0.0001f;
						}
						while (linkedWaypoint->childs.find(distance) != linkedWaypoint->childs.end())
						{
							distance += 0.0001f;
						}
						linkingWaypoint->childs[distance] = linkedWaypoint;
						linkedWaypoint->childs[distance] = linkingWaypoint;
					}
					wpLinking = false;
					wpLinked = false;
				}
			}

			if ( (mRState == 2) && ctrlPressed && !shiftPressed)
			{
				if (editorState == EDIT_WAYPOINTS)
				{
					map<string, Waypoint>::iterator iterWp;
					for (iterWp = mSceneMgr->actualZone.wPntList.begin(); iterWp != mSceneMgr->actualZone.wPntList.end(); iterWp++)
					{
						hgeRect* wpRect = new hgeRect();
						orderCircle->GetBoundingBox(iterWp->second.x+mSceneMgr->gx, iterWp->second.y+mSceneMgr->gy, wpRect);
						if (mouseRect->Intersect(wpRect))
						{
							map<float, Waypoint*>::iterator iterChild;
							for (iterChild = iterWp->second.childs.begin(); iterChild != iterWp->second.childs.end(); iterChild++)
							{
								iterChild->second->childs.erase(iterChild->first);
							}
							mSceneMgr->actualZone.wPntList.erase(iterWp);
							delete wpRect;
							break;
						}
						else
							delete wpRect;
					}
				}
			}

		/* ------------------------------------------------------- */
		/* Apply the "movement" to the global values and collision */
		/* detectors.                                              */
		/* ------------------------------------------------------- */

			// ## Global values
			mSceneMgr->gx += dx;
			mSceneMgr->gy += dy;
			mSceneMgr->dgx = dx;
			mSceneMgr->dgy = dy;
			gmx = mx-mSceneMgr->gx;
			gmy = my-mSceneMgr->gy;


			// Detect loss of intersections between screen BBs and the background
			bgRect->x1 = mSceneMgr->gx;
			bgRect->y1 = mSceneMgr->gy;
			bgRect->x2 = mSceneMgr->gx+mSceneMgr->actualZone.w;
			bgRect->y2 = mSceneMgr->gy+mSceneMgr->actualZone.h;
			screenLInt = bgRect->Intersect(screenLRect);
			screenTInt = bgRect->Intersect(screenTRect);
			screenRInt = bgRect->Intersect(screenRRect);
			screenBInt = bgRect->Intersect(screenBRect);

			// If the background goes away from a screen bounding boxes, discard the previous changes
			if (!screenLInt)
			{
				mSceneMgr->gx -= dx;
				dx = 0;
			}
			if (!screenTInt)
			{
				mSceneMgr->gy -= dy;
				dy = 0;
			}
			if (!screenRInt)
			{
				mSceneMgr->gx -= dx;
				dx = 0;
			}
			if (!screenBInt)
			{
				mSceneMgr->gy -= dy;
				dy = 0;
			}

			// Define whether the mouse was on an obstruded zone or not
			destCollides = CheckPointCollision(toInt(gmx), toInt(gmy));

		/* ---------------------------------------------------- */
		/* End loop maths                                       */
		/* ---------------------------------------------------- */

			// Global alpha glow
			timerAlpha += dt;
			if (timerAlpha > M_PI_2)
				timerAlpha = 0;

			// Reset variation
			dx = 0;
			dy = 0;

		/* ---------------------------------------------------- */
		/* Updates                                              */
		/* ---------------------------------------------------- */

			// Update keyhandler
			myKeyHandler.updateKeys(dt);

			// Update render order every 0.1 sec
			mSceneMgr->buildRenderList(debugZ, timerUpdtateRender);
			timerUpdtateRender += dt;
			if (timerUpdtateRender >= 0.05f)
			{
				timerUpdtateRender = 0.0f;

			}

			// Update the cursor animation if it has one
			/*if (cursor->animated)
				cursor->anim->Update(dt);*/

			break;
		}

/********************************/
		case LOADING:
/********************************/
		{
			static string fonts_file;
			static string cursors_file;
			static int state1 = 1;
			static int state2 = 1;

			if (loaderState == 0)
			{
				mSceneMgr->mDxDevice = hge->Gfx_GetDevice();
				mSceneMgr->initValues();

				hge->System_Log("Parsing config.ini...");
				hge->System_SetState(HGE_INIFILE, "config.ini");
				mSceneMgr->actualZone.name = hge->Ini_GetString("Files", "starting_zone", "");
				cursors_file = hge->Ini_GetString("Files", "cursors", "");
				fonts_file = hge->Ini_GetString("Files", "fonts", "");

				mSceneMgr->aspectRatio = hge->Ini_GetFloat("Game", "aspect_ratio", 1.6f);

				hge->System_Log("Parsing config : done.\n");

				mSceneMgr->parseFonts(fonts_file);
				mSceneMgr->parseCursors(cursors_file);

				jumpToNextState = true;
				mSceneMgr->mLoadingBar.filling += 0.05f;
				mSceneMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading_zone");
			}
			else if (loaderState == 1)
			{
				bool finished, state;
				state = mSceneMgr->parseZoneDyn(state1, state2, &finished, 0.9f);
				if (finished)
				{
					jumpToNextState = true;
					mSceneMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading");
					state1 = 1;
					state2 = 1;
				}
				else
				{
					if (state)
					{
						state1++;
						state2 = 1;
					}
					else
						state2++;
				}
			}
			else if (loaderState == 2)
			{
				ordercircle_tex = mSceneMgr->loadTexture("order.png", true);
				HTEXTURE logo_tex = mSceneMgr->loadTexture("logo.png");

				HTEXTURE circle_tex = mSceneMgr->loadTexture("circle.png", true);
				circle = mSceneMgr->createSprite(circle_tex,0,0,128,128);
				circle->SetHotSpot(64,64);
				circle->SetColor(ARGB(150, 0, 200, 255));

				// Create sprites
				hge->System_Log("Creating system sprites...");

				// Create the order circle
				orderCircle = mSceneMgr->createSprite(ordercircle_tex,0,0,32,32);
				orderCircle->SetColor(ARGB(255, 0, 200, 255));
				orderCircle->SetHotSpot(16,16);

				logo = mSceneMgr->createSprite(logo_tex,0,0,128,128);

				Button* m = mSceneMgr->createButton("main_menu", EDIT_IDDLE);
				Button* w = mSceneMgr->createButton("edit_waypoints", EDIT_WAYPOINTS);

				Menu* menu1 = mSceneMgr->createMenu(m);
				menu1->buttons.push_back(w);
				mSceneMgr->setMenu(m->name);

				Menu* menu2 = mSceneMgr->createMenu(w);
				menu2->buttons.push_back(m);

				wpFont = mSceneMgr->getHGEFont(16, mSceneMgr->getBFont("calibri_bold_out"));
				debugFont = mSceneMgr->createFont(wpFont);

				// Create the screen BBs
				screenLRect = mSceneMgr->createRect(0, 0, 4, mSceneMgr->sHeight);
				screenTRect = mSceneMgr->createRect(0, 0, mSceneMgr->sWidth, 4);
				screenRRect = mSceneMgr->createRect(mSceneMgr->sWidth-4, 0, mSceneMgr->sWidth, mSceneMgr->sHeight);
				screenBRect = mSceneMgr->createRect(0, mSceneMgr->sHeight-4, mSceneMgr->sWidth, mSceneMgr->sHeight);
				mSceneMgr->scrRect = mSceneMgr->createRect(0, 0, mSceneMgr->sWidth, mSceneMgr->sHeight);

				// Create the cursor
				cursor = mSceneMgr->switchCursor("normal");

				hge->System_Log("Creating system sprites : done.");

				jumpToNextState = true;
				mSceneMgr->mLoadingBar.filling += 0.05f;
			}

			else if (loaderState == 3)
			{
				hge->System_Log("Now playing !");
				mSceneMgr->gameState = GAME;
			}

			if (jumpToNextState)
			{
				jumpToNextState = false;
				loaderState++;
			}

			break;
		}
	}

    return false;
}


bool RenderFunc()
{
	switch (mSceneMgr->gameState)
	{
/********************************/
		case GAME:
/********************************/
		{
			// Begin rendering.
    		hge->Gfx_BeginScene();

			// Clear screen with black color
			hge->Gfx_Clear(0);

			// Render the background first
			hge->System_SetState(HGE_TEXTUREFILTER, false);
			std::map<float, BGPart>::iterator iterParts;
			for (iterParts = mSceneMgr->actualZone.parts.begin(); iterParts != mSceneMgr->actualZone.parts.end(); iterParts++)
			{
				BGPart* tmpPart = &iterParts->second;
				if (showCollision)
				{
					tmpPart->bg_col->Render(tmpPart->x+mSceneMgr->gx, tmpPart->y+mSceneMgr->gy);
				}
				else
				{
					tmpPart->bg->Render(tmpPart->x+mSceneMgr->gx, tmpPart->y+mSceneMgr->gy);
				}
			}
			hge->System_SetState(HGE_TEXTUREFILTER, true);

			// Render doodads
			if (showDoodads)
			{
				map<float, Object>::iterator iterObj;
				for (iterObj = mSceneMgr->zSortedList.begin(); iterObj != mSceneMgr->zSortedList.end(); iterObj++)
				{
					if (iterObj->second.type == "doodad")
					{
						Doodad* d = static_cast<Doodad*>(iterObj->second.ptr);
						d->sprite->Render(floor(d->getX()),floor(d->getY()));
					}
				}

				// Render always in top doodads
				map<float, Doodad*>::iterator iterDoodad;
				for (iterDoodad = mSceneMgr->renderInTopList.begin(); iterDoodad != mSceneMgr->renderInTopList.end(); iterDoodad++)
				{
					Doodad* d = iterDoodad->second;
					d->sprite->Render(toInt(d->getX()), toInt(d->getY()));
				}
			}

			// Render random circles
			if (showWaypoints)
			{
				map<string, Waypoint>::iterator iterWp;
				for (iterWp = mSceneMgr->actualZone.wPntList.begin(); iterWp != mSceneMgr->actualZone.wPntList.end(); iterWp++)
				{
					Waypoint wp = iterWp->second;
					circle->RenderEx(wp.x+mSceneMgr->gx, wp.y+mSceneMgr->gy, 0.0f, wp.size/64.0f, wp.size/102.4f);
				}
			}

			// Render waypoints
			if (showWaypoints)
			{
				wpFont->SetColor(ARGB(255, 0, 200, 255));
				map<string, Waypoint>::iterator iterWp;
				for (iterWp = mSceneMgr->actualZone.wPntList.begin(); iterWp != mSceneMgr->actualZone.wPntList.end(); iterWp++)
				{
					Waypoint wp = iterWp->second;
					orderCircle->Render(wp.x+mSceneMgr->gx, wp.y+mSceneMgr->gy);
					map<float, Waypoint*>::iterator iterChild;
					for (iterChild = wp.childs.begin(); iterChild != wp.childs.end(); iterChild++)
					{
						hge->Gfx_RenderLine
						(
							wp.x+mSceneMgr->gx,
							wp.y+mSceneMgr->gy,
							iterChild->second->x+mSceneMgr->gx,
							iterChild->second->y+mSceneMgr->gy,
							ARGB(80, 0, 200, 255)
						);
					}
					wpFont->printf
					(
						wp.x + 5 + mSceneMgr->gx, wp.y - 15 + mSceneMgr->gy, HGETEXT_LEFT,
						wp.name.c_str()
					);
				}
				wpFont->SetColor(ARGB(255, 255, 255, 255));
			}

			// Render the line
			if (wpLinking)
			{
				if (wpLinked)
				{
					hge->Gfx_RenderLine
					(
						linkingWaypoint->x+mSceneMgr->gx,
						linkingWaypoint->y+mSceneMgr->gy,
						linkedWaypoint->x+mSceneMgr->gx,
						linkedWaypoint->y+mSceneMgr->gy,
						ARGB(255, 0, 200, 255)
					);
				}
				else
				{
					hge->Gfx_RenderLine
					(
						linkingWaypoint->x+mSceneMgr->gx,
						linkingWaypoint->y+mSceneMgr->gy,
						mx,
						my,
						ARGB(255, 0, 200, 255)
					);
				}
			}

			logo->Render(15, 0);

			mSceneMgr->actualMenu->title->sel_spr->Render(5, 120);
			float y = 120+47;
			vector<Button*>::iterator iterButton;
			for (iterButton = mSceneMgr->actualMenu->buttons.begin(); iterButton != mSceneMgr->actualMenu->buttons.end(); iterButton++)
			{
				Button* b = *iterButton;
				if (b->pressed)
					b->down_spr->Render(25, y);
				else
					b->up_spr->Render(25, y);

				y += 47;
			}

			// Print infos
			debugFont->printf
			(
				mSceneMgr->sWidth-10, 0, HGETEXT_RIGHT,
			    "FPS : %d",
				hge->Timer_GetFPS()
			);

			// Render the cursor above all
			cursor->sprite->Render(curx, cury);

			// End rendering, update the screen
			hge->Gfx_EndScene();
			break;
		}

/********************************/
		case LOADING:
/********************************/
		{
			// Begin rendering.
    		hge->Gfx_BeginScene();

			mSceneMgr->loadingBackground->RenderStretch(0,0,mSceneMgr->sWidth,mSceneMgr->sHeight);

			mSceneMgr->loadingBackground->RenderStretch(0,0,mSceneMgr->sWidth,mSceneMgr->sHeight);

			mSceneMgr->mLoadingBar.background->Render(mSceneMgr->castBarX, mSceneMgr->castBarY);
			mSceneMgr->mLoadingBar.gauge_active->RenderEx
			(
				mSceneMgr->castBarX+2-246.0f/2.0f, mSceneMgr->castBarY,
				0.0f,
				mSceneMgr->mLoadingBar.filling*242.0f/26.0f,
				1.0f
			);
			mSceneMgr->mLoadingBar.spark->Render
			(
				mSceneMgr->castBarX+2-246.0f/2.0f+mSceneMgr->mLoadingBar.filling*242.0f,
				mSceneMgr->castBarY+1
			);

			// The font is rendered twice with a small offset to simulate a shadow
			hgeFont* captionFnt = mSceneMgr->getHGEFont(13, mSceneMgr->getBFont("calibri"));
			captionFnt->SetColor(ARGB(255,0,0,0));
			captionFnt->printf
			(
				mSceneMgr->castBarX-113, mSceneMgr->castBarY+5, HGETEXT_LEFT, "%s",
				mSceneMgr->mLoadingBar.caption.c_str()
			);
			captionFnt->SetColor(ARGB(255,255,255,255));
			captionFnt->printf
			(
				mSceneMgr->castBarX-114, mSceneMgr->castBarY+4, HGETEXT_LEFT, "%s",
				mSceneMgr->mLoadingBar.caption.c_str()
			);

			mSceneMgr->mLoadingBar.border->Render(mSceneMgr->castBarX, mSceneMgr->castBarY-2);

			hge->Gfx_EndScene();
			break;
		}
	}

    return false;
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	srand((unsigned)time(0));

    hge = hgeCreate(HGE_VERSION);
    hge->System_SetState(HGE_LOGFILE, "WoWRLEditor.log"); // Initialize the Log file
    hge->System_SetState(HGE_TITLE, "WoWRL - Map Editor"); // Set the frame title
    hge->System_SetState(HGE_FRAMEFUNC, FrameFunc);
	hge->System_SetState(HGE_RENDERFUNC, RenderFunc);

    mSceneMgr = SceneManager::getSingleton();

	hge->System_Log("Parsing display config...");
    hge->System_SetState(HGE_INIFILE, "config.ini");
    mSceneMgr->sWidth = toInt(hge->Ini_GetFloat("Display", "scr_width", 1024.0f));
    mSceneMgr->sHeight = toInt(hge->Ini_GetFloat("Display", "scr_height", 768.0f));
    int sDepth = toInt(hge->Ini_GetFloat("Display", "scr_depth", 32));
    int sMaxFPS = toInt(hge->Ini_GetFloat("Display", "max_fps", 60));
    bool windowed = toBool(hge->Ini_GetString("Display", "windowed", "false"));
    hge->System_Log("Parsing display config : done.\n");
    string language = hge->Ini_GetString("Game", "language", "en");
    string strTableFile = "locale_" + language + ".str";
    mSceneMgr->strTable = new hgeStringTable(strTableFile.c_str());

    hge->System_SetState(HGE_FPS, sMaxFPS); // Set max FPS
    hge->System_SetState(HGE_WINDOWED, windowed); // Set Windowed
    hge->System_SetState(HGE_SCREENWIDTH, toInt(mSceneMgr->sWidth)); // Set screen resolution
    hge->System_SetState(HGE_SCREENHEIGHT, toInt(mSceneMgr->sHeight));
    hge->System_SetState(HGE_SCREENBPP, sDepth); // Set screen bit per pixel value

    hge->System_SetState(HGE_ICON, MAKEINTRESOURCE (1));

    hge->System_SetState(HGE_USESOUND, false); // Disactivate sound, for the moment

    if(hge->System_Initiate())
    {
        // Create loading bar
        string loadingBar = "loading_bar.png";
        mSceneMgr->loadTexture(loadingBar);
        mSceneMgr->mLoadingBar.border = mSceneMgr->createSprite(mSceneMgr->textureList[loadingBar],1,57,250,30);
		mSceneMgr->mLoadingBar.border->SetHotSpot(125, 0);
		mSceneMgr->mLoadingBar.spark = mSceneMgr->createSprite(mSceneMgr->textureList[loadingBar],84,30,7,24);
		mSceneMgr->mLoadingBar.spark->SetHotSpot(5, 0);
		mSceneMgr->mLoadingBar.spark->SetBlendMode(BLEND_COLORMUL | BLEND_ALPHABLEND | BLEND_NOZWRITE);
		mSceneMgr->mLoadingBar.gauge_active = mSceneMgr->createSprite(mSceneMgr->textureList[loadingBar],1,29,26,26);
		mSceneMgr->mLoadingBar.gauge_error = mSceneMgr->createSprite(mSceneMgr->textureList[loadingBar],29,29,26,26);
		mSceneMgr->mLoadingBar.gauge_finish = mSceneMgr->createSprite(mSceneMgr->textureList[loadingBar],57,29,26,26);
		mSceneMgr->mLoadingBar.background = mSceneMgr->createSprite(mSceneMgr->textureList[loadingBar],1,1,246,26);
		mSceneMgr->mLoadingBar.background->SetHotSpot(123, 0);
		mSceneMgr->mLoadingBar.filling = 0.0f;

		//int fileNbr = rand()%2 + 1;
		int fileNbr = 1;

		// Load the loading background
		if (mSceneMgr->sWidth == 1024)
		{
			mSceneMgr->loadTexture("Zones/LoadingScreen/loading_screen_" + toString(fileNbr)+ "_1024.jpg");
			mSceneMgr->loadingBackground = mSceneMgr->createSprite(mSceneMgr->textureList["Zones/LoadingScreen/loading_screen_" + toString(fileNbr)+ "_1024.jpg"],0,0,1024,768);
		}
		else
		{
			mSceneMgr->loadTexture("Zones/LoadingScreen/loading_screen_" + toString(fileNbr)+ "_1280.jpg");
			mSceneMgr->loadingBackground = mSceneMgr->createSprite(mSceneMgr->textureList["Zones/LoadingScreen/loading_screen_" + toString(fileNbr)+ "_1280.jpg"],0,0,1280,1024);
		}
		mSceneMgr->mLoadingBar.caption = mSceneMgr->strTable->GetString("gui_loading");

		// Load ressources and start
		mSceneMgr->loadTexture("black.png");
    	mSceneMgr->gameState = LOADING;
		hge->System_Start();

        hge->System_Log("Game ended.");

        // End, delete sprites and rects, free the textures
		mSceneMgr->freeTextures();
		mSceneMgr->deleteSprites();
		mSceneMgr->deleteRects();
		mSceneMgr->deleteDoodads();
		//mSceneMgr->deleteFonts(); // Crashes the program if deleteSprites has been called before
		//mSceneMgr->actualZone.deleteSelf(); // Not needed anymore : deleteSprites does the job
    }
    else
    {
        MessageBox(NULL, hge->System_GetErrorMessage(), "Error", MB_OK | MB_ICONERROR | MB_APPLMODAL);
    }

    hge->System_Shutdown();

    hge->Release();

    return 0;
}
